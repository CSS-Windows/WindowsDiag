﻿# xray_net.ps1
# Created by tdimli
# March 2020
#
# Support for known issues in NET area
# contributors: 
# developers: 

# version
$NET_version = "1.0.200404.0"

# Area and Area/Component arrays
$NET = @("DhcpSrv")

#Component/Diagnostic (Check) Function arrays
$DhcpSrv = @("DhcpSrv_BootServerHostName")
$DnsSrv = @()

# For more details, please review readme file for guidance for diagnostic function developers

# begin: diagnostic functions

#region net_dhcpsrv_KB4503857
# Component: DHCP Server
#
# Checks for: The issue where a DHCP Server has Option 66 (Boot Server Host Name) defined in one or more 
# scopes but these names cannot be resolved to IP addresses
# This will cause DHCP Server repeatedly spending time to resolve these names and can prevent it from serving clients
# This simple configuration/name resolution issue can cause DHCP outages
# This command checks DHCP configuration, identifies all Option 66 instances that are configured, 
# then tries to resolve those names to IP addresses, reports any names that fails this
# 
# Parameter(s)
# $offline Boolean, Input
# $False if running on the actual computer
# $True  if not running on the actual computer, diagnostics needs to run against offline data 
# 
# Returns 
# 
# $ReturnCode_Success if diagnostic function ran successfully
# $ReturnCode_Failed  if diagnostic function failed to run successfully
# $ReturnCode_Skipped if diagnostic function chose not to run (for example if it cannot run offline)
#
# If diagnostic function identifies an issue, it should call ReportIssue and provide detailed error message (issue details and
# instructions on how to resolve, link to public KBs etc.)
function DhcpSrv_BootServerHostName
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [Boolean]
        $offline
    )

    $issueDocName = "net_dhcpsrv_KB4503857.txt"
    $issueMsg = "DHCP Server: `nFollowing Option 66 (Boot Server Host Name) values are configured but cannot be resolved via DNS. This can cause DHCP outages!`n"

    if($offline) {
        return $ReturnCode_Skipped
    }

    $outfile = MakeFileName "dhcpexport" "xml"

    try{
        Export-DhcpServer -File $outfile -Force -ErrorVariable DhcpError
    }
    catch {
        # export failed, not running on DHCP server?
        LogToFile "Error: Export failed - exiting! (Error: $_)"
        return $ReturnCode_Failed
    }

    [xml]$Dhcp = Get-Content $outfile

    $FailedNames = ""

    # Check Server Options for unresolvable Option 66 Boot Server Host Name
    $Dhcp.DHCPServer.IPv4.OptionValues.OptionValue | ForEach-Object -Process {
        if ($_.OptionId -eq 66) {
            $Option66 = $_.Value
            if (!(ResolveDnsName $Option66)) {
                # failed, add error to return msg
                $FailedNames += "$Option66 (IPv4->Server Options)`n"
            }
        }
    }

    # Check Server-level Policy Options for unresolvable Option 66 Boot Server Host Name
    $Dhcp.DHCPServer.IPv4.Policies.Policy | ForEach-Object -Process {
        $PolicyName = $_.Name
        $_.OptionValues.OptionValue | ForEach-Object -Process {
            if ($_.OptionId -eq 66) {
                $Option66 = $_.Value
                if (!(ResolveDnsName $Option66)) {
                    # failed, add error to return msg
                    $FailedNames += "$Option66 (IPv4->Policies->$PolicyName)`n"
                }
            }
        }
    }

    # Check Scopes for unresolvable Option 66 Boot Server Host Name
    $Dhcp.DHCPServer.IPv4.Scopes.Scope | ForEach-Object -Process {
        $ScopeId = $_.ScopeId

        # Scope options
        $_.OptionValues.OptionValue | ForEach-Object -Process {
            if ($_.OptionId -eq 66) {
                $Option66 = $_.Value
                if (!(ResolveDnsName $Option66)) {
                    # failed, add error to return msg
                    $FailedNames += "$Option66 (IPv4->Scope[$ScopeId])`n"
                }
            }
        }

        # Scope Policy Options
        $_.Policies.Policy | ForEach-Object -Process {
            $PolicyName = $_.Name
            $_.OptionValues.OptionValue | ForEach-Object -Process {
                if ($_.OptionId -eq 66) {
                    $Option66 = $_.Value
                    if (!(ResolveDnsName $Option66)) {
                        # failed, add error to return msg
                        $FailedNames += "$Option66 (IPv4->Scope[$ScopeId]->Policies->$PolicyName)`n"
                    }
                }
            }
        }
    }

    if ($FailedNames){
        $issueMsg += $FailedNames
        ReportIssue $issueMsg $issueDocName
    }

    return $ReturnCode_Success
}

# Returns $false if name cannot be resolved
function ResolveDnsName
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [String]
        $DnsName
    )

    $result = Resolve-DnsName -Name $DnsName -Type A -ErrorVariable DnsError -ErrorAction SilentlyContinue

    if($DnsError -or ($result.Count -eq 0)){
        return $false
    }
    foreach($rec in $result) {
        if ($rec.IP4Address) {
            return $true
        }
    }
    return $false
}
#endregion net_dhcpsrv_KB4503857

# end: check functions