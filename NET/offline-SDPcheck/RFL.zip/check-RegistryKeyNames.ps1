<# last edit by: waltere 2018-04-05
   File Name: check-RegistryKeyNames.ps1 [full-path-to-expanded-SDP-report]
   Objective: 	1. check for accidently blanks/spaces in reg export files of SDP report
   		2. Compare SDP reg settings with given list of important reg.keys with default values
   call script with -Verbose or -Debug for add. console output
   Note: If you want to use the Explorer plug in, doubleclick the Registry file \\localhost\ToolsShare\rfl\Rfl-Check_ShellExtension.reg

VERSION and AUTHORs:
        Ver 1.04 - 27.02.2015
        Ioan Corcodel  	- ioanc@microsoft.com
	Walter Eder	- waltere@microsoft.com

HISTORY
	2015-02-02	V1.00 adjusted RegEx matching, excluded _reg*.HIV files, introduced $exceptionRegNameList
	2015-02-02	V1.01 summary output of findings
	2015-02-08	V1.02 added function Compare-RegName-Value-vs-DefaultValue
	2015-02-10	V1.03 added more output found in reg file, tables for Reg entries
	2015-03-13	V1.05 corrected function Compare-RegName-Value-vs-DefaultValue (all previous checks were done only for last reg_file in SDP folder
	2015-08-26	V1.06 check in stdout.log if Registry outputs are enabled. -> "ERROR: Registry editing has been disabled by your administrator."
	2015-10-08	v1.07 triple performance of function Compare-RegName-Value-vs-DefaultValue
				+ write to file
	2015-10-09	v1.08 again, double performance of function Compare-RegName-Value-vs-DefaultValue
	2015-10-10	v1.09 - run script with NodeNames of Cluster report, again, double performance
			- corrected false positive FileNotFoundCacheLifeTimeInSec\ FileNotFoundCacheLifetime\ (-> use trailing Space in Reg_Reference)
	2015-10-13	v1.10 - corrected possible false positive for Reg.keys with same name in diff. HKLM-path, i.e. EnableSecuritySignature
			- now including "*_reg_Print*.txt" in investigation
	2015-10-14	v1.11 - including UNC hardening settings
	2015-10-20	- excluding big *_reg_print* again
	2015-11-19	v1.12 Win10/2016TH2 addition
	2015-11-26	check if '*stdout*.log' exists in function CheckRegistryEditingDisabledSDP
	2015-03-24	Finding: Leading "_" seems to be a false positive! - let's correct in script
	2016-01-18	v1.13 DCR from TomAu: false positive in regkeys ending with trailing backslash '\' '+' '-' '#'; add '_' '/' characters to Leading
	2016-02-10	v1.14 using FQDN emeacssdfs.europe.corp.microsoft.com
	2016-02-20	v1.15 ErrMsg to ErrMsgRG
	2016-02-17	v1.16 DCR EriqS done: addition to compare RegArrays of Cluster Nodes
	2016-03-14	v1.17 appending Cluster Nodes differences to R-E-G output files.
			- don't open Notepad window, if Cluster report for additional nodes is the same
	2016-03-23	      check:	 if ($CurrArr)
	2016-04-17	v1.18 replace check for stdout.log with results.xml;
	2016-05-01	v1.19 $UsingCulture="en-US"
	2016-07-27	v1.20 using your favorite editor (FavEditor instead of notepad) to open result file
	2016-08-03  	adding 2016RS1
	2017-04-01	adding 2016RS2
	2017-10-06  	v1.21 adding 2016RS3
	2018-04-05  	adding 2016RS4

	ToDo: 	/known issue:
		- combine issues found in PS output (trailing space, only show once in SUMMARY
			RegName                              REG_type     RegValue   HKEY
			ex: P:\Sample_SDPs\2012R2\2012R2_clu-7node_CTSHyperV
		  perhaps: do a Cluster summary output)
		- adjustment for localized language SDP reports (like Russian with cyrillic characters in Registry)
		- integrate script functionality into SDP / UDE rules

#>

<#
.SYNOPSIS
The script reads SDP report and checks for accidently Registry key names containing a leading or trailing Space character.
The script compares all the listed registry settings against default values

SYNTAX: .\check-RegistryKeyNames.ps1 [full-path-to-expanded-SDP-report]

.DESCRIPTION
Step#1: The script reads in all *_reg_*.txt files from SDP report and checks for accidently Registry key names containing a leading or trailing Space character.
You can configure to omit some known fals positive RegNames in the scripts paramter $exceptionRegNameList, see customization section.
Step#2: The script compares all the registry settings against default values (only given RegNames in ref__RegistryReference.csv are compared)

If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

.EXAMPLE
Example 1
do the reg check on UNC path
\\localhost\ToolsShare\rfl\check-RegistryKeyNames.ps1 \\ioanc00\temp\New_RFL\SDPs\FileServer

Example 2
do the reg check on local disk path
\\localhost\ToolsShare\rfl\check-RegistryKeyNames.ps1 C:\SRdata\SDPs\FileServer

.LINK
\\localhost\ToolsShare\rfl\check-RegistryKeyNames.ps1
ioanc@microsoft.com ; waltere@microsoft.com ;

#>

Param(
	[ValidateScript({Test-Path $_ -PathType 'Container'})]
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Choose a writable SDP folder location, i.e. C:\SR\SDP-report\ ')]
	[string]$SDPPath
	)

Process
{
############################################################
## customization section of script
$RFLpath  = "\\localhost\ToolsShare\rfl\RflLists\"
#$RegReferenceCsvFile = $RFLpath + 'ref__Registry_Reference_test.csv'
$RegReferenceCsvFile = $RFLpath + 'ref__RegistryReference.csv'
[string[]]$exceptionRegNameList = "Cardinality",".*http.*" # Whitelist note: "Cardinality " has FalsePositive trailing Space
############################################################
$OpenSummary=1		# with Notepad/FavEditor
$DbgOut=0		# used for verbose debug output
$Stats=0
$OutFileChars=300		# max line lenght in outfile
#$StatsServerPath="\\netpod.europe.corp.microsoft.com\upload\RFL\"
$StatsServerPath="\\waltere-vdi.europe.corp.microsoft.com\netpod\tools\RFL\"
$VerMa="1"
$VerMi="21"
$UsingCulture="en-US"	# for Select-String
#$UsingCulture="tr-TR"	# for Select-String # "tr-TR"
$ActualCulture = Get-Culture
Write-verbose "Note: UsingCulture = $UsingCulture - your Culture setting: $ActualCulture "
$start = Get-Date
$CheckDate = (Get-Date -UFormat "%Y-%m-%d_%R-%S").Replace(":","-")
#$Date = date
  #for ( $i = 0; $i -ne $date.GetDateTimeFormats().Count; $i++ ) {"Index $($i) Format: $($date.GetDateTimeFormats()[$i])" }
#$CheckDate = ($Date.GetDateTimeFormats()[41]).Replace(":","-")
$CountInvFil = $StatsServerPath +'countReg.dat'
$CountInvFil2 = $CountInvFil +'.us'
$newline_Seperator  = "
==========================================================="
#Set-Variable -Name ErrorMsgRG -value "" -Scope Script #$ErrorMsgRG = ""
Set-Variable -Name ErrorMsgRG -Scope Script -Force
Set-Variable -Name ComputerName -value "" -Scope Script
$RegReferenceCsvFileReleaseDate = ((get-item $RegReferenceCsvFile)[-1]).LastWriteTime

If ($PSBoundParameters[�Debug�]) { $DebugPreference='Continue'}
If ($Stats) {
  ($j=[int32](Get-Content $CountInvFil -ErrorAction SilentlyContinue)) |Out-Null
  (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
  }

########################################################### 2016-04-18
## avoid tr-TR issue with Turkish character 'i /I' in Select-String -Pattern calls
Function Using-Culture (
[System.Globalization.CultureInfo]$culture = (throw �USAGE: Using-Culture -Culture culture -Script {scriptblock}�),
[ScriptBlock]$script= (throw �USAGE: Using-Culture -Culture culture -Script {scriptblock}�))
{
    $OldCulture = [System.Threading.Thread]::CurrentThread.CurrentCulture
    trap
    {
        [System.Threading.Thread]::CurrentThread.CurrentCulture = $OldCulture
    }
    [System.Threading.Thread]::CurrentThread.CurrentCulture = $culture
    Invoke-Command $script
    [System.Threading.Thread]::CurrentThread.CurrentCulture = $OldCulture
}

Function Open-WithFavEditor ()
{  #check if User preference is OpenWithFavEditor=1
  New-PSDrive -Name HKCU -PSProvider Registry -Root HKEY_CURRENT_USER #|out-null
  $registryPathHKCU = "HKCU:\Software\RFLcheck\shellExtension"
  $OpenWithFavEditor = (Get-ItemProperty -Path $registryPathHKCU -Name OpenWithFavEditor).OpenWithFavEditor
}

### Trail SDPPath with '\' and allow path with space character
if ($SDPPath.EndsWith("\")){$SDPPath="$SDPPath"}
else {$SDPPath="$SDPPath" +"\"}
If (-NOT (Test-Path $SDPPath -PathType 'Container')){Throw "$($SDPPath) is not a valid folder"}


###########################################################
### Step#1: function Get-OS-from-MSinfo32* files
# Return: $OSVersion
function Get-OS-from-MSinfo32 ($SDPPath,$NodeName)
{
	write-debug "__enter Get-OS-from-MSinfo32($SDPPath,$NodeName)"
	### Validate user input of expanded SDP report and identify the number of msinfo32.txt files and the names of the computers $NodeNames (in Cluster Report)
	$msinfo32 = $SDPPath + $NodeName + '*msinfo*.txt' # Try .txt
	If (-NOT (Test-Path $msinfo32)) {
	 Write-Verbose "** $SDPPath without *msinfo32.txt"
	 $msinfo32 = $SDPPath + $NodeName + '*msinfo*.nfo' # Try .nfo
	 }
	  ### Get OS version from SDP report from msinfo.txt
	  If ("$msinfo32" -match ".txt"){
	    Write-Debug "...$NodeName Using msinfo32.txt = $msinfo32 "
	    #Read-in content from Msinfo file
	    if ($msinfo32file = get-childitem $msinfo32) {
	         Write-Debug "msinfo32file: $msinfo32file "
		 $SDPdate = $msinfo32file.LastWriteTime
		 Write-Host "`n$NodeName : SDP Date: $SDPdate"
		 $msinfo32 = Get-Content $msinfo32 -TotalCount 7
		 If ($msinfo32) {$OSbuild = $msinfo32[-1]
		 		$OSName = $msinfo32[-2];$OSName=$OSName.Split(" ",3)[2]
		 		$ComputerName = $msinfo32[1].Split("")[-1] }
      		 Else {$ErrorMsgRG += "No-Valid-MsI32txt "}
		 }
	  }
	  Else { # Get OS version from SDP report from msinfo.nfo  / seems not to work for some localized OS
	    Write-Debug "...$NodeName Using msinfo32.nfo = $msinfo32 "
	    if ($msinfo32file = get-childitem $msinfo32) {
		$SDPdate = $msinfo32file.LastWriteTime
		Write-Host "`n$NodeName : SDP Date: $SDPdate"
		[xml]$nfo = Get-Content $msinfo32file
		$summary = $nfo.MSInfo.Category.Data.value
		If ($summary.'#cdata-section') {$OSbuild = $summary.'#cdata-section'[1]
		      				$OSName = $summary.'#cdata-section'[0]
		      				$computername = $summary.'#cdata-section'[4] }
      		Else {$ErrorMsgRG += "No-Valid-MsI32nfo "}
		}
	  } #end Else
	### match Build number in SDP report with OS short name
	$RegistryArray.ComputerName = $ComputerName
	$RegistryArray.SDPdate = $SDPdate
	$RegistryArray.OSversion = $OSversion
	if("$OSbuild" �match "2600"){$RegistryArray.OSVersion_old="old-XP"}   # or Windows XP
	if("$OSbuild" �match "3790"){$RegistryArray.OSVersion_old="old-2003"}   # or Windows 2003
	if("$OSbuild" �match "6001"){$RegistryArray.OSVersion_old="old-2008-SP1"}   # or Windows Vista SP1
	if(("$OSbuild" -match "6002") -or ("$OSbuild" -match "6003") ){$RegistryArray.OSVersion="2008"}   # or Windows Vista SP2
	if("$OSbuild" �match "7600"){$RegistryArray.OSVersion_old="old-2008R2-RTM"} # or Windows 7 RTM
	if("$OSbuild" �match "7601"){$RegistryArray.OSVersion="2008R2"} # or Windows 7
	if("$OSbuild" �match "9200"){$RegistryArray.OSVersion="2012"}   # or Windows 8
	if("$OSbuild" �match "9600"){$RegistryArray.OSVersion="2012R2"} # or Windows 8.1
	if("$OSbuild" �match "10.0.10240"){$RegistryArray.OSVersion="2016"} 	# or Windows 10
	if("$OSbuild" �match "10.0.10586"){$RegistryArray.OSVersion="2016TH2"} 	# or Windows 10 TH2
	if("$OSbuild" �match "10.0.14393"){$RegistryArray.OSVersion="2016RS1"} 	# or Windows 10 RS1
	if("$OSbuild" -match "10.0.15063"){$RegistryArray.OSVersion="2016RS2"} 	# or Windows 10 RS2
	if("$OSbuild" -match "10.0.16299"){$RegistryArray.OSVersion="2016RS3"} 	# or Windows 10 RS3	
	if("$OSbuild" -match "10.0.17134"){$RegistryArray.OSVersion="2016RS4"} 	# or Windows 10 RS4
	if("$OSbuild" -match "10.0.17763"){$RegistryArray.OSVersion="2016RS5"} 	# or Windows 10 1809 RS5 October 2018 Update
	if("$OSbuild" -match "10.0.18309"){$RegistryArray.OSVersion="201619H1"} # or Windows 10 1903 19H1 March 2019 Update 
	Write-host " SDP Date: $($RegistryArray.SDPdate) / OS-Version: $($RegistryArray.OSVersion) $($RegistryArray.OSVersion_old)"
	Write-host " SDP computer name: $ComputerName $OSbuild $OSName"
	# "$RegistryArray.OSVersion $RegistryArray.ComputerName"
} # end function Get-OS-from-MSinfo32


##########################################################
### Step#2: function CheckRegistryEditingDisabledSDP
# Return: xxx if line is present: ERROR: Registry editing has been disabled by your administrator.
function CheckRegistryEditingDisabledSDP ($SDPPath,$Nodename)
{
   $SDPoutFile = $SDPPath + '*stdout*.log'
   If (Test-Path $SDPoutFile) {
	$SDPoutFileContent = Get-Content $SDPoutFile
	$RegEdDisabled = Using-Culture $UsingCulture {$SDPoutFileContent | Select-String "Registry editing has been disabled"} #-quiet -ErrorAction SilentlyContinue
	#$RegEdDisabled = $SDPoutFileContent | Select-String "Registry editing has been disabled" #-quiet -ErrorAction SilentlyContinue
	Write-verbose "**SDPoutFile: $SDPoutFile - RegEdDisabled: $RegEdDisabled"
	Write-debug "**SDPoutFile: $SDPoutFile - RegEdDisabled: $RegEdDisabled"
	if ($RegEdDisabled)
  	  {
	   $ErrorMsgRG += "Reg-Edit_disabled "
	   $RegistryArray.WARNmsg = "***WARNING for this customer SDP report: Registry editing has been disabled at SDP runtime! see stdout*.log`n"
	   Write-Host -BackgroundColor Blue -ForegroundColor Red -NoNewline -Object $RegistryArray.WARNmsg -Separator .
	  }
   }
   else {Write-Host "[Informational]: $SDPoutFile does not exist in this report."}
} # end function CheckRegistryEditingDisabledSDP

###########################################################
### Step#3: execute-Reg-Check-Blank: function to check for Registry key names containing incorrect 'leading or trailing Space' characters
# Return:
function execute-Reg-Check-Blank ($SDPPath,$Nodename)
{
write-debug "__enter execute-Reg-Check-Blank ($SDPPath,$Nodename)"
Write-Host "...Checking Registry files for incorrect RegKey names with leading or trailing Space character - Please wait ... "
## read files with $Nodename*_reg_* in their names
#$regfiles = dir $SDPPath|?{$_.name -match "_reg_*.txt"} # changed from "_reg_" to "_reg*.txt"
$RegistryArray.regFiles = Get-Item -path ($SDPPath + $NodeName + "*_reg*") -Exclude "*.hiv","*_reg_Print*" #Why _print? These are pretty big!
$startReg = Get-Date

## don't scan reg entries with known false positives
#$exceptionRegStrings = $exceptionRegNameList  �join "|"
$exceptionRegStrings = (($exceptionRegNameList  |foreach {[regex]::escape($_)}) -join "|")
Write-Debug "Exception List: '$exceptionRegNameList' - Match_string: '$exceptionRegStrings'"

foreach ($Reg_file in $RegistryArray.regFiles){
      Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "." -Separator .
      $HkeyPathTable=@()
      $content = Get-Content($Reg_file.pspath)
      ## Build Table of RegKeyPath with list of RegKeyNames
      #  $HkeyPath example: HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\services\Dhcp
      #  $HkeyPathTable row example: HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\services\Dhcp\    Group    REG_SZ    TDI
      foreach ($line in $content)
      {
            if ($line -match "^HKEY"){
              $HkeyPath = $line #.Replace('\','\\') #.Replace('\','-')
            }
            else { # accumulate RegNames
#             	if ($line -match "[0-9a-zA-Z_\)\}\*\/\$\%\?\.\:]") {
             	if ($line -match "^    ") {
                	$line = $HkeyPath + "\" + $line
#               	$line = $HkeyPath + "\\" + $line
               $HkeyPathTable += $line
                }
            }
      }
# Note: no perf gain here
#	Write-verbose "HkeyPathTable Before: $($HkeyPathTable.count)"
#	$HkeyPathTable= $HkeyPathTable | Sort-Object | Get-Unique #v1.07 - 2015-10-08
#	Write-verbose "HkeyPathTable After : $($HkeyPathTable.count)"
  #    $RegistryArray.RegNamesArray = $HkeyPathTable #foreach ($line in $HkeyPathTable { $_ -NotMatch "\[HK" }
      $RegistryArray.RegNamesArray = $HkeyPathTable | Sort-Object | Get-Unique #foreach ($line in $HkeyPathTable { $_ -NotMatch "\[HK" }
      # Build complete list of all registry names
      $RegistryArray.AllRegNamesArray += $RegistryArray.RegNamesArray	# used later in function Compare-RegName-Value-vs-DefaultValue
      $RegistryArray.AllRegNamesArray = $RegistryArray.AllRegNamesArray | sort -unique # 14.10.2015
      #Write-debug "_ Table: $($HkeyPathTable)"
      Write-debug "__[execute-Reg-Check-Blank] done filling RegNamesArray:`n$($RegistryArray.RegNamesArray)"
      ## Check for leading or trailing Space characters
      foreach ($entry in $HkeyPathTable){
        #?# [string]$entry = $entry
     	# if (($entry -match "(REG_DWORD)") -or ($entry -match "(REG_SZ)") -or ($entry -match "(REG_MULTI_SZ)")) {
      	if (($entry -match "(REG_)") -and ($entry -Notmatch $exceptionRegStrings)) {
  #         if ($entry -notmatch "[0-9a-zA-Z_\)\}\*\/\$\%\?\.\:](\s){4,4}REG_")		# trailing space at the end of the KeyName
            if ($entry -notmatch "[0-9a-zA-Z_\(\)\{\}\*\/\$\%\?\.\:\+\-\#\\](\s){4,4}REG_")		# trailing space at the end of the KeyName #2016-01-18
              {	Write-Host -BackgroundColor Red -ForegroundColor Cyan -NoNewline -Object "." -Separator .
                #Add_RegNameEntryToArray $RegistryArray.TrailingIncorrectArray $entry 	 #call function
		#$pattern = "(?<HKEY>^HKEY_.*)(\s){4,}(?<RegName>\w.*(\s){4,})\s*(?<REG_type>REG_.*)(\s){4,4}(?<RegValue>.*)" ## 4 spaces or more before or after RegName !
		$pattern = Using-Culture $UsingCulture {"(?<HKEY>^HKEY_.*)(\s){4,}(?<RegName>\w.*(\s){4,})\s*(?<REG_type>REG_.*)(\s){4,4}(?<RegValue>.*)"} ## 4 spaces or more before or after RegName !
		Write-debug "Trail pattern: $pattern"
		if ($entry -match $pattern)
		  {
		  $SDPentry = New-Object PSObject -Property @{
		  	   HKEY 	= ($Matches.HKEY).Replace("HKEY_LOCAL_MACHINE","HKLM")
		  	   RegName 	= ($Matches.RegName).Replace("    ","~")
		  	   REG_type 	= $Matches.REG_type
		  	   RegValue 	= $Matches.RegValue
		  	   }
		  Write-Verbose "... adding SDP_RegKey:  $($SDPentry.RegName) to Trailing-List"
		  $RegistryArray.TrailingIncorrectArray += $SDPentry
		  }

               	Write-Verbose "reg-File: $($Reg_file.name)"
               	Write-Debug "Trailing_Space: $entry "
               	## make note of filename to output
               	$RegistryArray.TrailingIncorrectFileArray += $Reg_file
              }
  #         if ($entry -notmatch "\\(\s){4,4}[/(a-zA-Z0-9/{/*/./@/#/$/%/?/./:/\\]")	# leading space at the start of the KeyName
            if ($entry -notmatch "\\(\s){4,4}[/(a-zA-Z0-9_/{/*/./@/#/$/%/?/./:///\\]")	# leading space at the start of the KeyName #2016-01-18
              {	Write-Host -BackgroundColor DarkRed -ForegroundColor Cyan -NoNewline -Object "." -Separator .
		#$pattern = "(?<HKEY>^HKEY_.*)(\s){4,}(?<RegName>\w.*(\s){4,})\s*(?<REG_type>REG_.*)(\s){4,4}(?<RegValue>.*)" ## 4 spaces or more before or after RegName !
		$pattern = Using-Culture $UsingCulture {"(?<HKEY>^HKEY_.*)(\s){4,}(?<RegName>\w.*(\s){4,})\s*(?<REG_type>REG_.*)(\s){4,4}(?<RegValue>.*)"} ## 4 spaces or more before or after RegName !
		Write-debug "Lead pattern: $pattern"
		if ($entry -match $pattern)
		  {
		  $SDPentry = New-Object PSObject -Property @{
		  	   HKEY 	= ($Matches.HKEY).Replace("HKEY_LOCAL_MACHINE","HKLM")
		  	   RegName 	= ($Matches.RegName).Replace("    "," ")
		  	   REG_type 	= $Matches.REG_type
		  	   RegValue 	= $Matches.RegValue
		  	   }
		  Write-Verbose "... adding SDP_RegKey:  $($SDPentry.RegName) to Leading-List"
		  $RegistryArray.LeadingIncorrectArray += $SDPentry
		  }
               	Write-Verbose "reg-File: $($Reg_file.name)"
               	Write-Debug "Leading_Space: $entry "
               	$RegistryArray.LeadingIncorrectFileArray += $Reg_file
              }
            }
      }
   Write-Verbose "Reg-File $($Reg_file.name) done"
   }

if ($RegistryArray.TrailingIncorrectArray -or $RegistryArray.LeadingIncorrectArray) {
  if ($RegistryArray.TrailingIncorrectArray) {
      Write-Host -BackgroundColor Magenta -ForegroundColor Black -Object "`n__Reg-Files-Blank-Check: $($RegistryArray.TrailingIncorrectArray.count) Registry key name(s) containing 'trailing Space' character"
      $RegistryArray.TrailingIncorrectArray |select RegName,REG_type,RegValue,HKEY  |sort HKEY,RegName|ft -auto
      }
  if ($RegistryArray.LeadingIncorrectArray) {
      Write-Host -BackgroundColor Magenta -ForegroundColor Black -Object "`n__Reg-Files-Blank-Check: $($RegistryArray.LeadingIncorrectArray.count) Registry key name(s) containing 'leading blank' character"
      $RegistryArray.LeadingIncorrectArray |select RegName,REG_type,RegValue,HKEY  |sort HKEY,RegName|ft -auto
      }
}
else {Write-Host -BackgroundColor Green -ForegroundColor Black -Object "`n$(Get-Date -UFormat "%R:%S") Reg-Files-Blank-Check OK: No Registry key name contains leading or trailing Space character."}


$RegistryArray.ignoredFiles = Get-Item -path ($SDPPath + $NodeName + "*_reg*") -Include "*.hiv" #,"*_reg_Print*"
Write-Verbose "..ignored Reg Files: "
Write-Verbose "$($RegistryArray.ignoredFiles)"
#Write-Host "`nTotal $($RegistryArray.regFiles.count) _reg_*.txt files checked, $($RegistryArray.ignoredFiles.count) *_reg_*.Hiv or big *_reg_Print.txt ignored."
Write-Host "`nTotal $($RegistryArray.regFiles.count) _reg_*.txt files checked, $($RegistryArray.ignoredFiles.count) *_reg_*.Hiv ignored."
$endReg = Get-Date
Write-Host -BackgroundColor Black -ForegroundColor Gray -Object "$(Get-Date -UFormat "%R:%S") Reg-Files-Blank-Check:  v$VerMa.$VerMi took $($endReg - $startReg)"
write-debug "___leaving [execute-Reg-Check-Blank]"
} #end function execute-Reg-Check-Blank

###########################################################
### Step#4: function Compare-RegName-Value-vs-DefaultValue
# compare all RegKeyNames in given SDP _reg_ files with Standard settings
# Return:
#http://blogs.technet.com/b/heyscriptingguy/archive/2011/02/18/speed-up-array-comparisons-in-powershell-with-a-runtime-regex.aspx
# $a = �red.�,�blue.�,�yellow.�,�green.�,�orange.�,�purple.�
# $b = �blue.�,�green.�,�orange.�,"white.","gray."
# [regex] $a_regex = �(?i)^(� + (($a |foreach {[regex]::escape($_)}) �join �|�) + �)$�
# $b -match $a_regex
function Compare-RegName-Value-vs-DefaultValue ($RegNamesArray,$NodeName)
{
#$RegistryArray.regFiles = Get-Item -path ($SDPPath + $NodeName + "*WebClient_reg_output*") -Exclude "*.hiv","*_reg_Print*" #*_reg*
	$startRegCompare = Get-Date

	write-debug "__entering Compare-RegName-Value-vs-DefaultValue($RegName, )"
	Write-Host "...Checking for differences in Registry settings "
	Write-Host "  - Yellow blocks mark non default settings ..."
	# lookup RegName and default value in reg reference list $RegReferenceCsvFile
	Write-Verbose "_Fetch reg reference List: $RegReferenceCsvFile"
	$DefaultRegValuesCsvFile = import-csv $RegReferenceCsvFile

	#[regex] $DefRegKeys_regex = �(?i)^(� + (($DefaultRegValuesCsvFile |foreach {[regex]::escape($_.RegName)}) �join �|�) + �)$�
	#$DefRegKeys_regex = (($DefaultRegValuesCsvFile |foreach {[regex]::escape($_.RegName)}) �join �| �)
	$DefRegKeys_regex = Using-Culture $UsingCulture {(($DefaultRegValuesCsvFile |foreach {[regex]::escape($_.RegName)}) �join �| �) }
	Write-Host " ..Note: checks can only be done on available *_reg* files from SDP report"
	Write-Verbose " ..Checking: $DefRegKeys_regex"
#	$UniqueAllRegNamesArray = $RegistryArray.AllRegNamesArray | Sort-Object | Get-Unique #v1.10 - 2015-10-14 # sort out only unique
#$UniqueAllRegNamesArray = $UniqueAllRegNamesArray | sort -Unique ### http://blogs.technet.com/b/heyscriptingguy/archive/2012/01/15/use-powershell-to-choose-unique-objects-from-a-sorted-list.aspx

	#$SDPRegNamesMatchList = $RegistryArray.AllRegNamesArray | Select-String "$DefRegKeys_regex"	#may need Function Using-Culture for Turkish TR-TR?
	$SDPRegNamesMatchList = Using-Culture $UsingCulture {$RegistryArray.AllRegNamesArray | Select-String "$DefRegKeys_regex" }
	Write-debug "SDPRegNamesMatchList: $SDPRegNamesMatchList"
	if ($SDPRegNamesMatchList) {
	foreach ($line in $DefaultRegValuesCsvFile) {
	   Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "." -Separator .
	   $Component 		= $line.Component
	   $HKEY 		= $line.HKEY
	   $RegName 		= $line.RegName
	   $REG_type 		= $line.REG_type
	   $DefaultValue 	= $line.DefaultValue
	   $KBref 		= $line.KBref
	   $Comment 		= $line.Comment

	#write-host "....checking $($RegistryArray.AllRegNamesArray)"
	#$RegStringFile = "c:\temp\RegStringFileKB.txt"
        #$RegistryArray.AllRegNamesArray | Out-File -FilePath $RegStringFile

	#   $regMatch= $SDPRegNamesMatchList | Select-String "$RegName" #-quiet
		$HKEY_regex = ($HKEY.replace("\","\\"))
$RegName_regex = ([regex]::escape($RegName))
#		$RegName_regex = ($RegName.replace("\\*\","\\\\\*\\")) #^\\\\\w+ for UNC hardening #[regex]::escape($_)
#		$RegName_regex = ($RegName.replace("\\*\","^\\\\\w+\\\w+")) #^\\\\\w+ for UNC hardening
#	   $regMatch_regex = "$($HKEY_regex)\s{4,5}$($RegName).*\s{4,5}.*"
	   $regMatch_regex = "$($HKEY_regex)\s{4,6}$($RegName_regex)\s{4,6}.*"
	   Write-debug "regMatch_regex: $regMatch_regex"
	   #$regMatch= $SDPRegNamesMatchList | Select-String "$regMatch_regex" #-quiet
	   $regMatch= Using-Culture $UsingCulture {$SDPRegNamesMatchList | Select-String "$regMatch_regex"} #-quiet
	   Write-debug "regMatch: $regMatch"
	   if ($regMatch) { # example: HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters\    SMB2    REG_DWORD    0x1
	  	$regMatch | ForEach-Object {
	##  	  $pattern = "(?<HKEY>^HKEY_.*)(\s){4,4}(?<RegName>\w.*(\s){4,4})\s*(?<REG_type>REG_.*)(\s){4,4}(?<RegValue>.*)"
	  	  $pattern = "(?<HKEY>^HKEY_.*)(\s){4,6}(?<RegName>\S.*(\s){4,6})\s*(?<REG_type>REG_.*)(\s){4,4}(?<RegValue>.*)"
	  	  if ($_ -match $pattern)
	  	    {
			#Write-host "$RegName : $($SDPvalue)"
			$SDPentry = New-Object PSObject -Property @{
	  	          HKEY 		= $Matches.HKEY
	  	          RegName 	= ($Matches.RegName).Replace("   ","")
	  	          REG_type 	= $Matches.REG_type
	  	          RegValue 	= $Matches.RegValue
	  	          Component	= $Component
	  	          DefaultValue	= $DefaultValue
	  	          KBref		= $KBref
	  	          Comment	= $Comment
	  	      	}
	  	      	Write-debug "SDPentry:  $($SDPentry.RegName)"
	  	      	Write-debug "Reference: $($RegName)"
	##  	  	If (($SDPentry.RegName -match $RegName) -and ($DefaultValue -ne $SDPentry.RegValue))
	  	  	If ($DefaultValue -ne $SDPentry.RegValue)
	  	  	{ 	Write-Host -BackgroundColor Yellow -ForegroundColor Cyan -NoNewline -Object "." -Separator .
	  	  		Write-Verbose "Found difference: $($RegKeyNameDiffValueArray)
	  	  		 	=> Default Value: $RegName $DefaultValue `n"
	  	  		$RegistryArray.RegKeyNameDiffValueArray += $SDPentry
				Write-Verbose " Component: $($line.component) RegName: $($line.RegName) DefValue: $($line.DefaultValue) -differs to- SDP: $($SDPentry.RegValue) "
			}
	  	    } # end if ($_ -match $pattern)
	  	} # end ForEach-Object
	   }#end if ($regMatch)
	} # end foreach ($line in $DefaultRegValuesCsvFile)
	} # end if ($SDPRegNamesMatchList)
	else { Write-Host "[Informational] No match of given registry names to compare"}

	# ToDo: inform engineer about discrepancy (report in file)
	#       store the regkeyname (hopefully unique) while scanning all reg files and do the comparison only once at end of script

	$endRegCompare = Get-Date
	Write-Host -BackgroundColor Black -ForegroundColor Gray -Object "`n$(Get-Date -UFormat "%R:%S") Reg-Names-Compare script v$VerMa.$VerMi took: $($endRegCompare - $startRegCompare)"
	write-debug "___leaving [execute-Reg-Check-Blank]"
} #end function Compare-RegName-Value-vs-DefaultValue

###########################################################
### function Add_RegNameEntryToArray --- currently not used!
# Return:
function Add_RegNameEntryToArray ($RegNamesArray,$RegNameEntry)
{
#  	$RegNameEntry | ForEach-Object {
  	  $pattern = "(?<HKEY>^HKEY_.*)(\s){4,}(?<RegName>\w.*(\s){4,})\s*(?<REG_type>REG_.*)(\s){4,4}(?<RegValue>.*)" ## 4 spaces or more before or after RegName !
  	  if ($RegNameEntry -match $pattern)
  	  {
   	      	  $SDPentry = New-Object PSObject -Property @{
  	          HKEY 		= $Matches.HKEY
  	          RegName 	= ($Matches.RegName).Replace("   ","")
  	          REG_type 	= $Matches.REG_type
  	          RegValue 	= $Matches.RegValue
  	      	}
  	      	Write-Verbose "... adding SDP_RegKey:  $($SDPentry.RegName) to Array $($RegNamesArray.name)"
  	      	$RegNamesArray += $SDPentry
  	  }
#	}
} # end function Add_RegNameEntryToArray


### ::main #####################################################################################
$MsinfoFiles = Get-Item -path ($SDPPath + "*Msinfo*.txt")

 if (!$MsinfoFiles) {$MsinfoFiles = Get-Item -path ($SDPPath + "*Msinfo*.nfo")}
  if (!$MsinfoFiles) {
	Write-Host -BackgroundColor Black -ForegroundColor Red -Object  "There are no *Msinfo*.* files in $SDPPath - Please double-check SDP-path again!"
	Write-Host " This error happens for non-standard SDP reports, i.e. VSS, SCCM or SQL SDP reports"
	$ErrorMsgRG += "No-Valid-msinfo32 "
	#Get user input for OS:
	Write-Verbose " To run this script, you can input the OS as third parameter, i.e. 2008,2008R2,2012,2012R2"
      	#   continue to allow parameter #3 as OSversion, workaround for no MsInfo32 file in SDP, plus manual optional 3rd parameter OSversion
      	$MsinfoFiles = Get-Item -path ($SDPPath + '*evt_System.txt')
	Write-Verbose " Proceed with Files: $MsinfoFiles "
	}
Write-Host "$(Get-Date -UFormat "%R:%S") ==Registry Check==... running checks for incorrect entries and check against different/non-standard key values... "
$NodeNames = foreach ($NodeName in $MsinfoFiles){($NodeName.name).split('_')[0]}
Write-Host "$(Get-Date -UFormat "%R:%S") ...NodeName(s): $NodeNames"

### Get SDP report type, i.e. VSS, SCCM or SQL SDP reports) #2016-01-18
 #$SDPpathStdoutFile = Get-Item -path ($SDPPath + "stdout.log") -ErrorAction SilentlyContinue
 #if (!$SDPpathStdoutFile) {$ErrorMsg += "No-Valid-stdout "}
 #else { $stdout = Get-Content $SDPpathStdoutFile -TotalCount 3
 #	$SDPtype = $stdout[-1];$SDPtype=$SDPtype.Split(" ",2)[0] }
 $SDPpathResultsFile = Get-Item -path ($SDPPath + "results.xml") -ErrorAction SilentlyContinue
 if (!$SDPpathResultsFile) {$ErrorMsg += "No-Valid-resultsXml "}
 else { [xml]$Types = Get-Content $SDPpathResultsFile	#Select-Xml -Xml $Types -XPath "//ID"
	$SDPtype = $Types.SelectSingleNode("//ID")|  % {  $_.InnerText }
	}
## foreach loop: processing per NodeName in Cluster report
$NodeCnt=0
foreach ($NodeName in $NodeNames) {
	$NodeCnt++
	if ($($NodeNames.count) -gt 1) {Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "$($NodeCnt) " -Separator .
					Write-Host "$(Get-Date -UFormat "%R:%S") ___Node $NodeCnt $NodeName"}
	$DiffValKeys = ""
	$startNode = Get-Date
	Set-Variable -Name RegistryArray -Scope Script
	Set-Variable -Name prev_DiffRegistryArray -Scope Script
	Set-Variable -Name curr_DiffRegistryArray -Scope Script
	#Set-Variable -Name ComputerName  -value "" -Scope Script

	$RegistryArray = New-Object PSObject -Property @{
		ComputerName			= $Null
		SDPdate				= @()
		WARNmsg				= @()
		regFiles			= @()
		ignoredFiles			= @()
	  	TrailingIncorrectArray		= @()
	  	TrailingIncorrectFileArray	= @()
	  	LeadingIncorrectArray	 	= @()
	  	LeadingIncorrectFileArray	= @()
	  	RegNamesArray			= @()
	  	AllRegNamesArray		= @()
	  	RegKeyNameDiffValueArray 	= @()
	  	OSVersion			= $Null
	 	OSVersion_old			= $Null
	 #	CheckFileOut			= @()
		}

    # Add new dynamic variable with the name RegistryArray_$NodeName, for every Nodename
    # To access variable use:  get-variable -Name "RegistryArray_$NodeName"
    new-variable -Name "RegistryArray_$NodeName" -Value $RegistryArray -Force
#initialize
#[string[]]$RegistryArray.CheckFileOut = $Null

### 1. Get OSversion
$result1 = Get-OS-from-MSinfo32 $SDPPath $NodeName			# Call function
Write-Verbose "OSVersion in SDP report: $($RegistryArray.OSVersion) - ComputerName: $($NodeName)"

$regCheckFile = $SDPPath + '!'+$NodeName+'_R-E-G-Check_'+$RegistryArray.OSVersion+'.txt'
#"" > $regCheckFile # initialize, write new file

### 2. Check if _reg_ files are relevant (Administrator has not disabled Registry editing )
$result1a = CheckRegistryEditingDisabledSDP $SDPPath $NodeName		# Call function

### 3. run the registry checks for keys with blank characters
	execute-Reg-Check-Blank $SDPPath $NodeName			# Call function
$endRegCheck = Get-Date
Write-debug "RegNamesArray: $($RegistryArray.RegNamesArray)"

### 4. Compare-RegName-Value-vs-DefaultValue
Write-Debug "..in main"
	#reduce nr of AllRegNamesArray by sorting unique
	Write-verbose "AllRegNamesArray Before: $($RegistryArray.AllRegNamesArray.count)"
	$RegistryArray.AllRegNamesArray = $RegistryArray.AllRegNamesArray | Sort-Object | Get-Unique
	Write-verbose "AllRegNamesArray After : $($RegistryArray.AllRegNamesArray.count)"
	Compare-RegName-Value-vs-DefaultValue $RegistryArray.AllRegNamesArray $NodeName	# Call function
Write-Output "... see details in output file: $regCheckFile "

$endCompare = Get-Date

### write onscreen summary
Write-Output " => Table of different Registry settings:"
if ($($NodeNames.count) -gt 1) { Write-Output "SUMMARY Node_#$($NodeCnt): $NodeName "}
else { Write-Output "SUMMARY: $NodeName "}
foreach ($Regkey in $RegistryArray.TrailingIncorrectArray) { $TrailingKeys += ($Regkey.RegName) }
$TrailFileList = $RegistryArray.TrailingIncorrectFileArray -split (" ")
Write-Debug "Trail: $($RegistryArray.TrailingIncorrectArray)"
Write-Verbose "Trail: $($TrailingKeys)"
$TrailingCnt = ($RegistryArray.TrailingIncorrectArray).count
foreach ($Regkey in $RegistryArray.LeadingIncorrectArray) { $LeadingKeys += ($Regkey.RegName) }
$LeadFileList= $RegistryArray.LeadingIncorrectFileArray -split (" ")
Write-Debug "Lead : $($RegistryArray.LeadingIncorrectArray)"
Write-Verbose "Lead : $($LeadingKeys)"
$LeadingCnt  = ($RegistryArray.LeadingIncorrectArray).count
foreach ($Regkey in $RegistryArray.RegKeyNameDiffValueArray) { $DiffValKeys += ($Regkey.RegName)  }
Write-Debug "Diff: $($RegistryArray.RegKeyNameDiffValueArray)"
Write-Verbose "Diff: $($DiffValKeys)"
$DiffValCnt  = ($RegistryArray.RegKeyNameDiffValueArray).count
If (($TrailingCnt) -or ($LeadingCnt))
	{ Write-Host -BackgroundColor Magenta -ForegroundColor Black -Object  "- Found $($TrailingCnt + $LeadingCnt) inconsistent Registry Name entries with 'Trailing Space': $TrailingCnt - 'Leading Space': $LeadingCnt"
	  Write-Output "  in ($($RegistryArray.TrailingIncorrectFileArray.count) + $($RegistryArray.LeadingIncorrectFileArray.count)) Registry File(s): `n"
	  Write-Output "- Trailing space (~): $TrailFileList "
	  $RegistryArray.TrailingIncorrectArray |select RegName,REG_type,RegValue,HKEY  |sort HKEY,RegName|ft -auto
	  Write-Output "- Leading space: $LeadFileList "
	  $RegistryArray.LeadingIncorrectArray |select RegName,REG_type,RegValue,HKEY  |sort HKEY,RegName|ft -auto
	  Write-Output "...check this inconsistency right away! `n => And if this is a false positive, inform script author WalterE for script enhancement. Thx!"
	}
If ($DiffValCnt)
	{ Write-Host -BackgroundColor Yellow -ForegroundColor Black -Object  "`n- Found $($DiffValCnt) registry key values different to default setting (compared only known keys):`n '$($DiffValKeys)'"
	}

#If (($TrailingCnt) -or ($LeadingCnt) -or ($DiffValCnt)) {}#Write-Output "...open summary file with FavEditor"}
#$RegistryArray | measure-object -property RegKeyNameDiffValueArray
If (-not (($TrailingCnt) -or ($LeadingCnt) -or ($DiffValCnt))) {Write-Host -BackgroundColor Green -ForegroundColor Black -Object "$(Get-Date -UFormat "%R:%S") Reg-Compare: ...no issues found"}
####################
#Create Output file, Write to file
"Registry Check Summary:"  > $regCheckFile
" SDP-date: $($RegistryArray.SDPdate) - OS-Version: $($RegistryArray.OSVersion) - Name: $($RegistryArray.ComputerName) $OSbuild $OSName" >> $regCheckFile
" SDP-path: $SDPPath " >> $regCheckFile
" SDP-type: $SDPtype $newline_Seperator" >> $regCheckFile
" $CheckDate Found $($DiffValCnt) registry key values different to default setting (compared only known keys, see Appendix table below; listed in existing *reg* files of SDP report):"  >> $regCheckFile
" $($DiffValKeys) $newline_Seperator" >> $regCheckFile
$RegistryArray.RegKeyNameDiffValueArray |select Component,RegName,REG_type,RegValue,DefaultValue,KBref,Comment |sort Component,RegName |ft -auto| Out-file $regCheckFile -Append -Width $OutFileChars #Tee-Object -file $regCheckFile
"Note:" +$RegistryArray.WARNmsg+ "$newline_Seperator" >> $regCheckFile

## Write Registry Blank test
if ($RegistryArray.TrailingIncorrectArray) {
	"- Trailing space (~): $newline_Seperator" >> $regCheckFile
	$RegistryArray.TrailingIncorrectFileArray >> $regCheckFile
    $RegistryArray.TrailingIncorrectArray |select RegName,REG_type,RegValue,HKEY |sort HKEY,RegName|ft -auto |Out-file $regCheckFile -Append -Encoding String -Width $OutFileChars
    }
if ($RegistryArray.LeadingIncorrectArray) {
	"- Leading space: $newline_Seperator" >> $regCheckFile
	$RegistryArray.LeadingIncorrectFileArray >> $regCheckFile
    $RegistryArray.LeadingIncorrectArray  |select RegName,REG_type,RegValue,HKEY |sort HKEY,RegName|ft -auto |Out-file $regCheckFile -Append -Encoding String -Width $OutFileChars
    }
if ($RegistryArray.ignoredFiles) {
#	"- ignored Reg Files (*.hiv or big *_reg_Print.txt): $newline_Seperator"  >> $regCheckFile
	"- ignored Reg Files (*_reg_*.hiv): $newline_Seperator"  >> $regCheckFile
	$RegistryArray.ignoredFiles >> $regCheckFile
    }
#Write-Output "Table of Registry settings (known keys), which are compared to def.value (last update: $($RegReferenceCsvFileReleaseDate)):"
  "$newline_Seperator
  APPENDIX: Table of Registry settings (known keys), which are compared to def.value (last update: $($RegReferenceCsvFileReleaseDate)):
  Note: Registry key values different to default setting can only be detected if the key is listed in the collection of the SDP speciality report. $newline_Seperator" >> $regCheckFile
  $DefaultRegValuesCsvFile1 = import-csv $RegReferenceCsvFile
  $DefaultRegValuesCsvFile1 |select Component,RegName,REG_type,DefaultValue,KBref,Comment |sort Component,RegName |ft -auto | Out-file $regCheckFile -Append -Encoding String -Width $OutFileChars

$endNode = $end = Get-Date
$Duration = $end - $start
$DurBlank = $endRegCheck - $start
$DurRegComp = $endCompare - $endRegCheck
$DurNode = $endNode - $startNode
Write-Host -BackgroundColor Blue -ForegroundColor Red -NoNewline -Object $RegistryArray.WARNmsg -Separator .
Write-Host "Summary stored in file: $regCheckFile"

#####################################
# Save result of current Cluster node
#new-variable -Name "myRegistryArray_$NodeName" -value $RegistryArray -Force
$curr_DiffRegistryArray  = $RegistryArray.RegKeyNameDiffValueArray
#$curr_R = (get-variable -Name "myRegistryArray_$NodeName")

if ($NodeCnt -gt 1) {
	Write-host "...Running Cluster nodes consistency check"
	if ($DbgOut) {	Write-host "$NodeName_Prev Prev:"
			$prev_DiffRegistryArray |select Component,RegName,RegValue,DefaultValue |ft -auto}
	$PrevArr = $prev_DiffRegistryArray |select Component,RegName,RegValue,DefaultValue
	if ($DbgOut) {	Write-host "$NodeName Curr:"
			$curr_DiffRegistryArray |select Component,RegName,RegValue,DefaultValue |ft -auto}
	$CurrArr = $curr_DiffRegistryArray |select Component,RegName,RegValue,DefaultValue
 if ($CurrArr) {
	$Diffs = (Compare-Object ($PrevArr | ConvertTo-CSV) ($CurrArr | ConvertTo-CSV) -SyncWindow 20)
	if  ($Diffs -eq $null) {Write-Host -BackgroundColor Green -ForegroundColor Black -Object  "$(Get-Date -UFormat "%R:%S") $NodeName_Prev / $NodeName ClusterNode Reg-Compare-Arrays are equal"
				"- Checking for different reg settings in Cluster nodes: $newline_Seperator" >> $regCheckFile
				" $NodeName_Prev / $NodeName ClusterNode Reg-Compare-Arrays are equal" >> $regCheckFile }
	else {	##ToDo - also open FavEditor, if TrailingCnt or LeadingCnt
		Write-host -BackgroundColor Black -ForegroundColor Red -Object "$NodeName_Prev / $NodeName Differences:"
		$Diffs |ft -auto
		## append in current $regCheckFile
		"- Checking for different reg settings in Cluster nodes: $newline_Seperator" >> $regCheckFile
		"$NodeName_Prev / $NodeName Differences:"  >> $regCheckFile
		$Diffs |ft -auto | Out-file $regCheckFile -Append -Encoding String -Width $OutFileChars
		### open output file with FavEditor
		If (($OpenSummary) -and (($TrailingCnt) -or ($LeadingCnt) -or ($DiffValCnt) -or ($RegistryArray.WARNmsg))) {
			Write-Host "... open output Summary file with FavEditor, because inconsistencies or differences were found for $NodeName."
			Invoke-Item $regCheckFile
			} #end if
		} #end else
	} #end if ($CurrArr)
} #end if ($NodeCnt -gt 1)
# save previous NodeName and DiffRegistryArray for next node loop
$NodeName_Prev = $NodeName
$prev_DiffRegistryArray = $curr_DiffRegistryArray

### open output file with FavEditor
If (($OpenSummary) -and ($NodeCnt -eq 1) -and (($TrailingCnt) -or ($LeadingCnt) -or ($DiffValCnt) -or ($RegistryArray.WARNmsg))) {
	Write-Host "... open output Summary file with FavEditor, because inconsistencies or differences were found."
	Invoke-Item $regCheckFile
	### open output file with favorite Editor
	 #if (Open-WithFavEditor) {Write-Host "... open output Summary file with favorite Editor"
	 #						Invoke-Item $regCheckFile}
	}
#Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R:%S") $($NodeName) Done SDP Registry-check Script version v$VerMa.$VerMi took $DurNode"

} #end of foreach ($NodeName in $NodeNames) loop: processing per NodeName

<#
if ($NodeNames.count -gt 1) {
	foreach ($NodeName in $NodeNames) {
		$myArrayRegSums += , (get-variable -Name "myArrayRegSum_$NodeName")
	}
}
#>
Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R:%S") Name(s): '$NodeNames' Done SDP Registry-check Script version v$VerMa.$VerMi took $Duration"

Write-output "`n"
If ($Stats) {
  "$j" + " ;$CheckDate; $($RegistryArray.OSVersion); $PSculture; " + ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; Trail: $TrailingCnt '$($TrailingKeys)' Lead: $LeadingCnt '$($LeadingKeys)' Diff: $DiffValCnt '$($DiffValKeys)'" + "; RegBlank: $($DurBlank)"  + "; RegComp: $($DurRegComp)" + "; Type: $($SDPtype)" + "; Err: $($ErrorMsgRG)" + "; $NodeCnt" + "; $SDPPath" + "; v$VerMa.$VerMi" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
  }
} #end Process
#http://blogs.technet.com/b/heyscriptingguy/archive/2011/02/18/speed-up-array-comparisons-in-powershell-with-a-runtime-regex.aspx
# $a = �red.�,�blue.�,�yellow.�,�green.�,�orange.�,�purple.�
# $b = �blue.�,�green.�,�orange.�,"white.","gray."
# [regex] $a_regex = �(?i)^(� + (($a |foreach {[regex]::escape($_)}) �join �|�) + �)$�
# $b -match $a_regex