﻿#************************************************
# RC_HTTPRedirectionTSGateway.ps1
# Version 1.0
# Date: 5-1-2012
# Author: davidcop
# Description: Checks for HTTP redirection on either the /rpc virtual directory or the web site that host the /rpc virtual directory
#************************************************

  function CheckforHTTPRedir
  {
    Param ([String] $RPCProxyPath)

    $cmdtorun = ($env:windir) + "\system32\inetsrv\appcmd list config $RPCProxyPath -section:httpRedirect"

    $HTTPRedirectSectionSite = invoke-Expression $cmdtorun
    if ($HTTPRedirectSectionSite -ne $null)
    {
      foreach ($HTTPRedirectSectionSiteEntry in $HTTPRedirectSectionSite)
      {
        $HTTPRedirectSectionSiteEntrylowercase =  $HTTPRedirectSectionSiteEntry.tolower()
        If ($HTTPRedirectSectionSiteEntrylowercase.contains("<httpredirect") -and $HTTPRedirectSectionSiteEntrylowercase.contains("enabled=""true"""))
        {
          $RootCauseDetected = $true
          if (!($RPCProxyPath.contains("/rpc"))) 
          {
            if ($HTTPRedirectSectionSiteEntrylowercase.contains("childonly=""true"""))
            {
              $RootCauseDetected = $false
            }
            else
            {
              $RootCauseDetected = $true
            }
          }
        }
      }
    }
    return $RootCauseDetected
  }


Import-LocalizedData -BindingVariable ScriptVariable
$InformationCollected = new-object PSObject
$RootCauseDetected=$false
Display-DefaultActivity -Rule 2745
# Write-DiagProgress -Activity $ScriptVariable.id_ctshttpredirectioncheck -Status $ScriptVariable.id_ctshttpredirectioncheckdescription
$RootCauseName = "RC_HTTPRedirectionTSGateway"


if ((($OSVersion.major -eq 6) -and (($OSVersion.minor -ge 0) -and ($OSVersion.minor -le 2))) -or ($OSVersion.major -eq 10))  # Win 7/R2 .. Win10
{


  $TSGateway = get-wmiobject -query "select * from win32_service where name = 'tsgateway' and started = 'True'"
  if ($TSGateway -ne $null)
  {
    $RPCProxyWebsite = $null
    $RPCProxyWebsiteString = $null
    $HTTPRedirectSectionSite = $null
    $HTTPRedirectSectionSiteEntry = $null
    $HTTPRedirectSectionSiteEntrylowercase = $null
    $RPCVirtDirPath = $null
    $HTTPRedirectSectionVirtDir = $null
    $HTTPRedirectSectionVirtDirEntry = $null
    $HTTPRedirectSectionVirtDirEntrylowercase = $null

    if (test-path -path "HKLM:\SOFTWARE\Microsoft\RPC\RpcProxy")
    {
      $RPCProxyWebsite = (get-itemproperty -path "HKLM:\SOFTWARE\Microsoft\RPC\RpcProxy").Website
      if ($RPCProxyWebsite -eq $null)
      {
        $RPCProxyWebsite = "default web site"
      }
	}
	else
	{
	  $RPCProxyWebsite = "default web site"
    }

    $RPCProxyWebsiteString = "`"" + $RPCProxyWebsite + "`""
    $RPCSite = CheckforHTTPRedir $RPCProxyWebsiteString
    $RPCVirtDirPath = "`"" + $RPCProxyWebsite + "/rpc`""
    $RPCVDir = CheckforHTTPRedir $RPCVirtDirPath
	
	if (($RPCSite -eq $false) -and ($RPCVdir -eq $false))
	{
	  Update-DiagRootCause -id $RootCauseName -Detected $false
	}

	if (($RPCSite -eq $true) -or ($RPCVdir -eq $true))
	{
      add-member -inputobject $InformationCollected -membertype noteproperty -name "Web Site" -value $RPCProxyWebsiteString
      add-member -inputobject $InformationCollected -membertype noteproperty -name "Virtual Directory" -value $RPCVirtDirPath
	  Update-DiagRootCause -id $RootCauseName -Detected $true
	  write-GenericMessage -RootCauseId $RootCauseName -InternalContentURL "https://vkbexternal.partners.extranet.microsoft.com/VKBWebService/ViewContent.aspx?scid=B;EN-US;2003650" -Verbosity "Warning" -InformationCollected $InformationCollected -Visibility 3 -SupportTopicsID 8134 -SolutionDescription $ScriptVariable.id_ctshttpredirectionchecksolution
	}

    $RPCProxyWebsite = $null
    $RPCProxyWebsiteString = $null
    $HTTPRedirectSectionSite = $null
    $HTTPRedirectSectionSiteEntry = $null
    $HTTPRedirectSectionSiteEntrylowercase = $null
    $RPCVirtDirPath = $null
    $HTTPRedirectSectionVirtDir = $null
    $HTTPRedirectSectionVirtDirEntry = $null
    $HTTPRedirectSectionVirtDirEntrylowercase = $null
    $string = $null
  }
}

## 04/03: Added new Trap info
#Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}
Trap [Exception]
{
	WriteTo-ErrorDebugReport -ErrorRecord $_ 
	continue 
}
