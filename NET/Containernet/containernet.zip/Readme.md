# Complementary Scripts

## containernet.bat Purpose: collect Container Networking data
The script is used to collect ETL traces needed for Container Networking scenario. It collect HNS ETL for Container Networking and TCPIP/WFP/VFP/WinNAT ETL for Container Networking Datapath. 

Alternate approach: downlaod TSS toolset and invoke: `TSS Container`
