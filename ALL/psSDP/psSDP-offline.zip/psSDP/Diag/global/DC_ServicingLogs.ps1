﻿#************************************************
# DC_ServicingLogs.ps1
# Version 1.0
# Date: 2009-2019
# Author: + Walter Eder (waltere@microsoft.com)
# Description: Collects additional information.
# Called from: TS_AutoAddCommands_SETUP.ps1
#*******************************************************
Param($MachineName = $Computername, $Path = "")
if($Path -ne "")
{
	$SkipOSVersionCheck = $true
}
else
{
	$SkipOSVersionCheck = $false
	$Path = "$Env:windir"
}
Import-LocalizedData -BindingVariable ServicingStrings
	
Write-DiagProgress -Activity $ServicingStrings.ID_Servicing -Status $ServicingStrings.ID_ServicingObtaining

$sectionDescription = $ServicingStrings.ID_Servicing
if (($SkipOSVersionCheck -eq $true) -or ($OSVersion.Major -ge 6))
{
	$filesToCollect = "$Path\Logs\CBS\CBS*.Log"
	$filesDescription = $ServicingStrings.ID_ServicingCBSLogs
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
	}

	$filesToCollect = "$Path\winsxs\pending.xml"
	$filesDescription = $ServicingStrings.ID_ServicingSXS
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
	}

	$filesToCollect = "$Path\winsxs\pending.xml.bad"
	$filesDescription = $ServicingStrings.ID_ServicingSXSBad
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
	}

	$filesToCollect = "$Path\winsxs\poqexec.log"
	$filesDescription = $ServicingStrings.ID_ServicingPOQ
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
	}

	$filesToCollect = "$Path\logs\DPX\setupact.log"
	$filesDescription = $ServicingStrings.ID_ServicingDPX
	if (test-path $FilesToCollect) {
	CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
	}

	#please use \EPS\Setup\DC_WindowsUpdateLog.ps1 to obtain this file.
	#$filesToCollect = "$Path\windowsupdate.log"
	#$filesDescription = $ServicingStrings.ID_ServicingWinUpLog
	#if (test-path $FilesToCollect) {
	#	CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
	#}

	$filesToCollect = "$Path\logs\CBS\CheckSUR.log"
	$filesDescription = $ServicingStrings.ID_ServicingSUR
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
	}

	$filesToCollect = "$Path\SoftwareDistribution\ReportingEvents.log"
	$filesDescription = $ServicingStrings.ID_ServicingReportEvent
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
	}

	$filesToCollect = "$Path\servicing\Sessions.xml"
	$filesDescription = $ServicingStrings.ID_ServicingSessions
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
	}
	
	$filesToCollect = "$Path\servicing\Sessions\*.*"
	$filesDescription = "Sessions folder"
	if (test-path $FilesToCollect) 
	{
		CompressCollectFiles -filesToCollect $filesToCollect -DestinationFileName ($MachineName + "_Sessions.zip") -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $false
	}
	if($SkipOSVersionCheck -eq $false)
	{
		$OutputFile= $MachineName + "_reg_Components.HIV"
		RegSave -RegistryKey "HKLM\COMPONENTS" -OutputFile $OutputFile -fileDescription "Components Hive"

		$OutputFile= $MachineName + "_reg_Component_Based_Servicing.HIV"
		RegSave -RegistryKey "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing" -OutputFile $OutputFile -fileDescription "Component Based Servicing Hive"

		$TrustedInstallerKey = "HKLM\SYSTEM\CurrentControlSet\services\TrustedInstaller"
		$OutputFile= $MachineName + "_reg_TrustedInstaller.TXT"
		RegQuery -RegistryKeys $TrustedInstallerkey -OutputFile $OutputFile -fileDescription "Trusted Installer Service" -Recursive $true
	}

	$FilesToCollect = "$Path\winsxs\reboot.xml"
	$FilesDescription = "reboot.xml from winsxs folder"
	$sectionDescription = "Servicing Logs"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
	}

	$FilesToCollect = "$Path\system32\driverstore\drvindex.dat"
	$FilesDescription = "DriverStore Index Data File"
	$sectionDescription = "DriverStore"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
	}

	$FilesToCollect = "$Path\system32\driverstore\INFCACHE.1"
	$FilesDescription = "DriverStore INF Cache DB"
	$sectionDescription = "DriverStore"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
	}

	$FilesToCollect = "$Path\system32\driverstore\infpub.dat"
	$FilesDescription = "DriverStore INF Pub Data File"
	$sectionDescription = "DriverStore"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
	}

	$FilesToCollect = "$Path\system32\driverstore\infstor.dat"
	$FilesDescription = "DriverStore INF Stor Data File"
	$sectionDescription = "DriverStore"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
	}

	$FilesToCollect = "$Path\system32\driverstore\infstrng.dat"
	$FilesDescription = "DriverStore Strng Data File"
	$sectionDescription = "DriverStore"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
	}
	
	$FilesToCollect = "$Path\Logs\CBS\CbsPersist_*.cab"  #CbsPersist_<Time/date stamp>.cab
	$FilesDescription = "CBS Persist Cab Files"
	$sectionDescription = "Servicing Logs"
	if (test-path $FilesToCollect) {		
		CompressCollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -DestinationFileName "CbsPersist.zip"
	}
}

#Rule Number: 5721
#Rule Title: [Idea ID 5721] [Windows] Add Servicing registry keys to "Windows Setup" Manifest
#Only applies Windows 8
if(($SkipOSVersionCheck -eq $true) -or (($OSVersion.Major -eq 6) -and ($OSVersion.Minor -eq 2)))
{
	$PoliciesServicingPath='HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Servicing'
	if(Test-Path $PoliciesServicingPath)
	{
		$OutputFile= $MachineName + "_servicing_FOD_Repair_sources.txt"
		if($MachineName -eq $Computername)
		{
			RegQuery -RegistryKeys $PoliciesServicingPath -OutputFile $OutputFile -fileDescription "Servicing Policy Registry Key" -Recursive $true -SectionDescription $ServicingStrings.ID_Servicing
		}
		$PoliciesServicing = Get-ItemProperty($PoliciesServicingPath)
		$PoliciesServicingId = "Policies Servicing"
		$ReportDisplayName = "Servicing Group Policy Entries"
		$InformationCollected = New-Object psobject
		add-member -inputobject $InformationCollected -membertype noteproperty -name "Alternate Source File Path" -value $PoliciesServicing.LocalSourcePath
		if($PoliciesServicing.UseWindowsUpdate -eq 2)
		{
			add-member -inputobject $InformationCollected -membertype noteproperty -name "Never Attempt to download payload from WU" -value "Enabled"
		}
		else
		{
			add-member -inputobject $InformationCollected -membertype noteproperty -name "Never Attempt to download payload from WU" -value "Disabled"
		}
		if($PoliciesServicing.RepairContentServerSource -eq 2)
		{
			add-member -inputobject $InformationCollected -membertype noteproperty -name "Contact WU instead of WSUS for repair content" -value "Enabled"
		}
		else
		{
			add-member -inputobject $InformationCollected -membertype noteproperty -name "Contact WU instead of WSUS for repair content" -value "Disabled"
		}
		$InformationCollected | ConvertTo-Xml2 | update-diagreport -id  $PoliciesServicingId -name $ReportDisplayName -Verbosity "Informational"
	}
}

if((($OSVersion.Major -eq 6) -and ($OSVersion.Minor -eq 0)) -or 
	(($OSVersion.Major -eq 6) -and ($OSVersion.Minor -eq 1)) -or 
	(($OSVersion.Major -eq 6) -and  ($OSVersion.Minor -eq 2)))
{
	if($MachineName -eq $Computername)
	{
		$CommandToExecute = "cmd.exe /d /c dism /online /get-packages > GetPackages.txt"
		$SectionDescription = "List of installed pacakges"
		$FileDescription = "dism /online /get-packages output"
		RunCmD -commandToRun $CommandToExecute -sectionDescription $SectionDescription -filesToCollect "GetPackages.txt" -fileDescription $FileDescription –noFileExtensionsOnDescription -BackgroundExecution -RenameOutput $true
	}
}
