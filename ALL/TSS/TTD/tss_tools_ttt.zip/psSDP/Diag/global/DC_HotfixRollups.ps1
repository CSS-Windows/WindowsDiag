﻿#************************************************
# DC_HotfixRollups.ps1
# Version 1.0.04.02.14: Created script to easily view what rollups are installed for W7/WS2008R2, W8/WS2012, and W8.1/WS2012R2
# Version 1.1.05.16.14: Added W8.1 Update1 (April2014 rollup);  Added OS Version below each heading.
# Version 1.2.05.19.14: Added May2014 updates for W8/W8.1
# Version 1.3.07.23.14: Added June and July, 2014
# Version 1.4.08.13.14: Added Aug2014 updates for W8/W8.1
# Version 1.5.09.17.14: Added Sep2014 updates for W8/W8.1
# Version 1.6.10.16.14: Added Oct2014 updates for W8/W8.1
# Date: 2019
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Creates output to easily identify what rollups are installed on W7/WS2008R2 and later.
# Called from: Networking Diagnostics
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Import-LocalizedData -BindingVariable ScriptVariable

$OutputFile = $ComputerName + "_HotfixRollups.TXT"
$sectionDescription = "Hotfix Rollups"


function CheckForHotfix ($hotfixID, $title)
{
	$hotfixesWMIQuery = "SELECT * FROM Win32_QuickFixEngineering WHERE HotFixID='KB$hotfixID'"
	$hotfixesWMI = get-wmiobject -query $hotfixesWMIQuery											# or PS > Get-HotFix
	$link = "http://support.microsoft.com/kb/" + $hotfixID
	if ($hotfixesWMI -eq $null)
	{
		"No          $hotfixID - $title   ($link)" | Out-File -FilePath $OutputFile -append
	}
	else
	{
		"Yes         $hotfixID - $title   ($link)" | Out-File -FilePath $OutputFile -append
	}
}

#----------detect OS version and SKU
	$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
	[int]$bn = [int]$wmiOSVersion.BuildNumber
	$sku = $((gwmi win32_operatingsystem).OperatingSystemSKU)

if ($bn -eq 18362)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 19H1 v1903 and Windows Server 2019 19H1 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4505057 -title "2019-KB4505057 Update for Windows 10, version 1903: May 19, 2019"
}
elseif ($bn -eq 17763)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 RS5 v1809 and Windows Server 2019 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4505056 -title "May 19, 2019-KB4505056 (OS Build 17763.504)"
	CheckForHotfix -hotfixID 4493509 -title "April 9, 2019-KB4493509 (OS Build 17763.437)"
	CheckForHotfix -hotfixID 4489899 -title "March 12, 2019-KB4489899 (OS Build 17763.379)"
	CheckForHotfix -hotfixID 4487044 -title "February 12, 2019-KB4487044 (OS Build 17763.316)"
	CheckForHotfix -hotfixID 4480116 -title "January 8, 2019-KB4480116 (OS Build 17763.253)"
	CheckForHotfix -hotfixID 4471332 -title "December 11, 2018-KB4471332 (OS Build 17763.194)"
	CheckForHotfix -hotfixID 4470788 -title "Servicing stack update for Windows Server 2019 and Windows 10 version 1809: December 5, 2018"
}
elseif ($bn -eq 17134)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 RS4 v1803 and Windows Server 2016 RS4 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4505064 -title "May 19, 2019-KB4505064 (OS Build 17134.766)"
	CheckForHotfix -hotfixID 4493437 -title "April 25, 2019-KB4493437 (OS Build 17134.753)"
	CheckForHotfix -hotfixID 4489894 -title "March 19, 2019-KB4489894 (OS Build 17134.677)"
	CheckForHotfix -hotfixID 4487017 -title "February 12, 2019-KB4487017 (OS Build 17134.590)"
	CheckForHotfix -hotfixID 4480966 -title "January 8, 2019-KB4480966 (OS Build 17134.523)"
	CheckForHotfix -hotfixID 4471324 -title "December 11, 2018-KB4471324 (OS Build 17134.471)"
	CheckForHotfix -hotfixID 4485449 -title "Servicing stack update for Windows Server version 1803 and Windows 10 version 1803: February 12, 2019"
}
elseif ($bn -eq 16299)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 RS3 v1709 and Windows Server 2016 RS3 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4505062  -title "May 19, 2019-KB4505062 (OS Build 16299.1150)"
	CheckForHotfix -hotfixID 4493440 -title "April 25, 2019-KB4493440 (OS Build 16299.1127)"
	CheckForHotfix -hotfixID 4489890 -title "March 19, 2019-KB4489890 (OS Build 16299.1059)"
	CheckForHotfix -hotfixID 4486996 -title "February 12, 2019-KB4486996 (OS Build 16299.967)"
	CheckForHotfix -hotfixID 4480978 -title "January 8, 2019-KB4480978 (OS Build 16299.904)"
	CheckForHotfix -hotfixID 4471329 -title "December 11, 2018-KB4471329 (OS Build 16299.846)"
	CheckForHotfix -hotfixID 4485448 -title "Servicing stack update for Windows Server 2016 version 1709 and Windows 10 version 1709: February 12, 2019"
}
elseif ($bn -eq 15063)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 RS2 v1703 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4505055 -title "May 19, 2019-KB4505055 (OS Build 15063.1808)"
	CheckForHotfix -hotfixID 4493436 -title "April 25, 2019-KB4493436 (OS Build 15063.1784)"
	CheckForHotfix -hotfixID 4489888 -title "March 19, 2019-KB4489888 (OS Build 15063.1716)"
	CheckForHotfix -hotfixID 4487020 -title "February 12, 2019-KB4487020 (OS Build 15063.1631)"
	CheckForHotfix -hotfixID 4480973 -title "January 8, 2019-KB4480973 (OS Build 15063.1563)"
	CheckForHotfix -hotfixID 4471327 -title "December 11, 2018-KB4471327 (OS Build 15063.1506)"
	CheckForHotfix -hotfixID 4487327 -title "Servicing stack update for Windows 10, version 1703: February 12, 2019"
}
elseif ($bn -eq 14393)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 RS1 and Windows Server 2016 RS1 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4505052 -title "May 19, 2019-KB4505052 (OS Build 14393.2972)"
	CheckForHotfix -hotfixID 4493473 -title "April 25, 2019-KB4493473 (OS Build 14393.2941)"
	CheckForHotfix -hotfixID 4489889 -title "March 19, 2019-KB4489889 (OS Build 14393.2879)"
	CheckForHotfix -hotfixID 4487026 -title "February 12, 2019-KB4487026 (OS Build 14393.2791)"
	CheckForHotfix -hotfixID 4480961 -title "January 8, 2019-KB4480961 (OS Build 14393.2724)"
	CheckForHotfix -hotfixID 4471321 -title "December 11, 2018-KB4471321 (OS Build 14393.2665)"
	CheckForHotfix -hotfixID 4485447 -title "Servicing stack update for Windows Server 2016 and Windows 10, version 1607: February 12, 2019"
}	
elseif ($bn -eq 10240)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 and Windows Server 2016 RTM Rollups"	 | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	
	CheckForHotfix -hotfixID 4505051 -title "May 19, 2019-KB4505051 (OS Build 10240.18218)"
	CheckForHotfix -hotfixID 4493475 -title "April 9, 2019-KB4493475 (OS Build 10240.18186)"
	CheckForHotfix -hotfixID 4489872 -title "March 12, 2019-KB4489872 (OS Build 10240.18158)"
	CheckForHotfix -hotfixID 4487018 -title "February 12, 2019-KB4487018 (OS Build 10240.18132)"
	CheckForHotfix -hotfixID 4480962 -title "January 8, 2019-KB4480962 (OS Build 10240.18094)"
	CheckForHotfix -hotfixID 4471323 -title "December 11, 2018-KB4471323 (OS Build 10240.18063)"
	CheckForHotfix -hotfixID 4093430 -title "Servicing stack update for Windows 10, version 1507: April 10, 2018"
}
elseif ($bn -eq 9600)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 8.1 and Windows Server 2012 R2 Rollups"	 | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4499151 -title "May 14, 2019-KB4499151 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4493446 -title "April 9, 2019-KB4493446 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4489881 -title "March 12, 2019-KB4489881 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4487000 -title "February 12, 2019-KB4487000 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4480963 -title "January 8, 2019-KB4480963 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4471320 -title "December 11, 2018-KB4471320 (Monthly Rollup)"
	CheckForHotfix -hotfixID 3123245 -title "Update improves port exhaustion identification in Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3173424 -title "Servicing stack update for Windows 8.1 and Windows Server 2012 R2: July 12, 2016"
	CheckForHotfix -hotfixID 3179574 -title "August 2016 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3172614 -title "July 2016 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3013769 -title "December 2014 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3000850 -title "November 2014 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 2919355 -title "[Windows 8.1 Update 1] Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2 Update: April 2014"
	CheckForHotfix -hotfixID 2883200 -title "Windows 8.1 and Windows Server 2012 R2 General Availability Update Rollup"
}
elseif ($bn -eq 9200)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 8 and Windows Server 2012 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------"  | Out-File -FilePath $OutputFile -append
	
	CheckForHotfix -hotfixID 4499171 -title "May 14, 2019-KB4499171 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4493451 -title "April 9, 2019-KB4493451 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4489891 -title "March 12, 2019-KB4489891 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4487025 -title "February 12, 2019-KB4487025 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4480975 -title "January 8, 2019-KB4480975 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4471330 -title "December 11, 2018-KB4471330 (Monthly Rollup)"
	CheckForHotfix -hotfixID 3173426 -title "Servicing stack update for Windows Server 2012: July 12, 2016"
	CheckForHotfix -hotfixID 3179575 -title "August 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3172615 -title "July 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3161609 -title "June 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3156416 -title "May 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3013767 -title "December 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 3000853 -title "November 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 2995388 -title "October 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012 "
	CheckForHotfix -hotfixID 2984005 -title "September 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 2975331 -title "August 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 2967916 -title "July 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012" 
	CheckForHotfix -hotfixID 2962407 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: June 2014" 
	CheckForHotfix -hotfixID 2955163 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: May 2014"
	CheckForHotfix -hotfixID 2934016 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: April 2014" 	
	CheckForHotfix -hotfixID 2928678 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: March 2014" 	
	CheckForHotfix -hotfixID 2919393 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: February 2014"
	CheckForHotfix -hotfixID 2911101 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: January 2014"
	CheckForHotfix -hotfixID 2903938 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: December 2013"
	CheckForHotfix -hotfixID 2889784 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: November 2013"
	CheckForHotfix -hotfixID 2883201 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: October 2013"
	CheckForHotfix -hotfixID 2876415 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: September 2013"
	CheckForHotfix -hotfixID 2862768 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: August 2013"	
	CheckForHotfix -hotfixID 2855336 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: July 2013"	
	CheckForHotfix -hotfixID 2845533 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: June 2013"	
	CheckForHotfix -hotfixID 2836988 -title "Windows 8 and Windows Server 2012 Update Rollup: May 2013" 				
	CheckForHotfix -hotfixID 2822241 -title "Windows 8 and Windows Server 2012 Update Rollup: April 2013"				
	CheckForHotfix -hotfixID 2811660 -title "Windows 8 and Windows Server 2012 Update Rollup: March 2013"				
	CheckForHotfix -hotfixID 2795944 -title "Windows 8 and Windows Server 2012 Update Rollup: February 2013"			
	CheckForHotfix -hotfixID 2785094 -title "Windows 8 and Windows Server 2012 Update Rollup: January 2013"				
	CheckForHotfix -hotfixID 2779768 -title "Windows 8 and Windows Server 2012 Update Rollup: December 2012"			
	CheckForHotfix -hotfixID 2770917 -title "Windows 8 and Windows Server 2012 Update Rollup: November 2012"			
	CheckForHotfix -hotfixID 2756872 -title "Windows 8 Client and Windows Server 2012 General Availability Update Rollup"
}
elseif ($bn -eq 7601)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 7 and Windows Server 2008 R2 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn + "   (RTM=7600, SP1=7601)" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------"  | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4499164 -title "May 14, 2019-KB4499164 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4493472 -title "April 9, 2019-KB4493472 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4489878 -title "March 12, 2019-KB4489878 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4486563 -title "February 12, 2019-KB4486563 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4480970 -title "January 8, 2019-KB4480970 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4471318 -title "December 11, 2018-KB4471318 (Monthly Rollup)"
	CheckForHotfix -hotfixID 3125574 -title "Convenience roll-up update for Windows 7 SP1 and Windows Server 2008 R2 SP1"
	CheckForHotfix -hotfixID 3177467 -title "Servicing stack update for Windows 7 SP1 and Windows Server 2008 R2 SP1: September 20, 2016"
	CheckForHotfix -hotfixID 2775511 -title "An enterprise hotfix rollup is available for Windows 7 SP1 and Windows Server 2008 R2 SP1"

	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Followup Fixes Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   -----------------------------"  | Out-File -FilePath $OutputFile -append
	CheckForHotfix -hotfixID 2732673 -title "`"Delayed write failed`" error message when .pst files are stored on a network file server that is running Windows Server 2008 R2"
	CheckForHotfix -hotfixID 2728738 -title "You experience a long logon time when you try to log on to a Windows 7-based or a Windows Server 2008 R2-based client computer that uses roaming profiles"
	CheckForHotfix -hotfixID 2878378 -title "OpsMgr 2012 or OpsMgr 2007 R2 generates a Heartbeat Failure message and then goes into a greyed out state in Windows Server 2008 R2 SP1"
}
elseif ($bn -eq 6002)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows Vista and Windows Server 2008 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn + "   (RTM=6000, SP2=6002)" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------"  | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4499149 -title "May 14, 2019-KB4499149 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4493471 -title "April 9, 2019-KB4493471 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4489880 -title "March 12, 2019-KB4489880 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4487023 -title "February 12, 2019-KB4487023 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4480968 -title "January 8, 2019-KB4480968 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4471325 -title "December 11, 2018-KB4471325 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4493730 -title "Servicing stack update for Windows Server 2008 SP2: April 9, 2019"
}

	CollectFiles -filesToCollect $OutputFile -fileDescription "Hotfix Rollups" -SectionDescription $sectionDescription

