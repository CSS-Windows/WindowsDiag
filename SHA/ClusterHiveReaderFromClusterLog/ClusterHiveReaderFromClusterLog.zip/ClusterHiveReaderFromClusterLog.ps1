<#  
.SYNOPSIS 
    Script Name:  ClusterHiveReaderFromClusterLog.ps1    	
    Version:      1.3
    Last Update:  12 March 2020
    Author:       Josef Holzer 

.DESCRIPTION
    In 2016 and later we store all Configuration Info on top of the Cluster Log in csv format
    The script reads the header of the cluster.log file and creates the following files:    
    ClusterLogName-ClusConfig-All.txt             # Contains all Info Exported as AllObjects  fl *
    ClusterLogName-ClusConfig-All.xml             # Contains all Info as Powershell Objects
    ClusterLogName-ClusConfig-All-Overview.txt    # Contains most important info as | ft Prop1, Prop2...
    ClusterLogName-ClusConfig-ProcessIDs.txt      # All PIDs of Processes that wrote to cluster log (only if -FindPIDs was passed)

    
    HowTo Use it the simple way: 
    - Copy ClusterHiveReaderFromClusterLog.ps1 to your path where you have one or multiple Cluster Logs (2016 or later)
    - Run it without any parameters


.PARAMETER FindPIDs
    - switch parameter (default is $False) so by default we don�t search for PIDs in Cluster Logs    
    - If you called the script with -FindPIDs it will find ProcessID�s that wrote into ClusterLog
    - it will save the results in ClusterLogName-ClusConfig-ProcessIDs.txt     
    - if we have a valid path to Parameter: FileWithProcessInfoPathFull it will resolve PIDs to Process Names
      this works on all cluster logs
    - It can take a couple of mins 

	
.PARAMETER  Path
    - $PDW (default)  # $PWD is the current path of the Powershell window
    - enter the full name (Path\Filename) to a Cluster.Log file or 
    - enter the path to a couple of Cluster.log files
      the script will take the first one which contains config Info (2016 or later)    	


.PARAMETER FileWithProcessInfoPathFull
    enter the full name (Path\Filename) to the file that contains Process Information
    if you collected the data with GetLogs.ps1 this would be NodeName-GeneralInfoPerHost.xml
    or you collected simply with Get-Process | Export-CliXml -path c:\temp\NodeName-ProcessInfo.xml
    The script will take both formats

    
.EXAMPLE     
    ClusterHiveReaderFromClusterLog.ps1    
    - if you have several cluster logs in c:\logs and copy the script to this folder you simply run the script with no parameters
    - it will then take the first (2016 or later ) cluster.log that contains config data and process it

.EXAMPLE    
    ClusterHiveReaderFromClusterLog.ps1 -FindPIDs -Path "C:\ClusterLog\H19N1.H19Corp.com_cluster.log" -FileWithProcessInfoPathFull "C:\ClusterLog\H19N1-GeneralInfoPerHost.xml" 
    - it will read cluster configuration and write it down into file names mentioned above including *ProcessIDs
	

#>

#region    ::::: Params ::::: 
param(
    [Switch]$FindPIDs= $false,                                         # If Script was called with -FindPIDs it will find ProcessID�s that wrote to the ClusterLog 
                                                                       # and write it to a file e.g. PROD_cluster.log-ClusConfig-ProcessIDs.txt

    $Path= "$PWD",                                                     # Either FullPath to one single ClusterLog or path that contains several clusterLogs; default is current path
    #$Path= "$PWD\H19N1.H19Corp.com_Acluster-Test.log",                # Sample with Full Path to a single Cluster Log            
    
    
    $FileWithProcessInfoPathFull=""                                    # Full Path to *.xml file that contains Process Objects
                                                                       # GetLogs.ps1 collects these Info�s by default    
                                                                       # Could simply be collected with Get-Process | Export-Clixml -path "$PWD\H19N1-Process.xml    
                                                                            
)

#endregion ::::: Params :::::


#region    ::::: Helper Functions :::::


function ShowProgress { 
# SYNOPSIS: show what we are doing so far; should be placed on top of all other functions
    param(
        $MessageUser = "",		      # pass your own message
        $ForeColor =  "White",	      # default ForeGroundColor is White       
        [Bool]$EndOfScript= $false    # End of Script Marker to flush the rest of Messages to *ScriptDebug.txt although DebugLogCountMax is not reached
    )
    
    If ($Script:DebugLogLevel -eq 0 ) { Return } # If DebugLogLevel is 0 exit this function imediately      
    
    # Get the function name, that was calling ShowProgress
    function GetFunctionName ([int]$StackNumber = 1) {
        # https://stackoverflow.com/questions/3689543/is-there-a-way-to-retrieve-a-powershell-function-name-from-within-a-function
        return [string]$(Get-PSCallStack)[$StackNumber].FunctionName
    }
    $TimeDisplay = [String](Get-Date -Format 'yyMMdd-HHmmss') # time stamp to display on each action/function call. eg 'yyMMdd-HHmmss'
    $TimeStampCurrent = Get-Date

    # Ignore error messages when it�s called the first time
    try{
        $TimeDiffToStart = $TimeStampCurrent - $TimeStampScriptStart		# overall duration since start of script
    }
    catch{}

    # Ignore error messages when it�s called the first time
    try{
        $TimeDiffToLast =  $TimeStampCurrent - $Script:TimeStampStartSaved	# time elapsed since the last action
    }
    catch{}

	$Script:TimeStampStartSaved = $TimeStampCurrent						# update/save timestamp to measure next progress duration
    $FuncName =  GetFunctionName -StackNumber 2							# Last Function Name
    [String]$DurScriptDisplay = "" + $TimeDiffToStart.Minutes + ":" + $TimeDiffToStart.Seconds	# " ;Script ran for Min:Sec  = " # display duration since script start
    [String]$DurFunctionDisplay = "" + $TimeDiffToLast.Minutes +  ":" + $TimeDiffToLast.Seconds	# " ;Last Action took Min:Sec= " # display duration of last action or function call
    if (-not ($TimeDiffToLast.TotalSeconds -ge 1) ) { $DurFunctionDisplay = "0:0" }

    
    If ($RunOnlyOnce){ # Only first time write the head line to explain the columns        
        $Description= "Script Started at $sTimeStampScriptStart ScriptFullName:$ScriptFullName on Host:$($Env:ComputerName) "        
        If (-Not ( Test-Path -Path $DebugLogPath ) ){ # if the DebugLogPath does not already exist, e.g. default is c:\MSDATA, then Create it 
            New-Item -Path $DebugLogPath -ItemType Directory
        }
        write-host -fore Green $Description
        $Description | Out-File -FilePath $DebugLogPathFull -Append

        $Description= "TimeStamp    |TimeSinceScriptStarted Min:Sec|DurationOfLastAction Min:Sec|FunctionName| UserMessage"
        <#
            Sample Output
            "TimeStamp   |TimeSinceScriptStarted Min:Sec|DurationOfLastAction Min:Sec|FunctionName| UserMessage"
            190820-103322|0:0                           |0:0                         |CreateFolder| Enter
            190820-103322|0:0|0:0|CreateFolder| ...On Node:H16N2 creating folder: \\H16N2\C$\MS_DATA\190820-103322
            190820-103322|0:0|0:0|CreateFolder| try:CreateFolder: \\H16N2\C$\MS_DATA\190820-103322
            190820-103322|0:0|0:0|CreateFolder| Folder \\H16N2\C$\MS_DATA\190820-103322 could be created successfully
            190820-103322|0:0|0:0|CreateFolder| Exit
        #>
        write-host $Description
        $Description | Out-File -FilePath $DebugLogPathFull -Append
        $Script:RunOnlyOnce= $False
    }
    $FullString= "$TimeDisplay|$DurScriptDisplay|$DurFunctionDisplay|$FuncName| $MessageUser"
    write-host -Fore $ForeColor $FullString
    
    # if $DebugLogToFile is $Ture store Output in the Logfile
    if ($DebugLogToFile){
        $Script:DebugLogCount++
        $Script:DebugLogBuffer+= $FullString
        #write-host "DebugLogCount: $($Script:DebugLogCount)"
        if ( ($Script:DebugLogCount -ge $DebugLogCountMax) -or ($EndOfScript) )  {
            write-host -ForegroundColor Yellow "Flushing DebugLogBuffer to $DebugLogPathFull"
            $Script:DebugLogBuffer | Out-File -FilePath $DebugLogPathFull -Append

            $Script:DebugLogCount= 0    # Reset DebugLogCount to 0
            $Script:DebugLogBuffer= @() # Reset DebugLogBuffer to empty String        
        }
    }
} # End of ShowProgress


function IsLogFromCluster2016OorLater{
    param(
        $ClusterLogPathFull
    )
    ShowProgress "Enter"
    $IsLog2016OorLater=$false
    $FirstLine= Get-Content -path $ClusterLogPathFull -First 1
    if ( !($FirstLine.Contains("[=== Cluster") ) ) { # if First Line of ClusterLog does not contain "[=== Cluster" it�s server 2012 or older
        #write-host "The Clusterlog: $ClusterLogPathFull does not contain any Config Infos"
        #write-host "Config Info is only available in Server 2016 or later"        
    }
    else{
        $IsLog2016OorLater= $true
    }
    ShowProgress "Exit"
    Return $IsLog2016OorLater
}

function GetNodeName{
    ShowProgress "Enter"
    $C= Get-Content -path $ClusterLogPathFull -First 20

    foreach($Line in $C){
        if ( $Line.Contains("Current node:") ){
            $Line -match '(?<NodeName>name\s\((.*))\)\sid' | Out-Null
            $s= $matches.NodeName
            $NodeName= $s.Replace('name (','')                
        }    
    }
    ShowProgress "Exit"
    Return $NodeName
}

function GetClusterLogHeaderLines{
    param(
        $ClusterLogPathFull,
        $NumOfLines
    )
    ShowProgress "Enter"
    ShowProgress "`$Lines= Get-ChildItem -path `$ClusterLogPathFull | Get-Content -First $NumOfLines"
    $Lines= Get-ChildItem -path $ClusterLogPathFull | Get-Content -First $NumOfLines
    ShowProgress "Exit"
    Return $Lines
}

function GetClusterLogAllLines{
    param(
        $ClusterLogPathFull
    )
    ShowProgress "Enter"
    ShowProgress "`$Lines= Get-ChildItem -path `$ClusterLogPathFull | Get-Content"
    $Lines= Get-ChildItem -path $ClusterLogPathFull | Get-Content
    ShowProgress "Exit"
    Return $Lines
}


function GetFirstClusterLogFile{
    Param(
        $Path
    )
    
    $FoundClusterLogWithHeaderInfo= $False # Declare a Bool Variable that tells us if we found a ClusterLogFile with Header info - set false for now

    $ClusterLogFiles= Get-ChildItem -Path "$Path\*Cluster*log"
    foreach($File in $ClusterLogFiles){
        $FirstLine= Get-Content -Path $File.FullName -First 1
        If ($FirstLine.Contains("[=== Cluster") ) { # if its a Cluster Log that contains Header Lines with config info
            $FoundClusterLogWithHeaderInfo= $True  # So we found at least 1 cluster Log with Header Info
            $ClusterLogPathFull= $File.FullName
            ShowProgress -ForeColor Green "Found *Cluster*Log file with config Info: $($ClusterLogPathFull)"
            BREAK # Get out of this loop
        }        
    }
    If (!($FoundClusterLogWithHeaderInfo)){ # if we did not find a Cluster Log file with Header Lines
        ShowProgress -ForeColor Magenta "Could not fine a *Cluster*Log File with Config Info in $Path"
        ShowProgress -ForeColor Magenta "Please enter a valid path to a cluster Log file"
        Exit # Get out of this script
    }
    Return $ClusterLogPathFull
}

function GetClusterLogFileFullPath{
    param(
        $Path
    )

    if (Test-Path $Path){ # if $Path exists     
        if ( ((Get-Item $Path).PSIsContainer) ){ # if $Path is a Directory 
            $ClusterLogPathFull= GetFirstClusterLogFile -Path $Path                   
        }
        else{ # if $Path is Cluster Log Files are 
            $ClusterLogPathFull= $Path
        }    
    } # if $Path does not exist
    else{
        ShowProgress -ForeColor Magenta "The following Path does not exist: $($Path)"
        ShowProgress -ForeColor Magenta "Please enter a valid Path"
        EXIT # Get out of this script
    }
    Return $ClusterLogPathFull
}

function RemoveClusConfigCsv{
    param(
        $DataPath,
        $Prefix
    )
    ShowProgress "Enter"
    $ClusConfigCsvFiles= Get-ChildItem -Path "$DataPath\$Prefix-*.csv"
    $ClusConfigCsvFiles | Remove-Item     
    ShowProgress "Exit"
}

function HEX2DEC {    
    param(
        $HEX
    )
    #ShowProgress "Enter"
    $DEC= [System.Convert]::ToInt32($HEX,16)
    #ShowProgress "Exit"
    Return $DEC
}

function DEC2HEX{
    param(
        $DEC
    )
    ShowProgress "Enter"
    foreach($value in $DEC){
        �{0:x}� -f [UInt32]$value
    }
    ShowProgress "Exit"
}


function MapResIDToName{
    param(
        $sResID,
        $oClusResAll
    )
    $oRes= $oClusResAll | Where-Object {$_.ObjectID -eq "$sResID"}
    $ResName= $oRes.ObjectName
    Return $ResName
}

function MapNodeIdToName{
    param(
        $NodeId, 
        $Nodes
    )
    $oNode= $Nodes | Where-Object {$_.NodeNumber -eq $NodeId}
    $NodeName= $oNode.Name
    Return $NodeName   
}


function GetResNamesInGroup{
    param(
        $oGroup,
        $oClusResAll
    )
    $sResIdsAsOneString= $oGroup.Resources      # Get ResourceId�s as one big string
    $aResIdsInGroup= $sResIdsAsOneString.Split(" ")   # Get ResourceId�s one string per Resource
    
    $ResNames=@()
    foreach($sResId in $aResIdsInGroup ){
        if (!([string]::IsNullOrEmpty($sResId)) ) { # if $sResId is not Null or empty
            $sResName= MapResIDToName -sResID $sResId -oClusResAll $oClusResAll
            $ResNames+= $sResName
        }
        else{
            # the element of this array does not contain a ResId - ignore it
        }
    }

    #$oGroup | Add-Member -NotePropertyName $ResNames -NotePropertyValue $ResNames
        
    Return $ResNames
}

function CreateClusterGroup{
    param(
        $oClusGroups, 
        $oClusNodes,
        $ClusResAll        
    )
    $oGroups= @()
    foreach($oGroup in $oClusGroups){
        $ResNames= GetResNamesInGroup -oGroup $oGroup -oClusResAll $oClusResAll

        $G= [PSCustomObject][ordered]@{ 
                GroupName=        $oGroup.ObjectName
                GroupId=          $oGroup.ObjectId
                GroupType=        $oGroup._groupType
                GroupStartDelay=  $oGroup._groupStartDelay
                GroupStatusInfo=  $oGroup._groupStatusInformation
                ResNames=         $ResNames
                ResIds=           $oGroup.resources
                OwnerNodeId=      $oGroup._pOwnerNode
                OwnerNodeName=    MapNodeIdToName -NodeId ($oGroup._pOwnerNode) -Nodes $oClusNodes
                DefaultOwner=     $oGroup._defaultOwner
                PreviousOwner=    $oGroup._previousOwner
                PreferredOwners=  $oGroup._preferredOwners
                Priority=         $oGroup._priority
                State=            $oGroup._state
                IsCore=           $oGroup._isCore
                LastOnlineNode=   $oGroup._lastOnlineNode
                LastOfflineNode=  $oGroup._lastOnlineOffline
                LastFailOverTime= $oGroup._lastFailoverTime
                FailoverThreshold=$oGroup._failoverThreshold
                FailoverPeriod=   $oGroup._failoverPeriod
                AutoFailBackType= $oGroup._autoFailbackType
                Description=      $oGroup._description
                MoveType=         $oGroup._moveType
                MoveTarget=       $oGroup._moveTarget
        }
        $oGroups+= $G # Add New Object to the Dynamic Array    
    }
    Return $oGroups
}

#endregion    ::::: Helper Functions :::::



ShowProgress "Basic Preparations End"

#endregion ::::: Basic Preparations :::::

#region    ::::: Workerfunctions ::::: 

function GetPIDTID{ # Function to get ProcessID�s in Cluster Log - Needs a File where we can get the Process IDs from    
    param(
        $ClusterLogAllLines # Pass $ClusterLogAllLines
    )
    ShowProgress "Enter"
    IF ($FindPIDs -eq $false){
        ShowProgress "Exit as `$FindPIDs switch is not true"
        RETURN # exit this function, if the switch $FindPIDs is false
    }
    $Lines= $ClusterLogAllLines
    $dPIDs= @()

    # Walk through each Line of the Cluster Log    
    $i=0
    ShowProgress -ForeColor Green "Total Lines in ClusterLog $($ClusterLogPathFull): $($Lines.Count)"
    $LinesWithColon= $Lines | Where {$_.Contains("::")}    
    $hPIDs= $LinesWithColon | ForEach-Object {$_ -match '(?<PID>[0-9a-f]*)\.[0-9a-f]*::' | Out-Null ; $hPID= $Matches.PID; $hPID }
    $hP= $hPIDs | Group
        
    $hAllPIDs= $hP.Name # $dP.Name are all PIDs in the Cluster Logs we found 
    
    $PIDProcName= @() 
    $sPIDS= @()

    if ($FileWithProcessInfoPathFull -ne ""){ # If a path to a File with Process Info was passed
        if  (Test-Path $FileWithProcessInfoPathFull) { # If we have a file that contains process Info
            $ProcInfoAvailable= $True
            $I= Import-Clixml -path $FileWithProcessInfoPathFull # Thats the file where we can find the Process Objects
        
            if ( !([string]::IsNullOrWhiteSpace($I.Process)) ){ #if $FileWithProcessInfoPathFull was collected with GetLogs
                $Processes= $I.Process
            }
            else{ # if $FileWithProcessInfoPathFull is a single file that only contains Process Objects
                  # Could be collected with e.g. Get-Process | Export-Clixml -Path "H19N1-Process.xml"
                $Processes= $I
            }
        }
    }

    # Now walk through each of the PIDs
    foreach($hPID in $hAllPIDs){        
        if ($ProcInfoAvailable){ # If there is a *.xml file that contains Process Name and Id Info
            $dPID= HEX2DEC -HEX $hPID 
            $ProcName= ($Processes | Where {$_.ID -eq $dPID}).ProcessName # Find the Process Obj with matching $PID      
        }
        else{
            $ProcName= "Cant find Process Info File $FileWithProcessInfoPathFull"
        }
        
        $PP= [PSCustomObject][ordered]@{  
            hPID=        $hPID                 # Current Process ID in DEC
            dPID=        HEX2DEC -HEX $hPID    # Current Process ID in HEX
            ProcessName= $ProcName             # Process Name
        }
        $PIDProcName+= $PP # Add New Object to the Dynamic Array    
    }        
    "Processes that wrote into ClusterLog:$ClusterLogPathFull" | Out-File -FilePath "$DataPath\$Prefix-ProcessIDs.txt"
    $PIDProcName                                               | Out-File -FilePath "$DataPath\$Prefix-ProcessIDs.txt" -Append
    ShowProgress "Exit"
    Return $PIDProcName
}

function CreateConfigFilescsv{    
    param(
        $ClusterLogHeaderLines # Pass $ClusterLogHeaderLines
    )
    $Lines= $ClusterLogHeaderLines    
    ShowProgress "Enter"
    # Get Content of Cluster Log 
    $TopicLineNums= @() # Empty Arry to take Line numbers of the topics    
    #Walk through each line and check for "[===" which is a Topic Line like [=== Nodes ====]
    $i=0
    foreach($Line in $Lines){
        if($Line.Contains("[===")){ # find Topic Lines
            $TopicLineNums+= $i     # Add Topic LineNumber e.g. 10 to dynamic Array $TopicLineNums
        }
        $i++    
    }

    # $TopicLineNums # Spew out TopicLineNums
        
    $j=0
    # Walk through Topic Line Numbers
    foreach($TopicLineNum in $TopicLineNums){    
        # Get Topic Name
        $TopicName=    $Lines[$TopicLineNum]          # [=== Cluster ====] etc. 
        $Name=     $TopicName.Replace("[=== ","")
        $Name=     $Name.Replace(" ===]","")  # Cluster

        # if we have reached the Topic [=== System ===] , than exit this loop immediately, don�t want to read the rest
        if ($Name -eq "System" ){
            BREAK # exit this loop
        }

        $FileName=     "$Prefix-$Name.csv"   # File Name Mask for the Topic Files like ClusConfig-Nodes.csv
        $FileNameFull= ( (Split-Path $ClusterLogPathFull) + "\$FileName" ) # Create Full File Name including the path

        New-Item -Path $FileNameFull -Type File -Force | Out-Null # Create File
        #write-host "FileNameFull: $($FileNameFull)"
        #$Lines[$TopicLineNum] | Out-File -FilePath $FileNameFull

        # Calculate Number of lines of this topic by substracting the Line Number of the next Topic from the Line Number of the current Topic
        $NumOfLines= $TopicLineNums[$j+1] - $TopicLineNums[$j] 
        #write-host "j:$j"    

        # CheckForDuplicateMembers in the first Line of the Topic                           
        # e.g. Duplicate string "Ignore" Name,Id,Description,NodeId,NetworkId,AdapterName,ClusnetEndpoint,AdapterId,Addresses,Address,InterfaceIndex,STATE,Ignore,DhcpEnabled,isConnectedToiSCSI,HasDefaultGateway,Connected,initialState,ignore,        
        $FirstLine= $Lines[$TopicLineNum+1] # First line under Topic "Network Interfaces"

        # Check for Duplicate MemberNames
        $DuplicateName= (($FirstLine.split(",") | Group-Object) | Where-Object count -gt 1).Name # Check if we have duplicate properties and get the name of it; Who knows, when they fix it

        if ($Null -ne $DuplicateName){ # if we have a duplicate Name Rename the 2nd and 3rd ..occurance
            
            $sProps= $FirstLine.Split(",")

            $PropString= ""
            $FirstTime= $True
            $i=2
            foreach($P in $sProps){    

                if ($P -ne $DuplicateName){
                    # if its not the duplicate Property Name
                    $PropString+= "$P,"
                }    
       
                if ( ($P -eq $DuplicateName) -and ($FirstTime -eq $False) ){
                    $P= "$P$i"
                    $PropString+= "$P,"
                    $i++
                }
    
                if ( ($P -eq $DuplicateName) -and $FirstTime)  { # if its duplicate Property Name and the first time        
                    $PropString+= "$P,"  # write prop as is
                    $FirstTime= $False   # set FirstTime to false
                        
                }
            }
            $L= $PropString.Length
            $CorrectFirstLine= $PropString.Remove($L-1)                     

            # Correct String:  Name,Id,Description,NodeId,NetworkId,AdapterName,ClusnetEndpoint,AdapterId,Addresses,Address,InterfaceIndex,STATE,Ignore,DhcpEnabled,isConnectedToiSCSI,HasDefaultGateway,Connected,initialState,  
            # CorrectFirstLine with renamed Duplicate Member Name like _embeddedFailureAction, ...., _embeddedFailureAction2
            #: "ObjectId,ObjectName,...several Members...,_embeddedFailureAction,_isNetworkFailure,...some Members...,_embeddedFailureAction2,...some Members....,lastStateChangeTime,
            $CorrectFirstLine | Out-File -FilePath $FileNameFull -Append # Add the Correct first Line to the *.csv file               
            $StartInLine= 2  # As we already wrote the first line in case of a Duplicate Member we will set $StartInLine to 2                      
        
        }        
        else{ # if we do not have a duplicate name - then the bug is fixed and we simply write the first line to the file 
            $FirstLine | Out-File -FilePath $FileNameFull -Append                
            $StartInLine= 1                            
        }

        # Walk through each line of this topic below the topic string
        for($i= $TopicLineNum+$StartInLine;$i -lt $TopicLineNums[$j+1]; $i++){ # if we found a Duplicate Member above, we start in 2nd Line
            # write-host "i: $i NumofLines:$NumOfLines"
            #write-host "$($Lines[$i]))"
            $Lines[$i] | Out-File -FilePath $FileNameFull -Append                
        }
        $j++  # Increment TopicLIneNum
        # if we reach the last topic - exit loop - should not happen, as we should exit at [=== System ===]
        if ($j -ge $TopicLineNums.Length-1){
            BREAK
        }     
    }    
    ShowProgress "Exit"
}

function CreateConfigAllFilexml{
    param(
        $DataPath,
        $ClusConfigAllxml,
        $PIDProcName

    )
    ShowProgress "Enter"
    # Read ClusConfig*.CSV files    
    $ClusConfigFiles= Get-ChildItem -Path "$DataPath\$Prefix-*.csv"

    $Commands=
    ("
      `$C= Import-CliXml -path 'FullPathToYourXMLFile' e.g. `$I= Import-CliXML -path `"C:\MS_DATA\191113-113833\ClusConfig.xml`"
      `$C.Nodes
    ")

    $ClusConfig= [PSCustomObject][ordered]@{  
        Commands= $Commands

    }

    foreach($File in $ClusConfigFiles){
        $I= Import-CSV -path $File.FullName
        # write-host "FileName: $($File.Name)"
        # Create Property Name from File Name like "ClusConfig-Network Interfaces.csv"              
        # Use Regular Expression (RegEx) to filter out the Topic Name like "Network Interfaces"
        $File.Name -match 'ClusConfig-(?<TopicName>[\w\s]*)\.csv' | Out-Null  #[\w any word char; \s space; * 0 or more occurencies
        $PropName= $matches.TopicName        
        $PropName= $PropName.Replace(" ","")  # Remove spaces in the Name
        #Write-host "PropName: $PropName"

        #Add all Objects from each *.csv File that we imported to the Config.xml file
        $ClusConfig | Add-Member -NotePropertyName $PropName -NotePropertyValue $I     
    }

    # Add Group2 Property, which contains resolved ResNames and NodeNames
    $oClusGroups= $ClusConfig.Groups 
    $oClusResAll= $ClusConfig.Resources # Get ClusterResources as PSObject
    $oClusNodes=  $ClusConfig.Nodes
    $Groups2= CreateClusterGroup -oClusGroups $oClusGroups -oClusNodes $oClusNodes -ClusResAll $oClusResAll
    $ClusConfig | Add-Member -NotePropertyName "Groups2" -NotePropertyValue $Groups2 # Add Groups2 to the Object


    # Add ProcessIDs Property
    if ($FindPIDs -eq $True){ # if switch FindPIDs is $True then Add this NoteProperty
        $ClusConfig | Add-Member -NotePropertyName "ProcessIDs" -NotePropertyValue $PIDProcName # Add Process ID�s in the Cluster Log     
    }
    $ClusConfig | Export-Clixml -Path $ClusConfigAllxml    # Export to *.xml file
    <#
        $ClusConfig | Export-CSV    -Path "$DataPath\ClusConfig-All.csv"    # Export to Comma separated version file
        $ClusConfig | ConvertTo-Json -Depth 1 | Set-Content -Path "$DataPath\ClusConfig-All.json"  # Export to json file    

        #Import 
        Get-Content -Path "$PathFUll.Json" -Raw | ConvertFrom-Json # Import json
    #>
    ShowProgress "Exit"
}

function CreateClusConfigAllOverviewtxt{
    param(
        $ClusConfigAllxml,
        $PIDProcName
    )
    ShowProgress "Enter"
    $A= Import-CliXml -path $ClusConfigAllxml  # Import *.xml file with Cluster Config PSObjects

    # Create File ClusConfig-All-Overview.txt
    $str= @()

    $str+= "[=== Cluster ===]" + (":"*150)
    $str+=  $A.Cluster
    $str+= ""; $str+= "" # Add empty Lines


    $str+= "[=== Resources ===]" + (":"*150)
    $str+= $A.Resources | ft *Name, ObjectId, resourceType, _state, OwnerGroup, _looksAliveInterval, _isAliveInterval, _deadlockTimeout, _pendingTimeout
    $str+= $A.Resources | ft *Name, _looksAliveInterval, _isAliveInterval, _deadlockTimeout, _pendingTimeout, _separateMonitor, _restartAction, _restartPeriod, _restartThreshold, _immediateDelayRestartTime
    $str+= $A.Resources | ft *Name, _separateMonitor, _flags, _restartAction, _restartPeriod, _restartThreshold, _immediateDelayRestartTime, _persistentState
    $str+= $A.Resources | ft *Name, *fail*
    $str+= $A.Resources | ft *Name, *state*
    $str+= $A.Resources | ft *Name, *process*
    $str+= $A.Resources | ft *Name, *attach*
    $str+= $A.Resources | ft *Name, _beingDeleted, _issueInitializeControl, _poisoned
    $str+= ""; $str+= "" # Add empty Lines


    $str+= "[=== Groups ===]" + (":"*150)
    $str+= $A.Groups | ft *Name, ObjectId, _groupType, _pOwnerNode, _state
    $str+= $A.Resources | ft *Name,  @{Label="FailureTime";Expression={[DateTime]::FromFileTime($_._failureTime)}}, _failureCount, *failure*, _isFailingDueToVeto
    #$str+= $A.Groups | ft *Name, *fail*  
    $str+= $A.Groups | fl *Name, resources
    $str+= $A.Groups | ft *Name, *owner* 
    $str+= $A.Groups | ft *Name, *state*  
    $str+= $A.Groups | ft *Name, *time*
    $str+= $A.Groups | ft *Name, *move*
    $str+= ""; $str+= "" # Add empty Lines

    $str+= "[=== Groups2 ===]" + (":"*150)
    $str+= $A.Groups2 | ft GroupName, Description
    $str+= $A.Groups2 | ft GroupName, State, IsCore, Priority, Last*, Failover*, AutoFailBackType, Move*
    $str+= $A.Groups2 | ft Group* 
    $str+= $A.Groups2 | ft GroupName, ResNames    
    $str+= $A.Groups2 | ForEach-Object {$_.GroupName ; "========================"; $_ | Select -ExpandProp ResNames; "";""}     
    $str+= $A.Groups2 | ft GroupName, ResIds
    $str+= $A.Groups2 | ft GroupName, *Owner*
    $str+= $A.Groups2 | ft GroupName 
    $str+= ""; $str+= "" # Add empty Lines


    $str+= "[=== Group Sets ===]" + (":"*150)
    $str+= $A.GroupSets
    $str+= ""; $str+= "" # Add empty Lines


    $str+= "[=== Resource Types ===]" + (":"*150)
    $str+= $A.ResourceTypes | ft *Name, PossibleNodes, *Time*, *Live*, _useStorageMonitor, _deadlockTimeout, _dumpPolicy  
    $str+= ""; $str+= "" # Add empty Lines


    $str+= "[=== Nodes ===]" + (":"*150)
    $str+= $A.Nodes | Sort-Object -Property Id | ft Name, Id, comp, state, paused, stopped, isShuttingDown,  failureReported, NodeNumber, IsLocalNode
    $str+= ""; $str+= "" # Add empty Lines


    $str+= "[=== Networks ===]" + (":"*150)
    $str+= $A.Networks | ft Name, Id, description, role, transport, ignore, state, linkSpeed, rdmacapable, autoMetric, metric 
    $str+= $A.Networks | ft Name, *address*, PrefixList 
    $str+= $A.Networks | ft Name, AssociatedInterfaces
    $str+= ""; $str+= "" # Add empty Lines


    $str+= "[=== Network Interfaces ===]"
    $str+= $A.NetworkInterfaces | sort name | ft Name, Id, Description, NodeId, NetworkId, AdapterName, ClusnetEndpoint, AdapterId
    $str+= $A.NetworkInterfaces | sort name | ft Name, Addresses  
    $str+= $A.NetworkInterfaces | sort name | ft Name, Address, InterfaceIndex, STATE, DhcpEnabled, isConnectedToiSCSI, HasDefaultGateway, Connected, initialState, ignore  
    $str+= ""; $str+= "" # Add empty Lines


    $str+= "[=== Volumes ===]" + (":"*150)
    $str+= $A.Volumes | ft *friendlyName, ResourceId, DiskNumber, SectorSize, PartitionNumber, DriveLetterMask, EnforceWriteThrough, EnableBlockCache, diskConnectivity, Mds*
    $str+= $A.Volumes | ft *friendlyName, _pseudoVolumeGuid, _volumeFullName,  RealVolumeGuid 
    $str+= $A.Volumes | ft *friendlyName, _parentVolumeId,  VolumeUniqueId,  VolumeNumber, VolumeOffset

    $str+= $A.Volumes | ft *Name*
    $str+= $A.Volumes | ft *friendlyName, FileSystemLength, SerialNumber, mappingMode, InitForDismount, DismountingNode, IsReadOnly, SnapshotInProgress, RedirectIoForSnapshot, stateChangeEvent
    $str+= $A.Volumes | ft *friendlyName, Desired, Actual, SequenceId, StateChangeTickCount, NFilterPaused, FilterContext, CsvFsState, StateChangeCounter
    $str+= $A.Volumes | ft *friendlyName, LastMappingMode, isDismounted, isActive, snapshotType
    $str+= ""; $str+= "" # Add empty Lines


    $str+= "[=== Volume Logs ===]" + (":"*150)
    $str+= $A.VolumeLogs
    $str+= ""; $str+= "" # Add empty Lines


    $str+= "[=== SBL Disks ===]" + (":"*150)
    $str+= $A.SBLDisks | ft DeviceNumber, *Id*
    $str+= $A.SBLDisks | ft DeviceNumber, IsSblCacheDevice, HasSeekPenalty, NumPaths, DiskState, BindingAttributes, DirtyPages, DirtySlots
    $str+= $A.SBLDisks | ft DeviceNumber, IsMaintenanceMode, IsOrphan, SblAttributes, Manufacturer, ProductId, Serial, Revision, HealthCounters
    $str+= ""; $str+= "" # Add empty Lines


    $str+= "[=== Certificates ===]" + (":"*150)
    $str+= $A.Certificates | ft *
    $str+= ""; $str+= "" # Add empty Lines


    $str+= "[=== Performance ===]" + (":"*150)
    $str+= $A.Performance | ft * 
    $str+= ""; $str+= "" # Add empty Lines

    if ($FindPIDs -eq $True){
        $str+= "==== PIDs of Processes that have written to the Cluster Log ==="  + (":"*150)
        $str+= $PIDProcName
    }

    $str | Out-File -FilePath $ClusConfigAllOverviewtxt

    ShowProgress "Exit"
}

function CreateClusConfigAlltxt{
    param(
        $ClusConfigAllxml, 
        $PIDProcName,
        $ClusConfigAlltxt
    )
    ShowProgress "Enter"
    $A= Import-CliXml -path $ClusConfigAllxml  # Import *.xml file with Cluste Config PSObjects
    $str2= @()
    # Create ClusConfig-All-Overview.txt
    $TopicNames= ($A | gm | where { $_.MemberType -eq "NoteProperty" }).Name

    foreach($Name in $TopicNames){
        $str2+= "[=== $Name ===]" + (":"*150)
        if ($Name -eq "Cluster"){
            $str2+= $A.$Name     
        }
        else{
            $str2+= $A.$Name | fl *
        }        
        $str2+= ""; $str+= "" # Add empty Lines
    }

    $str2+= "==== PIDs of Processes that have written to the Cluster Log ==="  + (":"*150)
    $str2+= $PIDProcName
 
    $str2 |  Out-File -FilePath $ClusConfigAlltxt
    ShowProgress "Exit"
}

#endregion    ::::: Workerfunctions ::::: 



#region       ::::: Basic Preparations :::::
# If $Path is a Full Path to a *Cluster*Log file that�s it, otherwise find first *Cluster*Log file with config info in $Path
$ClusterLogPathFull = GetClusterLogFileFullPath -Path $Path 
$DataPath= $ClusterLogPathFull | Split-Path  # Path to ClusConfig*.csv Files 
$ClusterLogFileNameNoExt= (Split-Path $ClusterLogPathFull -Leaf)

#$NodeName= GetNodeName
#$Prefix= "$NodeName-ClusConfig"
$Prefix= "$ClusterLogFileNameNoExt-ClusConfig"

$ClusConfigAllxml=         "$DataPath\$Prefix-All.xml"           # *.xml file that contains all PS Objects of Cluster Config
$ClusConfigAlltxt=         "$DataPath\$Prefix-All.txt"           # .txt file that contains all Info as txt | fl *
$ClusConfigAllOverviewtxt= "$DataPath\$Prefix-All-Overview.txt"  # Overview of Cluster Config in Tables


#function Show Progress - Global parameters
$Script:TimeStampScriptStart= Get-Date
$sTimeStampScriptStart= [String](Get-Date -Format 'yyMMdd-HHmmss') # Date as String to be used in Folder Name for Files e.g. MS_DATA\190820-1032
$TimeStampScriptStart = Get-Date				         # get the timestamp, when this script starts
$TimeStampStartSaved  = $Script:TimeStampScriptStart	 # only first time save the script start timestamp
$DebugLogPath         = $DataPath                        # Directory, where the logs are stored
$DebugLogPathFull     = "$DataPath\$Prefix-$sTimeStampScriptStart-ScriptDebug.txt"   # FullPath of the Scripts Debug.log
$DebugLogLevel        = 3                                # If DebugLogLevel is 3 everything is logged; 0 is disabled, 1=Light, 2= Medium, 3=All
$DebugLogBuffer       = @()                              # Collect DebugLog Messages in ShowProgress and save them later to a file
$DebugLogCount        = 0                                # Counter for DebugLogs
$DebugLogCountMax     = 200                              # After X Messages Save to file 
$DebugLogToFile       = $True                            # Default is True, so we spew out the Debug Messages to a File 
$RunOnlyOnce          = $True                            # Bool to spew out some Messages only once
$ScriptFullName       = $MyInvocation.InvocationName     # Full Path of the Script Name
#END of Show Progress - Global parameters
#endregion       ::::: Basic Preparations :::::


#region    ::::: MAIN ::::: 
# ========================================================= MAIN ==============================================================
ShowProgress "Enter - MAIN"


# if $FindPIDs is true 
if ($FindPIDs.IsPresent){ # Only run this option alone, as it takes a very long time
    ShowProgress -ForeColor Green  "Find PIDs in ClusterLogFile: $ClusterLogPathFull"
    ShowProgress -ForeColor Yellow "This could take a couple of min- depending on file size...."
    ShowProgress ""
    $ClusterLogAllLines = GetClusterLogAllLines -ClusterLogPathFull $ClusterLogPathFull    
    $PIDProcName= GetPIDTID -ClusterLogAllLines $ClusterLogAllLines # find all PIDs - Save $PIDProcName as global Var to be reused on later functions           
}

# Check if we have a cluster Log of Server 2016 or later; only those contain config info; if not exit
if ( (IsLogFromCluster2016OorLater $ClusterLogPathFull) ){ 
    
    # Read first around 1000 Lines to be sure the Config Inf is in; makes things faster
    $ClusterLogHeaderLines= GetClusterLogHeaderLines -ClusterLogPathFull $ClusterLogPathFull -NumOfLines 1000 
    
    # Read Header of Cluster Log and create *.csv files cluster.csv, Nodes.csv...
    CreateConfigFilescsv   -ClusterLogHeaderLines $ClusterLogHeaderLines     

    # Read Header of Cluster Log and create *.xml file that contains all Info as Object
    CreateConfigAllFilexml  -DataPath $DataPath -ClusConfigAllxml $ClusConfigAllxml -PIDProcName $PIDProcName
    
    # Create Overview *.txt file; Tables with most important Info
    CreateClusConfigAllOverviewtxt -ClusConfigAllxml $ClusConfigAllxml -PIDProcName $PIDProcName 
    
    # Create *.txt file that contains all Info; $A.$Name | fl *
    CreateClusConfigAlltxt  -ClusConfigAllxml $ClusConfigAllxml -ClusConfigAlltxt  $ClusConfigAlltxt -PIDProcName $PIDProcName

    RemoveClusConfigCsv -DataPath $DataPath -Prefix $Prefix   # Remove the Cluster-CSV files     
}
else{
    ShowProgress -ForeColor Magenta "ClusterLogFile is not of Server 2016 or later: $ClusterLogPathFull "
    ShowProgress ""
}


# End of Script Messages
$TimeStampScriptEnd= Get-Date
$ScriptRunDuration= ($TimeStampScriptEnd-$TimeStampScriptStart).Seconds
if ($ScriptRunDuration -le 0){
    $ScriptRunDuration= 1
}
# EndOfScript Marker - need to guarantee, that the rest of the Messages in the Buffer are flushed to *ScriptDebug.txt
ShowProgress -EndOfScript $True -MessageUser "End of Script - Script ran [Sec]: $ScriptRunDuration " 

#endregion    ::::: MAIN ::::: 

