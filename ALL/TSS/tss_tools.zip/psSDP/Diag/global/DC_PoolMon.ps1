﻿#************************************************
# DC_PoolMon.ps1
# Version 1.0
# Date: 05-22-2020
# Author: Walter Eder
# Updated: 
# Description: This script obtains DC_PoolMon Snaps
#              via the DC_PoolMon.exe tool, saving output to a
#              file named $ComputerName_DC_PoolMon.txt
#************************************************
#Last Updated Date: 05-22-2020
#Updated By: 
#Description: 
#************************************************

if($debug -eq $true){[void]$shell.popup("Run DC_PoolMon.ps1")}
Import-LocalizedData -BindingVariable PoolMonStrings -FileName DC_PoolMon -UICulture en-us
	
Write-DiagProgress -Activity $PoolMonStrings.ID_PoolMon -Status $PoolMonStrings.ID_PoolMonRunning

$fileDescription = $PoolMonStrings.ID_PoolMonOutput
$sectionDescription = $PoolMonStrings.ID_PoolMonOutputDesc
$OutputFile = $ComputerName + "_PoolMon.txt"
$CommandToExecute = "cmd.exe /c PoolMon.exe -t -b -r -n $OutputFile"
if ($OSArchitecture -ne 'ARM')
{
	RunCmD -commandToRun $CommandToExecute -sectionDescription $sectionDescription -filesToCollect $OutputFile -fileDescription $fileDescription -BackgroundExecution
}
else
{
	 'Skipping running {PoolMon.exe} since it is not supported in ' + $OSArchitecture + ' architecture.' | WriteTo-StdOut
}
