﻿<# Script name: tss_Cluster_GetLogs.ps1 
::
::  THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
::  ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
::  IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
::  PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
::
#> 

<#  
    .SYNOPSIS 
        Script to gather certain logs

    .DESCRIPTION 
        Please run the script on one of the Cluster Nodes
        This Script collects eventlogs, Cluster logs, Cluster config data...
        At the end you´ll get a *.zip file

        FEEDBACK
        Emanuel Nicolae Lego
        - Failover Cluster Operational Logs ( Josefh ) 
        - Cluster Validation Reports (Josefh ) 
        - MS_Info32.nfo ( Josefh ) 
        - HyperV-Logs (VMMS, HyperV SDP) (Robert Vierthaler) 
        - Patchliste für RFL Check (Walter Eder)

        Josef Holzer
        - Define how far we should go back in the logs
          $Evts= Get-WinEvent -LogName $LogName | Where-Object {$_.TimeCreated -ge ( (Get-Date).AddHours( -1 * $MinutesBack )) } 
          Return $Evts
        - Check if we have enough space on the disk 

    
    .PARAMETER LogPathLocal
        Pass your own Path where you want to store the files 
        default is a Path under C:\ with the current time stamp; like c:\180425-100734-SDP
    
    
    .PARAMETER LogNames
        Define your Eventlogs you want to gather; Default is below 
        -LogNames "System", "Application", "*CSVFS*", "*Smb*", "*winrm*", "*wmi*", "*spaces*" 
    
            
    .Example 
        .\GetLogs-180425.ps1
        This will run the script with default parameters
        It will create a directory like c:\180425-100734-SDP and store all data there
        You´ll get a *.zip file in this directory like 180425-094956-MSDATA.zip

    .EXAMPLE 
        .\GetLogs-180425.ps1 -LogPathLocal C:\temp\MSDATA
        This will create the folder C:\temp\MSDATA and store the data there 
        You´ll get a *.zip file in this directory like 180425-094956-MSDATA.zip

    .LINK 
        To provide feedback write a mail to josefh@microsoft.com

#> 

param(
	#[ValidateScript({Test-Path -LiteralPath $_ -PathType 'Container'})]
	[Parameter(Mandatory=$False,Position=0,HelpMessage='Choose a writable output folder location, i.e. C:\Temp\ ')]
	[string]$DataPath = (Split-Path $MyInvocation.MyCommand.Path -Parent)
	,
	[switch]$ZipData,
	[switch]$Tcmd,
	[switch]$ScanEventLog,
	[switch]$Livekd
)

#region ::::: Helper Functions Begin :::::


# Helperfunction to show what we are doing so far; should be placed on Top of the script...
$TimeStampScriptStart= Get-Date # ...to get the Timestamp, when this script starts
$TimeStampStartSaved  = $TimeStampScriptStart  # Only First time save the script start Timestamp
Function ShowProgress { # <josefh:ShowProgress helper function
    param(
        $MessageUser="",       # pass your own Message
        $ForeColor=  "white",  # default ForeGround Color is white
        $BackColor=  "blue"    # default BackGroundColor is Blue
    )
    # Get the Function name, that was calling ShowProgress
    function GetFunctionName ([int]$StackNumber = 1) {
        # https://stackoverflow.com/questions/3689543/is-there-a-way-to-retrieve-a-powershell-function-name-from-within-a-function
        return [string]$(Get-PSCallStack)[$StackNumber].FunctionName
    }

    $Message1= [String](Get-Date -Format 'yyMMdd-HHmmss') + ": "
    $TimeStampCurrent= Get-Date
    $TimeDiffToStart= $TimeStampCurrent - $TimeStampScriptStart
    $TimeDiffToLast=  $TimeStampCurrent - $Script:TimeStampStartSaved

    $Script:TimeStampStartSaved= $TimeStampCurrent

    $Message2=  GetFunctionName -StackNumber 2 # Last Function Name
    
    $Message3= " ;Duration Min:Sec  = " + $TimeDiffToStart.Minutes + ":" + $TimeDiffToStart.Seconds
    $Message4= " ;Last Action took Min:Sec= " + $TimeDiffToLast.Minutes +  ":" + $TimeDiffToLast.Seconds

    
    if (-not ($TimeDiffToLast.TotalSeconds -ge 1) ){ $Message4= "" }
    write-host -Fore $ForeColor $Message1 $Message2 $MessageUser $Message3 $Message4
}


# Create LogFolder
function CreateLogFolderLocal{
    param(
        $LogPathLocal        
    )
    ShowProgress "...Start CreateLogFolder:$LogPathLocal"       
    # Create LocalPath, where we store all Files
    if (-not (Test-Path $LogPathLocal) ){
        write-host "creating Logpath: $LogPathLocal"
        [void](New-Item -Path $LogPathLocal -ItemType Directory)
        
        if (-not (Test-Path $LogPathLocal\EventLogs) ){
			write-host "creating Logpath: $LogPathLocal\EventLogs"
			[void](New-Item -Path "$LogPathLocal\EventLogs" -ItemType Directory)}
              
        if (-not (Test-Path $LogPathLocal\DependencyReports) ){
			write-host "creating Logpath: $LogPathLocal\DependencyReports"
			[void](New-Item -Path "$LogPathLocal\DependencyReports" -ItemType Directory)}
    }
    else{
        write-host -Fore Magenta "This Path: $LogPathLocal already exists; please pass another argument for -LogPathLocal or delete this path"
        EXIT
    }
    ShowProgress "...Finished CreateLogFolder: $LogPathLocal"       
}


function TestNodeConnection{
    param(
        $ClusterName
    )
    ShowProgress "...Start TestNodeConnection"
    $ClusterNodes= Get-ClusterNode -Cluster $ClusterName

    $GoodNodes= @()
    $BadNodes=  @()
    ForEach($ClusterNode in $ClusterNodes){
        if (Test-Connection -ComputerName $ClusterNode.Name -Count 1 -Quiet){
            $GoodNodes+= $ClusterNode
        }
        else {
            $BadNodes+= $ClusterNode
        }
    }
    $Nodes= [PSCustomObject]@{
        Good= $GoodNodes
        Bad=  $BadNodes
    }
        
    ShowProgress "   - Could     connect to Nodes: $($Nodes.Good)" -ForeColor "green"
    if ($Nodes.Bad -ne $Null){
        ShowProgress "   - Could not connect to Nodes: $($Nodes.Bad)" -ForeColor "red"
    }
    else{
        ShowProgress "   - Could connect to all Nodes" -ForeColor "green"

    }
    ShowProgress "...Finished TestNodeConnection"
    Return $Nodes.Good # Return only the Good Nodes we can reach
}
#endregion ::::: Helper Functions End :::::


#region ::::: Worker Functions Begin ::::::
# Gather Event Logs
Function GatherEventLogs{
    param(
        $ClusterName= ".",  # . is local cluster, but it could be replaced by the Cluster Name as string to run remotely
        $ClusterNodes,
        $LogNames,
        $MinutesBack
    )
    # Gather EventLogs from All Nodes 
    ForEach($ClusterNode in $ClusterNodes){        
        ForEach($LogName in $LogNames){
            $LogFamilyNames= Get-WinEvent -ListLog $LogName # LogName could be a Pattern like *SMB* which results in Several Logs
            ForEach($LogFamilyName in $LogFamilyNames){
                $LogFileName= ($LogFamilyName.LogName).Replace("/","_")
                $LogFileXML=  "$LogPathLocal\EventLogs\$($ClusterNode.Name)" + "_" + $LogFileName + ".XML"
                $LogFileTXT=  "$LogPathLocal\EventLogs\$($ClusterNode.Name)" + "_" + $LogFileName + ".Log"
                $LogFileEvtx= "$LogPathLocal\EventLogs\$($ClusterNode.Name)" + "_" + $LogFileName + ".evtx"

                #Gather SystemEventlogs
                ShowProgress "...Start Gathering EventLog: $($LogFamilyName.LogName) for Node: $($ClusterNode.Name)"

                # Collecting EventLogs respecting HoursBack
                $StartTime= (Get-Date).AddMinutes(-$MinutesBack) 
                # Using a Filter Hash Table to filter events that match $MinutesBack
                # More Info:  https://blogs.technet.microsoft.com/heyscriptingguy/2014/06/03/use-filterhashtable-to-filter-event-log-with-powershell/
                $Evts= Get-WinEvent -ComputerName $ClusterNode.Name -ErrorAction SilentlyContinue  -FilterHashtable @{Logname=$LogFamilyName.LogName; StartTime=$StartTime}

                #Sorting Events and selecting properties we really need
                $EvtsSorted= $Evts | Sort TimeCreated -Descending | Select TimeCreated, LevelDisplayName, ProviderName, Id,  Message, MachineName, ContainerLog

                # Export Events to deserialized *.xml file
                $EvtsSorted | Export-CliXml -Path $LogFileXML
                # Export Events as simple *.txt file
                $EvtsSorted | Export-Csv -Path $LogFileTXT -NoTypeInformation

                # Gathering Eventlogs in old Style *.evtx - will be implemented soon
                # wevtutil /remote:$ClusterNode.Name epl $LogFamilyName.LogName $LogFileEvtx

                ShowProgress "...Finished Gathering        $($LogFamilyName.LogName) for Node: $($ClusterNode.Name)";write-host
            }
            
        }
    }
}

# Get Cluster Logs
Function GatherClusterLogs{
    param(
        $ClusterName,     # could be replaced by the Cluster Name as string to run remotely
        $MinutesBack      # How much Minutes should we look back in the logs - it´s defined in the main chapter
    )
    
    ShowProgress "...Start Gathering Cluster Logs for Cluster Name:$ClusterName"

    # Gather ClusterLogs from All Nodes
    Get-ClusterLog -Cluster $ClusterName -TimeSpan $MinutesBack -Destination $LogPathLocal
    ShowProgress "...Finished Gathering Cluster Logs for Cluster Name:$ClusterName";write-host
}


function GatherClusterInfo{
    param(
        $ClusterName, # could be replaced by the Cluster Name as string to run remotely
        $ClusterNodes
    )
    ShowProgress "...Start Gathering ClusterInfo"
    
    $C= New-Object PSObject -Property @{ # Create your own Object with your properties 
        Name=           $ClusterName
        CSV=            Get-ClusterSharedVolume
        CSVParm=        Get-ClusterSharedVolume | Get-ClusterParameter
        CSVState=       Get-ClusterSharedVolumeState
        Group=          Get-ClusterGroup
        Net=            Get-ClusterNetwork
        NIC=            Get-ClusterNetworkInterface
        Node=           Get-ClusterNode
        Param=          Get-Cluster -Name $ClusterName | fl *
        Quorum=         Get-ClusterQuorum
        Res=            Get-ClusterResource
    }
    # Export Cluster Info 
    $FileName= "$LogPathLocal\$($ClusterName.Name)_ClusterInfo.XML"
    $C | Export-Clixml -Path $FileName
    
    # Create Dependency Reports and save to LogPathLocal
    $ClusterGroups= $C.Group
    ForEach($ClusterGroup in $ClusterGroups){
        Get-ClusterResourceDependencyReport -Group $ClusterGroup -ErrorAction SilentlyContinue | Copy-Item -Destination "$LogPathLocal\DependencyReports"
        Rename-Item -Path "$LogPathLocal\DependencyReports\$($ClusterGroup.Id).htm" -NewName "$ClusterGroup-ClusGroupDependencyRep.htm" -ErrorAction SilentlyContinue
    }
    ShowProgress "...Finished Gathering ClusterInfo - stored in  $FileName "
    ShowProgress "...Finished Gathering DependencyReports - stored in  $LogPathLocal\DependencyReports" ; write-host
}


# Collect Cluster Hive and other files you need specific to cluster Nodes
function GatherClusterHives{
    param(
        $ClusterName,  # . is Local cluster
        $ClusterNodes
    )

    ShowProgress "...Start Gathering ClusterHives..."
    
    ForEach($ClusterNode in $ClusterNodes){          # Walk through each ClusterNode 
		ShowProgress "...Start Gathering ClusterHive on $ClusterNode"
        $PathEnd= $LogPathLocal.Split(":")[1]
        $LogPathRemote= "\\$ClusterNode\C$" +"$PathEnd"
        if (-not (Test-Path $LogPathRemote) ){
            write-host creating remote Logpath and copy remote Hive: $LogPathRemote
            [void](New-Item -Path $LogPathRemote -ItemType Directory)
        }

        # Saving the cluster Hive of the current Node
        $ClusterHiveName= "$ClusterNode-Cluster.Hiv"
        $ClusterHiveNameFull= "$LogPathRemote\$ClusterHiveName"
        if (Test-Path $ClusterHiveNameFull){  # if this FullName already exists for any reasons the script would hang...
            $TimeStamp= [String](Get-Date -Format 'yyMMdd-hhmmss')  
            $ClusterHiveName= "$ClusterNode-Cluster-$TimeStamp.Hiv" # ...so let´s add a time stamp
            $ClusterHiveNameFull= "$LogPathRemote\$ClusterHiveName"
        }
        
        # Export Cluster Hive on the remote node
        Invoke-Command -ComputerName $ClusterNode -ScriptBlock { Invoke-Expression "REG SAVE 'HKLM\cluster' $Using:ClusterHiveNameFull" }

        # Copy Cluster Hive from remote node to local node we run the script from
        [void](Invoke-Expression "robocopy $LogPathRemote $LogPathLocal $ClusterHiveName")

        ShowProgress "...Finished Gathering ClusterHives on $ClusterNode - stored in $ClusterHiveName "; write-host
    }
}

function GatherNetInfoPerNode{
    param(
            $ClusterName,  # . is Local cluster 
            $ClusterNodes
        )

    ForEach($ClusterNode in $ClusterNodes){          # Walk through each FirewallRule 
        
        ShowProgress "...Start Gathering GatherNetInfoPerNode on: $ClusterNode"

        $net= [PSCustomObject][ordered]@{  
            HostName=         $ClusterNode.Name
            NetIpconfig=      Get-NetIPConfiguration -CimSession $ClusterNode.Name
            Ipconfig=         Ipconfig /all

            SmbMultichannelConnection= Get-SmbMultichannelConnection -CimSession $ClusterNode.Name
            SmbServerConfiguration= Get-SmbServerConfiguration -CimSession $ClusterNode.Name
            SmbConnection= Get-SmbConnection -CimSession $ClusterNode.Name
            SmbSession= Get-SmbSession -CimSession $ClusterNode.Name
            SmbBandWidthLimit= Get-SmbBandWidthLimit -CimSession $ClusterNode.Name -ErrorAction SilentlyContinue
            SmbServerNetworkInterface= Get-SmbServerNetworkInterface -CimSession $ClusterNode.Name
            SmbMultichannelConstraint= Get-SmbMultichannelConstraint -CimSession $ClusterNode.Name
            SmbWitnessClient= Get-SmbWitnessClient -CimSession $ClusterNode.Name

            NIC= Get-NetAdapter -CimSession $ClusterNode.Name
            NICAdv= Get-NetAdapterAdvancedProperty -CimSession $ClusterNode.Name -Name *
            NICBind= Get-NetAdapterBinding -CimSession $ClusterNode.Name –Name *
            NICRxTx= Get-NetAdapterChecksumOffload -CimSession $ClusterNode.Name -Name *
            NICHW= Get-NetAdapterHardwareInfo -CimSession $ClusterNode.Name -Name *
            NICRIpsec= Get-NetAdapterIPsecOffload -CimSession $ClusterNode.Name -Name *
            NICLso= Get-NetAdapterLso -CimSession $ClusterNode.Name -Name *
            NICQos= Get-NetAdapterQos -CimSession $ClusterNode.Name –Name *

            NICREnc= Get-NetAdapterEncapsulatedPacketTaskOffload -CimSession $ClusterNode.Name -Name *
            NICRdma= Get-NetAdapterRdma -CimSession $ClusterNode.Name –Name *
            NICRsc= Get-NetAdapterRsc -CimSession $ClusterNode.Name –Name *
            NICRss= Get-NetAdapterRss -CimSession $ClusterNode.Name –Name *
            NICSriov= Get-NetAdapterSriov -CimSession $ClusterNode.Name –Name *
            NICVmqQueue= Get-NetAdapterVmqQueue -CimSession $ClusterNode.Name –Name *
            NICVmq= Get-NetAdapterVmq -CimSession $ClusterNode.Name –Name *
        }
        
        # Export Info from each Node in a Separate File
        $net | Export-CliXML -Path "$LogPathLocal\$($ClusterNode.Name)-NetInfoPerNode.xml"
        ShowProgress "...Finished Gathering GatherNetInfoPerNode - stored in $LogPathLocal\$($ClusterNode.Name)-NetInfoPerNode.xml"; write-host
                        
    }
}    


function GatherGeneralInfoPerNode{
    param(
            $ClusterName,   # . is Local cluster 
            $ClusterNodes
        )
    
    ForEach($ClusterNode in $ClusterNodes){          # Walk through each FirewallRule 
        
        ShowProgress "...Start Gathering GeneralInfoPerNode"

        $Gen= [PSCustomObject][ordered]@{  
            HostName=         $ClusterNode.Name
            Hotfix=           Get-Hotfix -ComputerName $ClusterNode            
        }
        #$aClusterNodes+= $C   # Add the current object to the Array

        # Export Info from each Node in a Separate File
        $Gen | Export-CliXML -Path "$LogPathLocal\$($ClusterNode.Name)-GeneralInfoPerNode.xml"
        ShowProgress "...Finished Gathering GeneralInfoPerNode - stored in $LogPathLocal\$($ClusterNode.Name)-GeneralInfoPerNode.xml"; write-host
                        
    }
    
}

function GatherClusterValidation{
    param(
        $ClusterName,
        $TestNames
    )
    ShowProgress "...Start GatherClusterValidation"
    # Extension .htm is added automatically 
    Test-Cluster -Cluster $ClusterName -Include $TestNames -ReportName "$LogPathLocal\$ClusterName-Validation-Report" 
    ShowProgress "...Finished GatherClusterValidation"
}


# Tcmd Tracing - Start - on Each Cluster Node
Function StartTcmdTracingOnEachNode{
    param(
        $ClusterNodes,
        $ToolPath
    )
    ShowProgress "Start"
    ForEach($ClusterNode in $ClusterNodes){
        ShowProgress -ForeColor Green "....Start T.cmd tracing on Node:$ClusterNode"
        Invoke-Command -ComputerName $ClusterNode.Name -ScriptBlock { Invoke-Expression "cd $Using:ToolPath; $Using:ToolPath\t.cmd clion srvon circ:500" }
    }
      ShowProgress "Stop"
}

# Tcmd Tracing - Off - on Each Cluster Node
Function StopTcmdTracingOnEachNode{
    param(
        $ClusterNodes,
        $ToolPath
    )
    ShowProgress "Start"
    ForEach($ClusterNode in $ClusterNodes){
        ShowProgress -ForeColor Green "....Stop T.cmd tracing on Node:$ClusterNode"
        # Switch On t.cmd Tracing t.cmd clion srvon circ:500
        Invoke-Command -ComputerName $ClusterNode.Name -ScriptBlock { Invoke-Expression "cd $Using:ToolPath; $Using:ToolPath\t.cmd off" }
    }
      ShowProgress "Stop"
}

# Scan EventLog for a certain Id in an endless loop (e.g. 5120 in System Eventlog)
Function ScanEventLogOnEachNode{    
    param(
        $ClusterNodes,
        $EventLogName, 
        $TriggerId,
        $IntervalInSec
    )
    ShowProgress "Start"
    $StartTime= (Get-Date).AddSeconds(-$IntervalInSec)

    ShowProgress -ForeColor Yellow -MessageUser "...Now waiting for EventId:$TriggerId"

    $i= 0
    for (;;) { # Infinite Loop
        $i++ # Incrementing $i Counter variable
        Write-Progress -Activity "$i - Scanning EventLog:$EventLogName for TriggerEventID:$TriggerId on All Nodes " -PercentComplete $i
        #Write-Host "Scanning Evntlogs of all Nodes on $TriggerId"        
        ForEach($ClusterNode in $ClusterNodes){                            
            $Evts= Get-WinEvent -ComputerName $ClusterNode.Name -ErrorAction SilentlyContinue  -FilterHashtable @{Logname=$EventLogname; ID=$TriggerId; StartTime=$StartTime}
        
            # To manually write a Event 5120 to the System EventLog do the following
            # New-EventLog -ComputerName $Env:ComputerName –LogName System –Source 'CSS-System-5120' -ErrorAction SilentlyContinue
            # Write-Eventlog -ComputerName $Env:ComputerName -LogName System -Source ‘CSS-System-5120’ -EventId 5120 -EntryType Warning -Message "CSS-5120 - MS Custom Event Entry from PSwindow on Node $env:ComputerName"

            if ( $Evts -ne $Null){ # if the TriggerEventId is logged do the following 
                write-host -Fore Magenta "EventID:$TriggerId has been logged in EventLog:$EventLogName on Node:$($ClusterNode.Name)"
                ShowProgress -ForeColor Magenta "Stop Scanning Events"               
                Return  # Exiting Function           
            }
                
        }        
        Start-Sleep -Seconds $IntervalInSec # Time Interval we scan the Event-Log   
    } 
    
    ShowProgress "Finished"
    
}

Function MoveTcmdCabFilesToMSDATAFolder{
    param(
        $ClusterNodes
    )
    ShowProgress "Start"
    ForEach($ClusterNode in $ClusterNodes){                
        $TcmdUNCPath= $ToolPath.Replace(":","$")
        $Path= "\\$($ClusterNode.Name)\$TcmdUNCPath"
        ShowProgress "...Moving $Path\*.cab to $LogPathLocal"
        Get-ChildItem -Path "$Path\*.cab" | Move-Item -Destination $LogPathLocal -Force        
    }
    ShowProgress "Stop "
}

Function PrepareLiveKd{
    param(
        $ClusterNodes,
        $LiveKdExeFolderName
    )
    ForEach($ClusterNode in $ClusterNodes){
        ShowProgress -ForeColor Green "Start - Node:$($ClusterNode.Name)"
        # create the Registry Key Livekd 
        Invoke-Command -ComputerName $ClusterNode -ScriptBlock { 
            New-Item  -Path 'HKCU:\SOFTWARE\Sysinternals' -Name Livekd -ErrorAction SilentlyContinue 
        }
        # Create the ValueName EulaAccepted and set it to 1 to prevent the popup, when livekd is started 
        Invoke-Command -ComputerName $ClusterNode -ScriptBlock { 
            New-ItemProperty -Path 'HKCU:\SOFTWARE\Sysinternals\Livekd' -Name "EulaAccepted" -PropertyType DWord -Value 1 -ErrorAction SilentlyContinue 
        }
        # Create LiveKdFolderNameFull        
        Invoke-Command -ComputerName $ClusterNode -ScriptBlock { 
            New-Item -Path $Using:LiveKdExeFolderName -Type Directory -ErrorAction SilentlyContinue
        }
    }
    ShowProgress "Stop "
}

# Create a Live Kd Dump on All Nodes locally
Function CreateLiveKdDump{
    param(
        $ClusterNodes,
        $LiveKdExeFolderName, 
        $LiveKdDmpFolderName
    )
    ShowProgress -ForeColor Magenta "Start"
    ForEach($ClusterNode in $ClusterNodes){
        $LiveKdDmpNameFull= "$LivekdDmpFolderName\$($ClusterNode.Name)-LivkdDump-$Script:TimeStampForLogFolderName.dmp"
        $Command= "$LiveKdExeFolderName\livekd.exe " + "-ml -o " + $LiveKdDmpNameFull
        ShowProgress -ForeColor Green "Create Livekd Dump on Node:$($ClusterNode.Name)"
        Invoke-Command -ComputerName $ClusterNode -ScriptBlock { Invoke-Expression $Using:Command }        
    }
    ShowProgress "Stop "
}

Function MoveLiveKdDumpsToMSDataFolder{
    param(
        $ClusterNodes,
        $LiveKdDmpFolderName
    )
    ShowProgress "Start"
    ForEach($ClusterNode in $ClusterNodes){                
        $LiveKdDmpFolderNameUNC= $LiveKdDmpFolderName.Replace(":","$")
        $Path= "\\$($ClusterNode.Name)\$LiveKdDmpFolderNameUNC"
        ShowProgress "...Moving $Path\*.dmp to $LogPathLocal"
        Get-ChildItem -Path "$Path\*.dmp" | Move-Item -Destination $LogPathLocal -Force        
    }
    ShowProgress "Stop "
}

#endregion ::::: Worker Functions END ::::::


#region ::::::::::::::::::::::::::::::::::::::::::::::::: MAIN :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
ShowProgress " ----------- Start Script ---------- "

#region ::::: Define global Variables Begin ::::: 

# Create TimeStamp as String to be used in the folder name
[String]$TimeStampForLogFolderName=    (Get-Date -Format 'yyMMdd-HHmmss') 
# Create LocalPath where we store the data 
#[String]$LogPathLocal= "$env:SystemDrive\MS_DATA\AdditionalLogs-$TimeStampForLogFolderName"
[String]$LogPathLocal= "$DataPath\AdditionalLogs-$TimeStampForLogFolderName"

$ClusterName= "." # default is local Cluster
$ClusterName= Get-Cluster -Name $ClusterName # Get Cluster Name

# T.cmd folder Path
$ToolPath= "C:\ToolPath"

# How much Minutes should we look back in the logs: 24h -> 1440; 1 Week --> 10080; 4 Weeks --> 40320; 3 Month --> 120960
$MinutesBack= 5 

# To check which EventLogNames could be added for e.g. cluster: Get-WinEvent -ListLog "*clus*"
$EventLogNames=("System", "Application", "*CSVFS*", "*Smb*", "*winrm*", "*wmi*", "*spaces*","Microsoft-Windows-FailoverClustering/Operational" )
<#$EventLogNames=(
  "Microsoft-Windows-FailoverClustering/Operational", 
  "Microsoft-Windows-SMBWitnessClient/Admin",
  "Microsoft-Windows-FailoverClustering/Operational"
)#>


$ClusterValidationTestNames=(
    "Cluster Configuration",
    "Hyper-V Configuration",
    "Inventory","Network",
    #"Storage",
    "System Configuration"
)
#endregion ::::: Define global Variables End ::::: 



#region ::::: Call Helper Functions Begin ::::: 
$ClusterNodes= TestNodeConnection -ClusterName $ClusterName

CreateLogFolderLocal -LogPathLocal $LogPathLocal
#endregion ::::: Call Helper Functions End ::::: 



#region ::::: Call Worker Functions Begin ::::: 
Start-Transcript -Path "$LogPathLocal\$TimeStampForLogFolderName-Transcript.Log"

if ($Livekd.IsPresent -eq $true) {
	# create the Registry Key Livekd and create the ValueName EulaAccepted and set it to 1 to prevent the popup, when livekd is started  
	PrepareLiveKd    -ClusterNodes $ClusterNodes -LiveKdExeFolderName $ToolPath
}

if ($Tcmd.IsPresent -eq $true) {
	#region ::::: t.cmd - Wait for Event Begin ::::: 
	# download latest t.cmd Version from the product group folder \\ntdev\ssd\TraceFiles
	# Tcmd Tracing - Start - on Each Cluster Node
	StartTcmdTracingOnEachNode -ClusterNodes $ClusterNodes -ToolPath $ToolPath
}

if ($ScanEventLog.IsPresent -eq $true) {
	# Scan EventLog for TriggerId in an Endless Loop, then if Id is logged comeback
	ScanEventLogOnEachNode     -ClusterNodes $ClusterNodes -EventLogName "System" -TriggerId "5120" -IntervalInSec 2
}

if ($Livekd.IsPresent -eq $true) {
	#Create a LivekdDump on all Nodes
	CreateLiveKdDump -ClusterNodes $ClusterNodes -LiveKdExeFolderName $ToolPath -LiveKdDmpFolderName $ToolPath
}
if ($Tcmd.IsPresent -eq $true) {
	# Tcmd Tracing - Stop - on Each Cluster Node
	StopTcmdTracingOnEachNode  -ClusterNodes $ClusterNodes -ToolPath $ToolPath
	#Copy *.cab files created by t.cmd to $LogPathLocal (MS_DATA Folder)
	MoveTcmdCabFilesToMSDATAFolder -ClusterNodes $ClusterNodes 
	#endregion ::::: t.cmd - Wait for Event End ::::: 
}

if ($Livekd.IsPresent -eq $true) {
	# Move LiveKdDumps To MSData Folder
	MoveLiveKdDumpsToMSDataFolder -ClusterNodes $ClusterNodes -LiveKdDmpFolderName $ToolPath
	#endregion ::::: LiveKd End ::::: 
}

#region ::::: Gathering Logs ::::: 
# Quick running parts
GatherNetInfoPerNode       -ClusterName $ClusterName -ClusterNodes $ClusterNodes
GatherGeneralInfoPerNode   -ClusterName $ClusterName -ClusterNodes $ClusterNodes
GatherClusterHives         -ClusterName $ClusterName -ClusterNodes $ClusterNodes

# Longer running Parts
# Recalculate the Minutes we should look back in Logs, depending on how long it took until the Trigger-Event occurred
$MinutesBack= ( (Get-Date) - $TimeStampStartSaved ).Minutes + 10
GatherEventLogs            -ClusterName $ClusterName -ClusterNodes $ClusterNodes -MinutesBack $MinutesBack -LogNames $EventLogNames
GatherClusterLogs          -ClusterName $ClusterName                             -MinutesBack $MinutesBack
GatherClusterValidation    -ClusterName $ClusterName -TestNames $ClusterValidationTestNames
write-host
#endregion ::::: Gathering Logs ::::: 

ShowProgress " ----------- Finished Script ---------- "

Stop-Transcript
write-host

# Final Message
write-host -ForegroundColor Magenta " Logfiles can be found in Folder: $LogPathLocal" 

#endregion ::::: Call Worker Functions End ::::: 

if ($ZipData.IsPresent -eq $true) {
	# Create Zip File
	# Compress-Archive -Path "$LogPathLocal\*" -CompressionLevel Optimal -DestinationPath "$LogPathLocal\$TimeStamp-MSDATA.zip"

	# Remove all other Files in this Folder
	# Get-ChildItem -path "$LogPathLocal\*" -exclude *.zip -Recurse | Remove-Item -Force
}
#endregion