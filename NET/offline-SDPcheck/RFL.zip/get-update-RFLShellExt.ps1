# File: \\localhost\ToolsShare\RFL\get-update-RFLShellExt.ps1 V2
# last edit by: waltere 2020-05-09
<#
Dear RFL-check users,
I got notice from some colleagues that the RFL-check Explorer plugin lead to incorrect experience on Windows 10 machines prior to Creators Update, when clicking on links/shortcuts/TrayIcon for �OneDrive for Business�/(former SkyDrive).
While it is not fully clear to me, why this issue happens only for this specific app (OneDrive/Skydrive) � likely a bug in the app, I spent some time to investigate (using Sysinternals ProcMon) the issue and most likely came to a solution.
Please update the current version of the RFL PlugIn on your system to latest version v1.11 by either clicking the registry file for the new version of the shell extension \\localhost\ToolsShare\rfl\Rfl-Check_ShellExtension.reg  (or copying it to local drive first in case you run into this error:
Q01: the registry file Rfl-Check_ShellExtension.reg does not import on double-click, error
   Cannot import P:\Rfl-Check_ShellExtension.reg: Error opening the file. There may be a disk of file system error. [OK]
A01: Solution: Copy the .reg file at first to local disk C:\temp )
But first please make sure you delete the existing registry Key HKEY_CLASSES_ROOT\Directory\shell\Check-RFL and all subkeys. This can be done using PS script remove-RFLShellExt.ps1

Then, for your convenience just run the PowerShell script: \\localhost\ToolsShare\rfl\get-update-RFLShellExt.ps1 for latest update.
FYI: if you run the script without elevation, this PS script will start a new process in elevated context and ask for UAC confirmation, because of the registry changes needed, so please agree to PowerShell UAC (User Account Control) prompts.
#>

<#
.SYNOPSIS
The script will install or update your current version of the RFL PlugIn on your system to latest version.
The registry file for the latest version of the shell extension is located here: \\localhost\ToolsShare\rfl\Rfl-Check_ShellExtension.reg

SYNTAX: .\get-update-RFLShellExt.ps1 [Check-RFL|Check_RFL_anchor|Check_SDP_anchor]

.DESCRIPTION
The script reads in your current registry RFL information and writes new registry key.
The script tries to run itself in elevated mode and ask user to agree, because REG changes need admin permission.
Note: In case of any error, you still can download to local drive and doubleclick the *.reg file on
   \\localhost\ToolsShare\rfl\Rfl-Check_ShellExtension.reg

.PARAMETER SkipAdminCheck
If this switch is present, then the check for administrator privileges will be skipped.

.EXAMPLE
To run the RFL shell PlugIn check and update on UNC path
	\\localhost\ToolsShare\rfl\get-update-RFLShellExt.ps1

.LINK
Update script: \\localhost\ToolsShare\rfl\get-update-RFLShellExt.ps1
ShellExtension: \\localhost\ToolsShare\rfl\Rfl-Check_ShellExtension.reg
RFL core team: waltere@microsoft.com

#>


[CmdletBinding()]
PARAM (
	[ValidateSet("Check-RFL","Check_RFL_anchor","Check_SDP_anchor")]
	[parameter(Mandatory=$False,Position=0,HelpMessage='Choose one from: [Check_RFL_anchor|Check_SDP_anchor]')]
	[string]$CheckType = "Check_RFL_anchor"
	,
  [parameter(Mandatory=$false)]
  [switch]$SkipAdminCheck = $false,
	[switch]$HostMode  = $false, #This tells the logging functions to show logging on the screen
	[switch]$ScriptMode = $false, #This tells the logging functions to show logging in log file
  [switch]$UseExitCode= $true  #This will cause the script to close after the error is logged if an error occurs.
	)

BEGIN {
	# update needs elevation
	Write-Host "[RFLshExt_Update] Checking for elevation... "
	$CurrentUser = New-Object Security.Principal.WindowsPrincipal $([Security.Principal.WindowsIdentity]::GetCurrent())
	if (($CurrentUser.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)) -eq $false)
	{
		$ArgumentList = "-noprofile -noexit -file `"{0}`" " #-Path `"$scriptPath`" -MaxStage $MaxStage"
		If ($ValidateOnly) { $ArgumentList = $ArgumentList + " -ValidateOnly" }
		If ($SkipValidation) { $ArgumentList = $ArgumentList + " -SkipValidation $SkipValidation" }
		If ($Mode) { $ArgumentList = $ArgumentList + " -Mode $Mode" }
		Write-Host "...elevating in new Admin PS window"
		Start-Process powershell.exe -Verb RunAs -ArgumentList ($ArgumentList -f ($myinvocation.MyCommand.Definition)) #-Wait
		Exit
	}
	# Run your code that needs to be elevated here...
#-------------------------------------------------
	Write-host -BackgroundColor Black -ForegroundColor Gray -Object "[RFLshExt_Update] ...Running now with Admin priv (Elevated)"

	$error.clear()	# clear PS script errors
  # This saves the starting ErrorActionPreference and then sets it to 'Stop'.
  $startErrorActionPreference = $errorActionPreference
  $errorActionPreference = 'Continue' # 'Stop' #
  # This gets the current path and name of the script.
  $invocation = (Get-Variable MyInvocation).Value
	$invocationLine= $($MyInvocation.Line)
  $scriptPath = Split-Path $invocation.MyCommand.Path
	$ScriptParentPath 	= Split-Path $MyInvocation.MyCommand.Path -Parent
  $scriptName = $invocation.MyCommand.Name
	$UserName  = ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)
	$UsrOSVersion = [Environment]::OSVersion.Version.ToString(3)
	$CheckDate = (Get-Date -UFormat "%Y-%m-%d_%R-%S").Replace(":","-")
	$Script:PSver = $PSVersionTable.PSVersion.Major
  #Write-Host "Running `"$scriptPath\$scriptName`"..." -BackgroundColor Black -ForegroundColor Green
	Set-Variable -Name ErrorMsg -Scope Script -Force
	[string]$Script:ErrorMsg=""

	#region: ###### customization section of script, logging configuration ########################
		$VerMa="1"
		$VerMi="17"
		$RFLpath = "\\localhost\ToolsShare\rfl"
		$ExpectedShellExtVersion = "2.06"	#
		$OnlyRun_AsAdmin = 0
		$start = Get-Date
		$Script:regFile = "$RFLpath\Rfl-Check_ShellExtension.reg"
		$Script:regFileV1remove = "$RFLpath\Rfl-Check_ShellExtension_V1-Remove.reg"
		#$Script:regFileV2 = "$RFLpath\Rfl-Check_ShellExtension.reg"
		$Script:regFileV2add = "$RFLpath\Rfl-Check_ShellExtension_V2-Add.reg"
		$Script:regFileV2remove = "$RFLpath\Rfl-Check_ShellExtension_V2-Remove.reg"
		$UsrOSVersion = [Environment]::OSVersion.Version.ToString(3)
		$LogLevel = 0
		if (Test-Connection -ComputerName waltere-vdi.europe.corp.microsoft.com -Quiet -Count 1) {[bool]$Stats=1} else {[bool]$Stats=0}
		$StatsServerPath="\\waltere-vdi.europe.corp.microsoft.com\ToolsShare\tools\RFL\"
		$CountInvFil = $StatsServerPath +'countRFLshExUpd.dat'
		$CountInvFil2 = $CountInvFil +'.us'
		$LogPath = $SDPPath + "_" + $scriptName + ".log"
		$ErrorThrown = $null
	#endregion: ###### customization section

	If ($Stats) { #increment at start of script
	 ($j=[int32](Get-Content $CountInvFil -TotalCount 1 -ErrorAction SilentlyContinue)) |out-null
	 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
	 }
	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}
	#ConsoleColor enumeration values: Black DarkBlue DarkGreen DarkCyan DarkRed DarkMagenta DarkYellow Gray DarkGray Blue Green Cyan Red Magenta Yellow White

	Set-Variable -Name ShellExtExists -Scope Script -Force
	Set-Variable -Name ShellExtVersion -Scope Script -Force
	Set-Variable -Name regFile -Scope Script -Force
	$Script:ShellExtVersion ='undefined'

	#region: Script Functions

	function ExitWithCode { param($exitcode) $host.SetShouldExit($exitcode); exit $exitcode}

	function checkPlugin-RFLShellExt ($CheckType,$ExpectedShellExtVersion) {
		Write-host "[RFLshExt_Plugin] Checking for existing ShellExt for $($CheckType) "
		#check if RFLShellExt is installed and 'Version' key exists
		New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null
		$registryPathHKCR = "HKCR:\Directory\shell\$($CheckType)"

		Write-host "[RFLshExt_Plugin] _Checking existing ShellExt in $registryPathHKCR"
		Try { $ErrorActionPreference = "stop"
			$Script:ShellExtExists = (Get-ItemProperty -Path $registryPathHKCR )
			if ($Script:ShellExtExists)	{ Write-host "[RFLshExt_Plugin] __Found ShellExt in $registryPathHKCR" }
		}
		Catch [System.Management.Automation.ItemNotFoundException]
			{ Write-host -BackgroundColor Black -ForegroundColor Yellow -Object "... Simplify: Consider to run Explorer-Extension update in elevated (Run as Administrator) PS cmd, see also _Help.rtf:"
			Write-host -BackgroundColor Black -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLpath\get-update-RFLShellExt.ps1"
			Write-host "[RFLshExt_Update] ...RFLshellPlugin not installed - creating it."
			#Write-host "[RFLshExt_Update] ...***please allow registry Version update when UAC prompted***"
			return "[RFLshExt_Update] RegKey $registryPathHKCR itself is missing."
		}
		Finally { $ErrorActionPreference = "Continue" }
	} #end checkPlugin-RFLShellExt

	function checkVer-RFLShellExt ($CheckType,$ExpectedShellExtVersion) {
		Write-host "[RFLshExt_Version] Checking ShellExt Version for $($CheckType) "
		#check if RFLShellExt is installed and 'Version' key exists
		New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null
		$registryPathHKCR = "HKCR:\Directory\shell\$($CheckType)"
		$name = "Version"
		$value = "1.00"
		Write-host "[RFLshExt_Version] _Checking current version in $registryPathHKCR"
		Try { $ErrorActionPreference = "stop"
			$Script:ShellExtVersion = (Get-ItemProperty -Path $registryPathHKCR -Name Version).Version
			if ($Script:ShellExtVersion)	{ Write-host "[RFLshExt_Version] __latest available ShellExtVersion is: $Script:ExpectedShellExtVersion"
				IF ($Script:ShellExtVersion -match $ExpectedShellExtVersion) {
					Write-host "[RFLshExt_Version] __Your RFL ShellExtension version $Script:ShellExtVersion is up-to-date";
					return "$Script:ShellExtVersion _up-to-date"}
				ELSE { if ($Script:ShellExtVersion -lt 1.09) {Write-host -BackgroundColor Black -ForegroundColor Red -Object " Support for this older RFL version will end *soon*, because Server \\muc-vfs-01a will be decommissioned."}
						Write-host -BackgroundColor Yellow -ForegroundColor Black -Object "[RFLshExt_Version] __Your RFL ShellExtension version $Script:ShellExtVersion is outdated!
	 .. Consider updating the RFL Shell Explorer Plugin `n $Script:regFileV2add
	 To do so, run in ELEVATED (Run as Administrator) PS window the command: "
					Write-host -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLpath\get-update-RFLShellExt.ps1"
					return "$Script:ShellExtVersion _outdated - user_informed"}
			}
		}
		Catch [System.Management.Automation.PSArgumentException]
		{
			if ($Script:ShellExtVersion -lt 1.09) {Write-host -BackgroundColor Black -ForegroundColor Red -Object "Support for this older RFL version will end *soon*, because Server \\muc-vfs-01a will be decommissioned. "}
			Write-host -BackgroundColor Yellow -ForegroundColor Black -Object "[RFLshExt_Version] __Your RFL ShellExtension version $Script:ShellExtVersion is outdated!
	 Please update the RFL Shell Extension `n $Script:regFileV2add
	 To do so, run in ELEVATED (Run as Administrator) PS window the command: "
			Write-host -BackgroundColor Black -ForegroundColor Cyan -Object " Powershell -ExecutionPolicy Bypass $RFLpath\get-update-RFLShellExt.ps1"
			"[RFLshExt_Version] RegKey $registryPathHKCR Property $name missing."
		}
		Catch [System.Management.Automation.ItemNotFoundException]
		{ Write-host "[RFLshExt_Version] RegKey $registryPathHKCR\Version is missing."
			Write-debug "[RFLshExt_Version] ...RFLshellPlugin not up-to-date"
			Write-debug "[RFLshExt_Version] ...***please allow registry Version update when UAC prompted***"
			"[RFLshExt_Version] RegKey $registryPathHKCR\Version is missing."
		}
		Finally { $ErrorActionPreference = "Continue" }
	} # end of checkVer-RFLShellExt

	function CheckForUpdates-RFLShellExt ($CheckType,$ExpectedShellExtVersion) {
	if ($OnlyRun_AsAdmin)
	 {
	 Write-host "[RFLshExt_ChkUpdates] checking registryPath: $registryPathHKCR\CheckForUpdates"
	 $name = "CheckForUpdates"
	 $value = "1"
	  Try { $ErrorActionPreference = "stop"
		$CheckForUpdates = (Get-ItemProperty -Path $registryPathHKCR -Name CheckForUpdates).CheckForUpdates
		if ($CheckForUpdates) {Write-host "[RFLshExt_ChkUpdates] Current CheckForUpdates: $CheckForUpdates"}
		if ($CheckForUpdates -NotMatch "0") {Write-host "[RFLshExt_ChkUpdates] Current ShellExt setting for CheckForUpdates: $CheckForUpdates"}
		else {	Write-host "[RFLshExt_ChkUpdates] CheckForUpdates: '$CheckForUpdates' - .. Consider updating the RFL Shell Explorer Plugin `n $Script:regFileV2add "
			Write-host "[RFLshExt_ChkUpdates] ... keep existing plugin settings because $registryPathHKCR\CheckForUpdates is set to '$CheckForUpdates'"
			break #continue
			}
	 }
	 Catch [System.Management.Automation.PSArgumentException]
	  { "[RFLshExt_ChkUpdates] RegKey $registryPathHKCR Property $name missing."
		 New-ItemProperty -Path $registryPathHKCR -Name $name -Value $value -PropertyType DWORD -Force | Out-Null
	  }
	 Catch [System.Management.Automation.ItemNotFoundException]
	  { "[RFLshExt_ChkUpdates] RegKey $registryPathHKCR itself is missing."
		 Write-host "[RFLshExt_ChkUpdates] ...RFLshellPlugin not installed - creating it"
		 New-Item -Path $registryPathHKCR -Force #| Out-Null
		 New-ItemProperty -Path $registryPathHKCR -Name $name -Value $value -PropertyType DWORD -Force | Out-Null
	 }
	 Finally {
		 "[RFLshExt_ChkUpdates] CheckForUpdates reg: $CheckForUpdates"
		 $ErrorActionPreference = "Continue" }
	 } # end of if ($OnlyRun_AsAdmin)
	} # end of CheckForUpdates-RFLShellExt

	function update-ShellExt ($CheckType,$ExpectedShellExtVersion) {
		IF (!($Script:ShellExtVersion -match $ExpectedShellExtVersion) -and ($CheckForUpdates -NotMatch "0")) {
			write-host "[RFLshExt_Update] ...Outdated Check_RFL ShellExtVersion v$Script:ShellExtVersion"
			Try
			{
			write-host "[RFLshExt_Update] ...removing existing entry Check_RFL v$Script:ShellExtVersion"
			$RegTryRemoveV1 = regedit /s $Script:regFileV1remove
			$RegTryRemoveV2 = regedit /s $Script:regFileV2remove
			write-host "[RFLshExt_Update] ...Importing latest v$ExpectedShellExtVersion $Script:regFile silently"
			$RegTryAdd = regedit /s $Script:regFile
			write-host "[RFLshExt_Update] ...Registry Update result: $RegTryAdd"
			Write-host -BackgroundColor Black -ForegroundColor Green -Object "[RFLshExt_Update] RFLShellExt $CheckType successfully updated"
			"RegImport-done $ExpectedShellExtVersion"
			}
			Catch [System.Security.SecurityException]
				{ "Registry Remove-Item $registryPathHKCR"
				}
			Catch
				{
					Write-Error "[RFLshExt_Update] Aborted. The error was '$($_.Exception.Message)'"
					Write-host -BackgroundColor Black -ForegroundColor Red -Object "[RFLshExt_Update] Aborted by user"
					"Aborted by user."
				}
			Finally
			{
				"$Script:ShellExtVersion RegVersion-not-matched. Prev.Ver: $Script:ShellExtVersion"
			}
		}
	} # end of update-ShellExt

	function autoupdate-ShellExt ($CheckType,$ExpectedShellExtVersion) {
		checkPlugin-RFLShellExt $CheckType $ExpectedShellExtVersion		#call function
		if ($Script:ShellExtExists)	{
			checkVer-RFLShellExt $CheckType $ExpectedShellExtVersion		#call function
		}
		update-ShellExt $CheckType $ExpectedShellExtVersion				#call function
	} #end of autoupdate-ShellExt

	function remove-ShellExt ($RegKey) {
		# SYNOPSIS :
		New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT |out-null

		Try	{
			write-host "[RFLshExt_Remove] _Trying to remove entry $RegKey"
			Remove-Item $RegKey -Recurse -ErrorAction SilentlyContinue
		}
		Catch [System.Security.SecurityException]
			{ "Registry Remove-Item $RegKey" }
		Catch [System.Management.Automation.ItemNotFoundException]
			{"RegKey $RegKey is missing."}
		Catch
			{
				Write-Error "[RFLshExt_Remove] Aborted. The error was '$($_.Exception.Message)'"
				Write-host -BackgroundColor Black -ForegroundColor Red -Object "[RFLshExt_Remove] Aborted by user"
				"Aborted by user."
			}
		Finally { " _ $RegKey done"}
	} #end of remove-ShellExt
	#endregion: Script Functions
} #end BEGIN


PROCESS {
	try {
		$ScriptBeginTimeStamp = Get-Date
		#region: MAIN :::::


		#for downlevel Plugin V1 with parameter Check-RFL
		if ($CheckType -match "Check-RFL") { $CheckType = "Check_RFL_anchor"}
		Write-host "CheckType: $CheckType "

		### main
		$au = autoupdate-ShellExt $CheckType $ExpectedShellExtVersion		#call function
		$Script:ResultMsg = $au
		Write-verbose "[RFLshExt_Update] AutoUpdate results: $au"
		If (-not $au) {Write-host "[RFLshExt_Update] .. Consider updating the RFL Shell Explorer Plugin $Script:regFile "}
		write-host -BackgroundColor Black -ForegroundColor Green -Object "[RFLshExt_Update] ...done. New RFL ShellExt $ExpectedShellExtVersion plugin should be available in your Windows Explorer context menu for folders right now."
		write-host -ForegroundColor Gray "Note: In case of any error, you still can download to local drive and doubleclick the *.reg file on
			 $($RFLpath)Rfl-Check_ShellExtension.reg `n"

		#endregion: MAIN :::::
	} # end try PROCESS
	catch {
		$ErrorThrown = $true
		$errorMessage = "$scriptName caught an exception on $($ENV:COMPUTERNAME):`n`n"
		$errorMessage += "Exception Type: $($_.Exception.GetType().FullName)"
		$errorMessage += "`n`n Exception Message: $($_.Exception.Message)"

		Write-Error $errorMessage -ErrorAction Continue
		<# Log error
				Write-Verbose "Logging the script's error..."
		# Log error - EventLog
				#An event log source needs to be preconfigured to use this.
				Write-EventLog `
					-EventId $AlertNumber `
					-LogName $LogName `
					-Source $EventSource `
					-Message $errorMessage `
					-EntryType Error
		# Log error - Email
				# This will attempt to send an immediate alert about the error.
				# The EventLog also needs to log the error because this one may not be sent.
				#use Send-MailMessage
		#>
		Start-Sleep -Seconds 3
		Write-Debug $errorMessage
		if ( $UseExitCode ) {
			$error.clear()	# clear script errors
			exit 1
		} #end UseExitCode
  } #end Catch PROCESS
	Finally {
	} #end Finally PROCESS
} #end PROCESS


END {
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
	$LogLevel = 0
	Write-host -BackgroundColor Gray -ForegroundColor Black -Object " Script $scriptName v$VerMa.$VerMi execution finished. Duration: $Duration `n"
  # This resets the ErrorActionPreference to the value at script start.
  $errorActionPreference = $startErrorActionPreference
	# Stats
	If ($Stats) { #increment at start of script
	 "$j; $CheckDate; $UsrOSVersion; $UserName; $Duration; $Script:ShellExtVersion; $Script:ResultMsg; v$VerMa.$VerMi; $env:computername" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
	 }
	if($ErrorThrown) {Throw $error[0].Exception.Message}
} #end END

#region: comments
<#
	The top section is comment based help so the Get-Help command will work with the script.
	The [CmdletBinding()] turns on advanced options like the common parameters.
	All sub functions are in the "BEGIN" section.
	My script code goes in the "PROCESS try" block.

VERSION and AUTHOR:
    Walter Eder	- waltere@microsoft.com

HISTORY
	2015-02-02	V1.04
	2016-07-02	- add capability to remove all RFL registry settings, see remove-RFLShellExt.ps1
	2017-04-03	V1.08 (removed platform, re-added VSS in Rfl-Check_ShellExtension_FQDN.reg)
	2017-10-06	v1.11 changed [RFLshExt_Update] to [RFLshExt_Version] + output enhancements
	2017-11-19	v1.13 using PS functions
	2019-02-25	v1.16 implemented RFLShellExtV2 update

	ToDo: 	/known issue:
	#https://blogs.msdn.microsoft.com/virtual_pc_guy/2010/09/23/a-self-elevating-powershell-script/


	Hints:
		# Wait for User Input
		Write-host -NoNewLine "Press any key to continue ..."; $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
#-------------------------------------------------
#$error[0] |fl * -force
#Write-Host -NoNewLine "Press any key to continue ...";
#$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
#>