	Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Write-Host -BackgroundColor Gray -ForegroundColor Black -Object " --- $(Get-Date -Format 'HH:mm:ss') $Global:SDPtech - Collect Phase module: Common ---"

	# version of the psSDP Diagnostic
	Run-DiagExpression .\DC_NetworkingDiagnostic.ps1

	# MSInfo
	Run-DiagExpression .\DC_MSInfo.ps1
	
	# Obtain pstat output
	Run-DiagExpression .\DC_PStat.ps1

	# CheckSym
	Run-DiagExpression .\DC_ChkSym.ps1

	#_# Collect summary report 
	Run-DiagExpression .\DC_SummaryReliability.ps1

Write-Host -BackgroundColor Gray -ForegroundColor Black -Object " --- $(Get-Date -Format 'HH:mm:ss') $Global:SDPtech - Collect Phase module: DC_WinStore ---"
	# Windows Store Inbox Applications Interactive [AutoAdded]
	#_# Run-DiagExpression .\DC_WinStoreMain.ps1
	
	Run-DiagExpression .\DC_WinStoreCollect.ps1
	Run-DiagExpression .\DC_WinUpdateCollect.ps1
	Run-DiagExpression .\DC_AppxCollect.ps1
	Run-DiagExpression .\DC_UEXCollect.ps1
	Run-DiagExpression .\DC_NgenCollect.ps1
	Run-DiagExpression .\DC_COMCollect.ps1
	Run-DiagExpression .\DC_SystemCollect.ps1

Write-Host -BackgroundColor Gray -ForegroundColor Black -Object " --- $(Get-Date -Format 'HH:mm:ss') $Global:SDPtech - Collect Phase module: Update ---"
	# Update History
	#Run-DiagExpression .\DC_UpdateHistory.ps1

	# Collect WindowsUpdate.Log
	Run-DiagExpression .\DC_WindowsUpdateLog.ps1

	# Hotfix Rollups
	Run-DiagExpression .\DC_HotfixRollups.ps1
	
Write-Host -BackgroundColor Gray -ForegroundColor Black -Object " --- $(Get-Date -Format 'HH:mm:ss') $Global:SDPtech - TS Phase module: ModernApps ---"
	# [Idea ID 7524] [Windows] WinStore -Modern applications fail to start if 'Audit the access of global system object' is enabled [AutoAdded]
	Run-DiagExpression .\TS_ModernAppsFailureForAuditOptionCheck.ps1

	# [Idea ID 7723] [Windows] WinStore - Modern applications fail to start if incompatible security - av software installed [AutoAdded]
	Run-DiagExpression .\TS_ModernAppsFailureForWindDefenderCheck.ps1

	# [Idea ID 7727] [Windows] WinStore - Cannot install Windows Store Apps [AutoAdded]
	Run-DiagExpression .\TS_ModernAppsFailureForTrustedPathCredentialsCheck.ps1

	# [Idea ID 7712] [Windows] WinStore - Modern Apps fail to run if the UAC File Virtualization driver is not running [AutoAdded]
	Run-DiagExpression .\TS_ModernAppsFailureForUACFileVirtualizationCheck.ps1

	# [Idea ID 7508] [Windows] WinStore - This app cannot open while the User Account Control is turned off [AutoAdded]
	Run-DiagExpression .\TS_ModernAppsFailureForUACDisabledCheck.ps1

	# [Idea ID 6253] [Windows] Win8:APP - Store Apps do not launch due to video resolution [AutoAdded]
	Run-DiagExpression .\TS_StoreAppsFailureForVideoResolutionCheck.ps1

	# [Idea ID 7499] [Windows] Win8:APP - Skype fails to start [AutoAdded]
	Run-DiagExpression .\TS_SkypeFailureForMissingKB2703761Check.ps1

	# [Idea ID 7544] [Windows] WinStore - Apps do not launch, because 'ALL APPLICATIONS PACKAGES' removed from DCOM ACL [AutoAdded]
	Run-DiagExpression .\TS_StoreAppsFailureForDCOMErrorCheck.ps1

	# [Idea ID 7510] [Windows] WinStore - Apps fail to start if default registry permissions modified [AutoAdded]
	Run-DiagExpression .\TS_ModernAppsFailureForRegistryPermissionCheck.ps1

	# [Idea ID 7546] [Windows] WinStore - Modern Apps Fail to Start if the User Profile directory is Moved from default [AutoAdded]
	Run-DiagExpression .\TS_ModernAppsFailureForUserProfileDirCheck.ps1

	# [Idea ID 7547] [Windows] WinStore - Modern Apps Fail to Start if the ProgramData directory is Moved from default [AutoAdded]
	Run-DiagExpression .\TS_ModernAppsFailureForProgramDataDirCheck.ps1

	# [Idea ID 7512] [Windows] WinStore - Apps fail to start if default file permissions modified [AutoAdded]
	Run-DiagExpression .\TS_ModernAppsFailureForFolderPermissionCheck.ps1

Write-Host -BackgroundColor Gray -ForegroundColor Black -Object " --- $(Get-Date -Format 'HH:mm:ss') $Global:SDPtech - Diag Phase module: TS_Net ---"
	# FirewallCheck [AutoAdded]
	Run-DiagExpression .\RC_FirewallCheck.ps1

	# List basic network configuration to results report [AutoAdded]
	Run-DiagExpression .\TS_BasicNetworkInfo.ps1

Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "*** $(Get-Date -UFormat "%R:%S") DONE TS_AutoAddCommands_APPS.ps1 `n"
