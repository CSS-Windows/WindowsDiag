# 2019-03-20 WalterE added Trap #_#

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Write-Host -BackgroundColor Gray -ForegroundColor Black -Object " --- $(Get-Date -Format 'HH:mm:ss') $Global:SDPtech - Collect Phase module: Common ---"
	# version of the psSDP Diagnostic
	Run-DiagExpression .\DC_NetworkingDiagnostic.ps1
	
	# Basic System Information [AutoAdded]
	Run-DiagExpression .\DC_BasicSystemInformation.ps1

	# MSInfo [AutoAdded]
	Run-DiagExpression .\DC_MSInfo.ps1
	
	# Obtain pstat output
	Run-DiagExpression .\DC_PStat.ps1
	
	# CheckSym - in Main
	#_#Run-DiagExpression .\DC_ChkSym.ps1

	# AutoRuns Information
	Run-DiagExpression .\DC_Autoruns.ps1

	# WhoAmI
	-DiagExpression .\DC_Whoami.ps1

	# Collects System and Application Event Logs 
	Run-DiagExpression .\DC_SystemAppEventLogs.ps1
	
	# Collects BCD information via BCDInfo tool or boot.ini
	Run-DiagExpression .\DC_BCDInfo.ps1

	# PoolMon
	Run-DiagExpression .\DC_PoolMon.ps1
	
	# Collect summary report 
	Run-DiagExpression .\DC_SummaryReliability.ps1		

Write-Host -BackgroundColor Gray -ForegroundColor Black -Object " --- $(Get-Date -Format 'HH:mm:ss') $Global:SDPtech - Collect Phase module: VSS ---"

	# Collect diagnostic information for VSS and Backup [AutoAdded]
	Run-DiagExpression .\DC_VSSPSS.ps1

	# Collect Event Logs for VSS and Backup [AutoAdded]
	Run-DiagExpression .\DC_VSSBackupEvtLogs.ps1

	# Collect registry information for VSS and Backup [AutoAdded]
	Run-DiagExpression .\DC_VSSBackupRegistry.ps1

	# Collect Files for VSS and Backup [AutoAdded]
	Run-DiagExpression .\DC_VSSBackupFiles.ps1

	# Collect Files for Windows Azure Backup [AutoAdded]
	Run-DiagExpression .\DC_CloudBackup.ps1

	# Detect 4KB Drives (Disk Sector Size) [AutoAdded]
	Run-DiagExpression .\TS_DriveSectorSizeInfo.ps1

Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "*** $(Get-Date -UFormat "%R:%S") DONE TS_AutoAddCommands_VSS.ps1 SkipTS: $Global:skipTS - SkipBPA: $Global:skipBPA"