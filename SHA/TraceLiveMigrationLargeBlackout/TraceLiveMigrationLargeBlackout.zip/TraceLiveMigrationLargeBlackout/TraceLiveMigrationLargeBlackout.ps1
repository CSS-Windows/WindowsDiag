<#
.SYNOPSIS
This is a simple Powershell script to collect Hyper-V traces in large blackout scenarios

.DESCRIPTION
There is the possibility to choose the mode of tracing :
 - For hyper-v : Using either Event channels or VMLTrace
 - For networking : Using either Powershell commands (quicker) or netsh & logman
 - For Xperf : You must have the latest WPT installed

The principle of this script is to be run on both source & destination nodes and pointung to the source node using the -SrcNode switch
Then, we start the migration and each node is waiting for a specific eventid (20415 or 20417) on the source node.

.EXAMPLE
./TraceLiveMigration.ps1

.NOTES
Put some notes here.

.LINK
http://www.bing.com
#>

Param(
    [string]$Path = "C:\MSLogs",
    [int32]$TimeoutInSeconds = 1200,    # Timeout to wait for the event
    [string]$EventID = "20417",         # Event ID to wait for
    [switch]$NoRestart,                 # We restart VMMS by default
    [Parameter(Mandatory)]              # Source Node
    [string]$SrcNode,
    [switch]$IncludeNetworkTrace,       # To include the network trace
    [ValidateSet("PowerShell","Netsh")][string]$NetMode,
    [switch]$IncludeXperf,              # To include the XPerf trace
    [switch]$Full,                      # To include system & application event logs
    [switch]$Cluster,                   # To include an export of the ClusDB
    [switch]$Export,                     # To include an export of the Configuration
    [ValidateSet("VML","Channel")][string]$VMLMode,
    [ValidateSet("Event","Manual")][string]$WaitMode = "Event",
    [switch]$Dbg
)


#region [========================= FUNCTIONS =========================]

$Global:DebugOutput = $Dbg

#region [===== Export functions =====]
function ExportClusDB([string]$Path,[switch]$Dbg)
{
    if ($Global:DebugOutput)
    {
        " >>> {0} {1}" -f (Get-PSCallStack)[0].FunctionName,(Get-PSCallStack)[0].Arguments
    }

    $FileSuffix = $ENV:ComputerName
    $OutputPath = $Path+"\"+$FileSuffix+"_ClusDB.hiv"

    Reg save HKLM\Cluster $OutputPath /y
}

function CollectConfigurations([string]$Path,
[ValidateSet("Before", "After")][string]$Step)
{
    if ($Global:DebugOutput)
    {
        " >>> {0} {1}" -f (Get-PSCallStack)[0].FunctionName,(Get-PSCallStack)[0].Arguments
    }

    write-host "Collect configurations $Step"
    $FileSuffix = $ENV:ComputerName
    
    $ListOfVMWP = $Path+"\"+$FileSuffix+"_VMWP_"+$step+".xml"
    $ListOfVMs = $Path+"\"+$FileSuffix+"_ListOfVMs_"+$step+".xml"
    $VMsNetAdap = $Path+"\"+$FileSuffix+"_VMsNetAdap_"+$step+".xml"

    if ($step -eq "After"){
        $HyperVConfig = $Path+"\"+$FileSuffix+"_HyperV_Config.xml"
        $NetAdapMgmtOS = $Path+"\"+$FileSuffix+"_NetAdapMgmtOS.xml"
        $VMQOutput = $Path+"\"+$FileSuffix+"_VMQ.xml"
        $VMQQueueOutput = $Path+"\"+$FileSuffix+"_VMQQueue.xml"
        $IPConfigOutput = $Path+"\"+$FileSuffix+"_IPConfig.xml"
        $NetAdapterRSS = $Path+"\"+$FileSuffix+"_NetAdapterRSS.xml"
        write-host "  Export the Hyper-V configuration"
        Get-VMHost | Export-Clixml -LiteralPath $HyperVConfig
        Get-VMNetworkAdapter -ManagementOS | Export-Clixml -LiteralPath $NetAdapMgmtOS
        Get-NetAdapterVmq | Export-Clixml -LiteralPath $VMQOutput
        Get-NetAdapterVmqQueue | Export-Clixml -LiteralPath $VMQQueueOutput
        Get-NetIPAddress | Export-Clixml -LiteralPath $IPConfigOutput
        Get-NetAdapterRss | Export-Clixml -LiteralPath $NetAdapterRSS
    }

    write-host "  Export the list of worker processes"
    Get-Process -Name VMWP -IncludeUserName -ErrorAction SilentlyContinue | Export-Clixml -LiteralPath $ListOfVMWP

    Write-Host "  Export the list of VMs"
    Get-VM | Export-Clixml -LiteralPath $ListOfVMs

    write-host "  Export the VMQ settings"
    Get-VM | Get-VMNetworkAdapter | Export-Clixml -LiteralPath $VMsNetAdap
    
}
#endregion

function SetRegistryKeysForVerboseTracing([switch]$Restart)
{
    if ($Global:DebugOutput)
    {
        " >>> {0} {1}" -f (Get-PSCallStack)[0].FunctionName,(Get-PSCallStack)[0].Arguments
    }

    write-host "Set registry keys for verbose tracing"
    $RegKey_Virtualization = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization"
    $RegKey_PerformanceTracing = $RegKey_Virtualization+"\PerformanceTracing"
    $RegKey_VML = $RegKey_Virtualization+"\VML"

    if ((Test-Path $RegKey_Virtualization) -ne $true){
        write-host "Not an hyper-v node"   
        break
    }
    New-ItemProperty -Path $RegKey_Virtualization -Name "EnablePerformanceTracing" -PropertyType DWORD -Value 1 -Force | Out-Null
    if ((Test-Path -Path $RegKey_PerformanceTracing) -eq $false ){
        New-Item -Path $RegKey_PerformanceTracing -Force | Out-Null
    }
    New-ItemProperty -Path $RegKey_PerformanceTracing -Name "EnableMigrationTrace" -PropertyType DWORD -Value 1 -Force | Out-Null
    New-ItemProperty -Path $RegKey_PerformanceTracing -Name "EnableVmbTrace" -PropertyType DWORD -Value 1 -Force | Out-Null
    New-ItemProperty -Path $RegKey_PerformanceTracing -Name "EnablePvmTrace" -PropertyType DWORD -Value 1 -Force | Out-Null
    if ((Test-Path -Path $RegKey_VML) -eq $false ){
        New-Item -Path $RegKey_VML -Force | Out-Null
    }
    New-ItemProperty -Path $RegKey_VML -Name "TraceLevel" -PropertyType DWORD -Value 3 -Force | Out-Null

    if ($Restart){
        Write-Host "Restart VMMS"
        Restart-Service VMMS -Force
    }
}

#region [===== Hyper-V Tracing =====]

function SetChannelSize([int32]$Size)
{
    if ($Global:DebugOutput)
    {
        " >>> {0} {1}" -f (Get-PSCallStack)[0].FunctionName,(Get-PSCallStack)[0].Arguments
    }

    wevtutil sl "Microsoft-Windows-Hyper-V-VMMS-Admin" /maxsize:$Size /quiet:true
    wevtutil sl "Microsoft-Windows-Hyper-V-Worker-Admin"  /retention:false /maxsize:$Size /quiet:true
    wevtutil sl "Microsoft-Windows-Hyper-V-High-Availability-Admin" /retention:false /maxsize:$Size /quiet:true

    wevtutil sl "Microsoft-Windows-Hyper-V-VMMS-Analytic" /enabled:false /retention:false /maxsize:$Size /quiet:true
    wevtutil sl "Microsoft-Windows-Hyper-V-VMMS-Analytic" /enabled:true /quiet:true

    wevtutil sl "Microsoft-Windows-Hyper-V-Worker-Analytic" /enabled:false /retention:false /maxsize:$Size /quiet:true
    wevtutil sl "Microsoft-Windows-Hyper-V-Worker-Analytic" /enabled:true /quiet:true

    wevtutil sl "Microsoft-Windows-Hyper-V-Worker-VDev-Analytic" /enabled:false /retention:false /maxsize:$Size /quiet:true
    wevtutil sl "Microsoft-Windows-Hyper-V-Worker-VDev-Analytic" /enabled:true /quiet:true

    wevtutil sl "Microsoft-Windows-Hyper-V-High-Availability-Analytic" /enabled:false /retention:false /maxsize:$Size /quiet:true
    wevtutil sl "Microsoft-Windows-Hyper-V-High-Availability-Analytic" /enabled:true /quiet:true
}

function EnableEventLogs([int32]$Size)
{
    if ($Global:DebugOutput)
    {
        " >>> {0} {1}" -f (Get-PSCallStack)[0].FunctionName,(Get-PSCallStack)[0].Arguments
    }

    Write-Host "Enable event logs"
    wevtutil sl "Microsoft-Windows-Hyper-V-VMMS-Analytic" /enabled:false /retention:false /maxsize:$Size /quiet:true
    wevtutil sl "Microsoft-Windows-Hyper-V-VMMS-Analytic" /enabled:true /quiet:true
    wevtutil sl "Microsoft-Windows-Hyper-V-Worker-Admin" /enabled:false /retention:false /maxsize:$Size /quiet:true
    wevtutil sl "Microsoft-Windows-Hyper-V-Worker-Admin" /enabled:true /quiet:true
    wevtutil sl "Microsoft-Windows-Hyper-V-Worker-Analytic" /enabled:false /retention:false /maxsize:$Size /quiet:true
    wevtutil sl "Microsoft-Windows-Hyper-V-Worker-Analytic" /enabled:true /quiet:true
    wevtutil sl "Microsoft-Windows-Hyper-V-Worker-VDev-Analytic" /enabled:false /retention:false /maxsize:$Size /quiet:true
    wevtutil sl "Microsoft-Windows-Hyper-V-Worker-VDev-Analytic" /enabled:true /quiet:true
    wevtutil sl "Microsoft-Windows-Hyper-V-High-Availability-Analytic" /enabled:false /retention:false /maxsize:$Size /quiet:true
    wevtutil sl "Microsoft-Windows-Hyper-V-High-Availability-Analytic" /enabled:true /quiet:true
}

function DisableAndExportLogs([string]$Path, [switch]$Full)
{
    if ($Global:DebugOutput)
    {
        " >>> {0} {1}" -f (Get-PSCallStack)[0].FunctionName,(Get-PSCallStack)[0].Arguments
    }

    write-host "Export event logs"
    $FileSuffix = $ENV:ComputerName
    $OutputFile = $Path+$FileSuffix+"_"

    wevtutil epl "Microsoft-Windows-Hyper-V-VMMS-Admin" $OutputFile"VMMS_Admin.evtx" /ow:true
    wevtutil sl "Microsoft-Windows-Hyper-V-VMMS-Analytic" /enabled:false /quiet:true
    wevtutil epl "Microsoft-Windows-Hyper-V-VMMS-Analytic" $OutputFile"VMMS_Analytic.evtx" /ow:true
    wevtutil sl "Microsoft-Windows-Hyper-V-Worker-Admin" /enabled:false /quiet:true
    wevtutil epl "Microsoft-Windows-Hyper-V-Worker-Admin" $OutputFile"Worker_Admin.evtx" /ow:true
    wevtutil sl "Microsoft-Windows-Hyper-V-Worker-Analytic" /enabled:false /quiet:true
    wevtutil epl "Microsoft-Windows-Hyper-V-Worker-Analytic" $OutputFile"Worker_Analytic.evtx" /ow:true
    wevtutil sl "Microsoft-Windows-Hyper-V-Worker-VDev-Analytic" /enabled:false /quiet:true
    wevtutil epl "Microsoft-Windows-Hyper-V-Worker-VDev-Analytic" $OutputFile"Worker_Vdev_Analytic.evtx" /ow:true
    wevtutil sl "Microsoft-Windows-Hyper-V-High-Availability-Analytic" /enabled:false /quiet:true
    wevtutil epl "Microsoft-Windows-Hyper-V-High-Availability-Analytic" $OutputFile"HA_Analytic.evtx" /ow:true

    if ($Full){
        wevtutil epl "System" $OutputFile"System.evtx"
        wevtutil epl "Application" $OutputFile"Application.evtx"
    }
}


function StartHyperVTracing([string]$Path,[string]$ThisScriptPath, [int32]$Size,[string]$VMLMode)
{
    if ($Global:DebugOutput)
    {
        " >>> {0} {1}" -f (Get-PSCallStack)[0].FunctionName,(Get-PSCallStack)[0].Arguments
    }

    if ($VMLMode -eq "VML")
    {
        StartVMLTrace -Path $Path -ThisScriptPath $ScriptPath -Size $Size 
    }
    else
    {
        EnableEventLogs -Size $Size 
    }
}

function StopHyperVTracing([string]$Path,[string]$ThisScriptPath,[string]$VMLMode)
{
    if ($Global:DebugOutput)
    {
        " >>> {0} {1}" -f (Get-PSCallStack)[0].FunctionName,(Get-PSCallStack)[0].Arguments
    }

    if ($VMLMode -eq "VML")
    {
        StopAndConvertVMLTrace -Path $Path -ThisScriptPath $ThisScriptPath
    }
    else
    {
        if ($Full){
            DisableAndExportLogs -Path $Path -Full
        }
        else{
            DisableAndExportLogs -Path $Path 
        }
    }
}

function StartVMLTrace([string]$Path,[string]$ThisScriptPath, [int32]$Size)
{
    if ($Global:DebugOutput)
    {
        " >>> {0} {1}" -f (Get-PSCallStack)[0].FunctionName,(Get-PSCallStack)[0].Arguments
    }
        
    StopVMLTrace -ThisScriptPath $ThisScriptPath -Path $Path

    SetChannelSize -Size $Size
    write-host "Starting the VMLTrace"
    $FileSuffix = $ENV:ComputerName
    $FilePath = $Path+"\"+$FileSuffix+"_VMLTrace.etl"
    $CommandLine = $ThisScriptPath+"\VMLTrace.exe /m v /m w /f vml all /f w all /f v all /f c all /f ha all /f vdev all /f m all /f wpmgr all /i /l "+$FilePath

    cmd.exe /c $CommandLine
}

function StopVMLTrace([string]$Path,[string]$ThisScriptPath)
{
    if ($Global:DebugOutput)
    {
        " >>> {0} {1}" -f (Get-PSCallStack)[0].FunctionName,(Get-PSCallStack)[0].Arguments
    }
    
    $CommandLine = $ThisScriptPath+"\VMLTrace.exe /s"
    cmd.exe /c $CommandLine
    
    $FileSuffix = $ENV:ComputerName
    $FilePath = $Path+"\"+$FileSuffix+"_VMLTrace.etl"
    
    if (Test-Path -Path $FilePath)
    {
        Remove-Item -Path $FilePath
    }
}

function StopAndConvertVMLTrace([string]$Path,[string]$ThisScriptPath)
{
    if ($Global:DebugOutput)
    {
        " >>> {0} {1}" -f (Get-PSCallStack)[0].FunctionName,(Get-PSCallStack)[0].Arguments
    }

    $FileSuffix = $ENV:ComputerName
    $EtlFilePath = $Path+"\"+$FileSuffix+"_VMLTrace.etl"
    $TxtFilePath = $Path+"\"+$FileSuffix+"_VMLTrace.txt"

    write-host "Stopping the VMLTrace"
    $CommandLine = $ThisScriptPath+"\VMLTrace.exe /s"
    
    cmd.exe /c $CommandLine

    write-host "Converting the VMLTrace"
    $CommandLine = "netsh trace convert input="+$EtlFilePath+" output="+$TxtFilePath+" overwrite=yes"
    
    cmd.exe /c $CommandLine
}

#endregion

#region [===== Network Tracing =====]
function StartNetwork([string]$Path, [string]$ThisScriptPath, [string]$NetMode)
{
    if ($Global:DebugOutput)
    {
        " >>> {0} {1}" -f (Get-PSCallStack)[0].FunctionName,(Get-PSCallStack)[0].Arguments
    }

    # possible values : PowerShell & Netsh
    if ($NetMode -eq "PowerShell")
    {
        StartNetworkTracingPShell -Path $Path
    }
    else 
    {
        StartNetworkTracing -Path $Path -ThisScriptPath $ThisScriptPath
    }
}

function StopNetwork([string]$ThisScriptPath, [string]$NetMode)
{
    if ($Global:DebugOutput)
    {
        " >>> {0} {1}" -f (Get-PSCallStack)[0].FunctionName,(Get-PSCallStack)[0].Arguments
    }

    if ($NetMode -eq "PowerShell")
    {
        StopNetworkTracingPShell
    }
    else 
    {
        StopNetworkTracing -ThisScriptPath $ThisScriptPath
    }
}

function StartNetworkTracing([string]$Path,[string]$ThisScriptPath)
{
    if ($Global:DebugOutput)
    {
        " >>> {0} {1}" -f (Get-PSCallStack)[0].FunctionName,(Get-PSCallStack)[0].Arguments
    }

    write-host "Starting the network trace"
    $CommandLine = $ThisScriptPath+"\StartNetTrace.cmd "+$Path
    
    cmd.exe /c $CommandLine
}

function StartNetworkTracingPShell([string]$Path)
{
    if ($Global:DebugOutput)
    {
        " >>> {0} {1}" -f (Get-PSCallStack)[0].FunctionName,(Get-PSCallStack)[0].Arguments
    }

    $FileSuffix = $ENV:ComputerName
    $EtlFilePath = $Path+"\"+$FileSuffix+"_Network.etl"
    
    write-host "Starting the network trace"
        
    Remove-NetEventSession -Name "NdisPacketCapture_Trace" -ErrorAction SilentlyContinue

    New-NetEventSession -Name "NdisPacketCapture_Trace" -LocalFilePath $EtlFilePath -MaxFileSize 4096

    Add-NetEventPacketCaptureProvider -SessionName "NdisPacketCapture_Trace" -TruncationLength 128 -IpProtocols 6  #-MultiLayer $true
    Start-NetEventSession "NdisPacketCapture_Trace"
}


function StopNetworkTracing([string]$ThisScriptPath)
{
    if ($Global:DebugOutput)
    {
        " >>> {0} {1}" -f (Get-PSCallStack)[0].FunctionName,(Get-PSCallStack)[0].Arguments
    }

    write-host "Stoping the network trace ... this step is expected to be long!"
    $CommandLine = $ThisScriptPath+"\StopNetTrace.cmd"
    cmd.exe /c $CommandLine
}

function StopNetworkTracingPShell()
{
    if ($Global:DebugOutput)
    {
        " >>> {0} {1}" -f (Get-PSCallStack)[0].FunctionName,(Get-PSCallStack)[0].Arguments
    }

    write-host "Stoping the network trace ..."
    Stop-NetEventSession -Name "NdisPacketCapture_Trace"
    Remove-NetEventSession -Name "NdisPacketCapture_Trace"
}
#endregion

#region [===== XPerf tracing =====]
function StartXperf([string]$ThisScriptPath)
{
    if ($Global:DebugOutput)
    {
        " >>> {0} {1}" -f (Get-PSCallStack)[0].FunctionName,(Get-PSCallStack)[0].Arguments
    }

    write-host "Starting the XPerf trace"
    $CommandLine = $ThisScriptPath+"\StartXPerf.cmd"
    cmd.exe /c $CommandLine
}

function StopXperf([string]$Path,[string]$ThisScriptPath)
{
    if ($Global:DebugOutput)
    {
        " >>> {0} {1}" -f (Get-PSCallStack)[0].FunctionName,(Get-PSCallStack)[0].Arguments
    }

    write-host "Stoping the XPerf trace ... this step is expected to be long!"
    $CommandLine = $ThisScriptPath+"\StopXPerf.cmd "+$Path+" "+$env:COMPUTERNAME
    cmd.exe /c $CommandLine
}
#endregion

#endregion

#region [=========================== MAIN ============================]

# Set the registry keys
if ($NoRestart){
    SetRegistryKeysForVerboseTracing
}
else{
    SetRegistryKeysForVerboseTracing -Restart
}

# Create a variable to store the current location of the script
$ScriptPath = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition

# Create the Export Path if needed
if ((Test-Path -Path $Path) -eq $false){
    new-item -Path $Path -ItemType Directory
}

# Collect configurations : Some data will be collected before and some after
if ($Export)
{
    CollectConfigurations -Path $Path -Step "Before"
}

# Start the Hyper-V Trace
StartHyperVTracing -Path $Path -ThisScriptPath $ScriptPath -Size 104857600 -VMLMode $VMLMode

# Start the network trace
if ($IncludeNetworkTrace){
    StartNetwork -Path $Path -ThisScriptPath $ScriptPath -NetMode $NetMode
}

# Start the XPerf trace
if ($IncludeXperf){
    StartXperf -ThisScriptPath $ScriptPath
}

# WaitMode can be either manual or event based

if ($WaitMode -eq "Manual")
{
    write-host "Press any key to continue ..." -ForegroundColor Green
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}

# Loop until we get a $EventId event
else {

    $StartingDate = Get-Date 
    Write-Host "Waiting for event $EventID starting " -NoNewline -ForegroundColor Green
    Get-Date -Format G

    While ($true){
        $CurrentDate = Get-Date
        $LastEventDate = (get-winevent -LogName Microsoft-Windows-Hyper-V-VMMS-Admin -ComputerName $SrcNode -ErrorAction SilentlyContinue | Where-Object { $_.Id -eq $EventID } | Select-Object -First 1).TimeCreated
        $SecSinceLastEvent = ($CurrentDate-$LastEventDate).TotalSeconds
        $TotalSecWait = ($CurrentDate-$StartingDate).TotalSeconds
        if ($SecSinceLastEvent -lt 5){
            Write-Host "Event $EventID detected on " -NoNewline -ForegroundColor Green
            Get-Date -Format G
            break
        }
        if ($TotalSecWait -gt $TimeoutInSeconds){
            Write-host "Timeout ($TimeoutInSeconds sec) exceeded"
            break
        }
    }
}

# Stop the network trace
if ($IncludeNetworkTrace){
    StopNetwork -ThisScriptPath $ScriptPath -NetMode $NetMode
}

# Stop the Hyper-V Tracing
StopHyperVTracing -Path $Path -ThisScriptPath $ScriptPath -VMLMode $VMLMode

# Stop the XPerf trace
if ($IncludeXperf){
    StopXperf -Path $Path -ThisScriptPath $ScriptPath
}

# Collect configurations after
if ($Export)
{
    CollectConfigurations -Path $Path -Step "After"
}

# Collect the cluster configuration
if ($Cluster)
{
    ExportClusDB -Path $Path
}

# End
write-host "Please zip the content of $Path and sent it to us"
write-host "Please don't forget to also send the NetTrace.etl file saved in your temp folder (see above)" -ForegroundColor Yellow

#endregion
