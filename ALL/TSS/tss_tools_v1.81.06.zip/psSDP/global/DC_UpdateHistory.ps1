﻿#************************************************
# UpdateHistory.ps1
# Version 1.0.1
# Date: 7/2/2013
# Author: v-maam
# Description:  This file will list all updates installed on the local machine
#************************************************
#_#Param($Prefix = '', $Suffix = '', $OutputFormats= @("TXT", "CSV", "HTM"), [int]$NumberOfDays=10, [Switch]$ExportOnly)
Param($Prefix = '', $Suffix = '', $OutputFormats= @("TXT", "CSV"), [int]$NumberOfDays=10, [Switch]$ExportOnly) #_#

trap
{		
	WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText "[UpdateHistory.ps1] error"
	continue
}

Import-LocalizedData -BindingVariable ScriptStrings

# ***************************
# Store the updates history output information in CSV, TXT, XML format
# ***************************

$Script:SbCSVFormat = New-Object -TypeName System.Text.StringBuilder
$Script:SbTXTFormat = New-Object -TypeName System.Text.StringBuilder
$Script:SbXMLFormat = New-Object -TypeName System.Text.StringBuilder

# Store the WU errors
$Script:WUErrors

# Store the Updated installed in the past $NumberOfDays days when $ExportOnly is not used
if($ExportOnly.IsPresent -eq $false)
{
	$LatestUpdates_Summary= New-Object PSObject
	$LatestUpdates_Summary | Add-Member -MemberType NoteProperty -Name "  Date" -Value ("<table><tr><td width=`"40px`" style=`"border-bottom:1px solid #CCCCCC`">Results</td><td width=`"60px`" style=`"border-bottom:1px solid #CCCCCC`">ID</td><td width=`"300px`" style=`"border-bottom:1px solid #CCCCCC`">Category</td></tr></table>")
	[int]$Script:LatestUpdateCount = 0
}

# ***************************
# Functions
# ***************************

Function GetHotFixFromRegistry
{
	$RegistryHotFixList = @{}
	$UpdateRegistryKeys = @("HKLM:\SOFTWARE\Microsoft\Updates")

	#if $OSArchitecture -ne X86 , should be 64-bit machine. we also need to check HKLM:\SOFTWARE\Wow6432Node\Microsoft\Updates
	if($OSArchitecture -ne "X86")
	{
		$UpdateRegistryKeys += "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Updates"
	}
						  						 	
	foreach($RegistryKey in $UpdateRegistryKeys)
	{
		If(Test-Path $RegistryKey)
		{
			$AllProducts = Get-ChildItem $RegistryKey -Recurse | Where-Object {$_.Name.Contains("KB") -or $_.Name.Contains("Q")}

			foreach($subKey in $AllProducts)
			{
				if($subKey.Name.Contains("KB") -or $subKey.Name.Contains("Q"))
				{
					$HotFixID = GetHotFixID $subKey.Name
					if($RegistryHotFixList.Keys -notcontains $HotFixID)
					{
						$Category = [regex]::Match($subKey.Name,"Updates\\(?<Category>.*?)[\\]").Groups["Category"].Value
						$HotFix = @{HotFixID=$HotFixID;Category=$Category}				
						foreach($property in $subKey.Property)
						{
							$HotFix.Add($property,$subKey.GetValue($property))
						}
						$RegistryHotFixList.Add($HotFixID,$HotFix)
					}
				}
			}
		}
	}
	return $RegistryHotFixList
}

Function GetHotFixID($strContainID)
{
	return [System.Text.RegularExpressions.Regex]::Match($strContainID,"(KB|Q)\d+(v\d)?").Value
}

Function ToNumber($strHotFixID)
{
	return [System.Text.RegularExpressions.Regex]::Match($strHotFixID,"([0-9])+").Value
}

Function FormatStr([string]$strValue,[int]$NumberofChars)
{
	if([String]::IsNullOrEmpty($strValue))
	{
		$strValue = " "
		return $strValue.PadRight($NumberofChars," ")
	}
	else
	{
		if($strValue.Length -lt $NumberofChars)
		{
			return $strValue.PadRight($NumberofChars," ")
		}
		else
		{
			return $strValue.Substring(0,$NumberofChars)
		}
	}
}

# Make sure all dates are with dd/mm/yy hh:mm:ss
Function FormatDateTime($dtLocalDateTime,[Switch]$SortFormat)
{	
	trap
	{		
		WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText "[FormatDateTime] Error Convert date time"
		continue
	}

	if([string]::IsNullOrEmpty($dtLocalDateTime))
	{
		return ""
	}
	
	if($SortFormat.IsPresent)
	{
		# Obtain dates on yyyymmdddhhmmss
		return Get-Date -Date $dtLocalDateTime -Format "yyyyMMddHHmmss"
	}
	else
	{
		return Get-Date -Date $dtLocalDateTime -Format G
	}
}

Function ValidatingDateTime($dateTimeToValidate)
{
	trap
	{		
		WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText "[ValidateDateTime] Error"
		continue
	}

	if([String]::IsNullOrEmpty($dateTimeToValidate))
	{
		return $false
	}

	$ConvertedDateTime = Get-Date -Date $dateTimeToValidate

	if($ConvertedDateTime -ne $null)
	{
		if(((Get-Date) - $ConvertedDateTime).Days -le $NumberOfDays)
		{
			return $true
		}
	}

	return $false
}

Function GetUpdateResultString($OperationResult)
{
	switch ($OperationResult)
	{
		"Completed successfully"  {return "<span xmlns:v=`"urn:schemas-microsoft-com:vml`"><v:group id=`"Inf1`" class=`"vmlimage`" style=`"width:15px;height:15px;vertical-align:middle`" coordsize=`"100,100`" title=`"Completed successfully`"><v:oval class=`"vmlimage`" style=`"width:100;height:100;z-index:0`" fillcolor=`"#009933`" strokecolor=`"#C0C0C0`" /></v:group></span>"}
		"In progress"  {return "<span xmlns:v=`"urn:schemas-microsoft-com:vml`"><v:group class=`"vmlimage`" style=`"width:14px;height:14px;vertical-align:middle`" coordsize=`"100,100`" title=`"In progress`"><v:roundrect class=`"vmlimage`" arcsize=`"10`" style=`"width:100;height:100;z-index:0`" fillcolor=`"#00FF00`" strokecolor=`"#C0C0C0`" /><v:shape class=`"vmlimage`" style=`"width:100; height:100; z-index:0`" fillcolor=`"white`" strokecolor=`"white`"><v:path v=`"m 40,25 l 75,50 40,75 x e`" /></v:shape></v:group></span>"}
		"Operation was aborted"  {return "<span xmlns:v=`"urn:schemas-microsoft-com:vml`"><v:group class=`"vmlimage`" style=`"width:15px;height:15px;vertical-align:middle`" coordsize=`"100,100`" title=`"Operation was aborted`"><v:roundrect class=`"vmlimage`" arcsize=`"20`" style=`"width:100;height:100;z-index:0`" fillcolor=`"#290000`" strokecolor=`"#C0C0C0`" /><v:line class=`"vmlimage`" style=`"z-index:2`" from=`"52,30`" to=`"52,75`" strokecolor=`"white`" strokeweight=`"8px`" /></v:group></span>"}
		"Completed with errors"  {return "<span xmlns:v=`"urn:schemas-microsoft-com:vml`"><v:group class=`"vmlimage`" style=`"width:15px;height:15px;vertical-align:middle`" coordsize=`"100,100`" title=`"Completed with errors`"><v:shape class=`"vmlimage`" style=`"width:100; height:100; z-index:0`" fillcolor=`"yellow`" strokecolor=`"#C0C0C0`"><v:path v=`"m 50,0 l 0,99 99,99 x e`" /></v:shape><v:rect class=`"vmlimage`" style=`"top:35; left:45; width:10; height:35; z-index:1`" fillcolor=`"black`" strokecolor=`"black`"></v:rect><v:rect class=`"vmlimage`" style=`"top:85; left:45; width:10; height:5; z-index:1`" fillcolor=`"black`" strokecolor=`"black`"></v:rect></v:group></span>"}
		"Failed to complete"  {return "<span xmlns:v=`"urn:schemas-microsoft-com:vml`"><v:group class=`"vmlimage`" style=`"width:15px;height:15px;vertical-align:middle`" coordsize=`"100,100`" title=`"Failed to complete`"><v:oval class=`"vmlimage`" style=`"width:100;height:100;z-index:0`" fillcolor=`"red`" strokecolor=`"#C0C0C0`"></v:oval><v:line class=`"vmlimage`" style=`"z-index:1`" from=`"25,25`" to=`"75,75`" strokecolor=`"white`" strokeweight=`"3px`"></v:line><v:line class=`"vmlimage`" style=`"z-index:2`" from=`"75,25`" to=`"25,75`" strokecolor=`"white`" strokeweight=`"3px`"></v:line></v:group></span>"}
		Default { return "<span xmlns:v=`"urn:schemas-microsoft-com:vml`"><v:group id=`"Inf1`" class=`"vmlimage`" style=`"width:15px;height:15px;vertical-align:middle`" coordsize=`"100,100`" title=`"{$OperationResult}`"><v:oval class=`"vmlimage`" style=`"width:100;height:100;z-index:0`" fillcolor=`"#FF9933`" strokecolor=`"#C0C0C0`" /></v:group></span>" }
	}
}

Function GetOSSKU($SKU)
{
	switch ($SKU)
	{
		0  {return ""}
		1  {return "Ultimate Edition"}
		2  {return "Home Basic Edition"}
		3  {return "Home Basic Premium Edition"}
		4  {return "Enterprise Edition"}
		5  {return "Home Basic N Edition"}
		6  {return "Business Edition"}
		7  {return "Standard Server Edition"}
		8  {return "Datacenter Server Edition"}
		9  {return "Small Business Server Edition"}
		10 {return "Enterprise Server Edition"}
		11 {return "Starter Edition"}
		12 {return "Datacenter Server Core Edition"}
		13 {return "Standard Server Core Edition"}
		14 {return "Enterprise Server Core Edition"}
		15 {return "Enterprise Server Edition for Itanium-Based Systems"}
		16 {return "Business N Edition"}
		17 {return "Web Server Edition"}
		18 {return "Cluster Server Edition"}
		19 {return "Home Server Edition"}
		20 {return "Storage Express Server Edition"}
		21 {return "Storage Standard Server Edition"}
		22 {return "Storage Workgroup Server Edition"}
		23 {return "Storage Enterprise Server Edition"}
		24 {return "Server For Small Business Edition"}
		25 {return "Small Business Server Premium Edition"}	
	}	
}

Function GetOS()
{
	$WMIOS = Get-WmiObject -Class Win32_OperatingSystem

	$StringOS = $WMIOS.Caption

	if($WMIOS.CSDVersion -ne $null)
	{
		$StringOS += " - " + $WMIOS.CSDVersion
	}
	else
	{
		$StringOS += " - Service Pack not installed"
	}

	if(($WMIOS.OperatingSystemSKU -ne $null) -and ($WMIOS.OperatingSystemSKU.ToString().Length -gt 0))
	{
		$StringOS += " ("+(GetOSSKU $WMIOS.OperatingSystemSKU)+")"
	}

	return $StringOS
}

# Query SID of an object using WMI and return the account name
Function ConvertSIDToUser([string]$strSID) 
{
	trap
	{		
		WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText "[ConvertSIDToUser] Error convert User SID to User Account"
		continue
	}
	
	if([string]::IsNullOrEmpty($strSID))
	{
		return
	}

	if($strSID.StartsWith("S-1-5"))
	{
		$UserSIDIdentifier = New-Object System.Security.Principal.SecurityIdentifier `
    	($strSID)
		$UserNTAccount = $UserSIDIdentifier.Translate( [System.Security.Principal.NTAccount])
		if($UserNTAccount.Value.Length -gt 0)
		{
			return $UserNTAccount.Value
		}
		else
		{
			return $strSID
		}
	}
	
	return $strSID	
}

Function ConvertToHex([int]$number)
{
	return ("0x{0:x8}" -f $number)
}

Function GetUpdateOperation($Operation)
{
	switch ($Operation)
	{
		1 { return "Install" }
		2 { return "Uninstall" }
		Default { return "Unknown("+$Operation+")" }
	}
}

Function GetUpdateResult($ResultCode)
{
	switch ($ResultCode)
	{
		0 { return "Not started" }
		1 { return "In progress" }
		2 { return "Completed successfully" }
		3 { return "Completed with errors" }
		4 { return "Failed to complete" }
		5 { return "Operation was aborted" }
		Default { return "Unknown("+$ResultCode+")" }
	}					
}

Function GetWUErrorCodes($HResult)
{
	if($Script:WUErrors -eq $null)
	{
		$WUErrorsFilePath = Join-Path $PWD.Path "WUErrors.xml"
		if(Test-Path $WUErrorsFilePath)
		{
			[xml] $Script:WUErrors = Get-Content $WUErrorsFilePath
		}
		else
		{
			"[Error]: Did not find the WUErrors.xml file, can not load all WU errors" | WriteTo-StdOut -ShortFormat
		}
	}

	$WUErrorNode = $Script:WUErrors.ErrV1.err | Where-Object {$_.n -eq $HResult}

	if($WUErrorNode -ne $null)
	{
		$WUErrorCode = @()
		$WUErrorCode += $WUErrorNode.name
		$WUErrorCode += $WUErrorNode."#text"
		return $WUErrorCode
	}

	return $null
}

Function PrintHeaderOrXMLFooter([switch]$IsHeader,[switch]$IsXMLFooter)
{
	if($IsHeader.IsPresent)
	{
		if($OutputFormats -contains "TXT")
		{
			# TXT formate Header
			LineOut -IsTXTFormat -Value ([String]::Format("{0} {1} {2} {3} {4} {5} {6} {7} {8}",
												(FormatStr "Category" 20),
												(FormatStr "Level" 6),
												(FormatStr "ID" 10),
												(FormatStr "Operation" 11),
												(FormatStr "Date" 23),
												(FormatStr "Client" 18),
												(FormatStr "By" 28),
												(FormatStr "Result" 23),
												"Title"))																								
			LineOut -IsTXTFormat -Value ("-").PadRight(200,"-")
		}

		if($OutputFormats -contains "CSV")
		{
			# CSV formate Header										
			LineOut -IsCSVFormat -Value ("Category,Level,ID,Operation,Date,Client,By,Result,Title")
		}

		if($OutputFormats -contains "HTM")
		{
			# XML format Header
			LineOut -IsXMLFormat -IsXMLLine -Value "<?xml version=`"1.0`" encoding=`"UTF-8`"?>"
			LineOut -IsXMLFormat -IsOpenTag -TagName "Root"
			LineOut -IsXMLFormat -IsOpenTag -TagName "Updates"
			LineOut -IsXMLFormat -IsXMLLine -Value ("<Title name=`"QFE Information from`">"+$Env:COMPUTERNAME+"</Title>")
			LineOut -IsXMLFormat -IsXMLLine -Value ("<OSVersion name=`"Operating System`">"+(GetOS)+"</OSVersion>")
			LineOut -IsXMLFormat -IsXMLLine -Value ("<TimeField name=`"Local time`">"+[DateTime]::Now.ToString()+"</TimeField>")
		}
	}
	
	if($IsXMLFooter)
	{
		if($OutputFormats -contains "HTM")
		{
			LineOut -IsXMLFormat -IsCloseTag -TagName "Updates"
			LineOut -IsXMLFormat -IsCloseTag -TagName "Root"
		}		
	}
}

Function LineOut([string]$TagName,[string]$Value,[switch]$IsTXTFormat,[switch]$IsCSVFormat,[switch]$IsXMLFormat,[switch]$IsXMLLine,[switch]$IsOpenTag,[switch]$IsCloseTag)
{
	if($IsTXTFormat.IsPresent)
	{		
		[void]$Script:SbTXTFormat.AppendLine($Value)
	}
	
	if($IsCSVFormat.IsPresent)
	{
		[void]$Script:SbCSVFormat.AppendLine($Value)
	}
	
	if($IsXMLFormat.IsPresent)
	{
		if($IsXMLLine.IsPresent)
		{
			[void]$Script:SbXMLFormat.AppendLine($Value)
			return
		}
		
		if(($TagName -eq $null) -or ($TagName -eq ""))
		{
			"[Warning]: Did not provide valid TagName: $TagName, will not add this Tag." | WriteTo-StdOut -ShortFormat
			return
		}
		
		if($IsOpenTag.IsPresent -or $IsCloseTag.IsPresent)
		{
			if($IsOpenTag.IsPresent)
			{
				[void]$Script:SbXMLFormat.AppendLine("<"+$TagName+">")
			}
	
			if($IsCloseTag.IsPresent)
			{
				[void]$Script:SbXMLFormat.AppendLine("</"+$TagName+">")
			}
		}
		else
		{
			[void]$Script:SbXMLFormat.AppendLine("<"+$TagName+">"+$Value+"</"+$TagName+">")
		}
	}
}

Function PrintUpdate([string]$Category,[string]$SPLevel,[string]$ID,[string]$Operation,[string]$Date,[string]$ClientID,[string]$InstalledBy,[string]$OperationResult,[string]$Title,[string]$Description,[string]$HResult,[string]$UnmappedResultCode)
{
	if($OutputFormats -contains "TXT")
	{
		LineOut -IsTXTFormat -Value ([String]::Format("{0} {1} {2} {3} {4} {5} {6} {7} {8}",
												(FormatStr $Category 20),
												(FormatStr $SPLevel 6),
												(FormatStr $ID 10),
												(FormatStr $Operation 11),
												(FormatStr $Date 23),
												(FormatStr $ClientID 18),
												(FormatStr $InstalledBy 28),
												(FormatStr $OperationResult 23),
												$Title))
	}

	if($OutputFormats -contains "CSV")
	{
		LineOut -IsCSVFormat -Value ([String]::Format("{0},{1},{2},{3},{4},{5},{6},{7},{8}",
												  $Category,
												  $SPLevel,
												  $ID,
												  $Operation,
												  $Date,
												  $ClientID,
												  $InstalledBy,
												  $OperationResult,
												  $Title))
	}

	if($OutputFormats -contains "HTM")
	{	
		if($Category -eq "QFE hotfix")
		{
			$Category = "Other updates not listed in history"
		}
		
		if(-not [String]::IsNullOrEmpty($ID))
		{
			$NumberHotFixID = ToNumber $ID
			if($NumberHotFixID.Length -gt 5)
			{
				$SupportLink = "http://support.microsoft.com/kb/$NumberHotFixID"				
			}
		}
		else
		{
			$ID = ""
			$SupportLink = ""
		}	

		if([String]::IsNullOrEmpty($Date))
		{
			$DateTime = ""
		}
		else
		{
			$DateTime = FormatDateTime $Date -SortFormat			
		}

		if([String]::IsNullOrEmpty($Title))
		{
			$Title = ""
		}
		else
		{
			$Title = $Title.Trim()
		}

		if([String]::IsNullOrEmpty($Description))
		{
			$Description = ""
		}
		else
		{
			$Description = $Description.Trim()			
		}

		# Write the Update to XML Formate
		LineOut -IsXMLFormat -TagName "Update" -IsOpenTag
		LineOut -IsXMLFormat -TagName "Category" -Value $Category
		if(-not [String]::IsNullOrEmpty($SPLevel))
		{
			LineOut -IsXMLFormat -TagName "SPLevel" -Value $SPLevel
		}
		LineOut -IsXMLFormat -TagName "ID" -Value $ID
		LineOut -IsXMLFormat -TagName "SupportLink" -Value $SupportLink
		LineOut -IsXMLFormat -TagName "Operation" -Value $Operation
		LineOut -IsXMLFormat -TagName "Date" -Value $Date
		LineOut -IsXMLFormat -TagName "SortableDate" -Value $DateTime
		LineOut -IsXMLFormat -TagName "ClientID" -Value $ClientID
		LineOut -IsXMLFormat -TagName "InstalledBy" -Value $InstalledBy
		LineOut -IsXMLFormat -TagName "OperationResult" -Value $OperationResult
		LineOut -IsXMLFormat -TagName "Title" -Value $Title
		LineOut -IsXMLFormat -TagName "Description" -Value $Description

		if((-not [String]::IsNullOrEmpty($HResult)) -and ($HResult -ne 0))
		{
			$HResultHex = ConvertToHex $HResult
			$HResultArray= GetWUErrorCodes $HResultHex
					
			LineOut -IsXMLFormat -IsOpenTag -TagName "HResult"
			LineOut -IsXMLFormat -TagName "HEX" -Value $HResultHex
			if($HResultArray -ne $null)
			{
				LineOut -IsXMLFormat -TagName "Constant" -Value $HResultArray[0]
				LineOut -IsXMLFormat -TagName "Description" -Value $HResultArray[1]
			}
			LineOut -IsXMLFormat -IsCloseTag -TagName "HResult"
			LineOut -IsXMLFormat -TagName "UnmappedResultCode" -Value (ConvertToHex $UnmappedResultCode)
		}

		LineOut -IsXMLFormat -TagName "Update" -IsCloseTag


		if (($ExportOnly.IsPresent -eq $false) -and (ValidatingDateTime $Date))
		{	
			if($LatestUpdates_Summary.$Date -ne $null)	
			{	
				$LatestUpdates_Summary.$Date = $LatestUpdates_Summary.$Date.Insert($LatestUpdates_Summary.$Date.LastIndexOf("</table>"),"<tr><td width=`"40px`" align=`"center`">" +(GetUpdateResultString $OperationResult) + "</td><td width=`"60px`"><a href=`"$SupportLink`" Target=`"_blank`">$ID</a></td><td>$Category</td></tr>")
			}
			else
			{
				$LatestUpdates_Summary | Add-Member -MemberType NoteProperty -Name $Date -Value ("<table><tr><td width=`"40px`" align=`"center`">" +(GetUpdateResultString $OperationResult) + "</td><td width=`"60px`"><a href=`"$SupportLink`" Target=`"_blank`">$ID</a></td><td>$($Category): $($Title)</td></tr></table>")	
			}
					
			$Script:LatestUpdateCount++
		}	
	}
}

Function GenerateHTMFile([string] $XMLFileNameWithoutExtension)
{
	trap
	{		
		WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText "[GenerateHTMFile] Error creating HTM file"
		continue
	}

	$UpdateXslFilePath = Join-Path $pwd.path "UpdateHistory.xsl"
	if(Test-Path $UpdateXslFilePath)
	{
		$XSLObject = New-Object System.Xml.Xsl.XslTransform
		$XSLObject.Load($UpdateXslFilePath)
		if(Test-Path ($XMLFileNameWithoutExtension + ".XML"))
		{
			$XSLObject.Transform(($XMLFileNameWithoutExtension + ".XML"), ($XMLFileNameWithoutExtension + ".HTM"))
		}
		else
		{
			"Error: HTML file was not generated" | WriteTo-StdOut -ShortFormat
		}
	}
	else
	{
		"Error: Did not find the UpdateHistory.xsl, won't generate HTM file" | WriteTo-StdOut -ShortFormat
	}
}

# ***************************
# Start here
# ***************************

Write-DiagProgress -Activity $ScriptStrings.ID_InstalledUpdates -Status $ScriptStrings.ID_InstalledUpdatesObtaining

# Get updates from the com object
"Querying IUpdateSession Interface to get the Update History" | WriteTo-StdOut -ShortFormat

$Session = New-Object -ComObject Microsoft.Update.Session
$Searcher = $Session.CreateUpdateSearcher()
$HistoryCount = $Searcher.GetTotalHistoryCount()
if ($HistoryCount -gt 0) 
{
	trap [Exception] 
	{
		WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText "Querying Update History"
		continue
	}

	$ComUpdateHistory = $Searcher.QueryHistory(1,$HistoryCount)
}
else
{
	$ComUpdateHistory = @()
	"No updates found on Microsoft.Update.Session" | WriteTo-StdOut -ShortFormat
}

# Get updates from the Wmi object Win32_QuickFixEngineering
"Querying Win32_QuickFixEngineering to obtain updates that are not on update history" | WriteTo-StdOut -ShortFormat

$QFEHotFixList = New-Object "System.Collections.ArrayList"
$QFEHotFixList.AddRange(@(Get-WmiObject -Class Win32_QuickFixEngineering))

# Get updates from the regsitry keys
"Querying Updates listed in the registry" | WriteTo-StdOut -ShortFormat
$RegistryHotFixList = GetHotFixFromRegistry

Write-DiagProgress -Activity $ScriptStrings.ID_InstalledUpdates -Status $ScriptStrings.ID_InstalledUpdatesFormateOutPut
PrintHeaderOrXMLFooter -IsHeader

# Format each update history to the stringbuilder
"Generating information for $HistoryCount updates found on update history" | WriteTo-StdOut -ShortFormat
foreach($updateEntry in $ComUpdateHistory)
{	
	#Do not list the updates on which the $updateEntry.ServiceID = '117CAB2D-82B1-4B5A-A08C-4D62DBEE7782'. These are Windows Store updates and are bringing inconsistent results
	if($updateEntry.ServiceID -ne '117CAB2D-82B1-4B5A-A08C-4D62DBEE7782')
	{		
		$HotFixID = GetHotFixID $updateEntry.Title
		$HotFixIDNumber = ToNumber $HotFixID
		$strInstalledBy = ""
		$strSPLevel = ""
	
		if(($HotFixID -ne "") -or ($HotFixIDNumber -ne ""))
		{
			foreach($QFEHotFix in $QFEHotFixList)
			{
				if(($QFEHotFix.HotFixID -eq $HotFixID) -or
		   			((ToNumber $QFEHotFix.HotFixID) -eq $HotFixIDNumber))
				{
					$strInstalledBy = ConvertSIDToUser $QFEHotFix.InstalledBy
					$strSPLevel = $QFEHotFix.ServicePackInEffect

					#Remove the duplicate HotFix in the QFEHotFixList
					$QFEHotFixList.Remove($QFEHotFix)
					break
				}
			}
		}
	
		#Remove the duplicate HotFix in the RegistryHotFixList
		if($RegistryHotFixList.Keys -contains $HotFixID)
		{
			$RegistryHotFixList.Remove($HotFixID)
		}

		$strCategory = ""		
		if($updateEntry.Categories.Count -gt 0)
		{
			$strCategory = $updateEntry.Categories.Item(0).Name
		}
	
		if([String]::IsNullOrEmpty($strCategory))
		{
			$strCategory = "(None)"
		}
	
		$strOperation = GetUpdateOperation $updateEntry.Operation
		$strDateTime = FormatDateTime $updateEntry.Date
		$strResult = GetUpdateResult $updateEntry.ResultCode

		PrintUpdate $strCategory $strSPLevel $HotFixID $strOperation $strDateTime $updateEntry.ClientApplicationID $strInstalledBy $strResult $updateEntry.Title $updateEntry.Description $updateEntry.HResult $updateEntry.UnmappedResultCode
	}
}

# Out Put the Non History QFEFixes
"Generating information for " + $QFEHotFixList.Count + " updates found on Win32_QuickFixEngineering WMI class" | WriteTo-StdOut -ShortFormat
foreach($QFEHotFix in $QFEHotFixList)
{
	$strInstalledBy = ConvertSIDToUser $QFEHotFix.InstalledBy
	$strDateTime = FormatDateTime $QFEHotFix.InstalledOn
	$strCategory = ""

	#Remove the duplicate HotFix in the RegistryHotFixList
	if($RegistryHotFixList.Keys -contains $QFEHotFix.HotFixID)
	{
		$strCategory = $RegistryHotFixList[$QFEHotFix.HotFixID].Category
		$strRegistryDateTime = FormatDateTime $RegistryHotFixList[$QFEHotFix.HotFixID].InstalledDate		
		if([String]::IsNullOrEmpty($strInstalledBy))
		{
			$strInstalledBy = $RegistryHotFixList[$QFEHotFix.HotFixID].InstalledBy
		}

		$RegistryHotFixList.Remove($QFEHotFix.HotFixID)
	}
	
	if([string]::IsNullOrEmpty($strCategory))
	{
		$strCategory = "QFE hotfix"
	}	
	if($strDateTime.Length -eq 0)
	{
		$strDateTime = $strRegistryDateTime
	}
	if([string]::IsNullOrEmpty($QFEHotFix.Status))
	{
		$strResult = "Completed successfully"
	}
	else
	{
		$strResult = $QFEHotFix.Status
	}	

	PrintUpdate $strCategory $QFEHotFix.ServicePackInEffect $QFEHotFix.HotFixID "Install" $strDateTime "" $strInstalledBy $strResult $QFEHotFix.Description $QFEHotFix.Caption
}

"Generating information for " + $RegistryHotFixList.Count + " updates found on registry" | WriteTo-StdOut -ShortFormat
foreach($key in $RegistryHotFixList.Keys)
{
	$strCategory = $RegistryHotFixList[$key].Category
	$HotFixID = $RegistryHotFixList[$key].HotFixID
	$strDateTime = $RegistryHotFixList[$key].InstalledDate
	$strInstalledBy = $RegistryHotFixList[$key].InstalledBy
	$ClientID = $RegistryHotFixList[$key].InstallerName

	if($HotFixID.StartsWith("Q"))
	{
		$Description = $RegistryHotFixList[$key].Description
	}
	else
	{
		$Description = $RegistryHotFixList[$key].PackageName		
	}

	if([string]::IsNullOrEmpty($Description))
	{
		$Description = $strCategory
	}

	PrintUpdate $strCategory "" $HotFixID "Install" $strDateTime $ClientID $strInstalledBy "Completed successfully" $strCategory $Description
}

PrintHeaderOrXMLFooter -IsXMLFooter

Write-DiagProgress -Activity $ScriptStrings.ID_InstalledUpdates -Status $ScriptStrings.ID_InstalledUpdatesOutPutAndCollectFile
$FileNameWithoutExtension = $ComputerName +"_"+ $Prefix + "Hotfixes" + $Suffix

"Creating output files" | WriteTo-StdOut -ShortFormat
if($OutputFormats -contains "CSV")
{
	$Script:SbCSVFormat.ToString() | Out-File ($FileNameWithoutExtension + ".CSV") -Encoding "UTF8"
}

if($OutputFormats -contains "TXT")
{
	$Script:SbTXTFormat.ToString() | Out-File ($FileNameWithoutExtension + ".TXT") -Encoding "UTF8"
}

if($OutputFormats -contains "HTM")
{
	$Script:SbXMLFormat.ToString().replace("&","") | Out-File ($FileNameWithoutExtension + ".XML") -Encoding "UTF8"

	"Generate the HTML Updates file according the UpdateHistory.xsl and XML file" | WriteTo-StdOut -ShortFormat
	GenerateHTMFile $FileNameWithoutExtension
}

$FileToCollects = @("$FileNameWithoutExtension.CSV","$FileNameWithoutExtension.TXT","$FileNameWithoutExtension.HTM")

if($ExportOnly.IsPresent)
{
	Copy-Item $FileToCollects -Destination (Join-Path $PWD.Path "result")
}
else
{
	if($Script:LatestUpdateCount -gt 0)
	{		
		$LatestUpdates_Summary | Add-Member -MemberType NoteProperty -Name "More Information" -Value ("<table><tr><td>For a complete list of installed updates, please open <a href= `"`#" + $FileNameWithoutExtension + ".HTM`">" + $FileNameWithoutExtension + ".HTM</a></td></tr></table>")
		$LatestUpdates_Summary | ConvertTo-Xml2 -sortObject | update-diagreport -id 11_Updates -name "Updates installed in past $NumberOfDays days ($($Script:LatestUpdateCount))" -verbosity informational
	}
	
	CollectFiles -filesToCollect $FileToCollects -fileDescription "Installed Updates and Hotfixes" -sectionDescription "General Information"
}

# SIG # Begin signature block
# MIIdugYJKoZIhvcNAQcCoIIdqzCCHacCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUJJAase+Ek348cGKezs1niXf+
# T4ygghhkMIIEwzCCA6ugAwIBAgITMwAAAJvgdDfLPU2NLgAAAAAAmzANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwMzMwMTkyMTI5
# WhcNMTcwNjMwMTkyMTI5WjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OjcyOEQtQzQ1Ri1GOUVCMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAjaPiz4GL18u/
# A6Jg9jtt4tQYsDcF1Y02nA5zzk1/ohCyfEN7LBhXvKynpoZ9eaG13jJm+Y78IM2r
# c3fPd51vYJxrePPFram9W0wrVapSgEFDQWaZpfAwaIa6DyFyH8N1P5J2wQDXmSyo
# WT/BYpFtCfbO0yK6LQCfZstT0cpWOlhMIbKFo5hljMeJSkVYe6tTQJ+MarIFxf4e
# 4v8Koaii28shjXyVMN4xF4oN6V/MQnDKpBUUboQPwsL9bAJMk7FMts627OK1zZoa
# EPVI5VcQd+qB3V+EQjJwRMnKvLD790g52GB1Sa2zv2h0LpQOHL7BcHJ0EA7M22tQ
# HzHqNPpsPQIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFJaVsZ4TU7pYIUY04nzHOUps
# IPB3MB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBACEds1PpO0aBofoqE+NaICS6dqU7tnfIkXIE1ur+0psiL5MI
# orBu7wKluVZe/WX2jRJ96ifeP6C4LjMy15ZaP8N0OckPqba62v4QaM+I/Y8g3rKx
# 1l0okye3wgekRyVlu1LVcU0paegLUMeMlZagXqw3OQLVXvNUKHlx2xfDQ/zNaiv5
# DzlARHwsaMjSgeiZIqsgVubk7ySGm2ZWTjvi7rhk9+WfynUK7nyWn1nhrKC31mm9
# QibS9aWHUgHsKX77BbTm2Jd8E4BxNV+TJufkX3SVcXwDjbUfdfWitmE97sRsiV5k
# BH8pS2zUSOpKSkzngm61Or9XJhHIeIDVgM0Ou2QwggYHMIID76ADAgECAgphFmg0
# AAAAAAAcMA0GCSqGSIb3DQEBBQUAMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eTAeFw0wNzA0MDMxMjUzMDlaFw0yMTA0MDMx
# MzAzMDlaMHcxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAf
# BgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAJ+hbLHf20iSKnxrLhnhveLjxZlRI1Ctzt0YTiQP7tGn
# 0UytdDAgEesH1VSVFUmUG0KSrphcMCbaAGvoe73siQcP9w4EmPCJzB/LMySHnfL0
# Zxws/HvniB3q506jocEjU8qN+kXPCdBer9CwQgSi+aZsk2fXKNxGU7CG0OUoRi4n
# rIZPVVIM5AMs+2qQkDBuh/NZMJ36ftaXs+ghl3740hPzCLdTbVK0RZCfSABKR2YR
# JylmqJfk0waBSqL5hKcRRxQJgp+E7VV4/gGaHVAIhQAQMEbtt94jRrvELVSfrx54
# QTF3zJvfO4OToWECtR0Nsfz3m7IBziJLVP/5BcPCIAsCAwEAAaOCAaswggGnMA8G
# A1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFCM0+NlSRnAK7UD7dvuzK7DDNbMPMAsG
# A1UdDwQEAwIBhjAQBgkrBgEEAYI3FQEEAwIBADCBmAYDVR0jBIGQMIGNgBQOrIJg
# QFYnl+UlE/wq4QpTlVnkpKFjpGEwXzETMBEGCgmSJomT8ixkARkWA2NvbTEZMBcG
# CgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWljcm9zb2Z0IFJvb3Qg
# Q2VydGlmaWNhdGUgQXV0aG9yaXR5ghB5rRahSqClrUxzWPQHEy5lMFAGA1UdHwRJ
# MEcwRaBDoEGGP2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1
# Y3RzL21pY3Jvc29mdHJvb3RjZXJ0LmNybDBUBggrBgEFBQcBAQRIMEYwRAYIKwYB
# BQUHMAKGOGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljcm9z
# b2Z0Um9vdENlcnQuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# BQUAA4ICAQAQl4rDXANENt3ptK132855UU0BsS50cVttDBOrzr57j7gu1BKijG1i
# uFcCy04gE1CZ3XpA4le7r1iaHOEdAYasu3jyi9DsOwHu4r6PCgXIjUji8FMV3U+r
# kuTnjWrVgMHmlPIGL4UD6ZEqJCJw+/b85HiZLg33B+JwvBhOnY5rCnKVuKE5nGct
# xVEO6mJcPxaYiyA/4gcaMvnMMUp2MT0rcgvI6nA9/4UKE9/CCmGO8Ne4F+tOi3/F
# NSteo7/rvH0LQnvUU3Ih7jDKu3hlXFsBFwoUDtLaFJj1PLlmWLMtL+f5hYbMUVbo
# nXCUbKw5TNT2eb+qGHpiKe+imyk0BncaYsk9Hm0fgvALxyy7z0Oz5fnsfbXjpKh0
# NbhOxXEjEiZ2CzxSjHFaRkMUvLOzsE1nyJ9C/4B5IYCeFTBm6EISXhrIniIh0EPp
# K+m79EjMLNTYMoBMJipIJF9a6lbvpt6Znco6b72BJ3QGEe52Ib+bgsEnVLaxaj2J
# oXZhtG6hE6a/qkfwEm/9ijJssv7fUciMI8lmvZ0dhxJkAj0tr1mPuOQh5bWwymO0
# eFQF1EEuUKyUsKV4q7OglnUa2ZKHE3UiLzKoCG6gW4wlv6DvhMoh1useT8ma7kng
# 9wFlb4kLfchpyOZu6qeXzjEp/w7FW1zYTRuh2Povnj8uVRZryROj/TCCBhAwggP4
# oAMCAQICEzMAAABkR4SUhttBGTgAAAAAAGQwDQYJKoZIhvcNAQELBQAwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMTAeFw0xNTEwMjgyMDMxNDZaFw0xNzAx
# MjgyMDMxNDZaMIGDMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MQ0wCwYDVQQLEwRNT1BSMR4wHAYDVQQDExVNaWNyb3NvZnQgQ29ycG9yYXRpb24w
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCTLtrY5j6Y2RsPZF9NqFhN
# FDv3eoT8PBExOu+JwkotQaVIXd0Snu+rZig01X0qVXtMTYrywPGy01IVi7azCLiL
# UAvdf/tqCaDcZwTE8d+8dRggQL54LJlW3e71Lt0+QvlaHzCuARSKsIK1UaDibWX+
# 9xgKjTBtTTqnxfM2Le5fLKCSALEcTOLL9/8kJX/Xj8Ddl27Oshe2xxxEpyTKfoHm
# 5jG5FtldPtFo7r7NSNCGLK7cDiHBwIrD7huTWRP2xjuAchiIU/urvzA+oHe9Uoi/
# etjosJOtoRuM1H6mEFAQvuHIHGT6hy77xEdmFsCEezavX7qFRGwCDy3gsA4boj4l
# AgMBAAGjggF/MIIBezAfBgNVHSUEGDAWBggrBgEFBQcDAwYKKwYBBAGCN0wIATAd
# BgNVHQ4EFgQUWFZxBPC9uzP1g2jM54BG91ev0iIwUQYDVR0RBEowSKRGMEQxDTAL
# BgNVBAsTBE1PUFIxMzAxBgNVBAUTKjMxNjQyKzQ5ZThjM2YzLTIzNTktNDdmNi1h
# M2JlLTZjOGM0NzUxYzRiNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzcitW2oynUC
# lTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtp
# b3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEGCCsGAQUF
# BwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3Br
# aW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0MAwGA1Ud
# EwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAIjiDGRDHd1crow7hSS1nUDWvWas
# W1c12fToOsBFmRBN27SQ5Mt2UYEJ8LOTTfT1EuS9SCcUqm8t12uD1ManefzTJRtG
# ynYCiDKuUFT6A/mCAcWLs2MYSmPlsf4UOwzD0/KAuDwl6WCy8FW53DVKBS3rbmdj
# vDW+vCT5wN3nxO8DIlAUBbXMn7TJKAH2W7a/CDQ0p607Ivt3F7cqhEtrO1Rypehh
# bkKQj4y/ebwc56qWHJ8VNjE8HlhfJAk8pAliHzML1v3QlctPutozuZD3jKAO4WaV
# qJn5BJRHddW6l0SeCuZmBQHmNfXcz4+XZW/s88VTfGWjdSGPXC26k0LzV6mjEaEn
# S1G4t0RqMP90JnTEieJ6xFcIpILgcIvcEydLBVe0iiP9AXKYVjAPn6wBm69FKCQr
# IPWsMDsw9wQjaL8GHk4wCj0CmnixHQanTj2hKRc2G9GL9q7tAbo0kFNIFs0EYkbx
# Cn7lBOEqhBSTyaPS6CvjJZGwD0lNuapXDu72y4Hk4pgExQ3iEv/Ij5oVWwT8okie
# +fFLNcnVgeRrjkANgwoAyX58t0iqbefHqsg3RGSgMBu9MABcZ6FQKwih3Tj0DVPc
# gnJQle3c6xN3dZpuEgFcgJh/EyDXSdppZzJR4+Bbf5XA/Rcsq7g7X7xl4bJoNKLf
# cafOabJhpxfcFOowMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkqhkiG9w0B
# AQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAG
# A1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTEw
# HhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQgQ29kZSBT
# aWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# q/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03a8YS2Avw
# OMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akrrnoJr9eW
# WcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0RrrgOGSsbmQ1
# eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy4BI6t0le
# 2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9sbKvkjh+
# 0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAhdCVfGCi2
# zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8kA/DRelsv
# 1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTBw3J64HLn
# JN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmnEyimp31n
# gOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90lfdu+Hgg
# WCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0wggHpMBAG
# CSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2oynUClTAZ
# BgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/
# BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBaBgNVHR8E
# UzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsGAQUFBwEB
# BFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNVHSAEgZcw
# gZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNy
# b3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsGAQUFBwIC
# MDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABlAG0AZQBu
# AHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKbC5YR4WOS
# mUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11lhJB9i0ZQ
# VdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6I/MTfaaQ
# dION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0wI/zRive
# /DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560STkKxgrC
# xq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQamASooPoI/
# E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGaJ+HNpZfQ
# 7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ahXJbYANah
# Rr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA9Z74v2u3
# S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33VtY5E90Z1W
# Tk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr/Xmfwb1t
# bWrJUnMTDXpQzTGCBMAwggS8AgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25pbmcg
# UENBIDIwMTECEzMAAABkR4SUhttBGTgAAAAAAGQwCQYFKw4DAhoFAKCB1DAZBgkq
# hkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGC
# NwIBFTAjBgkqhkiG9w0BCQQxFgQU+7qPkeRZx4mjyPQbm1XNwXDwzCEwdAYKKwYB
# BAGCNwIBDDFmMGSgSoBIAEMAVABTAHcAaQBuAGQAbwB3AHMAcwBlAHQAdQBwAF8A
# RABDAF8AVQBwAGQAYQB0AGUASABpAHMAdABvAHIAeQAuAHAAcwAxoRaAFGh0dHA6
# Ly9taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBAByCH8bNmwMp/HtMgvZ5
# j7fkVWC5/IBs0GDtj98C+rJe5W7F1x/PS9FoJnY0MH/aWBx2IxG2sxBVOQ7CMJCa
# 5V4n7FR9aMO+ICqrCTlHZ2Q0PF8X/wPRdsMo2pyNgsFfZn/8+iMA4TR9PJiRqxdJ
# 4ClyuPjW7awnyhm8WclYbCDQ7Dpqbv2bpu56KeHYMuOMWASKE5QgV/rn8ndvE1b9
# qm/Vze+v1wYKsgy81n+wW9+QrcVmpRlr6KL6MBlXFG4j2fZ8QBq8INzQA22nlqL5
# dI8ocm6aftZMeLIbJKbPcoMhZYtTIcMWZ267ut2Ktz1Zfs4HJIPH6x0CW7NeBWjp
# mwShggIoMIICJAYJKoZIhvcNAQkGMYICFTCCAhECAQEwgY4wdzELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEhMB8GA1UEAxMYTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBAhMzAAAAm+B0N8s9TY0uAAAAAACbMAkGBSsOAwIaBQCgXTAY
# BgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0xNjA3Mjgy
# MDA4MDNaMCMGCSqGSIb3DQEJBDEWBBTHz7ozoNkzpZj6h0f+u485H1e8+jANBgkq
# hkiG9w0BAQUFAASCAQAWZu7vhozJnynP5ohj51aCbL8dC81bxw9ZRaurWngdIykk
# NNuO6DLvZRq678NJYxy7xWaBkiznZioiLr65MFa5S6JcjwyaCFz4na+EgtWHlD3e
# guKJmJGSmm0NRjGwHqcP6ju0Lfl9No+FZvEh4HTN5MV5yJPLDSGClHFU/f+uFjLf
# VwjsaL7BIH5gy0TEhf/2KD823Gd5Lcyxkd/4ZkH8mK/O+2NQT/OpPaybwdXFFyPV
# eT2tXLe/s9no8RCGWsAOJPe73K764Qj4fWTbqeeCl4YDlvVccDPKiie3kPnOJBWx
# iHWY5Tv61zR972MMASW9c/d49h+6eQMtVjVbOs5h
# SIG # End signature block
