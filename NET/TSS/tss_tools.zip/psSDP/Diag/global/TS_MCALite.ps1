﻿#************************************************
# TS_MCALite.ps1
# Version 1.0.1
# Date: 7/17/2012
# Author: tspring
# Description:  [Idea ID 4796] [Windows] MaxConcurrentApi Problem Detection Lite
# Rule number:  4796
# Rule URL:  http://sharepoint/sites/rules/Rule Submissions/Forms/DispForm.aspx?ID=4796
#************************************************
# 2019-03-17 WalterE added Trap #_#

Import-LocalizedData -BindingVariable ScriptStrings
Display-DefaultActivity -Rule -RuleNumber 4796

$RuleApplicable = $false
$RootCauseDetected = $false
$RootCauseName = "RC_MaxConcurrentApiLite"
$PublicContent = "http://support.microsoft.com/kb/975363"
$Verbosity = "Error"
$Visibility = "4"
$SupportTopicsID = "18542"
$Title = $ScriptStrings.ID_MaxConcurrentApiLite_ST
$InformationCollected = new-object PSObject
$IssueDetected = $False


# ***************************
# Data Gathering
# ***************************

Function AppliesToSystem
{	$RuleApplicable = $false
	$cs = get-wmiobject -class win32_computersystem
	$DomainRole = $cs.domainrole

	if ($DomainRole -le 1)
	{#MaxConcurrentApi outages do not apply to workstations.
	$RuleApplicable = $false}
	else { 
			if ($OSVersion.Major -lt 6)
				{
				$OS = Get-WmiObject -Class Win32_OperatingSystem
				$sp = $OS.ServicePackMajorVersion
				#Hotfix Check for presence of Netlogon Performance Counters: KB928576
					if ($sp -ge 2)
						{if ((CheckMinimalFileVersion "$System32Folder\Nlperf.dll" 5 2 3790 4106) -and
								(CheckMinimalFileVersion "$System32Folder\Netapi32.dll" 5 2 3790 4106) -and
								(CheckMinimalFileVersion "$System32Folder\Netlogon.dll" 5 2 3790 4106)) 
								{$RuleApplicable = $True}}
			  		if ($sp -le 1)		
						{if ((CheckMinimalFileVersion "$System32Folder\Nlperf.dll" 5 2 3790 2962) -and
								(CheckMinimalFileVersion "$System32Folder\Netapi32.dll" 5 2 3790 2962) -and
								(CheckMinimalFileVersion "$System32Folder\Netlogon.dll" 5 2 3790 2962))
								{$RuleApplicable = $True}}
								}
			else {$RuleApplicable = $True}
		}
	if ($RuleApplicable -eq $True)
	{Write-DiagProgress -Activity $ScriptStrings.ID_MCALite_Status -Status $ScriptStrings.ID_MCALite_Wait
	return $True}
}


# **************
# Detection Logic
# **************
#Check to see if rule is applicable to this computer
if (AppliesToSystem)
	{function MCAProblemCheckLite { param($InstanceName)
	
		$DetectionTime = Get-Date
		$ProblemDetected = $False
		$SA = New-Object System.Diagnostics.PerformanceCounter("Netlogon", "Semaphore Acquires", $InstanceName)
		$ST = New-Object System.Diagnostics.PerformanceCounter("Netlogon", "Semaphore Timeouts", $InstanceName)
		$SW = New-Object System.Diagnostics.PerformanceCounter("Netlogon", "Semaphore Waiters", $InstanceName)
		$SH = New-Object System.Diagnostics.PerformanceCounter("Netlogon", "Semaphore Holders", $InstanceName)
		$ASHT = New-Object System.Diagnostics.PerformanceCounter("Netlogon", "Average Semaphore Hold Time", $InstanceName)
		$SemAcquires = $SA.NextValue()
		$SemTimeouts = $ST.NextValue()
		$SemWaiters = $SW.NextValue()
		$SemHolders = $SH.NextValue()
		$SemHoldTime = $ASHT.NextValue() 
		
		#Detect problems.  Exclude false positives if the counter has seen the buffer overrun bug from KB2685888.
		if ((($SemWaiters -gt 0) –and (-not($SemWaiters -gt 4294000000))) -or (($SemTimeouts -gt 0) –and (-not($SemTimeouts -gt 4294000000))))
			{$ProblemDetected = $true}
			
		$ReturnValues = new-object PSObject
		$InstanceName = $InstanceName.replace('\','')
		
		#Determine how long the computer has been running since last reboot.
		$wmi = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $ComputerName
		$LocalDateTime = $wmi.LocalDateTime
		$Uptime = $wmi.ConvertToDateTime($wmi.LocalDateTime) – $wmi.ConvertToDateTime($wmi.LastBootUpTime)
		$Days = $Uptime.Days.ToString()
		$Hours = $Uptime.Hours.ToString()
		$UpTimeStatement = $Days + " days " + $Hours + " hours"

		add-member -inputobject $ReturnValues -membertype noteproperty -name "Detection Time" -value $DetectionTime 
		add-member -inputobject $ReturnValues -membertype noteproperty -name "Time Since Last Reboot" -value $UpTimeStatement 
		add-member -inputobject $ReturnValues -membertype noteproperty -name "Trust Secure Channel To" -value $InstanceName
		add-member -inputobject $ReturnValues -membertype noteproperty -name "Client Timeouts (over life of secure channel)" -value $SemTimeouts
		add-member -inputobject $ReturnValues -membertype noteproperty -name "Clients Currently Waiting" -value $SemWaiters
		add-member -inputobject $ReturnValues -membertype noteproperty -name "MaxConcurrentApi Thread Uses (Semaphore Acquires over life of secure channel)" -value $SemAcquires
		add-member -inputobject $ReturnValues -membertype noteproperty -name "Semaphore Holders" -value $SemHolders
		add-member -inputobject $ReturnValues -membertype noteproperty -name "Average Semaphore Hold Time" -value $SemHoldTime
		add-member -inputobject $ReturnValues -membertype noteproperty -name "Problem Detected" -value $ProblemDetected
		
		return $ReturnValues}

function GetSecureChannelNames {
				#Returns an array of secure channel names from the Netlogon performannce counter.
				$Instances = New-Object System.Diagnostics.PerformanceCounterCategory("Netlogon")
				$AllInstanceNames = $Instances.GetInstanceNames()
				return $AllInstanceNames}

$SCNames = GetSecureChannelNames
$LoopCounter = $SCNames.Count
	
	for ($i = 0; $i -lt $LoopCounter; $i++)
		{
		$InformationCollected = MCAProblemCheckLite ($SCNames[$i])
		if ($InformationCollected."Problem Detected" -eq $true)
			{$IssueDetected = $True
			 Write-GenericMessage -RootCauseId $RootCauseName -PublicContentURL $PublicContent -InformationCollected $InformationCollected -Verbosity $Verbosity -Visibility $Visibility -SupportTopicsID $SupportTopicsID -InternalContentURL $InternalContent -SolutionTitle $Title -MessageVersion 2
			}
		}
}

# *********************
# Root Cause processing
# *********************

	if ($IssueDetected -eq $true)
	{
		# Red/ Yellow Light
		Update-DiagRootCause -id $RootCauseName -Detected $True
	}
	else
	{
		# Green Light
		Update-DiagRootCause -id $RootCauseName -Detected $False
	}


Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" ;Continue}