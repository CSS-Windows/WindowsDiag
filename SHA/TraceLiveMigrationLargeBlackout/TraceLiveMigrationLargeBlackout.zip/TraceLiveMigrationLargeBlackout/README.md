# TraceLiveMigration

Trace Live Migration with event channels with VMLTrace can't work
The trace is stopped when the 20415 or 20417 is hit
Possibility to include a network trace (in different mode : Powershell or netsh) and an xperf trace 
Possibility to chose the Hyper-V tracing mode : Either use VMLTrace.exe or Event Channels
