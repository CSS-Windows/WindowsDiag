<# Name: tss_EvtMonPS.ps1
	
PowerShell -noprofile "&{Invoke-Command -ScriptBlock {$EventID=30800;$NrOfMilliSec=60000;$EventlogName="Microsoft-Windows-SmbClient/Operational"; Get-WinEvent -LogName $EventlogName -FilterXPath "*[System[EventID=$EventID and TimeCreated[timediff(@SystemTime) <= $NrOfMilliSec]]]" -MaxEvents 5 -ErrorAction SilentlyContinue}}"
PowerShell -noprofile "&{Invoke-Command -ScriptBlock {Get-WinEvent -LogName "Microsoft-Windows-SmbClient/Operational"  -FilterXPath "*[System[EventID=30800]]" -MaxEvents 3 -ErrorAction SilentlyContinue }}"

	#Eventlog location on disk: "C:\Windows\System32\winevt\Logs\Microsoft-Windows-SmbClient%4Operational.evtx"
Example to delete Source
Get-WmiObject win32_nteventlogfile -Filter "logfilename='Microsoft-Windows-SmbClient/Operational'" | foreach {$_.sources}
Remove-Eventlog -Source "TSS"
#>

<#
.SYNOPSIS
Purpose: Monitor Eventlogs for specific event and stop script; in combi with TSS: stop it based on EventIDs in a non classic Eventlog
	The stop trigger condition is true if the EventID is found in specified Eventlog, the control is given back to calling script.
	From CMD script you can invoke this PowerShell script by: Powershell -noprofile -file "tss_EvtMon.ps1" -EventID 30800 -EventlogName "Microsoft-Windows-SmbClient/Connectivity" -EventData 0
	Multiple EventIDs are separated by '/', for example -EventID 40961/40962
	Multiple EventData strings are separated by '/', for example -EventData C:\Windows\System32\calc.exe/C:\Windows\System32\cmd.exe


If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
 
SYNTAX: .\tss_EvtMon.ps1 -EventID 30800 -EventlogName "Microsoft-Windows-SmbClient/Connectivity" -EventData 'find-my-string'


.DESCRIPTION
The script will stop, once the specific details EventID(s) and Eventdata string(s) are all met.
You need to run the script in Admin PowerShell window, if you want to monitor 'Security' Event Log
You can append the -verbose parameter to see more details.
When entering -EventData string, please enter the complete string as seen in Event 'XML View', for example 'C:\Windows\System32\calc.exe'
 as seen in 'XML View' <Data Name="NewProcessName">C:\Windows\System32\calc.exe</Data> 

.EXAMPLE
 .\tss_EvtMon.ps1 -EventID 30800 -EventlogName "Microsoft-Windows-SmbClient/Connectivity" - EventData 0

.EXAMPLE
 .\tss_EvtMon.ps1 -EventID 4688/4689 -EventlogName "Security" -EventData C:\Windows\System32\calc.exe/C:\Windows\System32\cmd.exe -verbose
 
This will monitor for multiple EventIDs  4688 and 4689, checking if either string 'C:\Windows\System32\calc.exe' or 'C:\Windows\System32\cmd.exe' exist in given EventID(s) 

.LINK
waltere@microsoft.com
#>

Param(
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Choose the EventID, or multiple separated by slash / ')]
	[string[]]$EventIDs 	#= 30800/30809
,
	[Parameter(Mandatory=$False,Position=1,HelpMessage='Choose the amount of time to search back in minutes ')]
	[Int32]$NrOfMin = 1
,
	[Parameter(Mandatory=$False,Position=2,HelpMessage='Choose name of EventLog-File' )]
	[string]$EventlogName 	#= "Microsoft-Windows-PowerShell/Operational" #"Microsoft-Windows-SmbClient/Operational"
,
	[Parameter(Mandatory=$False,Position=3,HelpMessage='Choose Stop WaitTime in Sec')]
	[Int32]$WaitTimeInSec = 0
,
	[Parameter(Mandatory=$False,Position=4,HelpMessage='optional: complete string in any EventData, or multiple separated by slash / ')]
	[string]$EventData = '0' #'3221226599' # = STATUS_FILE_NOT_AVAILABLE / '3221225996' = STATUS_CONNECTION_DISCONNECTED / '0' = STATUS_SUCCESS
)

$ScriptVer="1.03"		# Date: 2018-09-06
[Int32]$SleepInt=2			# how often should the evenlog file be scanned?
$Trigger=$False				# initialize 
[Int32]$val=0				# counter
[Int32]$MaxEvents=1			# we are only interested in a single occurence of EventID in Eventlog
[Int32]$NrOfMilliSec = 1000 * 60 * $NrOfMin	#amount of time in MilliSec to search back

[string[]]$Event_ID_list=$EventIDs.split("/")
Write-verbose "EventIDs: $Event_ID_list"
[array]$xpaths= @()
[string[]]$EvtDataStrings=$EventData.split("/")

foreach ($EventID in $Event_ID_list){
	foreach ($EvtDataString in $EvtDataStrings) 
	{
		if ($EventData -ne '0') {
			$xpath = @"
*[System[TimeCreated[timediff(@SystemTime) <= $NrOfMilliSec]]
[EventID=$EventID]]
[EventData[Data='$EvtDataString']]
"@
		} else {
		$xpath = @"
*[System[TimeCreated[timediff(@SystemTime) <= $NrOfMilliSec]]
[EventID=$EventID]]
"@
		}
		$xpaths += $xpath
		Write-host "---- EventID: $EventID - Xpath: `n$xpath"
	}
}

Write-host " Monitoring $EventlogName for EventID(s): '$Event_ID_list' EventData: '$EvtDataStrings' - Interval $SleepInt sec" -ForegroundColor Green
 $TimeStampStart= Get-Date
while (-not $Trigger) {Start-Sleep $SleepInt; 
						 foreach ($xpath in $xpaths) 
						  {
							$Trigger = $EvtEntry = Get-WinEvent -LogName $EventlogName -FilterXPath $xpath -MaxEvents $MaxEvents -ErrorAction SilentlyContinue |select Message,Id,TimeCreated;
							if ($Trigger) {
							$TimeStampCurrent=Get-Date; $Dur=($TimeStampCurrent - $TimeStampStart)
							Write-host " EventID '$($EvtEntry.Id)' - EventData '$EvtDataString' found at $($EvtEntry.TimeCreated) - after $($Dur.Days) D $($Dur.Hours) h $($Dur.Minutes) m $($Dur.Seconds) sec / $Dur" -ForegroundColor Yellow
							Write-verbose "$($EvtEntry.Message)"
							Start-Sleep $WaitTimeInSec
							break }
						  }
						$val++ ;  write-verbose "Loop# $val; $(Get-Date -Format 'yyMMdd-hhmmss') - monitoring EventID(s): '$Event_ID_list' EventData: '$EvtDataStrings'"
					  }

<#Test:
$xpath = @"
 *[System[TimeCreated[timediff(@SystemTime) <= $NrOfMilliSec]]
 [EventID=$EventIDs]]
 [UserData[EventData[ClientAddressLength='$EvtDataStrings']]]
"@
[EventData[Data='$EvtDataStrings']]

#EvtDataStrings : 3221226599 # for decimal -1073740697 / hex 0xc0000467 #  STATUS_FILE_NOT_AVAILABLE # The file is temporarily unavailable.
#EvtDataStrings : 3221225996 # for decimal -1073741300 / hex 0xc000020c #  STATUS_CONNECTION_DISCONNECTED
#EvtDataStrings : 3221225653 # STATUS_IO_TIMEOUT # The specified I/O operation on %hs was not completed before the time-out period expired.

# Test: .\tss_EvtMonPS.ps1 -EventID 1006 -EventlogName  'Microsoft-Windows-SMBServer/Security' -EvtDataStrings 128
#>