﻿PARAM (
	$ProcessToTerminate = $null,
	$ScriptBlockToExecute = $null,
	[string] $SessionName = "Session0",
	[switch] $EndMonitoring,
	[switch] $AllSessions
)

Function Get-DiagMonitoringSessionRegistryKey
{
	$DiagMonitoringRegistryKey = "Registry::HKCU\Software\Microsoft\CSSDiagnosticsMonitoring"
	if(-not (Test-Path $DiagMonitoringRegistryKey))
	{
		New-Item -Path $DiagMonitoringRegistryKey | Out-Null
	}
	return (Get-Item $DiagMonitoringRegistryKey)
}
Function Remove-DiagMonitoringSession($SessionName,[switch]$AllSessions)
{
	$MonitoringKey = Get-DiagMonitoringSessionRegistryKey
	if(-not [string]::IsNullOrEmpty($SessionName))
	{
		Remove-ItemProperty -LiteralPath $MonitoringKey.PSPath -Name $SessionName -ErrorAction SilentlyContinue | Out-Null
	}
	if($AllSessions.IsPresent -or ($MonitoringKey.GetValueNames().Length -eq 0))
	{
		Remove-Item -LiteralPath $MonitoringKey.PSPath -Recurse -ErrorAction SilentlyContinue | Out-Null
	}
}
Function Add-DiagMonitoringSession($SessionName,$Process)
{
	$MonitoringKey = Get-DiagMonitoringSessionRegistryKey
	New-ItemProperty -LiteralPath $MonitoringKey.PSPath -Name $SessionName -Value ("{0}|{1}" -f $Process.ID,$Process.StartTime.ToString()) | Out-Null
}

Function Get-DiagMonitoringExistingSessions
{
	param([switch]$Name)
	$MonitoringKey = Get-DiagMonitoringSessionRegistryKey
	$sessionNames = $MonitoringKey.GetValueNames()

	
	return $sessionNames | %{
		$sessionData = $MonitoringKey.GetValue($_).ToString().Split("|")
		$sessionPID = $sessionData[0]
		$sessionStartTime = $sessionData[1]
		
		# test if there's an active processes matching the session - else delete it.
		# matching processes will have the same PID and have been started at the same
		# time with a 5-second margin of error
		
		if($null -eq 
			(Get-Process -id $sessionPID -ErrorAction SilentlyContinue | ? {
				[Math]::Abs(
					[DateTime]::Parse($sessionStartTime).Subtract($_.StartTime).TotalSeconds) -lt 5
			})
		)
		{
			Remove-DiagMonitoringSession -SessionName $_
			return
		}
		
		if($Name.IsPresent)
		{
			return $_
		}
		else
		{
			$sessionObject = New-Object PSObject
			$sessionObject | Add-Member -MemberType NoteProperty -Name "Name" -Value $_
			$sessionObject | Add-Member -MemberType NoteProperty -Name "PID" -Value $sessionPID
			$sessionObject | Add-Member -MemberType NoteProperty -Name "StartTime" -Value $sessionStartTime
			$sessionObject
		}
	}
}

Function CreateSessionMonitorPS1 ($RunDiagMonitorPS1Path, $ConfigXMLPath)
{
	'$ConfigXMLPath = ' + "'" + $ConfigXMLPath + "'"
	$SigFound = $false
	Get-Content $RunDiagMonitorPS1Path -Encoding UTF8 | ForEach-Object -Process {
		if ($_.StartsWith("# SIG #"))
		{
			$SigFound = $true
			return ''
		}
		elseif (-not $SigFound)
		{
			$_
		}
	}
}

Function StartMonitoring ([array] $ExternalProcessesToMonitor, [string] $ScriptBlockToExecute,[string] $SessionName)
{
	[xml] $XMLMonitoring = "<Root />"
	$RootNode = $XMLMonitoring.get_DocumentElement()
	$RootNode.SetAttribute("ParentProcessID",$PID) | Out-Null
	$RootNode.SetAttribute("DiagnosticPath",$PWD.Path) | Out-Null
	$RootNode.SetAttribute("SessionName",$SessionName) | Out-Null
	
	if ($ExternalProcessesToMonitor.Count -gt 0)
	{
		$ProcessesToMonitorNode = [System.Xml.XmlElement]$RootNode.AppendChild($XMLMonitoring.CreateElement("ProcessesToMonitor"))
		Foreach ($ExternalProcesseToMonitor in $ExternalProcessesToMonitor)
		{
			#If Process to Monitor is an int, then it is a PID
			if ($ExternalProcessesToMonitor -as [int])
			{
				$ProcessInfo = Get-Process | Where-Object {$_.ID -eq $ProcessesToMonitorString}
				if ($ProcessInfo -ne $null)
				{
					$ProcessesToMonitorNode.AppendChild($XMLMonitoring.CreateElement("PID")).set_InnerText($ExternalProcessesToMonitor)
					"    Configuring to monitor process with PID $ExternalProcessesToMonitor" | WriteTo-StdOut -ShortFormat
				}
				else
				{
					"    Process with PID $ExternalProcessesToMonitor is not currently runnning and will not be monitored. It was probably terminated." | WriteTo-StdOut  -ShortFormat
				}
			}
			else
			{
				if (Test-Path $ExternalProcessesToMonitor)
				{
					$ExternalProcessesToMonitorProcessPath = [System.IO.Path]::GetFullPath($ExternalProcessesToMonitor)
					$ProcessesToMonitorNode.AppendChild($XMLMonitoring.CreateElement("ProcessPath")).set_InnerText($ExternalProcessesToMonitorProcessPath)
				}
				else
				{
					$ExternalProcessesToMonitorProcessName = [system.IO.Path]::GetFileNameWithoutExtension($ExternalProcessesToMonitor)
					$ProcessesToMonitorNode.AppendChild($XMLMonitoring.CreateElement("ProcessName")).set_InnerText($ExternalProcessesToMonitorProcessName)
				}
			}
		}
	}

	if (-not [string]::IsNullOrEmpty($ScriptBlockToExecute))
	{
		$ScriptBlockToRunNode = $XMLMonitoring.CreateElement('ScriptBlock')
		$ScriptBlockToRunNode.set_InnerText($ScriptBlockToExecute)
		$X = $RootNode.AppendChild($ScriptBlockToRunNode)
	}
	
	$ConfigXMLPath = [System.IO.Path]::GetTempFileName()
	
	$XMLMonitoring.Save($ConfigXMLPath)
	
	$PS1FilePath = ([System.IO.Path]::GetTempFileName() + ".ps1")
	
	$MonitoringPS1Content = CreateSessionMonitorPS1 $Script:MonitoringPS1FilePath $ConfigXMLPath
	$MonitoringPS1Content | Set-Content -Path $PS1FilePath -Encoding UTF8

	$FileFlagStop = Join-Path $PWD.Path "..\StopMonitoring_$($SessionName)."
	if (Test-Path $FileFlagStop)
	{
		[System.IO.File]::Delete($FileFlagStop)
	}

	#$monitoringProcess = Run-ExternalPSScript -BackgroundExecution -BackgroundExecutionTimeOut 0 -ScriptPath $PS1FilePath -BackgroundExecutionSkipMaxParallelDiagCheck
	$monitoringProcess = Run-ExternalPSScript -BackgroundExecution -BackgroundExecutionTimeOut 0 -ScriptPath $PS1FilePath -BackgroundExecutionSkipMaxParallelDiagCheck  -BackgroundExecutionSessionName "MonitorDiagExecution"
	Add-DiagMonitoringSession -SessionName $SessionName -Process $monitoringProcess

	$StartedFlagFileName = Join-Path $PWD.Path "..\MonitorStarted_$($SessionName)."
	$MAX_WAIT_ITERATIONS = 30
	$waitIterations = 0
	[Diagnostics.Debug]::Assert($waitIterations -le $MAX_WAIT_ITERATIONS)
	while ((-not (Test-Path $StartedFlagFileName)) -and ($waitIterations -lt $MAX_WAIT_ITERATIONS)){
		if(($waitIterations % 6) -eq 0) {(Split-Path $StartedFlagFileName -Leaf) + " has not yet been created. Waiting..." | WriteTo-StdOut -ShortFormat}
		sleep -Milliseconds 600
		$waitIterations++
	} 

	if(Test-Path $StartedFlagFileName)
	{
		trap [Exception] 
		{
			WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText ("Removing Session Monitoring Files for $($SessionName)")
			continue
		}
		
		"Deleting $StartedFlagFileName" | WriteTo-StdOut -ShortFormat
		
		$waitIterations = 1
		[Diagnostics.Debug]::Assert($waitIterations -le $MAX_WAIT_ITERATIONS)
		while ((Test-Path $StartedFlagFileName) -and ($waitIterations -lt $MAX_WAIT_ITERATIONS))
		{
			trap [Exception] 
			{
				WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText ("Deleting " + (Split-Path $StartedFlagFileName -Leaf))
				continue
			}
			
			[IO.File]::Delete($StartedFlagFileName)
			if(($waitIterations % 6) -eq 0) {(Split-Path $StartedFlagFileName -Leaf) + " - Trying to Delete." | WriteTo-StdOut -ShortFormat}
			sleep -Milliseconds 600
			$waitIterations++
		} 
		
		if(Test-Path $ConfigXMLPath)
		{
			"Deleting Config XML: $ConfigXMLPath" | WriteTo-StdOut -ShortFormat
			[IO.File]::Delete($ConfigXMLPath)
		}
		
		if(Test-Path $PS1FilePath)
		{
			"Deleting Session Monitor PS1 $PS1FilePath" | WriteTo-StdOut -ShortFormat
			[IO.File]::Delete($PS1FilePath)
		}
	}
}

#********************
# Script Starts Here
#********************

# Default session name to Session0 for back compat and for scenarios when 
# only one monitor is designed to be used.
if([string]::IsNullOrEmpty($SessionName)) 
{
	$SessionName = "Session0"
}

# Remove invalid path characters from session name since we're using the name in the path of a file.
[System.IO.Path]::GetInvalidPathChars() | %{ $SessionName = $SessionName.Replace($_,"_")}

if((-not ($EndMonitoring.IsPresent)) -and ((Get-DiagMonitoringExistingSessions -Name) -contains $SessionName))
{
	"[MonitorDiagExecution] ERROR: Duplicate `$SessionName=`"$SessionName`" provided. Monitoring cannot continue. Provide an alternate name." | WriteTo-StdOut -IsError
	return
}
elseif($EndMonitoring.IsPresent -and (-not $AllSessions.IsPresent) -and ((Get-DiagMonitoringExistingSessions -Name) -notcontains $SessionName))
{
	"[MonitorDiagExecution] ERROR: `$SessionName=`"$SessionName`" does not exist. Unable to stop monitoring process. Current Session names = $(Get-DiagMonitoringExistingSessions -Name | Out-String)" | WriteTo-StdOut -IsError
	return
}

$Script:MonitoringPS1FilePath = (Join-Path $PWD.Path 'TS_RunDiagMonitor.ps1')

if (Test-Path $Script:MonitoringPS1FilePath)
{
	if (-not ($EndMonitoring.IsPresent))
	{
		if (($ProcessToTerminate -ne $null) -or ($ScriptBlockToExecute -ne $null))
		{
			if ($ProcessToTerminate -isnot [array])
			{
				if (($ProcessToTerminate -isnot [string]) -or ($ProcessToTerminate -isnot [int]))
				{
					$ProcessToTerminate = [array] $ProcessToTerminate 
				}
				else
				{
					"ERROR: ExternalProcessToMonitor argument needs to contain array, string or integer, but its current type is " + $ProcessToTerminate.GetType().FullName + ". No external process will monitored" | WriteTo-StdOut -IsError
					$ProcessToTerminate = $null
				}
			}
			
			if (($ScriptBlockToExecute -ne $null) -and ($ScriptBlockToExecute -is [scriptblock]))
			{
				$ScriptBlockToExecute = $ScriptBlockToExecute.ToString()
			}
			
			$StatusMSG = "    [MonitorDiagnosticExecution] Sending Command To Start Monitoring. [Session: $SessionName]"
			
			if ($ProcessToTerminate.Count -gt 0) 
			{
				$StatusMSG += "`r`n         [Process(es) To Terminate: "+ [string]::Join(", ", $ProcessToTerminate) + " ]"
			}
			if ([string]::IsNullOrEmpty($ScriptBlockToExecute) -eq $false)
			{
				if ($ScriptBlockToExecute.Length -lt 100)
				{
					$StatusMSG += "`r`n         [Script Block To Execute:]`r`n"+ $ScriptBlockToExecute.replace("`n", "`n             ")
				}
				else
				{
					$StatusMSG += "`r`n         [Script Block To Execute (first 100 chars):]`r`n         " + $ScriptBlockToExecute.Remove(100).replace("`n", "`n            ") + "..."
				}
			}
			
			$StatusMSG | WriteTo-StdOut
			
			StartMonitoring -ExternalProcessesToMonitor $ProcessToTerminate -ScriptBlockToExecute $ScriptBlockToExecute -SessionName $SessionName
		}
		else
		{
			'ERROR: You have to use one of the arguments: ExternalProcessToMonitor ScriptBlockToExecute or EndMonitoring. Ending script' | WriteTo-StdOut -IsError
		}
	}
	else
	{
	
		#sleep several seconds for the package will not end immediately if the user click Close button
		"Before forwarding command to stop monitoring session $SessionName, waiting 2 seconds..." | WriteTo-StdOut -ShortFormat -Color ([System.ConsoleColor]::Cyan)
		sleep 2 
		"Forwarding command to stop monitoring [Session: $SessionName]" | WriteTo-StdOut -ShortFormat -Color ([System.ConsoleColor]::Cyan)
		if($AllSessions.IsPresent)
		{
			Get-DiagMonitoringExistingSessions -Name | %{
				$FileFlagStop = Join-Path $PWD.Path "..\StopMonitoring_$($_)."
				(Get-Date).ToString() | Out-File $FileFlagStop
			}
		}
		else
		{
			$FileFlagStop = Join-Path $PWD.Path "..\StopMonitoring_$($SessionName)."
			(Get-Date).ToString() | Out-File $FileFlagStop
		}
		Remove-DiagMonitoringSession -SessionName $SessionName -AllSessions:$AllSessions
	}
}
else
{
	"ERROR: $($Script:MonitoringPS1FilePath) cannot be found. Ending script" | WriteTo-StdOut -IsError
}

# SIG # Begin signature block
# MIIa7wYJKoZIhvcNAQcCoIIa4DCCGtwCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUyJTJuvnqjNoEHaGufWYw6FM5
# CsugghWCMIIEwzCCA6ugAwIBAgITMwAAAHD0GL8jIfxQnQAAAAAAcDANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTUwMzIwMTczMjAy
# WhcNMTYwNjIwMTczMjAyWjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkY1MjgtMzc3Ny04QTc2MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAoxTZ7xygeRG9
# LZoEnSM0gqVCHSsA0dIbMSnIKivzLfRui93iG/gT9MBfcFOv5zMPdEoHFGzcKAO4
# Kgp4xG4gjguAb1Z7k/RxT8LTq8bsLa6V0GNnsGSmNAMM44quKFICmTX5PGTbKzJ3
# wjTuUh5flwZ0CX/wovfVkercYttThkdujAFb4iV7ePw9coMie1mToq+TyRgu5/YK
# VA6YDWUGV3eTka+Ur4S+uG+thPT7FeKT4thINnVZMgENcXYAlUlpbNTGNjpaMNDA
# ynOJ5pT2Ix4SYFEACMHe2j9IhO21r9TTmjiVqbqjWLV4aEa/D4xjcb46Q0NZEPBK
# unvW5QYT3QIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFG3P87iErvfMdr24e6w9l2GB
# dCsnMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAF46KvVn9AUwKt7hue9n/Cr/bnIpn558xxPDo+WOPATpJhVN
# 98JnglwKW8UK7lXwoy2Ooh2isywt0BHimioB0TAmZ6GmbokxHG7dxHFU8Ami3cHW
# NnPADP9VCGv8oZT9XSwnIezRIwbcBCzvuQLbA7tHcxgK632ZzV8G4Ij3ipPFEhEb
# 81KVo3Kg0ljZwyzia3931GNT6oK4L0dkKJjHgzvxayhh+AqIgkVSkumDJklct848
# mn+voFGTxby6y9ErtbuQGQqmp2p++P0VfkZEh6UG1PxKcDjG6LVK9NuuL+xDyYmi
# KMVV2cG6W6pgu6W7+dUCjg4PbcI1cMCo7A2hsrgwggTsMIID1KADAgECAhMzAAAA
# ymzVMhI1xOFVAAEAAADKMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTE0MDQyMjE3MzkwMFoXDTE1MDcyMjE3MzkwMFowgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAJZxXe0GRvqEy51bt0bHsOG0ETkDrbEVc2Cc66e2bho8
# P/9l4zTxpqUhXlaZbFjkkqEKXMLT3FIvDGWaIGFAUzGcbI8hfbr5/hNQUmCVOlu5
# WKV0YUGplOCtJk5MoZdwSSdefGfKTx5xhEa8HUu24g/FxifJB+Z6CqUXABlMcEU4
# LYG0UKrFZ9H6ebzFzKFym/QlNJj4VN8SOTgSL6RrpZp+x2LR3M/tPTT4ud81MLrs
# eTKp4amsVU1Mf0xWwxMLdvEH+cxHrPuI1VKlHij6PS3Pz4SYhnFlEc+FyQlEhuFv
# 57H8rEBEpamLIz+CSZ3VlllQE1kYc/9DDK0r1H8wQGcCAwEAAaOCAWAwggFcMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBQfXuJdUI1Whr5KPM8E6KeHtcu/
# gzBRBgNVHREESjBIpEYwRDENMAsGA1UECxMETU9QUjEzMDEGA1UEBRMqMzE1OTUr
# YjQyMThmMTMtNmZjYS00OTBmLTljNDctM2ZjNTU3ZGZjNDQwMB8GA1UdIwQYMBaA
# FMsR6MrStBZYAck3LjMWFrlMmgofMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY0NvZFNpZ1BDQV8w
# OC0zMS0yMDEwLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljQ29kU2lnUENBXzA4LTMx
# LTIwMTAuY3J0MA0GCSqGSIb3DQEBBQUAA4IBAQB3XOvXkT3NvXuD2YWpsEOdc3wX
# yQ/tNtvHtSwbXvtUBTqDcUCBCaK3cSZe1n22bDvJql9dAxgqHSd+B+nFZR+1zw23
# VMcoOFqI53vBGbZWMrrizMuT269uD11E9dSw7xvVTsGvDu8gm/Lh/idd6MX/YfYZ
# 0igKIp3fzXCCnhhy2CPMeixD7v/qwODmHaqelzMAUm8HuNOIbN6kBjWnwlOGZRF3
# CY81WbnYhqgA/vgxfSz0jAWdwMHVd3Js6U1ZJoPxwrKIV5M1AHxQK7xZ/P4cKTiC
# 095Sl0UpGE6WW526Xxuj8SdQ6geV6G00DThX3DcoNZU6OJzU7WqFXQ4iEV57MIIF
# vDCCA6SgAwIBAgIKYTMmGgAAAAAAMTANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZIm
# iZPyLGQBGRYDY29tMRkwFwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQD
# EyRNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMTAwODMx
# MjIxOTMyWhcNMjAwODMxMjIyOTMyWjB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSMwIQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBD
# QTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALJyWVwZMGS/HZpgICBC
# mXZTbD4b1m/My/Hqa/6XFhDg3zp0gxq3L6Ay7P/ewkJOI9VyANs1VwqJyq4gSfTw
# aKxNS42lvXlLcZtHB9r9Jd+ddYjPqnNEf9eB2/O98jakyVxF3K+tPeAoaJcap6Vy
# c1bxF5Tk/TWUcqDWdl8ed0WDhTgW0HNbBbpnUo2lsmkv2hkL/pJ0KeJ2L1TdFDBZ
# +NKNYv3LyV9GMVC5JxPkQDDPcikQKCLHN049oDI9kM2hOAaFXE5WgigqBTK3S9dP
# Y+fSLWLxRT3nrAgA9kahntFbjCZT6HqqSvJGzzc8OJ60d1ylF56NyxGPVjzBrAlf
# A9MCAwEAAaOCAV4wggFaMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFMsR6MrS
# tBZYAck3LjMWFrlMmgofMAsGA1UdDwQEAwIBhjASBgkrBgEEAYI3FQEEBQIDAQAB
# MCMGCSsGAQQBgjcVAgQWBBT90TFO0yaKleGYYDuoMW+mPLzYLTAZBgkrBgEEAYI3
# FAIEDB4KAFMAdQBiAEMAQTAfBgNVHSMEGDAWgBQOrIJgQFYnl+UlE/wq4QpTlVnk
# pDBQBgNVHR8ESTBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtp
# L2NybC9wcm9kdWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEE
# SDBGMEQGCCsGAQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2Nl
# cnRzL01pY3Jvc29mdFJvb3RDZXJ0LmNydDANBgkqhkiG9w0BAQUFAAOCAgEAWTk+
# fyZGr+tvQLEytWrrDi9uqEn361917Uw7LddDrQv+y+ktMaMjzHxQmIAhXaw9L0y6
# oqhWnONwu7i0+Hm1SXL3PupBf8rhDBdpy6WcIC36C1DEVs0t40rSvHDnqA2iA6VW
# 4LiKS1fylUKc8fPv7uOGHzQ8uFaa8FMjhSqkghyT4pQHHfLiTviMocroE6WRTsgb
# 0o9ylSpxbZsa+BzwU9ZnzCL/XB3Nooy9J7J5Y1ZEolHN+emjWFbdmwJFRC9f9Nqu
# 1IIybvyklRPk62nnqaIsvsgrEA5ljpnb9aL6EiYJZTiU8XofSrvR4Vbo0HiWGFzJ
# NRZf3ZMdSY4tvq00RBzuEBUaAF3dNVshzpjHCe6FDoxPbQ4TTj18KUicctHzbMrB
# 7HCjV5JXfZSNoBtIA1r3z6NnCnSlNu0tLxfI5nI3EvRvsTxngvlSso0zFmUeDord
# EN5k9G/ORtTTF+l5xAS00/ss3x+KnqwK+xMnQK3k+eGpf0a7B2BHZWBATrBC7E7t
# s3Z52Ao0CW0cgDEf4g5U3eWh++VHEK1kmP9QFi58vwUheuKVQSdpw5OPlcmN2Jsh
# rg1cnPCiroZogwxqLbt2awAdlq3yFnv2FoMkuYjPaqhHMS+a3ONxPdcAfmJH0c6I
# ybgY+g5yjcGjPa8CQGr/aZuW4hCoELQ3UAjWwz0wggYHMIID76ADAgECAgphFmg0
# AAAAAAAcMA0GCSqGSIb3DQEBBQUAMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eTAeFw0wNzA0MDMxMjUzMDlaFw0yMTA0MDMx
# MzAzMDlaMHcxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAf
# BgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAJ+hbLHf20iSKnxrLhnhveLjxZlRI1Ctzt0YTiQP7tGn
# 0UytdDAgEesH1VSVFUmUG0KSrphcMCbaAGvoe73siQcP9w4EmPCJzB/LMySHnfL0
# Zxws/HvniB3q506jocEjU8qN+kXPCdBer9CwQgSi+aZsk2fXKNxGU7CG0OUoRi4n
# rIZPVVIM5AMs+2qQkDBuh/NZMJ36ftaXs+ghl3740hPzCLdTbVK0RZCfSABKR2YR
# JylmqJfk0waBSqL5hKcRRxQJgp+E7VV4/gGaHVAIhQAQMEbtt94jRrvELVSfrx54
# QTF3zJvfO4OToWECtR0Nsfz3m7IBziJLVP/5BcPCIAsCAwEAAaOCAaswggGnMA8G
# A1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFCM0+NlSRnAK7UD7dvuzK7DDNbMPMAsG
# A1UdDwQEAwIBhjAQBgkrBgEEAYI3FQEEAwIBADCBmAYDVR0jBIGQMIGNgBQOrIJg
# QFYnl+UlE/wq4QpTlVnkpKFjpGEwXzETMBEGCgmSJomT8ixkARkWA2NvbTEZMBcG
# CgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWljcm9zb2Z0IFJvb3Qg
# Q2VydGlmaWNhdGUgQXV0aG9yaXR5ghB5rRahSqClrUxzWPQHEy5lMFAGA1UdHwRJ
# MEcwRaBDoEGGP2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1
# Y3RzL21pY3Jvc29mdHJvb3RjZXJ0LmNybDBUBggrBgEFBQcBAQRIMEYwRAYIKwYB
# BQUHMAKGOGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljcm9z
# b2Z0Um9vdENlcnQuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# BQUAA4ICAQAQl4rDXANENt3ptK132855UU0BsS50cVttDBOrzr57j7gu1BKijG1i
# uFcCy04gE1CZ3XpA4le7r1iaHOEdAYasu3jyi9DsOwHu4r6PCgXIjUji8FMV3U+r
# kuTnjWrVgMHmlPIGL4UD6ZEqJCJw+/b85HiZLg33B+JwvBhOnY5rCnKVuKE5nGct
# xVEO6mJcPxaYiyA/4gcaMvnMMUp2MT0rcgvI6nA9/4UKE9/CCmGO8Ne4F+tOi3/F
# NSteo7/rvH0LQnvUU3Ih7jDKu3hlXFsBFwoUDtLaFJj1PLlmWLMtL+f5hYbMUVbo
# nXCUbKw5TNT2eb+qGHpiKe+imyk0BncaYsk9Hm0fgvALxyy7z0Oz5fnsfbXjpKh0
# NbhOxXEjEiZ2CzxSjHFaRkMUvLOzsE1nyJ9C/4B5IYCeFTBm6EISXhrIniIh0EPp
# K+m79EjMLNTYMoBMJipIJF9a6lbvpt6Znco6b72BJ3QGEe52Ib+bgsEnVLaxaj2J
# oXZhtG6hE6a/qkfwEm/9ijJssv7fUciMI8lmvZ0dhxJkAj0tr1mPuOQh5bWwymO0
# eFQF1EEuUKyUsKV4q7OglnUa2ZKHE3UiLzKoCG6gW4wlv6DvhMoh1useT8ma7kng
# 9wFlb4kLfchpyOZu6qeXzjEp/w7FW1zYTRuh2Povnj8uVRZryROj/TGCBNcwggTT
# AgEBMIGQMHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xIzAh
# BgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBAhMzAAAAymzVMhI1xOFV
# AAEAAADKMAkGBSsOAwIaBQCggfAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFA6E
# lnCx3w+iV6g1sNYVPteAwWH+MIGPBgorBgEEAYI3AgEMMYGAMH6gZIBiAEQASQBB
# AEcAXwBDAFQAUwBIAHkAcABlAHIAVgBfAGcAbABvAGIAYQBsAF8AVABTAF8ATQBv
# AG4AaQB0AG8AcgBEAGkAYQBnAEUAeABlAGMAdQB0AGkAbwBuAC4AcABzADGhFoAU
# aHR0cDovL21pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEBBQAEggEAYYyCVPS9o9Ny
# 2/OTsvBYB1V5qlpS4ym9qFIPuLu0pOq6y8yoRd0Zv9SsGVRwycIrEbuWicTvfEav
# 7EuY/XioXt9+aBoE1GpLyaTdidx+epgcUIyGw6RyYDecvttXj69xRQnl/k1K43Y4
# 0gXAsbt09Lcsl60vpmX5PSPwOg4+LHmyD9N/yywP3Int+d0gFYV6ElCQQpeDwDSR
# XZj8M/J/6DclKQrFlXO7jcpdTtb92462E9x/Nq/128cWVO6B/mUDlibm/m6VxNLz
# SoQRAC1dqu4ba72+cNSVWPPIapkNlMEge6R/nPcm4yLIeZfMGVCXafTtwSxTGzqw
# h0u//WaTw6GCAigwggIkBgkqhkiG9w0BCQYxggIVMIICEQIBATCBjjB3MQswCQYD
# VQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEe
# MBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEwHwYDVQQDExhNaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBQQ0ECEzMAAABw9Bi/IyH8UJ0AAAAAAHAwCQYFKw4DAhoF
# AKBdMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTE1
# MDQxNTE2MDE1M1owIwYJKoZIhvcNAQkEMRYEFO60EOU1y1fHwEsiy4Duuv+lW7Wy
# MA0GCSqGSIb3DQEBBQUABIIBACwIW2azbkspWAKbOrEx7JJFO5/lyQFsNBlAMEii
# xTX0N8pkbxLuzReMJptBZHx+sG3liFHb1sGeD5wYIvkiCHTXpPWRQJ43FGUGOc4L
# eJLq+keFm4wP0QmXsSoA90l2tVr6HqOWh2xSsk7LoB5XKtlnfW3QvA6KKzgsIvKc
# yhrIrzkeld7OLwZ+oNuxhoe9LrEiKPOkNINqV1zYDEupEg4GW6Gu3/vXOMzASBrm
# XtY6o6C36Yzt1uKK4EPIGbeLkWU4FePnS+pS1hA72BNTmdAiSAd1eKNsMJMwBZo3
# ktQ60Soeptd4148eFdXifgP564yTaMKKSpXgeToPtNEWBWI=
# SIG # End signature block
