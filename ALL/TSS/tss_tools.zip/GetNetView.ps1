# Script: GetNetView.ps1
# https://github.com/microsoft/Get-NetView
<#
This module is part of MSFT.Network.Tools which can be installed using this command: Install-Module MSFT.Network.Diag
Or install this module individually using this command: Install-Module Get-NetView
To see all modules from the Microsoft Core Networking team, please use: Find-Module -Tag MSFTNet
#>

[string]$scriptPath = (Split-Path $MyInvocation.MyCommand.Path -Parent)
Write-verbose "scriptPath: $scriptPath"

Import-Module -Name $scriptPath\Get-NetView.psm1   

Write-Host -ForegroundColor White -BackgroundColor DarkGreen "Collecting Get-NetView Diagnostics Data (Version: 2019.6.25.34):"
Get-NetView @PSBoundParameters 