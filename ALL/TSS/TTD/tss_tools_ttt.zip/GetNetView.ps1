# Script: GetNetView.ps1
# https://github.com/microsoft/Get-NetView
<#
This module is part of MSFT.Network.Tools which can be installed using this command: Install-Module MSFT.Network.Diag
Or install this module individually using this command: Install-Module Get-NetView
To see all modules from the Microsoft Core Networking team, please use: Find-Module -Tag MSFTNet
#>

[CmdletBinding()]
PARAM (
        [parameter(Mandatory=$false)]
        [ValidateScript({Test-Path $_ -PathType Container})]
        [String] $OutputDirectory = "",

        [parameter(Mandatory=$false)]
        [ScriptBlock[]] $ExtraCommands = @(),

        [parameter(Mandatory=$false)]
        [ValidateRange(1, 16)]
        [Int] $MaxThreads = 5,

        [parameter(Mandatory=$false)]
        [Switch] $SkipAdminCheck = $false
    )
	
#[string]$scriptPath = (Split-Path $MyInvocation.MyCommand.Path -Parent)
#Write-verbose "scriptPath: $scriptPath"

  # This gets the current path and name of the script.
  $invocation = (Get-Variable MyInvocation).Value
	$invocationLine= $($MyInvocation.Line)
  $scriptPath = Split-Path $invocation.MyCommand.Path
	$ScriptParentPath 	= Split-Path $MyInvocation.MyCommand.Path -Parent
	Write-Verbose "scriptPath:  $scriptPath - ScriptParentPath: $ScriptParentPath"

#Import-Module -Name $scriptPath\Get-NetView.psm1
Import-Module -Name $ScriptParentPath\Get-NetView.psm1   

Write-Host -ForegroundColor White -BackgroundColor DarkGreen "$(Get-Date -Format 'HH:mm:ss') Collecting Get-NetView Diagnostics Data (Version: 2019.10.25.60):"
Write-Verbose "PSBoundParameters: @PSBoundParameters "
	Get-NetView @PSBoundParameters 
# Scrub out
    Remove-Item $OutputDirectory\msdgb.*.zip -Force -ErrorAction SilentlyContinue
Write-Host -ForegroundColor White -BackgroundColor DarkGreen "$(Get-Date -Format 'HH:mm:ss') ..Done Get-NetView Diagnostics Data"

