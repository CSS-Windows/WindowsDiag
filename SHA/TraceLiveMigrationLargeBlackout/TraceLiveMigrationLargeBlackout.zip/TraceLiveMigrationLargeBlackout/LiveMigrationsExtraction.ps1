param(
    [int32]$DelayInDays=6,  # Number of days we want to get back in the past
    [string]$Path,          # Path to look for the events : If the argument is missing use the current path
    [string]$ExportPath     # Folder where to export the data
)

<#
    The Goal is to detect the VMs with a large blackout during a live migration 
    and isolate the event logs related to the migration of these VMs
    
    1. Identify the VMs with a large blackout and build a first list
        - Event ID 20415 will give normal blackouts on the source server (Microsoft-Windows-Hyper-V-VMMS/Admin)
        - Event ID 20417 will give the unexpectedly long blackouts on the source server (Microsoft-Windows-Hyper-V-VMMS/Admin)

    class C_evtBlackout{
        [string]$C_LoggingNode          The node that logs the event (not necessary the source or the destination hyper-v host)
        [string]$C_SourceNode           The Hyper-V host which is the source of the migration (we just keep the first field of the FQDN)
        [string]$C_DestinationNode      The Hyper-V host which is the destination of the migration (we just keep the first field of the FQDN)
        [DateTime]$C_TimeCreated        The time the event log has been logged (not necessary the begin or the end of the migration)
        [DateTime]$C_MigrationBegin     The time when the migration starts
        [DateTime]$C_MigrationEnd       The time when the migration endss
        [string]$C_EventID              The Event ID (why not ?)
        [string]$C_VMName               The Name of the VM : We use this field to display in the outputs
        [string]$C_VMGuid               The GUID of the VM : We use this field for searching correspondances
        [decimal]$C_Blackout            The Blacjout time (can be acceptable or unaccaptably long)
        [string]$C_Category             "VMMS_MIGRATION_START" , "WORKER_MIGRATION_START" or "VMMS_MIGRATION_REPORT" ... not sure it is really usefull
        [string]$C_EvtxPath             The path to the evtx file that contains the event : Will be used later to 
                                        create the collection of evtx to parse with the structured query
    }

    2. For each VM who experiments a too large blackout, identify:
        - When the migration starts and when it ends
        - Where the VM starts from and where it goes
        We rely on the events 21200, 21300, 20415 & 20417

    We'll build a list of the interresting events by getting only the usefull part through the above class
    We should parse the events several times because there is not one single event that contains both directions & timings.

    So we run only once all the events available in the Path to create a first collection
    Then we fill the missing fields with the data in this collection to have a couple of events
    that contain both : Direction & Timings

    3. For each VM who experiments a blackout
        - Use the Structured Query bellow on all the events on the source node
        - Use the Structured Query bellow on all the events on the destination node

    Events Detailed:
    ================
        
    Event 21200 (Microsoft-Windows-Hyper-V-VMMS/Analytic) : This one gives the VMName, the Source & the Destination
    - Text: Started live migration - source host (VM 'VMName', destination host 'DestinationHost', migration type 'MigrationTypeCode', performing 'Action').
    - Content:
        - System 
          - UserData
            - VmlEventLog
                Parameter0  VMGuid
                Parameter1  VMName  
                Parameter2  DestinationHost
                Parameter3  MigrationTypeName
                Parameter4  ???
                Parameter5  MigrationTypeCode
                Parameter6  Action

    Event 21300 (Microsoft-Windows-Hyper-V-Worker/Analytic) : This one gives when the action starts
    - Text: Started live migration - source node. (VM 'VMName', VMGuid)
    - Content :
        - System
          - UserData
            - VmlEventLog
                Parameter0 VMGuid
                Parameter1 VMName

    20415 Content (Microsoft-Windows-Hyper-V-VMMS/Admin) : This one tells the migrationblackout is acceptable
    - Text: The Virtual Machine Management service successfully completed the live migration of virtual machine  'VMName' with a blackout time of TimeInSeconds seconds (VMID VMGuid).
    - Content:
        - System
          - UserData 
            - VmlEventLog 
                Parameter0 VMName
                Parameter1 VMGuid
                Parameter2 TimeInSeconds

    20417 Content (Microsoft-Windows-Hyper-V-VMMS/Admin) : This one tells the migration blackout is too long
    - Text: The Virtual Machine Management service successfully completed the live migration of virtual machine  'VMName' with an unexpectedly long blackout time of TimeInSeconds seconds (VMID VMGUID)."
    - Content:
        - System
          - UserData 
            - VmlEventLog 
                Parameter0 VMName
                Parameter1 VMGuid
                Parameter2 TimeInSeconds

    Structured Queries
    ==================

    Primary query
    -------------
    <QueryList>
        <Query>
            <Select>
                *[System[(EventID=20415 or EventID=20417 or EventID=21300 or EventID=21200) and TimeCreated[timediff(@SystemTime) &lt;= $sDelay]]]
            </Select>
        </Query>
    </QueryList>"


    Secondary query for each event log
    ----------------------------------
    <QueryList>
        <Query>
            <Select>*[UserData[VmlEventLog[(VmId='<VMGUID>')]]] and *[System[TimeCreated[@SystemTime&gt;='<DATEBEGIN>Z' and @SystemTime&lt;='<DATEEND>Z']]]</Select>
            <Select>*[UserData[VmlDebugTrace[(VmId='<VMGUID>')]]] and *[System[TimeCreated[@SystemTime&gt;='<DATEBEGIN>Z' and @SystemTime&lt;='<DATEEND>Z']]]</Select>
            <Select>*[System[(EventID=20415) and TimeCreated[@SystemTime&gt;='<DATEBEGIN>Z' and @SystemTime&lt;='<DATEEND>Z']]] and *[UserData[VmlEventLog[(Parameter1='<VMGUID>')]]]</Select>
        </Query>
    </QueryList>

    We'll have to generate one filter per evtx file

    <QueryList>
        <Query Id="0" Path="file://<PATH_TO_EVTX_1.evtx>">
            <Select Path="file://<PATH_TO_EVTX_1.evtx>">*[UserData[VmlEventLog[(VmId='<VMGUID>')]]] and *[System[TimeCreated[@SystemTime&gt;='<DATEBEGIN>Z' and @SystemTime&lt;='<DATEBEND>Z']]]</Select>
            <Select Path="file://<PATH_TO_EVTX_1.evtx>">*[UserData[VmlDebugTrace[(VmId='<VMGUID>')]]] and *[System[TimeCreated[@SystemTime&gt;='<DATEBEGIN>Z' and @SystemTime&lt;='<DATEBEND>Z']]]</Select>
            <Select Path="file://<PATH_TO_EVTX_1.evtx>">*[System[(EventID=20415) and TimeCreated[@SystemTime&gt;='<DATEBEGIN>Z' and @SystemTime&lt;='<DATEBEND>Z']]] and *[UserData[VmlEventLog[(Parameter1='<VMGUID>')]]]</Select>

            <Select Path="file://<PATH_TO_EVTX_2.evtx>">*[UserData[VmlEventLog[(VmId='<VMGUID>')]]] and *[System[TimeCreated[@SystemTime&gt;='<DATEBEGIN>Z' and @SystemTime&lt;='<DATEBEND>Z']]]</Select>
            <Select Path="file://<PATH_TO_EVTX_2.evtx>">*[UserData[VmlDebugTrace[(VmId='<VMGUID>')]]] and *[System[TimeCreated[@SystemTime&gt;='<DATEBEGIN>Z' and @SystemTime&lt;='<DATEBEND>Z']]]</Select>
            <Select Path="file://<PATH_TO_EVTX_2.evtx>">*[System[(EventID=20415) and TimeCreated[@SystemTime&gt;='<DATEBEGIN>Z' and @SystemTime&lt;='<DATEBEND>Z']]] and *[UserData[VmlEventLog[(Parameter1='<VMGUID>')]]]</Select>

            <Select Path="file://<PATH_TO_EVTX_#.evtx>">*[UserData[VmlEventLog[(VmId='<VMGUID>')]]] and *[System[TimeCreated[@SystemTime&gt;='<DATEBEGIN>Z' and @SystemTime&lt;='<DATEBEND>Z']]]</Select>
            <Select Path="file://<PATH_TO_EVTX_#.evtx>">*[UserData[VmlDebugTrace[(VmId='<VMGUID>')]]] and *[System[TimeCreated[@SystemTime&gt;='<DATEBEGIN>Z' and @SystemTime&lt;='<DATEBEND>Z']]]</Select>
            <Select Path="file://<PATH_TO_EVTX_#.evtx>">*[System[(EventID=20415) and TimeCreated[@SystemTime&gt;='<DATEBEGIN>Z' and @SystemTime&lt;='<DATEBEND>Z']]] and *[UserData[VmlEventLog[(Parameter1='<VMGUID>')]]]</Select>
            ...
        </Query>
    </QueryList>



#>

#   Arguments

    if ($Path -ne $null){
        $Path = split-path -LiteralPath $script:MyInvocation.MyCommand.Path 
    }

    if (-not $ExportPath){
        $ExportPath = $Path+"\Export"
    }

    if ( -not(Test-Path -Path $ExportPath)){
        New-Item -ItemType "Directory" -Path $ExportPath | Out-Null
    }

#   Functions 
function BuildQuery([string[]]$ListOfEvents,[string]$VMGuid, [string]$DateBegin, [string]$DateEnd ){
    $Global:Query = "<QueryList>`n<Query Id=`"0`" Path=`"file://"+$ListOfEvents[0]+"`">`n"
    $ListOfEvents | ForEach-Object{
        $Global:Query += "<Select Path=`"file://"+$_+"`">*[UserData[VmlEventLog[(VmId='"+$VMGuid+"')]]] and *[System[TimeCreated[@SystemTime&gt;='"+$DateBegin+"Z' and @SystemTime&lt;='"+$DateEnd+"Z']]]</Select>`n"
        $Global:Query += "<Select Path=`"file://"+$_+"`">*[UserData[VmlDebugTrace[(VmId='"+$VMGuid+"')]]] and *[System[TimeCreated[@SystemTime&gt;='"+$DateBegin+"Z' and @SystemTime&lt;='"+$DateEnd+"Z']]]</Select>`n"
        $Global:Query += "<Select Path=`"file://"+$_+"`">*[System[(EventID=20415) and TimeCreated[@SystemTime&gt;='"+$DateBegin+"Z' and @SystemTime&lt;='"+$DateEnd+"Z']]] and *[UserData[VmlEventLog[(Parameter1='"+$VMGuid+"')]]]</Select>`n"
        $Global:Query += "<Select Path=`"file://"+$_+"`">*[System[(EventID=20417) and TimeCreated[@SystemTime&gt;='"+$DateBegin+"Z' and @SystemTime&lt;='"+$DateEnd+"Z']]] and *[UserData[VmlEventLog[(Parameter1='"+$VMGuid+"')]]]</Select>`n"
    }
    $Global:Query += "</Query>`n</QueryList>`n"
}

function ExtractEvents( [string]$SourceNode, 
                        [string]$DestinationNode,
                        [string]$DateBegin,
                        [string]$DateEnd,
                        [string]$VMName,
                        [string]$VMGuid,
                        [string]$Blackout,
                        [string]$ExportPath)
{

    $SourceNode, $DestinationNode | ForEach-Object {

        $CurrentNode = $_

        # --- List the events matching the current node
        $ListOfNodeEvents = @()
        Get-ChildItem | Where-Object Name -like "*evtx" | ForEach-Object { 
        if ( (Get-WinEvent -Path $_.FullName -MaxEvents 1).MachineName.split(".")[0] -eq $CurrentNode ){
            $ListOfNodeEvents +=  $_.FullName
            }
        }

        # --- Build the query
        $Global:Query = $null
        $MergingQueryFileName = "$ExportPath\VM_"+$VMName+"_Blackout_"+$Blackout+"_From_"+$SourceNode+"_to_"+$DestinationNode+"_filter_for_node_"+$CurrentNode
        $MergingQueryFilePath = New-Item -Path $MergingQueryFileName -ItemType File -Force
        $MergedEvtxPath = "$ExportPath\VM_"+$VMName+"_Blackout_"+$Blackout+"_From_"+$SourceNode+"_to_"+$DestinationNode+"_events_from_node_"+$CurrentNode+".evtx"

        BuildQuery -ListOfEvents $ListOfNodeEvents -VMGuid $VMGuid -DateBegin $DateBegin -DateEnd $DateEnd
        $Global:Query | Add-Content $MergingQueryFilePath
        
        # --- Run the extraction
        Write-Host "Extracting the events for the migration of $VMName from node $CurrentNode..."
        wevtutil.exe /sq epl $MergingQueryFilePath $MergedEvtxPath /ow:true
        write-host "`t$MergedEvtxPath`n" -ForegroundColor Green
    }
}

#   Variables

    [long]$lDelay_1D = 24*60*60*1000                # One day delay in milliseconds
    [long]$lDelay = $DelayInDays*$lDelay_1D         # To be multiplied by the argument $DelayInDays
    [string]$sDelay = [convert]::ToString($lDelay)  # The Delay as [string]
    [string]$Global:Query = $null
    
    # Query to collect the events to start from
    $QueryForMigrations = "<QueryList><Query><Select>*[System[(EventID=20415 or EventID=20417 or EventID=21300 or EventID=21200) and TimeCreated[timediff(@SystemTime) &lt;= $sDelay]]]</Select></Query></QueryList>"

#   Class Definition

    class C_evtBlackout{
        [string]$C_LoggingNode
        [string]$C_SourceNode
        [string]$C_DestinationNode
        [DateTime]$C_TimeCreated
        [DateTime]$C_MigrationBegin
        [DateTime]$C_MigrationEnd
        [string]$C_EventID
        [string]$C_VMName
        [string]$C_VMGuid
        [string]$C_Blackout
        [string]$C_Category
        [string]$C_EvtxPath
        SetMigrationEnd([datetime]$MigrationEnd){
            $this.C_MigrationEnd = $MigrationEnd
        }
        C_evtBlackout(  [string]$LoggingNode, 
                        [string]$SourceNode,
                        [string]$DestinationNode,
                        [DateTime]$TimeCreated, 
                        [DateTime]$MigrationBegin,
                        [DateTime]$MigrationEnd,
                        [string]$EventID, 
                        [string]$VMName, 
                        [string]$VMGuid,
                        [string]$Blackout,
                        [string]$Category,
                        [string]$EvtxPath){
            $this.C_LoggingNode = $LoggingNode
            $this.C_SourceNode = $SourceNode
            $this.C_DestinationNode = $DestinationNode
            $this.C_TimeCreated = $TimeCreated
            $this.C_MigrationBegin = $MigrationBegin 
            $this.C_MigrationEnd = $MigrationEnd
            $this.C_EventID = $EventID
            $this.C_VMName = $VMName
            $this.C_VMGuid = $VMGuid
            $this.C_Blackout = $Blackout
            $this.C_Category = $Category
            $this.C_EvtxPath = $EvtxPath
        }
    }

#   ===== I. Build the list of the migration events =====

    $ListOfMigrationEvents = @()

#   Look for all the events in the current folder

    Write-Host "Looking for the event logs related to live migration..." -ForegroundColor Yellow

    Get-ChildItem -LiteralPath $Path | Where-Object Name -like "*evtx" | ForEach-Object { 

        $EvtxPath = $_.FullName
        $MigrationEvents = Get-WinEvent -Path $_.FullName -FilterXPath $QueryForMigrations -ErrorAction SilentlyContinue

        if ($MigrationEvents.Count -gt 0){ 
            $MigrationEvents | ForEach-Object {
                # Elements common to each event
                    $LoggingNode = $_.MachineName.split(".")[0]
                    $SourceNode = $_.MachineName.split(".")[0]
                    $TimeCreated = $_.TimeCreated
                # Migration Start From Node-Src to Node-Dst logged by VMMS
                if ($_.Id -eq "21200"){ 
                    $DestinationNode = $_.Properties[2].Value
                    $MigrationBegin = $_.TimeCreated
                    $MigrationEnd = 0 # [DateTime] doesn't accepct $null
                    $VMName = $_.Properties[1].Value
                    $VMGuid = $_.Properties[0].Value
                    $Blackout = $null
                    $Category = "VMMS_MIGRATION_START"
                }
                # Migration Start logged by VMMS
                if ($_.Id -eq "21300"){
                    $DestinationNode = $null
                    $MigrationBegin = $_.TimeCreated
                    $MigrationEnd = 0 # [DateTime] doesn't accepct $null
                    $VMName = $_.Properties[1].Value
                    $VMGuid = $_.Properties[0].Value
                    $Blackout = $null
                    $Category = "WORKER_MIGRATION_START"
                }
                # Migration End from VMMS
                if ($_.Id -eq "20415" -or  $_.Id -eq "20417"){
                    
                    $DestinationNode = $null
                    $MigrationBegin = 0 # [DateTime] doesn't accepct $null
                    $MigrationEnd = $_.TimeCreated
                    $VMName = $_.Properties[0].Value
                    $VMGuid = $_.Properties[1].Value
                    $Blackout = $_.Properties[2].Value
                    $Category = "VMMS_MIGRATION_REPORT"
                }
                $ListOfMigrationEvents += [C_evtBlackout]::New( $LoggingNode,
                                                                $SourceNode,
                                                                $DestinationNode,
                                                                $TimeCreated,
                                                                $MigrationBegin, 
                                                                $MigrationEnd,
                                                                $_.Id,
                                                                $VMName,
                                                                $VMGuid,
                                                                $Blackout, 
                                                                $Category, 
                                                                $EvtxPath)
            }
        }
    }

#   Display the event logs that shows a large blackout

    Write-Host "List of large blackout events" -ForegroundColor Yellow
    $ListOfLargeBlackoutEvents = $ListOfMigrationEvents | Where-Object C_EventID -eq "20417"
    $ListOfLargeBlackoutEvents | Format-Table C_VMName, C_VMGuid, C_Blackout, C_MigrationEnd

    Write-Host "List of migration start" -ForegroundColor Yellow
    $ListOfLargeBlackoutVMs = ($ListOfLargeBlackoutEvents).C_VMGuid
    $ListOfMigrationEvents | Where-Object C_Category -eq "VMMS_MIGRATION_START" | Where-Object { $_.C_VMGuid -in $ListOfLargeBlackoutVMs} | Format-Table C_VMName, C_VMGuid, C_SourceNode, C_DestinationNode, C_MigrationBegin

#   =====   Building the queries for extraction

    Write-Host "Building the queries for extraction..." -ForegroundColor Yellow

#   -----   Because of different errors, it is possible that a VM starts twice but migrate only once.

$ListOfLargeBlackoutEvents | ForEach-Object {

    #   -----   Here we have a list containing source node and the migration end time
    #   -----       We need to find the destination node and the migration start time

    $VMGuid = $_.C_VMGuid
    $VMName = $_.C_VMName
    $SourceNode = $_.C_SourceNode
    #    $DestinationNode
    #    $MigrationBegin
    $MigrationEnd = $_.C_MigrationEnd
    $Blackout = $_.C_Blackout
    write-host "`n VM $VMName (GUID $VMGuid) Blackout : $Blackout `n" -BackgroundColor Yellow -ForegroundColor Black
    $ListOfComplementaryEvents = $ListOfMigrationEvents | Where-Object C_Category -eq "VMMS_MIGRATION_START" | Where-Object { $_.C_VMGuid -eq $VMGuid}
    
    # ==================== No complemantary events found - We'll ignode this one ====================
    if ($ListOfComplementaryEvents.count -eq 0){
            Write-Host "No luck for this one" -ForegroundColor Red
    }

    # ==================== We find one complementary event - It is the one that tells the migration starts ====================

    if ($ListOfComplementaryEvents.count -eq 1){

        $DestinationNode = $ListOfComplementaryEvents[0].C_DestinationNode
        $MigrationBegin = $ListOfComplementaryEvents[0].C_MigrationBegin
        Write-Host "From $SourceNode ($MigrationBegin) to $DestinationNode ($MigrationEnd)`n"

        # ---------- Building the queries for extraction ----------
        
        # ---  Dates as UniversalTime

        $MigrationBegin_UTime = $MigrationBegin.ToUniversalTime()
        $MigrationEnd_UTime = $MigrationEnd.ToUniversalTime()
        $DateBegin = "{0}-{1}-{2}T{3}:{4}:{5}.000" -f $MigrationBegin_UTime.Year, $MigrationBegin_UTime.Month, $MigrationBegin_UTime.Day, $MigrationBegin_UTime.Hour, $MigrationBegin_UTime.Minute, $MigrationBegin_UTime.Second
        $DateEnd = "{0}-{1}-{2}T{3}:{4}:{5}.999" -f $MigrationEnd_UTime.Year, $MigrationEnd_UTime.Month, $MigrationEnd_UTime.Day, $MigrationEnd_UTime.Hour, $MigrationEnd_UTime.Minute, $MigrationEnd_UTime.Second

        ExtractEvents -SourceNode $SourceNode -DestinationNode $DestinationNode -DateBegin $DateBegin -DateEnd $DateEnd -VMName $VMName -VMGuid $VMGuid -Blackout $Blackout -ExportPath $ExportPath
        
    }
    # ==================== We find more than one complementary event - if both directions match, start with the first try ====================
    if ($ListOfComplementaryEvents.count -gt 1){
        Write-Host "This one is complex " -ForegroundColor Yellow -NoNewline
        $DestinationHosts = ($ListOfComplementaryEvents).C_DestinationNode | Sort-Object -Unique
        if ($DestinationHosts.Count -eq 1) {
            Write-Host "but not too much because there is only one direction" -ForegroundColor Yellow
            Write-Host "Let's keep the first try as a Migration Begin" -ForegroundColor Yellow
            $DestinationNode = $DestinationHosts
            $MigrationBegin = (($ListOfComplementaryEvents).C_MigrationBegin | Sort-Object)[0]
            Write-Host "From $SourceNode ($MigrationBegin) to $DestinationNode ($MigrationEnd)`n"
   
            # ---------- Building the queries for extraction ----------
        
            # ---  Dates as UniversalTime

            $MigrationBegin_UTime = $MigrationBegin.ToUniversalTime()
            $MigrationEnd_UTime = $MigrationEnd.ToUniversalTime()
            $DateBegin = "{0}-{1}-{2}T{3}:{4}:{5}.000" -f $MigrationBegin_UTime.Year, $MigrationBegin_UTime.Month, $MigrationBegin_UTime.Day, $MigrationBegin_UTime.Hour, $MigrationBegin_UTime.Minute, $MigrationBegin_UTime.Second
            $DateEnd = "{0}-{1}-{2}T{3}:{4}:{5}.999" -f $MigrationEnd_UTime.Year, $MigrationEnd_UTime.Month, $MigrationEnd_UTime.Day, $MigrationEnd_UTime.Hour, $MigrationEnd_UTime.Minute, $MigrationEnd_UTime.Second
    
            ExtractEvents -SourceNode $SourceNode -DestinationNode $DestinationNode -DateBegin $DateBegin -DateEnd $DateEnd -VMName $VMName -VMGuid $VMGuid -Blackout $Blackout -ExportPath $ExportPath

        }
        else{
            Write-Host " ... too complex to automatize as there are several directions"
        }
    }
}
