﻿# diag_net.ps1
# Created by tdimli
# March 2020
#
# Diagnostic functions for NET area
# contributors: tdimli
# developers: tdimli
#
# For information on how to create a diagnostic function, please see developers.md at:
# https://github.com/CSS-Windows/WindowsDiag/tree/master/ALL/XRay/developer.md

# version
$NET_version = "1.0.200505.0"

# Area and Area/Component arrays
$NET = @("DhcpSrv", "802Dot1x") #, "WLAN", "Auth", "BITS", "BranchCache", "Container", "CSC", "DAcli", "DAsrv", "DFScli", "DFSsrv", "DHCPcli", "DNScli", "DNSsrv", "Firewall", "General", "HypHost", "HypVM", "IIS", "IPAM", "MsCluster", "MBAM", "MBN", "Miracast", "NCSI", "NetIO", "NFScli", "NFSsrv", "NLB", "NPS", "Proxy", "RAS", "RDMA", "RDScli", "RDSsrv" "SDN" "SdnNC" "SQLtrace" "SBSL" "UNChard" "VPN" "WFP" "Winsock" "WIP" "WNV" "Workfolders")

#Component/Diagnostic Function arrays
$DhcpSrv = @("net_dhcpsrv_KB4503857")
$802Dot1x = @("net_802Dot1x_KB4556307")

# begin: diagnostic functions

#region net_dhcpsrv_KB4503857
<#
Checks for:
The issue where a DHCP Server has Option 66 (Boot Server Host Name) defined
but the name(s) cannot be resolved to IP addresses.
This causes DHCP Server repeatedly spending time to resolve these names and
prevents it from serving clients. This can cause DHCP outages.
#>
function net_dhcpsrv_KB4503857
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [Boolean]
        $offline
    )

    $issueMsg = "
Following Option 66 (Boot Server Host Name) values are configured on this DHCP 
Server but cannot be resolved to IP address(es). This can cause a DHCP outage 
where DHCP clients will not be able to receive IP addresses!

Server name(s) that cannot be resolved:
=======================================
{0}
Option 66 config location(s):
=============================
{1}
Resolution:
===========
Check Option 66 entries listed above and ensure that all configured names can 
be resolved and resolved in a timely manner by the DHCP Server.

Please remove any Option 66 entries that
1. point to decommissioned servers or servers that do not exist anymore
2. are not being used anymore

For servers in the list that are still active and being used as boot servers:
1. Ensure DNS records are created for them so that the names can be resolved

To test if a name can be resolved: 
Command prompt: ping -4 <server-name>
Powershell: Resolve-DnsName -Name <server-name> -Type A
"

    # updates (oldest update first), which when installed, may lead to this issue
    $effectingUpdates = @()  # this issue is not specific to an update
    # updates (oldest update first), which when installed, resolve this issue
    $resolvingUpdates = @() # this issue is not resolved by an update

    if($offline) { 
        $xrayDiag.LogToFile("Cannot run offline, skipping")
        return $xrayDiag::ReturnCode_Skipped
    }

    $services = Get-Service -Name "DHCPServer" -ErrorAction SilentlyContinue
    if(($services.Count -ne 1) -or ($services.Status -ne "Running")) {
        # No DHCP Server, nothing to check
        $xrayDiag.LogToFile("DHCPServer service not running, nothing to check, skipping")
        return $xrayDiag::ReturnCode_Skipped
    }

    $dhcpexport = $xrayDiag.MakeFileName("dhcpexport", "xml")

    try{
        Export-DhcpServer -File $dhcpexport -Force -ErrorVariable DhcpError
    }
    catch {
        # export failed
        $xrayDiag.LogToFile("Error: Export failed - exiting! (Error: {0})" -f $_)
        return $xrayDiag::ReturnCode_Failed
    }

    [xml]$Dhcp = Get-Content $dhcpexport

    $badOptions = ""
    [System.Collections.Generic.List[String]] $failedNames = @()

    # Check Server Options
    foreach ($option in $Dhcp.DHCPServer.IPv4.OptionValues.OptionValue) {
        if ($option.OptionId -eq 66) {
            if ($failedNames.Contains($option.Value) -or !(ResolveDnsName $option.Value)) {
                # failed, add error to return msg
                $badOptions += $option.Value + " (IPv4->Server Options)`n"
                if (!$failedNames.Contains($option.Value)) {
                    $failedNames.Add($option.Value)
                }
            }
        }
    }

    # Check IPv4 Policies
    foreach ($policy in $Dhcp.DHCPServer.IPv4.Policies.Policy) {
        foreach ($option in $policy.OptionValues.OptionValue) {
            if ($option.OptionId -eq 66) {
                if ($failedNames.Contains($option.Value) -or !(ResolveDnsName $option.Value)) {
                    # failed, add error to return msg
                    $badOptions += $option.Value + " (IPv4->Policies->" + $policy.Name + ")`n"
                    if (!$failedNames.Contains($option.Value)) {
                        $failedNames.Add($option.Value)
                    }
                }
            }
        }
    }

    # Check Scopes
    foreach ($scope in $Dhcp.DHCPServer.IPv4.Scopes.Scope) {

        # Scope Pptions
        foreach($option in $scope.OptionValues.OptionValue) {
            if ($option.OptionId -eq 66) {
                if ($failedNames.Contains($option.Value) -or !(ResolveDnsName $option.Value)) {
                    # failed, add error to return msg
                    $badOptions += $option.Value + " (IPv4->Scope[" + $scope.ScopeId + "])`n"
                    if (!$failedNames.Contains($option.Value)) {
                        $failedNames.Add($option.Value)
                    }
                }
            }
        }

        # Scope Policies
        foreach ($policy in $scope.Policies.Policy) {
            foreach ($option in $policy.OptionValues.OptionValue) {
                if ($option.OptionId -eq 66) {
                    if ($failedNames.Contains($option.Value) -or !(ResolveDnsName $option.Value)) {
                        # failed, add error to return msg
                        $badOptions += $option.Value + " (IPv4->Scope[" + $scope.ScopeId + "]->Policies->" + $policy.Name + ")`n"
                        if (!$failedNames.Contains($option.Value)) {
                            $failedNames.Add($option.Value)
                        }
                    }
                }
            }
        }
    }

    if ($failedNames.Count -gt 0){
        $failedNames.Sort()
        $tempInfo = ""
        foreach ($failedName in $failedNames) {
            $tempInfo += "$failedName`n"
        }
        $issueMsg = [string]::Format($issueMsg, $tempInfo, $badOptions)
        $xrayDiag.ReportIssue($issueMsg, $xrayDiag::IssueType_Error, $effectingUpdates, $resolvingUpdates)
    }
    else {
        # no issue found, no reason to keep DHCP Server export
        Remove-Item $dhcpexport -ErrorAction SilentlyContinue
    }

    return $xrayDiag::ReturnCode_Success
}

# Returns $false if name cannot be resolved
function ResolveDnsName
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [String]
        $DnsName
    )

    # no need to check if IP address
    try {return ($DnsName -match [IPAddress]$DnsName)} catch {}

    $result = Resolve-DnsName -Name $DnsName -Type A -ErrorVariable DnsError -ErrorAction SilentlyContinue

    if($DnsError -or ($result.Count -eq 0)){
        return $false
    }
    foreach($rec in $result) {
        if ($rec.IP4Address) {
            return $true
        }
    }
    return $false
}
#endregion net_dhcpsrv_KB4503857

#region net_802Dot1x_KB4556307
<# 
Component: 802Dot1x
 
 Checks for:
 A post-release issue starting with Feb 2020 updates
 Resolved in 2020.4B and later
 Network indication is skipped when a 802.1x re-auth occurs.
 If account-based VLANs are used, then this may cause connectivity issues
#>
function net_802Dot1x_KB4556307
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [Boolean]
        $offline
    )

    $issueMsg = "
Following 802.1x network adapter (wired or wireless) is in connected state
but has no connectivity:

{0}

You might be hitting an issue affecting wired 802.1x adapters when user logon
triggers a change of VLAN.

Resolution:
Please install following Windows Update (or a later one) to resolve 
this issue:

April 14, 2020—KB4549951 (OS Builds 18362.778 and 18363.778)
https://support.microsoft.com/help/4549951/windows-10-update-kb4549951

 - Addresses an issue that prevents a wired network interface from obtaining a
 new Dynamic Host Configuration Protocol (DHCP) IP address on new subnets and 
 virtual LANs (VLAN) after wired 802.1x re-authentication. The issue occurs if
 you use VLANs that are based on accounts and a VLAN change occurs after a user
 signs in.
"
    # updates (oldest update first), which when installed, may lead to this issue
    $effectingUpdates = @("KB4535996","KB4540673","KB4551762","KB4541335","KB4554364")
    # updates (oldest update first), which when installed, resolve this issue
    $resolvingUpdates = @("KB4549951","KB4550945")

    if($offline) {
        $xrayDiag.LogToFile("Cannot run offline, skipping")
        return $xrayDiag::ReturnCode_Skipped
    }

    # Look for the issue
    $services = Get-Service -Name "dot3svc" -ErrorAction SilentlyContinue

    # issue only occurs with Wired Autoconfig, skip if it's not running
    if(($services.Count -eq 0) -or ($services.Status -ne "Running")) {
        # dot3svc (Wired AutoConfig) not running, nothing to check
        $xrayDiag.LogToFile("Wired AutoConfig (dot3svc) service is not running, nothing to check, skipping")
        return $xrayDiag::ReturnCode_Skipped
    }

    # dot3svc (Wired AutoConfig) is running
    try {
        $hotfixes = (Get-HotFix | Sort-Object -Property InstalledOn -Descending)
        foreach($hotfix in $hotfixes) {
            # look if any of the resolving updates that resolve this issue are installed
            if($hotfix.HotFixID -in $resolvingUpdates) {
                $xrayDiag.LogToFile("A resolving update ({0}) is installed!" -f $hotfix.HotFixID)
                break
            }
            # look if any of the effecting updates are installed
            if($hotfix.HotFixID -in $effectingUpdates) {
                $xrayDiag.LogToFile("An affected update ({0}) is installed!" -f $hotfix.HotFixID)
                # effecting update(s) installed, check for issue
                $netadapters = Get-NetAdapter
                foreach($netadapter in $netadapters) {
                    if(($netadapter.MediaConnectState -eq 1) -and ($netadapter.MediaType -eq "802.3")) { 
                        # adapter in connected state, test connectivity
                        $xrayDiag.LogToFile("Testing adapter [{0}] for issue..." -f $netadapter.Name)
                        $netipconfig = Get-NetIPConfiguration -InterfaceIndex $netadapter.ifIndex
                        # has IP address?
                        if($netipconfig.IPv4Address.count -gt 0) {
                            $xrayDiag.LogToFile("Pinging default gateway...")
                            $result = Test-Connection -ComputerName $netipconfig.IPv4DefaultGateway.NextHop -Count 1 -Quiet 
                            $xrayDiag.LogToFile("Test-Connection returned: {0}" -f $result)
                            if($result -eq $false) {
                                # try again with ping count=4 to avoid false positives
                                $result = Test-Connection -ComputerName $netipconfig.IPv4DefaultGateway.NextHop -Count 4 -Quiet 
                                $xrayDiag.LogToFile("Test-Connection (second try) returned: {0}" -f $result)
                                if($result -eq $false) {
                                    # Issue present
                                    $adapterInfo = "`tName: " + $netadapter.Name + ", IP Address: " + $netipconfig.IPv4Address
                                    $issueMsg = [string]::Format($issueMsg, $adapterInfo)
                                    $xrayDiag.ReportIssue($issueMsg, $xrayDiag::IssueType_Error, $effectingUpdates, $resolvingUpdates)
                                    # reporting one instance of the issue is sufficient
                                    break
                                }
                            }
                        }
                    }
                }
                # run the test once
                break
            }
        }
    }
    catch {
        $xrayDiag.LogToFile($Error[0].Exception)
        return $xrayDiag::ReturnCode_Failed
    }

    return $xrayDiag::ReturnCode_Success
}
#endregion net_802Dot1x_KB4556307

# end: diagnostic functions

Export-ModuleMember -Function * -Variable *