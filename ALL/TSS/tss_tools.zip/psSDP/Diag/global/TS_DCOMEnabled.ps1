﻿#************************************************
# TS_DCOMEnabledk.ps1
# Version 1.0.0
# Date: 03-23-2012
# Author: Jeremy LaBorde - jlaborde
# Description:  Checks to see if DCOM is enabled
#************************************************

. .\DistSvcs_Utils.ps1

Import-LocalizedData -BindingVariable ScriptStrings
Write-DiagProgress -Activity $ScriptStrings.ID_DSI_DistSvcs_RC_Activity -Status $ScriptStrings.ID_DSI_DistSvcs_RC_DCOMEnabledNotice


if( !(Get-EnableDCOM) )
{	AlertKnownIssue "RC_DCOMEnabled" "DCOM Is Not Enabled: http://msdn.microsoft.com/en-us/library/windows/desktop/ms687298(v=vs.85).aspx" "Internal"
} else
{	if( $global:gDebugSDPOn )
	{	Update-DiagRootCause -id "RC_DCOMEnabled" -Detected $false
	}
}
