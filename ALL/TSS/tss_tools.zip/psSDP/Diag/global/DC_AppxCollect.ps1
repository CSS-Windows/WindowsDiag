﻿#************************************************
# DC_AppxCollect.ps1
# Version 1.0
# Date: 2009-2019
# Author: Walter Eder (waltere@microsoft.com)
# Description: Collects AppX additional information.
# Called from: DC_WinStoreMain.ps1
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Write-verbose "$(Get-Date -UFormat "%R:%S") : Start of script DC_AppxCollect.ps1"

"\n\n==================== Starting AppXCollect.ps1 script ====================\n\n" | WriteTo-StdOut
Import-LocalizedData -BindingVariable ScriptStrings

# Registry keys
"Getting Appx Registry Keys" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_AppxRegistryKeys_Title -Status $ScriptStrings.ID_AppxRegistryKeys_Status
$sectionDescription = "Software Registry keys"
$Regkeys = "HKCU\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer"
$OutputFile = $ComputerName + "_reg_AppContainer_HKCU.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "HKCU AppContainer Registry Key" -SectionDescription $sectionDescription

$Regkeys =  "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\AppModel","HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\AppModel"
$OutputFile = $ComputerName + "_reg_AppModel.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "AppModel Registry Key" -SectionDescription $sectionDescription

$Regkeys = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Appx"
$OutputFile = $ComputerName + "_reg_Appx_HKLM.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "HKLM Appx Registry Key" -SectionDescription $sectionDescription

$Regkeys = "HKLM\Software\Policies\Microsoft\Windows\AppX"
$OutputFile = $ComputerName + "_reg_AppxPolicies_HKLM.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "HKLM Appx Policies Registry Key" -SectionDescription $sectionDescription

$Regkeys = "HKLM\Software\Microsoft\Windows\Windows Error Reporting\BrokerUp"
$OutputFile = $ComputerName + "_reg_BrokerUp.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "WER BrokerUp Registry Key" -SectionDescription $sectionDescription

$Regkeys = "HKCU\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel","HKLM\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel"
$OutputFile = $ComputerName + "_reg_LocalSettings_AppModel.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "LocalSettings AppModel Registry Key" -SectionDescription $sectionDescription

$Regkeys = "HKLM\Software\Microsoft\Windows\CurrentVersion\Internet Settings\PluggableProtocols"
$OutputFile = $ComputerName + "_reg_PluggableProtocols_HKLM.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "HKLM PluggableProtocols Registry Key" -SectionDescription $sectionDescription

$Regkeys = "HKLM\Software\Microsoft\Windows\CurrentVersion\WebApplicationHost","HKCU\Software\Microsoft\Windows\CurrentVersion\WebApplicationHost"
$OutputFile = $ComputerName + "_reg_webApplicationHost.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "WebApplicationHost Registry Key" -SectionDescription $sectionDescription

# Saved Directories
"Getting Appx Files" | WriteTo-StdOut
Write-DiagProgress  -Activity $ScriptStrings.ID_AppxFiles_Title -Status $ScriptStrings.ID_AppxFiles_Status
$sectionDescription = "Appx Files"
if(test-path "$env:SystemDrive\ProgramData\Microsoft\Windows\AppRepository")
{
	$DesinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
	Copy-Item "$env:SystemDrive\ProgramData\Microsoft\Windows\AppRepository" -Destination $DesinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
	CompressCollectFiles -filesToCollect $DesinationTempFolder -DestinationFileName "AppRepository.zip" -fileDescription "AppRepository files" -sectionDescription $sectionDescription -Recursive
}

if(test-path "$env:localappdata\Packages\Package.Metadata")
{
	$DesinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
	Copy-Item "$env:localappdata\Packages\Package.Metadata" -Destination $DesinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
	CompressCollectFiles -filesToCollect $DesinationTempFolder -DestinationFileName "PackageMetadata.zip" -fileDescription "PackageMetadata files" -sectionDescription $sectionDescription -Recursive
}


# Permission Data

# Directory Listings
"Getting Appx Directory Listings" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_DirListings_Title -Status $ScriptStrings.ID_DirListings_Status
$sectionDescription = "Appx Directory Listings"
if(test-path "$env:SystemDrive\ProgramFiles\WindowsApps")
{	$OutputFile = $ComputerName + "_DirList_WindowsApps.txt"
	dir "$env:SystemDrive\ProgramFiles\WindowsApps"        >> $OutputFile
	CollectFiles -filesToCollect $OutputFile -fileDescription "WindowsApps Directory Listings" -sectionDescription $sectionDescription
}
if(test-path "$env:windir\ImmersiveControlPanel")
{	$OutputFile = $ComputerName + "_DirList_ImmersiveControlPanel.txt"
	dir "$env:windir\ImmersiveControlPanel"                >> $OutputFile
	CollectFiles -filesToCollect $OutputFile -fileDescription "ImmersiveControlPanel Directory Listings" -sectionDescription $sectionDescription
}
if(test-path "$env:SystemDrive\Program Files\Internet Explorer")
{	$OutputFile = $ComputerName + "_DirList_InternetExplorer.txt"
	dir "$env:SystemDrive\Program Files\Internet Explorer" >> $OutputFile
	CollectFiles -filesToCollect $OutputFile -fileDescription "Internet Explorer Directory Listings" -sectionDescription $sectionDescription
}
if(test-path "$env:SystemDrive\Program Files (x86)\Internet Explorer")
{	$OutputFile = $ComputerName + "_DirList_InternetExplorerx86.txt"
	dir "$env:SystemDrive\Program Files (x86)\Internet Explorer" >> $OutputFile
	CollectFiles -filesToCollect $OutputFile -fileDescription "Internet Explorer(x86) Directory Listings" -sectionDescription $sectionDescription
}
if(test-path "$env:localappdata\Packages")
{	$OutputFile = $ComputerName + "_DirList_LocalAppData.txt"
	dir "$env:localappdata\Packages"                       >> $OutputFile
	CollectFiles -filesToCollect $OutputFile -fileDescription "Local Appdata Packages Directory Listings" -sectionDescription $sectionDescription
}
if(test-path "$env:SystemDrive\WindowApps")
{	$OutputFile = $ComputerName + "_DirList_WindowsAppx.txt"
	dir "$env:SystemDrive\WindowApps"                      >> $OutputFile
	CollectFiles -filesToCollect $OutputFile -fileDescription "SystemDrive WindowApps Directory Listings" -sectionDescription $sectionDescription
}


# Event Logs
"Getting Appx Event Logs" | WriteTo-StdOut
$sectionDescription = "Event Logs"
$EventLogNames = "Microsoft-Windows-AppXDeployment/Operational", "Microsoft-Windows-AppXDeploymentServer/Operational", 
				 "Microsoft-Windows-AppXDeploymentServer/Restricted"
Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription

$EventLogNames = "Microsoft-Windows-AppxPackaging/Operational"
Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription

$EventLogNames = "Microsoft-Windows-AppModel-Runtime/Admin"
Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription

$EventLogNames = "Microsoft-Windows-All-User-Install-Agent/Admin"
Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription

$EventLogNames = "Microsoft-Windows-AppHost/Admin"
Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription 

$EventLogNames = "Microsoft-Windows-CodeIntegrity/Operational"
Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription

$EventLogNames = "Microsoft-Windows-ApplicationResourceManagementSystem/Operational"
Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription

$EventLogNames = "Microsoft-Windows-SettingSync/Operational", "Microsoft-Windows-SettingSync/Debug"
Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription

$EventLogNames = "Microsoft-Windows-PackageStateRoaming"
Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription


# Appx PowerShell Commandlet output
"Getting Appx Data" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_AppxDataLogs_Title -Status $ScriptStrings.ID_AppxDataLogs_Status

$sectionDescription = "Appx Data"
$OutputFile = $ComputerName + "_Inventory.txt"
Get-AppxPackage | fl | Out-File -FilePath $OutputFile -append
CollectFiles -filesToCollect $OutputFile -fileDescription "Appx Package Inventory" -sectionDescription $sectionDescription
$OutputFile = $ComputerName + "_AppxLog.txt"
Get-AppxLog | fl | Out-File -FilePath $OutputFile -append 
CollectFiles -filesToCollect $OutputFile -fileDescription "Appx Log" -sectionDescription $sectionDescription


Write-verbose "$(Get-Date -UFormat "%R:%S") :   end of script DC_AppxCollect.ps1"