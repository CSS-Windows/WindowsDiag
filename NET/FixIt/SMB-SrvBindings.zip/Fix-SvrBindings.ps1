﻿#requires -RunAsAdministrator
#requires -Version 5
#requires -Modules SmbShare,NetAdapter

<# 
    .SYNOPSIS

    Repairs missing ms_server (SMB Server) bindings for network adapters. Fixes LanmanServer (SMB Server), LanmanWorkstation (SMB Client), NetBT (NetBIOS over TCP/IP) binding balance.

    .DESCRIPTION

    Fix-SvrBinding (the "script") was built in association with KBxxx, which is an issue discovered after the adapter binding for 
    the SMB subsystem in Windows was moved to a new API. The RASMAN (VPN) subsystem has not been migrated, which causes unbalanced
    bindings in the Linkage registry keys for the following services:

       - LanmanServer (Server service, which is the SMB server in Windows)
       - LanmanWorkstation (LanmanWorkstation service, which is the SMB client in Windows)
       - NetBT (NetBIOS over TCP/IP driver, which is needed for legacy SMBv1 over NetBIOS support)

    The script performs the following checks and repairs, when an issue is found on a Windows system.

       Fix 1:
       - Finds network adapter bindings where ms_server (SMB Server) is bound/installed and Enabled == True
       - Compares the list of ms_server bound adapters to the bindings in the Linkage registry keys using the adapter's DeviceID GUID
       - Bindings are automatically generated and added to the registry for any network adapter missing bindings
       - The Server service is then restarted; unless, the noSvrRestart parameter was set when the script was run
       - This fixes currently installed network adapters that should be bound to ms_server, but are not binding at boot due to the bug

       Fix 2:
       - The bindings in each Linkage registry key are scanned and compared
       - Any missing bindings are added to the appropriate Linkage registry value
       - This fix balances the Linkage bindings to prevent future network adapter additions or reinstallations from experiencing the binding bug

    Please note that this does not fix the fundamental code defect in Windows. The code defect will be addressed in a future update to Windows.
    The script is meant to restore functionality to Windows systems affected by the issue.

    IMPORTANT NOTE:

    The script needs to be run after installing a new VPN adapter, or any new VPN-based software that installs a VPN virtual adapter.
    The code defect is caused by the VPN subsystem (RASMAN) using a legacy set of APIs that does not create all the necessary
    bindings needed to bind a network adapter to SMB server. The issue could, therefore, reappear until the code defect is patched.

    .PARAMETER noSvrRestart
    
    Prevents the Server service (LanmanServer, or the SMB Server service) from being restarted after a network adapter bindings is added. The default is FALSE, when the parameter is not present, and the Server service is restarted as a result.

    .EXAMPLE

     .\Fix-Fix-SvrBindings.ps1

    Runs the script normally. The Server service will be restarted if network adapter bindings are added.
    
    .EXAMPLE

     .\Fix-Fix-SvrBindings.ps1 -noSvrRestart

    Runs the script, but will prevent the Server service from being restarted if a network adapter bindings is added.

    .INPUTS

    None.

    .OUTPUTS

    A log file is created on the user desktop.

#>

[CmdletBinding()]
param (
    # The Server service is restarted, by default, when an adapter binding is added/fixed. 
    # Adding this parameter will prevent the Server service restart. 
    # The Server service must be manually restarted, or the system rebooted, for adapter binding changes to take effect when this parameter is set.
    [switch]$noSvrRestart
)


############################
###                      ###
###     DECLARATIONS     ###
###                      ###
############################
#region

# set logging options
$script:dataPath = "$env:USERPROFILE\Desktop"
$script:logName = "$env:ComputerName`_SvrBinding_$(Get-Date -format "yyyyMMdd_HHmmss")`.log"

# the three registry paths to search
[string[]]$linkagePaths =   'HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Linkage',
                            'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Linkage',
                            'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Linkage'

# initial order and list of linkage values to test against
[string[]]$testOrder = "Bind","Export","Route"

#endregion

############################
###                      ###
###       FUNCTIONS      ###
###                      ###
############################
#region 

# FUNCTION: Get-TimeStamp
# PURPOSE:  Returns a timestamp string

function Get-TimeStamp 
{
    return "$(Get-Date -format "yyyyMMdd_HHmmss_ffff")"
} # end Get-TimeStamp


# FUNCTION: Write-Log
# PURPOSE:  Writes script information to a log file and to the screen when -Verbose is set.

function Write-Log {
    param ([string]$text, [switch]$tee = $false, [string]$foreColor = $null)

    $foreColors = "Black","Blue","Cyan","DarkBlue","DarkCyan","DarkGray","DarkGreen","DarkMagenta","DarkRed","DarkYellow","Gray","Green","Magenta","Red","White","Yellow"

    # check the log file, create if missing
    $isPath = Test-Path "$script:dataPath\$script:logName"
    if (!$isPath) {
        "$(Get-TimeStamp): Log started" | Out-File "$script:dataPath\$script:logName" -Force
        "$(Get-TimeStamp): Local log file path: $("$script:dataPath\$script:logName")" | Out-File "$script:dataPath\$script:logName" -Force
        Write-Verbose "Local log file path: $("$script:dataPath\$script:logName")"
    }
    
    # write to log
    "$(Get-TimeStamp): $text" | Out-File "$script:dataPath\$script:logName" -Append

    # write text verbosely
    Write-Verbose $text

    if ($tee)
    {
        # make sure the foreground color is valid
        if ($foreColors -contains $foreColor -and $foreColor)
        {
            Write-Host -ForegroundColor $foreColor $text
        } else {
            Write-Host $text
        }        
    }
} # end Write-Log


# FUNCTION: Update-LinkBinding
# PURPOSE:  Updates a Linkage binding list, given a path path, list name (Bind, Export, Route), and the binding(s) to add.

function Update-LinkBinding
{
    param ( [string]$regPath,
            [string[]]$arrAdd, 
            [string]$listName)
    
    Write-Log "Updating linakge binding:`nPath: $regPath`nAdditions: $($arrAdd | Out-String)`nList: $listName"
    
    # get the route list
    [string[]]$routeList = (Get-ItemProperty -Path $regPath -Name $listName)."$listName"

    foreach ($strAdd in $arrAdd)
    {
        # update the string[]
        $routeList += $strAdd
    }

    # update the registry
    try {
        Set-ItemProperty -Path $regPath -Name $listName -Value $routeList -ErrorAction Stop    
    }
    catch {
        Write-Log "ERROR: Could not update $regPath\$listName`: $($Error[0].ToString())"
        return $false
    }

    
    # check that the add was successful
    $routeList = (Get-ItemProperty -Path $regPath -Name $listName)."$listName"
    if ($routeList -contains $strAdd)
    {
        # hurray, it worked!
        Write-Log "Updates were successful."
        return $true
    } else {
        # oops, something done broke
        Write-Log "Updates failed for an unknown reason."
        return $false
    }

    # if we get here then something went horribly wrong and false is returned
    return $false
} #end Update-LinkBinding


# FUNCTION: Add-NetBindLink
# PURPOSE:  Adds network adapter bindings to a Bind linkage list, give the Linkage reg path, adapter GUID, and list name (which should be Bind)
function Add-NetBindLink
{
    param ($regPath, $guid, $listName)
    
    Write-Log "Building new bindings for $guid in $regPath\$listName`."

    # get the service
    $serviceName = $regPath.Split('\')[-2]

    if ($serviceName -eq "NetBT")
    {
        [string[]]$arrAdd = "\Device\Tcpip6_$guid",
                            "\Device\Tcpip_$guid"
    } else {
        [string[]]$arrAdd = "\Device\Tcpip_$guid",
                            "\Device\NetBT_Tcpip_$guid",
                            "\Device\Tcpip6_$guid",
                            "\Device\NetBT_Tcpip6_$guid"
    }
    
    return (Update-LinkBinding -regPath $regPath -arrAdd $arrAdd -listName $listName)
} #end Add-NetBindLink


# FUNCTION: Add-NetExportLink
# PURPOSE:  Adds network adapter bindings to a Bind linkage list, give the Linkage reg path, adapter GUID, and list name (which should be Export)

function Add-NetExportLink
{
    param ($regPath, $guid, $listName)

    Write-Log "Building new bindings for $guid in $regPath\$listName`."

    # get the service
    $serviceName = $regPath.Split('\')[-2]

    if ($serviceName -eq "NetBT")
    {
        [string[]]$arrAdd = "\Device\$serviceName`_Tcpip6_$guid",
                            "\Device\$serviceName`_Tcpip_$guid"
    } else {
        [string[]]$arrAdd = "\Device\$serviceName`_Tcpip_$guid",
                            "\Device\$serviceName`_NetBT_Tcpip_$guid",
                            "\Device\$serviceName`_Tcpip6_$guid",
                            "\Device\$serviceName`_NetBT_Tcpip6_$guid"
    }
    
    return (Update-LinkBinding -regPath $regPath -arrAdd $arrAdd -listName $listName)
} #end Add-NetExportLink


# FUNCTION: Add-NetRouteLink
# PURPOSE:  Adds network adapter bindings to a Bind linkage list, give the Linkage reg path, adapter GUID, and list name (which should be Route)

function Add-NetRouteLink
{
    param ($regPath, $guid, $listName)

    Write-Log "Building new bindings for $guid in $regPath\$listName`."

    # get the service
    $serviceName = $regPath.Split('\')[-2]

    if ($serviceName -eq "NetBT")
    {
        [string[]]$arrAdd = "`"Tcpip6`" `"$guid`"",
                            "`"Tcpip`" `"$guid`""
    } else {
        [string[]]$arrAdd = "`"Tcpip`" `"$guid`"",
                            "`"NetBT`" `"Tcpip`" `"$guid`"",
                            "`"Tcpip6`" `"$guid`"",
                            "`"NetBT`" `"Tcpip6`" `"$guid`""
    }
    
    return (Update-LinkBinding -regPath $regPath -arrAdd $arrAdd -listName $listName)
} #end Add-NetRouteLink


# FUNCTION: Get-Bind2Obj 
# PURPOSE:  Converts the Bind linkage lists into a custome set of PSObjects used to compare and update linkage lists

function Get-Bind2Obj 
{
    param ($bindObj)

    $results = @()

    foreach ($obj in $bindObj)
    {
        if ($obj -match '_')
        {
            $guid = $obj.Split('_')[-1]
            $provider = $obj.Split('\')[-1].Split('{')[0]
            $comparand = "$provider$guid"
        } else {
            $guid = $provider = $comparand = $obj.Split('\')[-1]
        }

        <#
            Each object contains the structure needed to compare, update, or diagnose binding issues.

            List = The list name where the object was created from
            FullName = The unmodified binding string
            Guid = The adapter DeviceID Guid associated with the binding, or the network provider name when no GUID is listed
            Proiver = Protocol(s) in the binding, in a common format since each list has a unique format. _<prot>[_<prot>]_  Examples: _Tcpip_, _NetBT_Tcpip6_
            Comparand = A combination of provider and GUID that makes the binding unique, but in a common format: <provider><guid>, NetbiosSmb
        #>
        
        $tmpObj = [PSCustomObject]@{
            List = "Bind"
            FullName = $obj
            Guid = $guid
            Provider = $provider
            Comparand = $comparand
        }
        $results  += $tmpObj
    }

    return $results 
} #end Get-Bind2Obj 


# FUNCTION: Get-Export2Obj 
# PURPOSE:  Converts the Export linkage lists into a custome set of PSObjects used to compare and update linkage lists

function Get-Export2Obj 
{
    param ($exportObj,$linkName)

    $results = @()

    foreach ($obj in $exportObj)
    {
        if ($obj -notmatch 'NetbiosSmb')
        {
            $guid = $obj.Split('_')[-1]
            
            switch -Regex ($obj)
            {
                "^.*NetBT.*$" {
                    $provider = $obj.Split('\')[-1].Split('{')[0] -replace "NetBT_",""        
                }

                "^.*LanmanServer.*$" {
                    $provider = $obj.Split('\')[-1].Split('{')[0] -replace "LanmanServer_",""        
                }

                "^.*LanmanWorkstation_.*$" {
                    $provider = $obj.Split('\')[-1].Split('{')[0] -replace "LanmanWorkstation_",""        
                }

                default {
                    $provider = $obj.Split('\')[-1].Split('{')[0]
                }
            }
            
            $comparand = "$provider$guid"
        } else {
            switch -Regex ($obj)
            {
                "^.*NetBT.*$" {
                    $guid = $provider = $comparand = $obj.Split('\')[-1].Split('{')[0] -replace "NetBT_",""        
                }

                "^.*LanmanServer.*$" {
                    $guid = $provider = $comparand = $obj.Split('\')[-1].Split('{')[0] -replace "LanmanServer_",""        
                }

                "^.*LanmanWorkstation_.*$" {
                    $guid = $provider = $comparand = $obj.Split('\')[-1].Split('{')[0] -replace "LanmanWorkstation_",""        
                }

                default {
                    $provider = $obj.Split('\')[-1].Split('{')[0]
                }
            }
        }

        <#
            Each object contains the structure needed to compare, update, or diagnose binding issues.

            List = The list name where the object was created from
            FullName = The unmodified binding string
            Guid = The adapter DeviceID Guid associated with the binding, or the network provider name when no GUID is listed
            Proiver = Protocol(s) in the binding, in a common format since each list has a unique format. _<prot>[_<prot>]_  Examples: _Tcpip_, _NetBT_Tcpip6_
            Comparand = A combination of provider and GUID that makes the binding unique, but in a common format: <provider><guid>, NetbiosSmb
        #>

        $tmpObj = [PSCustomObject]@{
            List = "Export"
            FullName = $obj
            Guid = $guid
            Provider = $provider
            Comparand = $comparand
        }
        $results += $tmpObj
    }

    return $results 
} #end Get-Export2Obj


# FUNCTION: Get-Route2Obj 
# PURPOSE:  Converts the Route linkage lists into a custome set of PSObjects used to compare and update linkage lists

function Get-Route2Obj 
{
    param ($routeObj)

    # stores the resulting object array
    $results = @()

    # loop through each Route binding
    foreach ($obj in $routeObj)
    {
        # bindings with a { have a GUID, and need parsing
        if ($obj -match '{')
        {
            # the last object is the DeviceID GUID
            $guid = $obj.Split(' ')[-1].Trim('"')
            $values = $obj.Split(' ')

            # generate a common provider string
            $provider = ($values | Where-Object {$_ -notmatch $guid} | ForEach-Object {$_.Trim('"')}) -join "_"
            $provider = "$provider`_"

            # create the comparand
            $comparand = ($obj.Split(' ') | ForEach-Object {$_.Trim('"')}) -join '_'

        } else {
            $guid = $provider = $comparand = $obj.Trim('"')
        }

        <#
            Each object contains the structure needed to compare, update, or diagnose binding issues.

            List = The list name where the object was created from
            FullName = The unmodified binding string
            Guid = The adapter DeviceID Guid associated with the binding, or the network provider name when no GUID is listed
            Proiver = Protocol(s) in the binding, in a common format since each list has a unique format. _<prot>[_<prot>]_  Examples: _Tcpip_, _NetBT_Tcpip6_
            Comparand = A combination of provider and GUID that makes the binding unique, but in a common format: <provider><guid>, NetbiosSmb
        #>

        $tmpObj = [PSCustomObject]@{
            List = "Route"
            FullName = $obj
            Guid = $guid
            Provider = $provider
            Comparand = $comparand
        }
        $results += $tmpObj
    }

    # return the array of objects
    return $results 
} #end Get-Route2Obj


# FUNCTION: Add-BindLinkage
# PURPOSE:  Adds a missing binding to a Bind Linkage list, given a path and a difference object from Get-Link

function Add-BindLinkage
{
    param ($regPath, $diffObj)

    ## generate the string to add
    if ($diffObj.MissingObj.Provider -eq 'NetbiosSmb')
    {
        $strAdd = "\Device\NetbiosSmb"
    } else {
        $strAdd = "\Device\$($diffObj.MissingObj.Comparand)"
    }
    
    # update the binding and return the result
    return (Update-LinkBinding -regPath $regPath -arrAdd $strAdd -listName "$($diffObj.MissingFrom)")
} #end Add-BindLinkage


# FUNCTION: Add-ExportLinkage
# PURPOSE:  Adds a missing binding to a Export Linkage list, given a path and a difference object from Get-Link

function Add-ExportLinkage
{
    param ($regPath, $diffObj)

    ## generate the string to add
    # get the service
    $serviceName = $regPath.Split('\')[-2]

    if ($diffObj.MissingObj.Provider -eq 'NetbiosSmb')
    {
        $strAdd = "\Device\$serviceName`_NetbiosSmb"
    } else {
        $strAdd = "\Device\$serviceName`_$($diffObj.MissingObj.Comparand)"
    }
    
    # update the binding and return the result
    return (Update-LinkBinding -regPath $regPath -arrAdd $strAdd -listName "$($diffObj.MissingFrom)")
} #end Add-ExportLinkage


# FUNCTION: Add-RouteLinkage
# PURPOSE:  Adds a missing binding to a Route Linkage list, given a path and a difference object from Get-Link

function Add-RouteLinkage
{
    param ($regPath, $diffObj)

    ## generate the string to add
    if ($diffObj.MissingObj.Provider -eq 'NetbiosSmb')
    {
        $strAdd = '"NetbiosSmb"'
    } else {
        $tmpProvider = ($diffObj.MissingObj.Provider.Split('_') | Where-Object {$_ -ne ""} | ForEach-Object {"`"$_`""}) -join ' '
        $strAdd = "$tmpProvider `"$($diffObj.MissingObj.Guid)`""
        $strAdd = $strAdd.Trim(" ")
    }

    # update the binding and return the result
    return (Update-LinkBinding -regPath $regPath -arrAdd $strAdd -listName "$($diffObj.MissingFrom)")
} #end Add-RouteLinkage


# FUNCTION: Get-Link 
# PURPOSE:  Gets a difference object for a Linkage list, given a reg path to a Linkage key.

function Get-Link 
{
    param ($link)

    # get the type of linkage value
    $linkName = $link | Get-Member -Type NoteProperty | Where-Object Name -notmatch "^PS.*$" | ForEach-Object {$_.Name}
    
    # call the appropriate Get-Bind2xxxxx function and return the result
    switch ($linkName) {
        "bind" {  
            # parse the bind list
            return (Get-Bind2Obj $link."$linkName" $linkName)

            break
        }

        "Export" {
            # parse the export list
            return (Get-Export2Obj $link."$linkName" $linkName)

            break
        }

        "Route" {
            # parse the route list
            return (Get-Route2Obj $link."$linkName" $linkName)

            break
        }
        default {
            Write-Host "Unknown link type: $linkName" 
            return $false
        }
    }

    # just in case something went wrong
    return $false
} #end Get-Link 


# FUNCTION: Get-ListDiff
# PURPOSE:  Compares link1 to link2, and returns a list of missing bindings that are not in link2 but are in link1. Accepts two difference objects from Get-Link.

function Get-ListDiff
{
    param ($link1, $link2)

    # convert the raw value to objects
    $list1 = Get-Link $link1
    $list2 = Get-Link $link2

    # stores a list of differences
    $diffList = @()

    # search through each value in list1 and see if it exists in list 2
    foreach ($item in $list1)
    {
        if ($list2.Comparand -notcontains $item.Comparand)
        {
            # add to diffList
            $tmpObj = [PSCustomObject]@{
                MissingFrom = $($list2[0].List)
                MissingObj = $item
            }

            $diffList += $tmpObj
        }
    }

    # return the diffList, if populated; otherwise, return $false
    if ($diffList)
    {
        #Write-Host "`nSource list:$($list2 | Format-List | Out-String)"
        return $diffList
    } else {
        return $false
    }
} #end Get-ListDiff

#endregion FUNCTIONS


############################
###                      ###
###         MAIN         ###
###                      ###
############################

##### NIC BINDING #####
#region

# get all net adapters, excluding adapters that are not bound to ms_server (Enabled = False)
$svrBingings = Get-NetAdapterBinding -ComponentID ms_server | Where-Object Enabled
$srvNetAdptrs =  Get-NetAdapter | Where-Object {$svrBingings.InterfaceAlias -contains $_.InterfaceAlias}
Write-Log "Net adapters bound to ms_server:`n$(($srvNetAdptrs | Sort-Object | Select-Object Name,InterfaceDescription,InterfaceAlias,InterfaceIndex,DeviceID) | Out-String)`n"

# get all net adapters, excluding adapters that are not bound to ms_msclient (Enabled = False). This is currently for monitoring purposes only.
$cliBingings = Get-NetAdapterBinding -ComponentID ms_msclient | Where-Object Enabled
$cliNetAdptrs =  Get-NetAdapter | Where-Object {$cliBingings.InterfaceAlias -contains $_.InterfaceAlias}
Write-Log "Net adapters bound to ms_msclient:`n$(($cliNetAdptrs | Sort-Object | Select-Object Name,InterfaceDescription,InterfaceAlias,InterfaceIndex,DeviceID) | Out-String)`n"

Write-Log "Checking bindings for net adapters." -tee -foreColor Green

# monitors whether a link was updated. Needed for logging and restarting Server.
$wasNicBindUpdated = $false

# lopp through each Linkage key location
foreach ($link in $linkagePaths)
{
    Write-Log "Testing NICs against: $link" -foreColor Yellow -tee

    # backup the reg value
    $backupReg = Get-Item $link
    $serviceName = $link.Split('\')[-2]
    $backupTimeStamp = Get-TimeStamp
    reg export $($backupReg.Name) "$PSScriptRoot\$serviceName`_$backupTimeStamp`.reg" /y | Out-Null

    # verify that the backup completed in a manner that is compatible with non-English localizations of Windows
    $isRegBackup = Get-Item "$PSScriptRoot\$serviceName`_$backupTimeStamp`.reg" -EA SilentlyContinue
    #create a regex pattern for the link. With -replace, the matching pattern is a regex expression, the replacement string is literal, so -replace '\\','\\' replaces a single backslash (\) with the double backslash (\\) needed for the select-string match later on
    [regex]$regLink = "^\[$(($link -replace "HKLM:", "HKEY_LOCAL_MACHINE") -replace '\\','\\')\]$"

    # make sure the file exists
    if (-not $isRegBackup)
    {
        Write-Log "CRITICAL: Failed to backup the $serviceName registry key." -tee -foreColor Red
        exit
    } 
    # 0-2 bytes is the size of an empty TXT doc, fail if it seems empty
    elseif ($isRegBackup.Length -le 2) 
    {
        Write-Log "CRITICAL: Failed to write data to the $serviceName registry file: $PSScriptRoot\$serviceName`_$backupTimeStamp`.reg" -tee -foreColor Red
        exit
    }
    # make sure the right link is in the content of the reg file. Key names are not localized so this is a safe operation.
    elseif (-NOT (Get-Content $isRegBackup | Select-String $regLink))
    {
        Write-Log "CRITICAL: Could not validate the $serviceName registry backup: $PSScriptRoot\$serviceName`_$backupTimeStamp`.reg" -tee -foreColor Red
        exit
    }
    

    # loop through each list in the testOrder
    foreach ($list in $testOrder)
    {
        # get the linkage list        
        $bndLinkage = Get-ItemProperty -Path $link -Name $list
        
        Write-Log "All bindings for $list`:`n`r$(($bndLinkage."$list" | Sort-Object) -join "`n`r")`n`r"

        # loop through list of adapters to find missing bindings
        foreach ($adapter in $srvNetAdptrs)
        {
            Write-Log "Checking bindings for $($adapter.Name) `n`rDescription: $($adapter.InterfaceDescription) `n`rGUID: $($adapter.DeviceID) `n`rStatus: $($adapter.Status)"
            
            # this looks for the DeviceID GUID in the linkage list
            $tmpBnd = $bndLinkage."$list" | Where-Object {$_ -match $adapter.DeviceID}

            # no results means the DeviceID GUID is missing and needs to be added...
            if (-not $tmpBnd)
            {
                Write-Log "$($adapter.Name) was not found on the $serviceName $list list.`n" -tee -foreColor Red

                # this switch is used to make the correct function call, based on which linkage list is being tested
                switch ($list)
                {
                    "Export" {
                        Write-Log "Adding Export link(s) for $($adapter.Name)."
                        $result = Add-NetExportLink -regPath $link -guid "$($adapter.DeviceID)" -listName $list

                        break
                    }

                    "Route" {
                        Write-Log "Adding Route link(s) for $($adapter.Name)."
                        $result = Add-NetRouteLink -regPath $link -guid "$($adapter.DeviceID)" -listName $list

                        break
                    }

                    "Bind" {
                        Write-Log "Adding Bind link(s) for $($adapter.Name)."
                        $result = Add-NetBindLink -regPath $link -guid "$($adapter.DeviceID)" -listName $list

                        break
                    }

                    default { Write-Log "`nSomething didn't work right...time to bail."; exit }
                } #end switch list

                # writes logging based on the result of adding the missing binding
                if ($result)
                {
                    Write-Log "Successfully added link(s) for $($adapter.Name) in $list" -tee -foreColor Green
                    # set wasNicBindUpdated to true so the Server service can be restarted
                    $wasNicBindUpdated = $true
                } else {
                    Write-Log "ERROR: Could not add link(s) for $($adapter.Name) in $list." -tee -foreColor Red
                }
            # ... a tmpBnd result means the binding is on the list
            } else
            {
                Write-Log "$($adapter.Name) was found on the $serviceName $list list.`n"
            } #end if (-not $tmpBnd)
        } #end adapter-srvNetAdptrs foreach
    } #end list-TestOrder foreach
} #end link-Linkage foreach

# check whether the Server service needs to be restarted
if ($wasNicBindUpdated)
{
    # test whether noSvrRestart was set and log accordingly
    if (-not $noSvrRestart)
    {
        Write-Log "Restarting the Server service."
        Restart-Service LanmanServer -Force
    } else {
        Write-Log "`nnoSvrRestart was set from the command line and a network adapter binding was added. The Server service was not restarted.`n`nThe server service must be manually restarted, or the system rebooted, for the fix to take effect.`n`n" -tee -foreColor Yellow
    }
} else {
    Write-Log "There were no missing network adapter bindings found - no modifications were necessary." -tee -foreColor Green
}
#endregion


##### RESYNC LINKAGE #####
#region

### make sure all the linkage bindings are synced ###

Write-Log "Testing whether the linkage lists are balanced." -tee -foreColor Yellow

# was a link updated? needed for logging purposes. A reboot is not needed after linkage bindings are balanced.
[bool]$wasLinkUpdated = $false

# loop through all Linkage paths
foreach ($link in $linkagePaths)
{
    Write-Log "`nValidating linkage lists for: $link" -ForegroundColor Green
    
    # loop throug the three binding lists
    foreach ($list in $testOrder)
    {
        #Write-Host "`nTest order:`n$($testOrder | fl | out-string)"
        for($i = 1; $i -lt $testOrder.Count; $i++)
        {
            # get the linkage values of the first list in testOrder, and then either the second or last list
            $sourceList = Get-ItemProperty -Path $link -Name $list
            $destList = Get-ItemProperty -Path $link -Name $testOrder[$i]

            Write-Log "`nComparing $list to $($testOrder[$i])"

            # look for differences in the two lists
            $difference = Get-ListDiff $sourceList $destList

            # add missing bindings when differences are found
            if ($difference)
            {
                Write-Log "`nThe following differences between $list and $($testOrder[$i]) were found:`n$($difference | Format-List | Out-String)" -tee

                # there could be more than one difference, so loop through all of them
                foreach ($diff in $difference)
                {
                    # call the appropriae function to add the missing binding, bases on the MissingFrom value in the difference object
                    switch ($diff.MissingFrom)
                    {
                        "Export" {
                            Write-Log "Updating Export link."
                            $result = Add-ExportLinkage $link $diff

                            break
                        }

                        "Route" {
                            Write-Log "Updating Route link."
                            $result = Add-RouteLinkage $link $diff

                            break
                        }

                        "Bind" {
                            Write-Log "Updating Bind link."
                            $result = Add-BindLinkage $link $diff

                            break
                        }

                        default { Write-Log "`nSomething didn't work right...time to bail."; exit }
                    } #end switch ($diff.MissingFrom)

                    # log based on results
                    if ($result)
                    {
                        Write-Log "Updated $($diff.MissingFrom) link successfully." -tee -foreColor Green
                        $wasLinkUpdated = $true
                    } else {
                        Write-Log "ERROR: Updating $($diff.MissingFrom) link failed." -tee -foreColor Red
                    }
                } #end foreach ($diff in $difference)
            } else {
                Write-Log "`nNo differences between $list and $($testOrder[$i]) were found"
            }
        } #end for($i = 1; $i -lt $testOrder.Count; $i++)

        ## Rotate the test order.
        ## This algorithm modifies the testOrder so that all linkage list combinations for each Linkage key is tested without duplication.
        # put the middle list into the first (0th) position in tmpTestOrder
        [string[]]$tmpTestOrder = $testOrder[1]
        
        # this loop puts the last testOrder item second and the first testOrder time last in the tmpTestOrder array
        for($i = 2; $i -le $testOrder.Count; $i++)
        {
            if ($i -eq $testOrder.Count)
            {
                $x = 0
            } else {
                $x = $i
            }

            $tmpTestOrder += $testOrder[$x]
        }

        # make tmpTestOrder the new testOrder
        $testOrder = $tmpTestOrder

        #set tmpTestOrder to null
        $tmpTestOrder = $null
    } #end foreach ($list in $testOrder)
} #end foreach ($link in $linkagePaths)

# log to console that there were no binding issues if wasLinkUpdated is still false
if (-not $wasLinkUpdated)
{
    Write-Log "System linkage is balanced - no modifications were necessary." -tee -foreColor Green
}

#endregion

# New final step. 
# We use PowerShell to "wiggle" the binding. RS2 seems to lose the binding on reboot unless PowerShell is used to disable/enable the binding.
# This code is run only when there was a need to fix a NIC binding, and after everything has been balanced/fixed.
if ($wasNicBindUpdated)
{
    Write-Log "Resetting the ms_server bindings with PowerShell to ensure the changes work after a reboot."
    
    # loop through list of adapters to find missing bindings
    foreach ($adapter in $srvNetAdptrs)
    {
        Disable-NetAdapterBinding -Name $($adapter.Name) -ComponentID ms_server -PassThru | Out-String | Write-Log
        Enable-NetAdapterBinding -Name $($adapter.Name) -ComponentID ms_server -PassThru | Out-String | Write-Log
    }
}

Write-Log "Please upload $script:dataPath\$script:logName to Microsoft for analysis." -tee -foreColor Yellow