<# last edit by: waltere 2019-02-03
   File Name: Arrange-SDPFolders.ps1
   Objective: This script organizes output from SDP into folders per computer name.
   supplied by Willy Moselhy (IBS) <v-waalmo@microsoft.com>
#>

# Load Common Library
#. ./utils_common_functions.ps1

<#
.SYNOPSIS
This script organizes output from SDP into folders per computer name.
and moves all files in folders back to the root of the SDP when using switch -Undo.

SYNTAX: .\Arrange-SDPFolders.ps1 -SDPPath [full-path-to-expanded-SDP-report] [ -HostMode -Undo ]

.DESCRIPTION
The script is used when a SDP report is used to collect data from multiple servers, like from a failover cluster.
When running, it will move the files into separate folders by computer name. It will also place RFL output into its own folder.

The -Undo switch can be used when you need to bring back the SDP files to their original state.
When you run -Undo, it will move all files in subfolders back to the root of the SDP and delete the folders afterwards.

Note: I recommend running RFLcheck before running this add-on for best results. 

If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

.PARAMETER Undo
    This switch will undo the folder grouping.
	The script moves all files in folders back to the root of the SDP.
	
.PARAMETER HostMode
    This tells the logging functions to show logging on the screen

.PARAMETER ScriptMode
    This  tells the logging functions to show logging in log file _Arrange-SDPFolders.log
	
.EXAMPLE
	 \\localhost\ToolsShare\rfl\Arrange-SDPFolders.ps1 -SDPPath \\MyPC\temp\SDPs\ClusterReports -HostMode
	 This command will arrange the files in \\MyPC\temp\SDPs\ClusterReports by computer name and RFL folder
	 It will also show detailed output in the console when switch -HostMode is supplied.

.EXAMPLE
	 \\localhost\ToolsShare\rfl\ArrangeSDPFolders.ps1 -Undo -SDPPath \\MyPC\temp\SDPs\ClusterReports -HostMode
	 This command will move files in subfolders back to \\MyPC\temp\SDPs\ClusterReports by computer name and RFL folder. 
	 It will also show detailed output in the console when switch -HostMode is supplied.

.LINK
	 \ \localhost\ToolsShare\rfl\Arrange-SDPFolders.ps1
	v-waalmo@microsoft.com ; waltere@microsoft.com
#>

[CmdletBinding()]
PARAM (
	# Path to SDP result folder containing !PStatSum_*.txt and other SDP analysis files
	[Parameter(Mandatory = $true,Position=0,HelpMessage='Choose a writable SDP folder location, i.e. C:\SR\SDP-report\ ')]
	[string] $SDPPath,

	[switch]$Undo		= $false, # This will undo the folder grouping
	[switch]$HostMode   = $true,  # This tells the logging functions to show logging on the screen
	[switch]$ScriptMode = $false, # This tells the logging functions to show logging in log file _Arrange-SDPFolders.log
	[switch]$UseExitCode= $true,  # This will cause the script to close after the error is logged if an error occurs.
	[String]$OSVersion			  # will be derived by parent/invoking RFLcheck script 
)


BEGIN {
    # This saves the starting ErrorActionPreference and then sets it to 'Stop'.
		$startErrorActionPreference = $errorActionPreference
		$errorActionPreference = 'Stop'
    # This gets the current path and name of the script.
		$invocation = (Get-Variable MyInvocation).Value
		$scriptPath = Split-Path $invocation.MyCommand.Path
		$scriptName = $invocation.MyCommand.Name
    #Write-Host "Running `"$scriptPath\$scriptName`"..." -BackgroundColor Black -ForegroundColor Green
	
	Set-Variable -Name ErrorMsg -Scope Script -Force
	[string]$Script:ErrorMsg=""
	### Trail SDPPath with \ and allow path with space character
		if ($SDPPath.EndsWith("\")){$SDPPath="$SDPPath"}
		else {$SDPPath="$SDPPath" +"\"}
		If (-NOT (Test-Path $SDPPath -PathType 'Container')){Throw "$($SDPPath) is not a valid folder"}

	#region: ###### customization section of script, logging configuration ########################
		$VerMa="1"
		$VerMi="02"
		#$ErrorActionPreference = "Continue" #"Stop"
		$RFLpath = "\\localhost\ToolsShare\rfl\"
		$LogLevel = 0
		$Stats=0
		$StatsServerPath="\\waltere-vdi.europe.corp.microsoft.com\netpod\tools\RFL\"
		$CheckDate = (Get-Date -UFormat "%Y-%m-%d_%R-%S").Replace(":","-")
		$CountInvFil = $StatsServerPath +'countArrFolder.dat'
		$CountInvFil2 = $CountInvFil +'.us'
		$LogPath = $SDPPath + "_" + $scriptName + ".log"
		$ErrorThrown = $null
	#endregion: ###### customization section
	
	If ($Stats) { #increment at start of script
	  ($j=[int32](Get-Content $CountInvFil -ErrorAction SilentlyContinue)) |out-null
	  (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
	  }
	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}
	

	#region: Logging Functions 
	function WriteLine ([string]$line,[string]$ForegroundColor, [switch]$NoNewLine){
		# SYNOPSIS:  writes the actual output - used by other Logging Functions
        if($Script:ScriptMode){
            if($NoNewLine) {
                $Script:Trace += "$line"
            }
            else {
                $Script:Trace += "$line`r`n"
            }
            Set-Content -Path $script:LogPath -Value $Script:Trace
        }
        if($Script:HostMode){
            $Params = @{
                NoNewLine       = $NoNewLine -eq $true
                ForegroundColor = if($ForegroundColor) {$ForegroundColor} else {"White"}
            }
            Write-Host $line @Params
        }
    }
    
    function WriteInfo([string]$message,[switch]$WaitForResult,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
		# SYNOPSIS:  handles informational logs
        if($WaitForResult){
            WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:    $("`t" * $script:LogLevel)$message" -NoNewline
        }
        else{
            WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:    $("`t" * $script:LogLevel)$message"  
        }
        if($AdditionalStringArray){
            foreach ($String in $AdditionalStringArray){
                WriteLine "                    $("`t" * $script:LogLevel)`t$String"     
            }       
        }
        if($AdditionalMultilineString){
            foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
                WriteLine "                    $("`t" * $script:LogLevel)`t$String"     
            }
        }
    }

    function WriteResult([string]$message,[switch]$Pass,[switch]$Success){
		# SYNOPSIS:  writes results - should be used after -WaitForResult in WriteInfo
        if($Pass){
            WriteLine " - Pass" -ForegroundColor Cyan
            if($message){
                WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:    $("`t" * $script:LogLevel)`t$message" -ForegroundColor Cyan
            }
        }
        if($Success){
            WriteLine " - Success" -ForegroundColor Green
            if($message){
                WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:    $("`t" * $script:LogLevel)`t$message" -ForegroundColor Green
            }
        } 
    }

    function WriteInfoHighlighted([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){
		# SYNOPSIS:  write highlighted info 
        WriteLine "[$(Get-Date -Format hh:mm:ss)] INFO:    $("`t" * $script:LogLevel)$message"  -ForegroundColor Cyan
        if($AdditionalStringArray){
            foreach ($String in $AdditionalStringArray){
                WriteLine "[$(Get-Date -Format hh:mm:ss)]          $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
            }
        }
        if($AdditionalMultilineString){
            foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
                WriteLine "[$(Get-Date -Format hh:mm:ss)]          $("`t" * $script:LogLevel)`t$String" -ForegroundColor Cyan
            }
        }
    }

    function WriteWarning([string]$message,[string[]]$AdditionalStringArray,[string]$AdditionalMultilineString){ 
		# SYNOPSIS:  write warning logs 
        WriteLine "[$(Get-Date -Format hh:mm:ss)] WARNING: $("`t" * $script:LogLevel)$message"  -ForegroundColor Yellow
        if($AdditionalStringArray){
            foreach ($String in $AdditionalStringArray){
                WriteLine "[$(Get-Date -Format hh:mm:ss)]          $("`t" * $script:LogLevel)`t$String" -ForegroundColor Yellow
            }
        }
        if($AdditionalMultilineString){
            foreach ($String in ($AdditionalMultilineString -split "`r`n" | Where-Object {$_ -ne ""})){
                WriteLine "[$(Get-Date -Format hh:mm:ss)]          $("`t" * $script:LogLevel)`t$String" -ForegroundColor Yellow
            }
        }
    }

    function WriteError([string]$message){
		# SYNOPSIS:  logs errors
			WriteLine ""
			WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:   $("`t`t" * $script:LogLevel)$message" -ForegroundColor Red
    }

    function WriteErrorAndExit($message){
		# SYNOPSIS:  logs errors and terminates script 
			WriteLine "[$(Get-Date -Format hh:mm:ss)] ERROR:   $("`t" * $script:LogLevel)$message"  -ForegroundColor Red
			Write-Host "Press any key to continue ..."
			$host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") | OUT-NULL
			$HOST.UI.RawUI.Flushinputbuffer()
			Throw "Terminating Error"
	}

	#endregion: Logging Functions

	#region: Script Functions
	function MoveItemLogErrorAndContinue ($File,$TargetFolder){
		#SYNOPSIS: This moves an item, adds any error to the log and resumes
		$MoveError = $null
		Move-Item -Path $File.FullName -Destination $TargetFolder -Force -ErrorAction SilentlyContinue -ErrorVariable MoveError | Out-Null
		if($MoveError){
			WriteError -message "An error ocurred while moving $($File.BaseName). Review the error below, correct it, and run the script again - $($MoveError.Exception.Message)"
		}
	}
	#endregion: Script Functions

} #end BEGIN

PROCESS {
	try {
		$ScriptBeginTimeStamp = Get-Date
		#region: MAIN :::::

		# Validate SDP folder for not having more than one consecutive space characters
		# if ($SDPPath -match "   ") {Throw "$($SDPPath) contains more consecutive space characters, please rename folder"} else {write-host "SDP folder is OK"}

		WriteInfo -message "...Starting '$scriptName' on $(Get-Date)"

		if ($Undo) { #This will undo the folder grouping
			$ArrangedFolders = Get-ChildItem -Path $SDPPath -Directory
			WriteInfo -message "Found $($ArrangedFolders.count) folders"
			foreach ($Folder in $ArrangedFolders){
				$ChildItems = $Folder | Get-ChildItem
				WriteInfo -message "Moving $($ChildItems.count) files in $($Folder.BaseName) to $SDPPath"
				$ChildItems | ForEach-Object{ MoveItemLogErrorAndContinue -File $_ -TargetFolder $SDPPath}
				if(! ($Folder | Get-ChildItem ) ){
					$Folder | Remove-Item -Force 
					WriteInfo -message "Deleted $Folder"
				}
			}
		} else {
		#region: Collect and segregate all child items
		WriteInfo -message "Enter: Collect and segregate all child items"
		$LogLevel++
			$SDPFolder = get-item -Path $SDPPath

			$ChildItems = $SDPFolder | Get-ChildItem -File
			Writeinfo -message "Found $($ChildItems.count) items" 
			$LogLevel++

			#We have 3 types of files
			# 1- Server Logs => Contain _ but does not start with !
			$ServerLogsItems = $ChildItems | Where-Object {$_.BaseName -like "*_*" -and $_.BaseName -notlike "!*"}
			WriteInfo -message "Server Logs:           $($ServerLogsItems.count)"

			# 2- RFL related => Start with !
			$RFLItems        = $ChildItems | Where-Object {$_.BaseName -like "!*"}
			WriteInfo -message "RFL files:             $($RFLItems.count)"

			# 3- SDP related and other => Does not start with ! and no _
			$SDPItems        = $ChildItems | Where-Object {$_.BaseName -notlike "*_*" -and $_.BaseName -notlike "!*"}
			WriteInfo -message "SDP files (and other): $($SDPItems.count)"
			$LogLevel--
		
		$LogLevel--
		WriteInfo -message "Exit: Collect and segregate all child items"
		#endregion: Collect and segregate all child items

		#region: Arrange server logs
		WriteInfo -message "Enter: Arrange server logs"
		$LogLevel++

			foreach ($File in $ServerLogsItems){
				$ServerName = ($File.BaseName -split "_")[0]   
				$TargetFolderPath = "$SDPFolder\$ServerName"
				if(!(Test-Path -Path $TargetFolderPath)){
					New-Item -Path $TargetFolderPath -ItemType Directory | Out-Null
					WriteInfo -message "Created new folder for $ServerName"
				}
				MoveItemLogErrorAndContinue -File $File -TargetFolder $TargetFolderPath
			}
		
		$LogLevel--
		WriteInfo -message "Exit: Arrange server logs"
		#endregion: Arrange server logs

		#region: Arrange RFL Files
		WriteInfo -message "Enter: Arrange RFL Files"
		$LogLevel++
		
			if($RFLItems){
				$RFLFolderPath = $SDPPath + "RFL"
				if(!(Test-Path -Path $RFLFolderPath)){
					New-Item -Path $RFLFolderPath -ItemType Directory | Out-Null
					WriteInfo -message "Created new folder for RFL files"
				}
				$RFLItems |ForEach-Object{ MoveItemLogErrorAndContinue -File $_ -TargetFolder $RFLFolderPath}
			}

		$LogLevel--
		WriteInfo -message "Exit: Arrange RFL Files"
		#endregion: Arrange RFL Files
		}

		#endregion: MAIN
	} # end try PROCESS
	catch {
		WriteError -message "An Error occured"
		WriteError -message $error[0].Exception.Message
		$ErrorThrown = $true
			
		$errorMessage = "$scriptName caught an exception on $($ENV:COMPUTERNAME):"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Type: $($_.Exception.GetType().FullName)"
		$errorMessage += "`n`n"
		$errorMessage += "Exception Message: $($_.Exception.Message)"

		Write-Error $errorMessage -ErrorAction Continue
		<# Log error
				Write-Verbose "Logging the script's error..."
		# Log error - EventLog
				#An event log source needs to be preconfigured to use this.
				Write-EventLog `
					-EventId $AlertNumber `
					-LogName $LogName `
					-Source $EventSource `
					-Message $errorMessage `
					-EntryType Error
		# Log error - Email
				# This will attempt to send an immediate alert about the error.
				# The EventLog also needs to log the error because this one may not be sent.
				#use Send-MailMessage
		#>
		Start-Sleep -Seconds 3
		Write-Debug $errorMessage
		if ( $UseExitCode ) {
			$error.clear()	# clear script errors
			exit 1
		} #end UseExitCode
    } #end Catch PROCESS
	Finally {   
	} #end Finally PROCESS
} #end PROCESS

END {
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
	$LogLevel = 0
	WriteInfo -message "Script $scriptName v$VerMa.$VerMi execution finished. Duration: $Duration `n"
	if($ErrorThrown) {Throw $error[0].Exception.Message}
	# Stats
	If ($Stats) { #increment at start of script
	  "$j" + " ;$CheckDate" + "; $OSVersion; " + ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; $NodeCnt" + "; $SDPPath" + "; $ErrorMsg" + "; v$VerMa.$VerMi" + "; Undo:$Undo"| Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
	  }
    # This resets the ErrorActionPreference to the value at script start.
    $errorActionPreference = $startErrorActionPreference
} #end END


