﻿#************************************************
# DC_UEXCollect.ps1
# Version 1.0
# Date: 2009-2019
# Author: Walter Eder (waltere@microsoft.com)
# Description: Collects Windows Explorer DAT files and TWinUI Eventlogs
# Called from: TS_AutoAddCommands_Apps.ps1
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}


Write-verbose "$(Get-Date -UFormat "%R:%S") : Start of script DC_UEXCollect.ps1"

"Starting DC_UEXCollect.ps1 script" | WriteTo-StdOut
#_# Import-LocalizedData -BindingVariable ScriptStrings

# Registry keys

# Saved Directories

"Getting Copies of Windows Explorer DAT files" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_WindowsExplorerDATfiles_Title -Status $ScriptStrings.ID_WindowsExplorerDATfiles_Status

$sectionDescription = "Windows Explorer DAT files"
if(test-path "$env:localappdata\Microsoft\Windows\Explorer")
{
	$DesinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
	Copy-Item "$env:localappdata\Microsoft\Windows\Explorer" -Destination $DesinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
	CompressCollectFiles -filesToCollect $DesinationTempFolder -DestinationFileName "WindowsExplorerDAT.zip" -fileDescription "Explorer DAT files" -sectionDescription $sectionDescription -Recursive
	Remove-Item $DesinationTempFolder -Force -Recurse
}


# Directory Listings

# Permission Data

# Event Logs

"Getting UEX Event Logs" | WriteTo-StdOut

$sectionDescription = "Event Logs"
$EventLogNames = "Microsoft-Windows-TWinUI/Operational"
Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription

$EventLogNames = "Microsoft-Windows-PushNotification-Platform/Operational", "Microsoft-Windows-PushNotification-Platform/Admin", "Microsoft-Windows-PushNotification-Platform"
Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription


Write-verbose "$(Get-Date -UFormat "%R:%S") :   end of script DC_UEXCollect.ps1"
