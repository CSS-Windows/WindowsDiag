﻿# check LanmanServer bindings


##### FUNCTIONS #####
#region 

# FUNCTION: Get-TimeStamp
# PURPOSE: Returns a timestamp string

function Get-TimeStamp 
{
    return "$(Get-Date -format "yyyyMMdd_HHmmss_ffff")"
} # end Get-TimeStamp


# FUNCTION: Write-Log
# PURPOSE: Writes script information to a log file and to the screen when -Verbose is set.

function Write-Log {
    param ([string]$text, [switch]$tee = $false, [string]$foreColor = $null)

    $foreColors = "Black","Blue","Cyan","DarkBlue","DarkCyan","DarkGray","DarkGreen","DarkMagenta","DarkRed","DarkYellow","Gray","Green","Magenta","Red","White","Yellow"

    # check the log file, create if missing
    $isPath = Test-Path "$script:dataPath\$script:logName"
    if (!$isPath) {
        "$(Get-TimeStamp): Log started" | Out-File "$script:dataPath\$script:logName" -Force
        "$(Get-TimeStamp): Local log file path: $("$script:dataPath\$script:logName")" | Out-File "$script:dataPath\$script:logName" -Force
        Write-Verbose "Local log file path: $("$script:dataPath\$script:logName")"
    }
    
    # write to log
    "$(Get-TimeStamp): $text" | Out-File "$script:dataPath\$script:logName" -Append

    # write text verbosely
    Write-Verbose $text

    if ($tee)
    {
        # make sure the foreground color is valid
        if ($foreColors -contains $foreColor -and $foreColor)
        {
            Write-Host -ForegroundColor $foreColor $text
        } else {
            Write-Host $text
        }        
    }
} # end Write-Log

#endregion FUNCTIONS


# set logging options
$script:dataPath = "$env:USERPROFILE\Desktop"
$script:logName = "$env:ComputerName`_SvrBinding.log"

# get the LanmanServer Bind value
$bndPath = "HKLM:\System\CurrentControlSet\Services\Lanmanserver\Linkage"
$bndName = "Bind"

$bndLinkage = Get-ItemProperty -Path $bndPath -Name $bndName

Write-Log "All bindings:`n$(($bndLinkage.Bind | Sort-Object) -join "`n")`n"

<#

    Tcpip_ = TCP/IPv4 bindings
    Tcpip6_ = TCP/IPv6 bindings
    NetBT_Tcpip_ = NetBt over TCP/IPv4
    NetBT_Tcpip6_ = NetBt over TCP/IPv6

    We only care about Tcpip_ and Tcpip6_ in this case.

#>

# collect the TCP/IPv4 and TCP/IPv4 specific bindings
$tcpip4Bnd = $bndLinkage.Bind | Where-Object {$_ -match "\\Tcpip_"}
Write-Log "tcpip[4] bindings:`n$(($tcpip4Bnd | Sort-Object) -join "`n")`n"

$tcpip6Bnd = $bndLinkage.Bind | Where-Object {$_ -match "\\Tcpip6_"}
Write-Log "tcpip6 bindings:`n$(($tcpip6Bnd | Sort-Object) -join "`n")`n"

# get all net adapters, excluding adapters that are not bound to ms_server (Enabled = False)
$svrBingings = Get-NetAdapterBinding -ComponentID ms_server | Where-Object Enabled
$netAdptrs =  Get-NetAdapter | Where-Object {$svrBingings.InterfaceAlias -contains $_.InterfaceAlias}
Write-Log "Net adapters bound to ms_server:`n$(($netAdptrs | Sort-Object | Select-Object Name,InterfaceDescription,InterfaceAlias,InterfaceIndex,DeviceID) | Out-String)`n"

# write SMB Server network interface details to log - requires admin rights
#$srvNet = Get-SmbServerNetworkInterface
#Write-Log "SMB Server network interface details: `n$($srvNet | Out-String)`n"


foreach ($adapter in $netAdptrs)
{
    Write-Log "Checking bindings for $($adapter.Name)`nDescription: $($adapter.InterfaceDescription)`nGUID: $($adapter.DeviceID) `nStatus: $($adapter.Status)" -tee
    
    # is the DeviceID in the binding lists
    $tmpBnd4 = $tcpip4Bnd | Where-Object {$_ -match $adapter.DeviceID}
    if (-not $tmpBnd4)
    {
        Write-Log "$($adapter.Name) was not found on the SMB Server binding list for TCP/IPv4." -tee -foreColor Red
    } else
    {
        Write-Log "$($adapter.Name) was found on the SMB Server binding list for TCP/IPv4." -tee -foreColor Green
    }

    $tmpBnd6 = $tcpip6Bnd | Where-Object {$_ -match $adapter.DeviceID}
    if (-not $tmpBnd4)
    {
        Write-Log "$($adapter.Name) was not found on the SMB Server binding list for TCP/IPv6." -tee -foreColor Red
    } else
    {
        Write-Log "$($adapter.Name) was found on the SMB Server binding list for TCP/IPv6." -tee -foreColor Green
    }

    $tmpBnd = $bndLinkage.Bind | Where-Object {$_ -match $adapter.DeviceID}
    if (-not $tmpBnd4)
    {
        Write-Log "$($adapter.Name) was not found anywhere on the SMB Server binding list.`n" -tee -foreColor Red
    } else
    {
        Write-Log "$($adapter.Name) was found on the SMB Server binding lists.`n" -tee -foreColor Green
    }
}

Write-Log "Please upload $script:dataPath\$script:logName to Microsoft for analysis." -tee -foreColor Yellow