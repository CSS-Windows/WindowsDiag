# Sample diagnostic function
#
# Wrapped in a region same name as function name
# Change the name and code as needed
#
# You can test your diagnostic function by running xray in developer mode, e.g.:
# .\xray.ps1 -Diagnostic net_dnscli_KB4562541_sample -DevMode

#region net_dnscli_KB4562541_sample
<# 
Component: dnscli, vpn
Checks for:
 The issue where multiple NRPT policies are configured and are in conflict.
 This will result in none of configured NRPT policies being applied.
Created by: tdimli 
#>
function net_dnscli_KB4562541_sample
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [Boolean]
        $offline
    )
$issueMsg = "
This computer has local NRPT rules configured when there are also domain 
group policy NRPT rules present. This can cause unexpected name resolution 
behaviour. 
When domain group policy NRPT rules are configured, local NRPT rules are 
ignored and not applied:
`tIf any NRPT settings are configured in domain Group Policy, 
`tthen all local Group Policy NRPT settings are ignored.

More Information:
https://docs.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2012-R2-and-2012/dn593632(v=ws.11)

Resolution:
Inspect configured NRPT rules and decide which ones to keep, local or domain 
Group Policy NRPT rules. 

Registry key where local group policy NRPT rules are stored:
  {0}

Registry key where domain group policy NRPT rules are stored:
  {1}

Note: Even if domain group policy registry key is empty, local group policy 
NRPT rules will still be ignored. Please delete the domain group policy 
registry key if it is not being used.
If it is being re-created, identify the policy re-creating it and remove the 
corresponding policy configuration.
"

    if($offline) {
        LogWrite "Cannot run offline, skipping"
        return $RETURNCODE_SKIPPED
    }

    # Look for the issue
    $localNRPTpath = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters"
    $domainNRPTpath = "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\DnsClient"
    $DnsPolicyConfig = "DnsPolicyConfig"

    try
    {
        $curBuild = [Convert]::ToUInt32($wmi_Win32_OperatingSystem.BuildNumber)
        $minBuild = 10000 
        if ($curBuild -gt $minBuild) {
            # Windows 10
            # are there any local NRPTs configured which risk being ignored?
            if ((Get-ChildItem -Path "Registry::$localNRPTpath\$DnsPolicyConfig" -ErrorAction SilentlyContinue).Count -gt 0) {
                # does domain policy NRPT key exist (empty or not)?
                $domainNRPT = (Get-ChildItem -Path "Registry::$domainNRPTpath" -ErrorAction SilentlyContinue)
                if ($domainNRPT -ne $null) {
                    if ($domainNRPT.Name.Contains("$domainNRPTpath\$DnsPolicyConfig")) {
                        # issue present: domain Group Policy NRPT key present, local Group Policy NRPT settings are ignored
                        $issueMsg = [string]::Format($issueMsg, "$localNRPTpath\$DnsPolicyConfig", "$domainNRPTpath\$DnsPolicyConfig")
                        ReportIssue $issueMsg $ISSUETYPE_ERROR $null $null
                    }
                }
            }
        }
        else {
            # issue does not apply to pre-Windows 10
            return $RETURNCODE_SKIPPED
        }
    }
	catch {
		LogWrite "Failed - exiting! (Error: $_)"
        return $RETURNCODE_FAILED
    }

    return $RETURNCODE_SUCCESS
}

# Helper function(s) can be defined here if you must, strictly for use by this diagnostic function only
# Using helper functions from other diagnostics is prohibited (here today, gone tomorrow as xray is dynamic!)

#endregion net_dnscli_KB4562541_sample