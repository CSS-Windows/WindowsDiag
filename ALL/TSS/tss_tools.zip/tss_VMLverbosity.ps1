<#
.SYNOPSIS
This is a Powershell script to collect Hyper-V traces when the scenario time is too long for a VMLTrace

.DESCRIPTION

Script to change Hyper-V Tracing Verbosity

Arguments:
  -Set : Set the verbosity

.EXAMPLE
.\VMLVerbosity.ps1 

.NOTES
[TBD]

.LINK
http://www.bing.com
#>

Param(  [Parameter(Mandatory)]
        [ValidateSet("Standard","Verbose")]
        [string]$Set)

function Registry_Set([ValidateSet("Standard","Verbose")][string]$Level,[ValidateSet("Yes","No")][string]$RestartService)  {
    if ($Level -eq "Standard"){
        Registry_SetStandard -RestartService $RestartService
    }
    else {
        Registry_SetVerbose -RestartService $RestartService
    }

}
function Registry_SetVerbose([ValidateSet("Yes","No")][string]$RestartService){
    write-host "Setting verbose tracing"
    try
    {
	    if(-not (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\VML"))
        {
            New-Item "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\VML" | Out-Null
        }
        New-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\VML" -name "TraceLevel" -propertytype DWord -value 3 -Force | Out-Null

        if(-not (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\VML\TraceLevelsEnabled"))
        {
            New-Item "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\VML\TraceLevelsEnabled" | Out-Null
        }
        New-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\VML\TraceLevelsEnabled" -name "Trace6" -propertytype QWord -value 0x0000000000000000 -Force  | Out-Null
        New-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\VML\TraceLevelsEnabled" -name "Trace0" -propertytype QWord -value 0xFFFFFFFFFFFFFF17 -Force  | Out-Null
        New-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\VML\TraceLevelsEnabled" -name "Trace3" -propertytype QWord -value 0xFFFFFFFFFFFFFFF7 -Force | Out-Null

        if(-not (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\PerformanceTracing"))
        {
            New-Item "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\PerformanceTracing" | Out-Null
        }
        New-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\PerformanceTracing" -name "EnableMigrationTrace" -propertytype DWord -value 1 -Force | Out-Null
        New-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\PerformanceTracing" -name "EnableVmbTrace" -propertytype DWord -value 1 -Force | Out-Null
        New-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\PerformanceTracing" -name "EnablePvmTrace" -propertytype DWord -value 1 -Force | Out-Null
        New-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\PerformanceTracing" -name "EnableFrTrace" -propertytype DWord -value 1 -Force | Out-Null
        New-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\PerformanceTracing" -name "EnableVmNicTrace" -propertytype DWord -value 1 -Force | Out-Null
        New-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\PerformanceTracing" -name "EnableStorageMigrationTrace" -propertytype DWord -value 1 -Force | Out-Null
        New-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\PerformanceTracing" -name "EnableWorkerTrace" -propertytype DWord -value 1 -Force | Out-Null
        New-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\PerformanceTracing" -name "EnableDynMemTrace" -propertytype DWord -value 1 -Force | Out-Null
    
        if(-not (Test-path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\EnablePerformanceTracing"))
        {
            New-Itemproperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization" -name "EnablePerformanceTracing" -propertytype Dword -value 1 -force | out-Null
        }
    
    }
    catch
    {
        throw "Error: couldn't enable performance tracing.`n"+$Error[0].Exception
    }
    if ($RestartService -eq "Yes"){
        Try
        {
            Write-Output "Restarting the Hyper-V service..."
            # Restart the Hyper-V service
            # Because VMMS can be auto-restarted by the cluster, the "Stop-Service" cmdlet
            # may sometimes hit a race with the cluster service. Hence, we always ignore Stop-Service/Wait-Process
            # failures and rely on a change of the start time to determine that restart was successful
            # Start-Service never fails if the service is already running.
            $vmmsStartTime = (Get-Process vmms -ErrorAction:SilentlyContinue).StartTime
            Stop-Service vmms -Force -ErrorAction SilentlyContinue
            Wait-Process vmms -ErrorAction:SilentlyContinue -Timeout:30
            $newVmmsStartTime = (Get-Process vmms -ErrorAction:SilentlyContinue).StartTime
            if(($null -ne $vmmsStartTime) -and ($null -ne $newVmmsStartTime) -and ($newVmmsStartTime -eq $vmmsStartTime))
            {
                throw "The VMMS process failed to stop and is still running"
            }
            Start-Service vmms

            while((Get-Service vmms).Status -eq "Started")
            {
                Write-Output "Waiting for the vmms service to restart..."
                Start-Sleep 1
            }
        }
        catch
        {
            throw "Error: couldn't restart Hyper-V services.`n"+$Error[0].Exception
        }
    }
}
function Registry_SetStandard([ValidateSet("Yes","No")][string]$RestartService)
    {
        write-host "Resetting tracing to standard"
        if ((Test-Path -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\VML"))
        {
        Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\VML" -Force -Recurse
        }
        if ((Test-Path -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\PerformanceTracing"))
        {
        Remove-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\PerformanceTracing" -Force -Recurse
        }
        if ((Test-Path -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization"))
        {
        remove-Itemproperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization" -name "EnablePerformanceTracing" -force | out-Null
        }

    if ($RestartService -eq "Yes"){
        Try
        {
            Write-Output "Restarting the Hyper-V service..."
            # Restart the Hyper-V service
            # Because VMMS can be auto-restarted by the cluster, the "Stop-Service" cmdlet
            # may sometimes hit a race with the cluster service. Hence, we always ignore Stop-Service/Wait-Process
            # failures and rely on a change of the start time to determine that restart was successful
            # Start-Service never fails if the service is already running.
            $vmmsStartTime = (Get-Process vmms -ErrorAction:SilentlyContinue).StartTime
            Stop-Service vmms -Force -ErrorAction SilentlyContinue
            Wait-Process vmms -ErrorAction:SilentlyContinue -Timeout:30
            $newVmmsStartTime = (Get-Process vmms -ErrorAction:SilentlyContinue).StartTime
            if(($null -ne $vmmsStartTime) -and ($null -ne $newVmmsStartTime) -and ($newVmmsStartTime -eq $vmmsStartTime))
            {
                throw "The VMMS process failed to stop and is still running"
            }
            Start-Service vmms

            while((Get-Service vmms).Status -eq "Started")
            {
                Write-Output "Waiting for the vmms service to restart..."
                Start-Sleep 1
            }
        }
        catch
        {
            throw "Error: couldn't restart Hyper-V services.`n"+$Error[0].Exception
        }
    }
}

# ::::: MAIN :::::

if ($Set -eq "Standard"){
    Write-Host "Set verbosity as Standard"
    Registry_Set -Level "Standard" -RestartService "Yes"
}
if ($Set -eq "Verbose"){
    Write-Host "Set verbosity as Verbose"
    Registry_Set -Level "Verbose" -RestartService "Yes"
}
