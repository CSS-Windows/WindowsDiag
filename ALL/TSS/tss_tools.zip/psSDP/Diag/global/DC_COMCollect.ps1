﻿#************************************************
# DC_COMCollect.ps1
# Version 1.0
# Date: 2009-2019
# Author: Walter Eder (waltere@microsoft.com)
# Description: Collects .Net Framework nGen files
# Called from: TS_AutoAddCommands_Apps.ps1
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}


Write-verbose "$(Get-Date -UFormat "%R:%S") : Start of script DC_COMCollect.ps1"

"\n\n==================== Starting COMCollect.ps1 script ====================\n\n" | WriteTo-StdOut
#_# Import-LocalizedData -BindingVariable ScriptStrings

# Registry keys
"Getting COM Registry Keys" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_COMRegistryKeys_Title -Status $ScriptStrings.ID_COMRegistryKeys_Status

$Regkeys = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Ole"
$OutputFile = $ComputerName + "_reg_Ole_HKLM.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "HKLM Ole Registry Key" -SectionDescription "Software Registry keys"

$Regkeys = "HKEY_CURRENT_USER\Software\Classes\Extensions","HKEY_LOCAL_MACHINE\Software\Classes\Extensions"
$OutputFile = $ComputerName + "_reg_Extensions.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "Extensions Registry Key" -SectionDescription "Software Registry keys"

$Regkeys = "HKEY_CURRENT_USER\Software\Classes\ActivatableClasses","HKEY_LOCAL_MACHINE\Software\Classes\ActivatableClasses"
$OutputFile = $ComputerName + "_reg_ActivatableClasses.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "ActivatableClasses Registry Key" -SectionDescription "Software Registry keys"

$Regkeys = "HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Windows NT\dcom"
$OutputFile = $ComputerName + "_reg_DCOM_HKLM.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "DCOM HKLM Registry Key" -SectionDescription "Software Registry keys"




# Saved Directories


# Directory Listings


# Permission Data
# TO BE DONE

# Event Logs

# Other Logs

"Getting COM Setup Log" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_COMSetupLog_Title -Status $ScriptStrings.ID_COMSetupLog_Status

$sectionDescription = "COM Setup Log"
if(test-path "$env:windir\Comsetup.log")
{	$OutputFile = $ComputerName + "_Comsetup.log"
	copy-item -Path "$env:windir\Comsetup.log" -Destination $OutputFile -Force
	CollectFiles -filesToCollect $OutputFile -fileDescription "COM Setup Log File" -sectionDescription $sectionDescription
}

Write-verbose "$(Get-Date -UFormat "%R:%S") :   end of script DC_COMCollect.ps1"
