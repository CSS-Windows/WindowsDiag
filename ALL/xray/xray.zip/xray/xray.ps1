﻿# xray.ps1
# by tdimli
# March 2020
# Detects known issues and helps resolve them

# parameters
# Specify either one or more area(s) or component(s), not both
Param(
    [Parameter(Mandatory=$true,
    ParameterSetName="Areas")]
    [String[]]
    $Area,

    [Parameter(Mandatory=$true,
    ParameterSetName="Components")]
    [String[]]
    $Component,

    [Parameter(Mandatory=$true,
    ParameterSetName="Diagnostics")]
    [String[]]
    $Diagnostic,

    [Parameter(Mandatory=$false,
    ParameterSetName="Areas")]
    [Parameter(Mandatory=$false,
    ParameterSetName="Components")]
    [Parameter(Mandatory=$false,
    ParameterSetName="Diagnostics")]
    [String]
    $DataPath,

    [Parameter(Mandatory=$false,
    ParameterSetName="Areas")]
    [Parameter(Mandatory=$false,
    ParameterSetName="Components")]
    [Parameter(Mandatory=$false,
    ParameterSetName="Diagnostics")]
    [switch]
    $Offline,

    [Parameter(Mandatory=$false,
    ParameterSetName="Areas")]
    [Parameter(Mandatory=$false,
    ParameterSetName="Components")]
    [Parameter(Mandatory=$false,
    ParameterSetName="Diagnostics")]
    [switch]
    $WaitBeforeClose,

    [Parameter(Mandatory=$false,
    ParameterSetName="Areas")]
    [Parameter(Mandatory=$false,
    ParameterSetName="Components")]
    [Parameter(Mandatory=$false,
    ParameterSetName="Diagnostics")]
    [switch]
    $DevMode,

    [Parameter(Position=0, Mandatory=$false,
    ParameterSetName="Help")]
    [AllowEmptyString()]
    [AllowNull()]
    [String]
    $Help
)

Import-Module -Name .\xray_WU.psm1 -Force
Import-Module -Name .\diag_api.psm1 -Force

Import-Module -Name .\diag_ads.psm1 -Force
Import-Module -Name .\diag_dnd.psm1 -Force
Import-Module -Name .\diag_net.psm1 -Force
Import-Module -Name .\diag_prf.psm1 -Force
Import-Module -Name .\diag_sha.psm1 -Force
Import-Module -Name .\diag_uex.psm1 -Force

# used for diagnostic development only
if ($DevMode) {
    Import-Module -Name .\diag_test.psm1 -Force
}

# version
$version = "1.0.201102.0"

# Area and Area/Component arrays
$TechAreas = @("ADS", "DND", "NET", "PRF", "SHA", "UEX")
#endregion globals

#region helpers

# Processes provided area(s) with all its components & checks
function RunDiagForArea($areas)
{
    foreach ($area in $areas) {
        LogWrite "Processing area:$area"

        try {
            $components = (Get-Variable -Name $area -ErrorVariable ErrorMsg -ErrorAction SilentlyContinue).Value
        }
        catch {
            LogWrite $Error[0].Exception
        }

        if($ErrorMsg) {
            LogWrite $ErrorMsg
        }
        else {
            RunDiagForComponent $components
        }
    }
}

# Processes provided components and runs corresponding diags
function RunDiagForComponent($components)
{
    if($components.Count -eq 0){
        LogWrite "No components!"
        return
    }

    foreach ($component in $components) {
        LogWrite "Processing component: $component"

        try {
            $diags = (Get-Variable -Name $component -ErrorVariable ErrorMsg -ErrorAction SilentlyContinue).Value
        }
        catch {
            LogWrite $Error[0].Exception
        }

        if($ErrorMsg) {
            LogWrite $ErrorMsg
        }
        else {
            RunDiag $diags
        }
    }
}

# Runs specified diagnostics
function RunDiag($diagnostics)
{
    if($diagnostics.Count -eq 0){
        LogWrite "No diagnostics!"
        return
    }

    foreach ($diag in $diagnostics) {
        if($executedDiags.Contains($diag)) {
            LogWrite "Skipping duplicate instance: $diag"
            continue
        }
        $Global:currDiagFn = $diag
        $executedDiags.Add($diag)
        LogWrite "Running diagnostic: $diag"
        XmlAddDiagnostic $diag
        Write-Host "." -NoNewline
        $time1 = (Get-Date).ToUniversalTime()

        $Global:numDiagsRun++
        if ($DevMode) {
            # no error/exception protection
            $result = & $diag $Offline
        }
        else {
            # to prevent failure messages from diag functions
            $ErrorActionPreference = "Stop"
            try {
                $result = & $diag $Offline
            }
            catch {
                $result = $RETURNCODE_EXCEPTION
                LogWrite $Error[0].Exception.Message
            }
            # revert to normal error handling 
            $ErrorActionPreference = "Continue"
        }

        LogWrite "$diag returned: $result"
        $time2 = (Get-Date).ToUniversalTime()
        [UInt64] $timeTaken = ($time2 - $time1).TotalMilliseconds
        XmlDiagnosticComplete $diag $result $timeTaken

        if($result -eq $RETURNCODE_SUCCESS){
            $Global:numDiagsSuccess++
        }
        elseif($result -eq $RETURNCODE_SKIPPED){
            $Global:numDiagsSkipped++
        }
        else {
            $Global:numDiagsFailed++
        }
        $Global:currDiagFn = $null
    }
}

# 'Translates' TSS scenarios to xray components 
function ValidateTssComponents
{
    param(
        [Parameter(Mandatory=$true)]
        [String[]]
        $TssComponents
    )

    $tssComps  = @("802Dot1x", "WLAN",     "Auth", "BITS", "BranchCache", "Container", "CSC", "DAcli", "DAsrv", "DFScli", "DFSsrv", "DHCPcli", "DhcpSrv", "DNScli", "DNSsrv", "Firewall", "General", "HypHost", "HypVM", "IIS", "IPAM", "MsCluster", "MBAM", "MBN", "Miracast", "NCSI", "NetIO", "NFScli", "NFSsrv", "NLB", "NPS", "Proxy", "RAS", "RDMA", "RDScli", "RDSsrv", "SDN", "SdnNC", "SQLtrace", "SBSL", "UNChard", "VPN", "WFP", "Winsock", "WIP", "WNV", "Workfolders")
    $xrayComps = @("802Dot1x", "802Dot1x", "Auth", "BITS", "BranchCache", "Container", "CSC", "DAcli", "DAsrv", "DFScli", "DFSsrv", "DHCPcli", "DhcpSrv", "DNScli", "DNSsrv", "Firewall", "General", "HypHost", "HypVM", "IIS", "IPAM", "MsCluster", "MBAM", "MBN", "Miracast", "NCSI", "NetIO", "NFScli", "NFSsrv", "NLB", "NPS", "Proxy", "RAS", "RDMA", "RDScli", "RDSsrv", "SDN", "SdnNC", "SQLtrace", "SBSL", "UNChard", "VPN", "WFP", "Winsock", "WIP", "WNV", "Workfolders")

    for ($i = 0; $i -lt $tssComps.Count; $i++) {
        $tssComps[$i] = $tssComps[$i].ToLower()
        $xrayComps[$i] = $xrayComps[$i].ToLower()
    }
    for ($i = 0; $i -lt $TssComponents.Count; $i++) {
        $TssComponents[$i] = $TssComponents[$i].ToLower()
    }
    [System.Collections.Generic.List[String]] $newComps = $TssComponents

    for ($i = 0; $i -lt $TssComponents.Count; $i++) {
        $index = -1
        for ($j = 0; $j -lt $tssComps.Count; $j++) {
            if ($tssComps[$j] -eq $TssComponents[$i]) {
                $index = $j
                break
            }
        }
        if($index -lt 0) {
            continue
        }
        if($TssComponents[$i] -ne $xrayComps[$index]) {
            # remove
            $newComps.RemoveAt($i)
            if(!$newComps.Contains($xrayComps[$index])) {
                # replace
                $newComps.Insert($i, $xrayComps[$index])
            }
        }
    }
    return [String[]] $newComps
}

# Displays help/usage info
function ShowHelp
{
    "
xray by tdimli, v$version

Checks for known issues

Usage:
xray.ps1 -Area <string[]> [-DataPath <string>] [-Offline] [-WaitBeforeClose] [<CommonParameters>]
xray.ps1 -Component <string[]> [-DataPath <string>] [-Offline] [-WaitBeforeClose] [<CommonParameters>]
xray.ps1 -Diagnostic <string[]> [-DataPath <string>] [-Offline] [-WaitBeforeClose] [<CommonParameters>]

xray.ps1 Shows help

    Parameters:
    Specify either Area or Component to check or Diagnostic to run (they are mutually exclusive), multiple items can be specified (comma-separated).
        When area(s) specified, all components within the specified area(s) are checked
            `"-Area all`" or `"-Area *`" checks all areas
        When component(s) specified, all diagnostics within the specified component(s) are run
        When diagnostic(s) specified, only the specified diagnostics are run
    -DataPath: Path for input/output files
    -Offline: Not running on the actual machine being examined (some -not all- diagnostics can use data files to search for issues)
    -WaitBeforeClose: If any known issues are detected, pauses just before script terminates/window closes
        Use to ensure detected issues are not missed

    Example: .\xray.ps1 -Component dhcpsrv,dnssrv -DataPath c:\xray

List of available diagnostic areas/components to scan for issues:

Area (version):  `tComponents:
=================`t==========="

    foreach ($techarea in $TechAreas) {
        $version_name = $techarea + "_version"
        $techarea_version = (Get-Variable -Name $version_name).Value
        $components = (Get-Variable -Name $techarea).Value
        "$techarea ($techarea_version)`t$components"
    }
    ""
}
#endregion helpers

#region main
# main script

if (($Area -eq $null) -and ($Component -eq $null) -and ($Diagnostic -eq $null)) {
    ShowHelp
    return
}

# validate DataPath, do it here before any file operations
$origDataPath = $DataPath
if(($DataPath.Length -eq 0) -or -not(Test-Path -Path $DataPath)) {
    $DataPath = (Get-Location).Path
}
else {
    $DataPath = Convert-Path $DataPath
}

InitGlobals $version $DataPath

LogWrite "xray by tdimli, v$version"

Write-Host "xray by tdimli, v$version`r`nStarting diagnostics, checking for known issues..."
foreach ($techarea in $TechAreas) {
    $version_name = $techarea + "_version"
    $techarea_version = (Get-Variable -Name $version_name).Value
    LogWrite " $techarea $techarea_version"
    XmlAddTechArea $techarea $techarea_version
}

# these splits are needed for TSS interoperability
if ($Area -ne $null) {
    $Area = $Area -split ","
    if (($Area -eq  "all") -or ($Area -eq  "*")) {
        $Area = $TechAreas
    }
}
if ($Component -ne $null) {
    $Component = $Component -split ","
    for ($i = 0; $i -lt $Component.Count; $i++) {
        $Component[$i] = $Component[$i].Replace(' ', '')
    }
}
if ($Diagnostic -ne $null) {
    $Diagnostic = $Diagnostic -split ","
}

# log parameters
LogWrite "Parameters:"
LogWrite " Area(s): $Area"
LogWrite " Component(s): $Component"
if(($Component -ne $null) -and ($Component.Count -gt 0)) {
    $ConvertedComponent = ValidateTssComponents $Component
    LogWrite "  after conversion: $ConvertedComponent"
    $Component = $ConvertedComponent
}
LogWrite " Diagnostic(s): $Diagnostic"
LogWrite " Datapath: $DataPath"
if (!$DataPath.Equals($origDataPath)) {
    LogWrite "  Original Datapath: $origDataPath"
}
LogWrite " Offline: $Offline"
LogWrite " WaitBeforeClose: $WaitBeforeClose"
LogWrite " DevMode: $DevMode"
XmlAddParameters $Area $Component $Diagnostic $Offline $WaitBeforeClose $DevMode

LogWrite "Log file: $logFile"
LogWrite "XML report: $xmlRptFile"

# collect basic system info
LogWrite "Collecting system info..."
AddSysInfo $Offline

# collect poolmon info
LogWrite "Collecting poolmon info..."
InitPoolmonData $Offline

# run diagnostics
LogWrite "Starting diagnostics, checking for known issues..."
[System.Collections.Generic.List[String]] $executedDiags = New-Object "System.Collections.Generic.List[string]"
if ($Area) {
    RunDiagForArea $Area
} elseif ($Component) {
    RunDiagForComponent $Component
} elseif ($Diagnostic) {
    RunDiag $Diagnostic
}
XmlMarkComplete

# log/show summary
$stats1 = "$numDiagsRun diagnostic check(s) run (R:$numDiagsSuccess S:$numDiagsSkipped F:$numDiagsFailed)"
$stats2 = "$numIssues issue(s) found"
if(Test-Path -Path $issuesFile){
    $stats2 += ", details saved to $issuesFile"
}
elseif(Test-Path -Path $infoFile) {
    $stats2 += ", details saved to $infoFile"
}

LogWrite $stats1
LogWrite $stats2
LogWrite "Diagnostics completed."

Write-Host
Write-Host $stats1
Write-Host $stats2
Write-Host "Diagnostics completed.`r`n"

if($WaitBeforeClose -and $issueShown) {
    # wait for user
    pause
}
#endregion main
