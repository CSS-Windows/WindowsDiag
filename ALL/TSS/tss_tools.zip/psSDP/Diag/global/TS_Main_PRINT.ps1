﻿# Load Common Library
# Load Reporting Utilities
#_#$debug = $false

. ./utils_cts.ps1
#_#. ./TS_RemoteSetup.ps1 

$FirstTimeExecution = FirstTimeExecution

if ($FirstTimeExecution) {

	Run-DiagExpression .\TS_PrintInfo.ps1 -DetectRootCauses
	
	# Auto Added Commands [AutoAdded]
	.\TS_AutoAddCommands_PRINT.ps1

	EndDataCollection

} else {
	#2nd execution. Delete the temporary flag file then exit
	EndDataCollection -DeleteFlagFile $True
}

Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}
