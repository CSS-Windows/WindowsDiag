﻿# 2019-03-17 WalterE added Trap #_#
Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 WriteTo-ErrorDebugReport -ErrorRecord $_
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Import-LocalizedData -BindingVariable SetupEventLogsStrings

$EventLogNames = @("System", "Application")
$EventLogAdvisorAlertXMLs = $SetupEventLogsStrings.ID_EPSEventLogAdvisorUnexpectedShutdown

& $Global:ToolsPath`\TS_GetEvents.ps1 -EventLogNames $EventLogNames -EventLogAdvisorAlertXMLs $EventLogAdvisorAlertXMLs
