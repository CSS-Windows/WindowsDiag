<# Last edit by: waltere 2020-04-06
 File Name: monthly_new-RFLReference_Tech_OS.ps1 [all|Net|Dom|Cluster|Core|VSS|HyperV|RDS|Print|Custom|HyCoClNe|SCVMM|SCVMM2012R2|Client|Exchange|Except|Master|CM2007|CM2012RTM|CM2012SP1|CM2012R2] [all|2008|2008R2|2012|2012R2|2016|2016RS1|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004]
 Help: get-help \\emeacssdfs\netpod\rfl\RflLists\monthly_new-RFLReference_Tech_OS.ps1 -detailed

 Old Server: \\emea\Shares\MUC-VFS-01A\rfl (\\muc-vfs-01a\rfl)
 DFS Server: \\hubertsdfs\rfl$ (\\emeaCssDfs\netpod\RFL)

Manually_ToDo: 	- verify $HfSgoOnline is set to correct value
		- verify that $MoveProdFiles=0, also $MovePuasFiles=0 when running this script and you want to check results first before doing production changes
 since May2016: 	- FIRST download manually latest rollup .csv files for 2008R2,2012,2012R2 KBs and then run script monthly_new-Master-or-Except-FromCsv_OS.ps1 (see more info in script)
 since Oct2016: 	- Win7/Win8.1/2012 cumulative xx-B, and xx-C
 starting Jun2017:	- 2016RS1 -C versions
- for 2008R2 RDS and All_OS , add:
# "2601888","RDS_2008R2_important_KB","KBOnlyVersion","0","9/22/2014","GDR","2601888 (v19.0)","Available Updates for Remote Desktop Services (Terminal Services) on Windows Server 2008 R2 SP1","http://support.microsoft.com/kb/2601888","KB only","KB only","KB only"," ","No Rollup"
+
exceptions 2008R2 ntkrnlpa ; copy the ntkrnl.exe entry to new line and change ntkrnl.exe with ntkrnlpa.exe
exceptions 2012R2 (wrong version-Nr) Advapi32.dll Secur32.dll Shell32.dll ; excel version 4.0xx but we need 6.3.xx - check version from last mounth

Upcoming WSD Release Calendar:
https://insights/Report?id=01a0847e-efc1-4071-a0dc-f94a0440c1a8&isPublished=true#=undefined&inputReleaseDate=2019-10-10&_tab=0&Security=undefined&NonSecurity=undefined&Hotfix=undefined

Check emails from psssec@microsoft.com for security updates

Objective: 	Run the script once a month after second Tuesday [LDR/GDR Hotfix Realease date], but verify that the new Hotfix articles are public already (this could take a few days)
		After runnning this script you may double check with script monthly_check-KBs_Tech_OS.ps1 for inconsistencies in KB articles.
	- monthly_new-RFLReference script will rewrite Comment entry to
	  "rBC" = verified WinSE entry in BugCheck info, if found in BugCheck info
	- monthly_correct-RollupInfo script will rewrite Comment entries to
	  "rEX" = derived from ref__Except_<OS>_latest.csv
	  "rKB" = verified by public KB info, if RollupInfo found in public KB

NOTE: Please use only ASCII Editor like Notepad for updating this script file and save file in ANSI, not Unicode! (Powershell Console does not like Unicode)

# "mrxsmb20.sys","Net_SMB_Client","6.2.9200.21582","0","11-Aug-2015","LDR","3086213 (v2.0)","Computer is forcibly restarted if RC4 is disabled in Windows Server 2012","http://support.microsoft.com/kb/3086213","3086213 (v2.0)","Computer is forcibly restarted if RC4 is disabled in Windows Server 2012","http://support.microsoft.com/kb/3086213","rEX","No Rollup"

Info on SSU: ADV990001 | Latest Servicing Stack Updates https://portal.msrc.microsoft.com/en-us/security-guidance/advisory/ADV990001


Order of Build RFL Process
==========================
Remember for MANUAL BUILD:
0-  PHASE  0: adjust .\RflLists\KBOnlyRollup_20*.csv; + download *.csv file in monthly rollup KBs,
0- 	"2008","2008R2","2012","2012R2","2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","201619H2","20162004"| ForEach-Object{.\RflLists\monthly_updateRFL_OS_Type.ps1 $_}  #(for updating *History.txt, )
	- delete the two lines reg. previous monthly KB in KBonlyRollup_<os>.csv
# ignore : PHASE  I: (.\RflLists\monthly_new-RFLReference_Tech_OS.ps1 Master all -verbose )	#(for master file, HfSgoOnline=1) # from http://hotfixserver // : New: http://aka.ms/trackitbinarysearch
1- 	"2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","201619H2","20162004"| ForEach-Object{.\RflLists\monthly_new-Master-or-Except-FromCsv_OS.ps1 $_}  #(for building 2016* MASTER file)
2-	.\RflLists\monthly_new-RFLReference_Tech_OS.ps1 all 2008,2008R2,2012,2012R2,2016,2016RS1,2016RS2,2016RS3,2016RS4,2016RS5,201619H1,201619H2,20162004 -verbose    #(for building TEMPLATES, HfSgoOnline=0)
3- 	"2008","2008R2","2012","2012R2"| ForEach-Object{.\RflLists\monthly_new-Master-or-Except-FromCsv_OS.ps1 $_} #(for updating 2008*,2012* EXCEPT files)
4- 	"2008","2008R2","2012","2012R2"| ForEach-Object{.\RflLists\monthly_correct-RollupInfo_Tech_OS.ps1 Master $_} #(for reading 2008,2008R2,2012* EXCEPT files + correct-RollupInfo)
5- now in \prestaging\ref_Master_* 2008, 2008R2, 20012R2 files manually correct exceptions:
# for 2012R2: Secur32.dll 6.3.9600.17415 #-#- Advapi32.dll 6.3.9600.18895 - Shell32.dll 6.3.9600.19735
 	 replace all previous month '20-07Rollup' lines
# for 2012
  	 replace all previous month '20-07Rollup' lines

 # for 2008R2: ntkrnlpa -> copy line from Ntoskrnl
  #_# microsoft.identityserver.dll         6.1.7601.23675 4034670    10-Feb-2017 LDR  No LDR Only available No LDR Only available          rEX   17-08Rollup
  #_# microsoft.identityserver.service.dll 6.1.7601.23675 4034670    10-Feb-2017 LDR  No LDR Only available No LDR Only available          rEX   17-08Rollup
  	replace all previous month '20-08Rollup' lines 
 for 2008: ntkrnlpa -> copy line from Ntoskrnl
	replace all previous month '20-08Rollup' lines 	
# for 2016 RS5+, 201619H1,201619H2,20162004
 a) update RS5+ machine with latest fix, then run .\get-psSDP.ps1 RFL - or TSS SDP:RFL 
 b) special RFLcheck: \\emeacssdfs.europe.corp.microsoft.com\netpodW$\rfl\check-rfl-csv_Tech_Path.ps1 All_OS -BuildRS5 -RunAddonBitMask 0 -SDPPath ""<path-to-SDP>" 
   ( \prestaging\ RS5+ Except and Master are supposed to be identical)
 c) edit \prestaging\ref__Master_2016*_latest.csv with corrections from RFLcheck, update binary date
 d) replace "GDR","4537818 (v1.0)","February 25, 2020-KB4537818 (OS Build 17763.1075)","http://support.microsoft.com/kb/4537818","KB only","KB only","KB only"," ","20-04Rollup"
6-  PHASE IIb: .\RflLists\monthly_new-RFLReference_Tech_OS.ps1 all 2008,2008R2,2012,2012R2,2016,2016RS1,2016RS2,2016RS3,2016RS4,2016RS5,201619H1,201619H2,20162004 BUILD -verbose	#(for building all tech databases) - month C update: 2008R2,2012,2012R2,2016RS1,2016RS3
7-  PHASE III: test the new database files
8-  	- MANUAL delete in 2008,2008R2,2012,2012R2 \prestaging\ref_Except_* all cum update entries ending with latest rollup: "20-08Rollup" - and copy back to production folder

ToDo: ?? don't copy back (copying back) prestaging Except files to production per script, use only Prestaging for source

--> do some visual checks for *Rollup, KB#, links or title
Link: 
(import-csv .\RflLists\ref__All_OS_20162004_latest.csv ) |?{$_.Title -match ' '} | Select-Object Binary,Version,Article,Published,Branch,LDROnlyKB,LDROnlyLink,Comment,RollupInfo | Sort-Object Version -desc | Format-Table -auto
(import-csv .\RflLists\ref__All_OS_201619H2_latest.csv ) |?{$_.Title -match ' '} | Select-Object Binary,Version,Article,Published,Branch,LDROnlyKB,LDROnlyLink,Comment,RollupInfo | Sort-Object Version -desc | Format-Table -auto
(import-csv .\RflLists\ref__All_OS_201619H1_latest.csv ) |?{$_.Title -match ' '} | Select-Object Binary,Version,Article,Published,Branch,LDROnlyKB,LDROnlyLink,Comment,RollupInfo | Sort-Object Version -desc | Format-Table -auto
(import-csv .\RflLists\ref__All_OS_2016RS5_latest.csv ) |?{$_.Title -match ' '} | Select-Object Binary,Version,Article,Published,Branch,LDROnlyKB,LDROnlyLink,Comment,RollupInfo | Sort-Object Version -desc | Format-Table -auto
(import-csv .\RflLists\ref__All_OS_2016RS4_latest.csv ) |?{$_.Title -match ' '} | Select-Object Binary,Version,Article,Published,Branch,LDROnlyKB,LDROnlyLink,Comment,RollupInfo | Sort-Object Version -desc | Format-Table -auto
(import-csv .\RflLists\ref__All_OS_2016RS3_latest.csv ) |?{$_.Title -match ' '} | Select-Object Binary,Version,Article,Published,Branch,LDROnlyKB,LDROnlyLink,Comment,RollupInfo | Sort-Object Version -desc | Format-Table -auto
(import-csv .\RflLists\ref__All_OS_2016RS2_latest.csv ) |?{$_.Title -match ' '} | Select-Object Binary,Version,Article,Published,Branch,LDROnlyKB,LDROnlyLink,Comment,RollupInfo | Sort-Object Version -desc | Format-Table -auto
(import-csv .\RflLists\ref__All_OS_2016RS1_latest.csv ) |?{$_.Title -match ' '} | Select-Object Binary,Version,Article,Published,Branch,LDROnlyKB,LDROnlyLink,Comment,RollupInfo | Sort-Object Version -desc | Format-Table -auto
(import-csv .\RflLists\ref__All_OS_2016_latest.csv ) |?{$_.Title -match ' '} | Select-Object Binary,Version,Article,Published,Branch,LDROnlyKB,LDROnlyLink,Comment,RollupInfo | Sort-Object Version -desc | Format-Table -auto

(import-csv .\RflLists\ref__All_OS_2012R2_latest.csv ) |?{$_.Title -match ' '} | Select-Object Binary,Version,Article,Published,Branch,LDROnlyKB,LDROnlyLink,Comment,RollupInfo | Sort-Object RollupInfo,Version -desc | Format-Table -auto
(import-csv .\RflLists\ref__All_OS_2012_latest.csv ) |?{$_.Title -match ' '} | Select-Object Binary,Version,Article,Published,Branch,LDROnlyKB,LDROnlyLink,Comment,RollupInfo | Sort-Object RollupInfo,Version -desc | Format-Table -auto
(import-csv .\RflLists\ref__All_OS_2008R2_latest.csv ) |?{$_.Title -match ' '} | Select-Object Binary,Version,Article,Published,Branch,LDROnlyKB,LDROnlyLink,Comment,RollupInfo | Sort-Object RollupInfo,Version -desc | Format-Table -auto
(import-csv .\RflLists\ref__All_OS_2008_latest.csv ) |?{$_.Title -match ' '} | Select-Object Binary,Version,Article,Published,Branch,LDROnlyKB,LDROnlyLink,Comment,RollupInfo | Sort-Object RollupInfo,Version -desc | Format-Table -auto


ref__Except:
(import-csv .\RflLists\ref__Except_2012_latest.csv ) |?{$_.Title -match ' '} | Select-Object Binary,Version,Article,Published,Branch,LDROnlyKB,LDROnlyLink,Comment,RollupInfo | Sort-Object RollupInfo,Version -desc | Format-Table -auto
(import-csv .\RflLists\ref__Except_2008R2_latest.csv ) |?{$_.Title -match ' '} | Select-Object Binary,Version,Article,Published,Branch,LDROnlyKB,LDROnlyLink,Comment,RollupInfo | Sort-Object RollupInfo,Version -desc | Format-Table -auto

Title:
(import-csv .\RflLists\ref__All_OS_2012R2_latest.csv ) |?{$_.Title -match ' '} | Select-Object Binary,Version,Article,Published,Branch,Title,LDROnlyKB,LDROnlyLink,Comment,RollupInfo | Sort-Object Article -desc | Format-Table -auto
(import-csv .\RflLists\PreStaging\ref__All_OS_2008R2_latest.csv ) |?{$_.Title -match ' '} | Select-Object Binary,Version,Article,Published,Branch,Title,LDROnlyKB,LDROnlyLink,Comment,RollupInfo User | Format-Table -auto

Master:
(import-csv .\RflLists\PreStaging\ref__Master_201619H1_latest.csv ) |?{$_.Title -match ' '} | Select-Object Binary,Version,Article,Published,Branch,LDROnlyKB,LDROnlyLink,Comment,RollupInfo | Sort-Object Binary,Version -desc | Format-Table -auto

A) For Platform RFL lists (outdated: Non-OS RFL lists are handled different)
-------------------------
PHASE 0 (note: set $MovePuasFiles=0 for this step!)
1.a) Build monthly Master RFL list, run this script with parameters:
	 						run ".\RflLists\monthly_new-RFLReference_Tech_OS.ps1 Master all -verbose"
	  Output files are: \RflLists\PreStaging\Temp\ref__Master_<OS>_latestPRE.csv
1.b) Only build new Tech Template files, in case you added a binary to a Tech, or do it for 2016* each month, FIRST set $HfSgoOnline=0
	 						run ".\RflLists\monthly_new-RFLReference_Tech_OS.ps1 all all -verbose"
	  Output files are: \RflLists\PreStaging\Template\ref__<Tech>_<OS>_template.csv

1.c) MANUALLY: make sure last month \RflLists\ref__Master_<OS>_latest.csv includes information for new binaries added, i.e. Svhdxflt.sys, Qmgr.dll, Webio.dll

PHASE I (Except)
2. MANUALLY: Either update the files '\RflLists\PreStaging\ref__Except_<OS>_latest.csv' MANUALLY and proceed with PHASE II - or perform following steps:
2. Check if last month's RflLists\PreStaging\$RefYYlastMM\ref__Except_<OS>_latest.csv for each OS are still valid, to do so, run this script with parameters:
	a) Generate NEW Binary Exception csv files:
	aa) if none exists, build new based on section '## EXCEPT' below:
							run ".\RflLists\monthly_new-RFLReference_Tech_OS.ps1 Except all"
	  Output files are: 	 \RflLists\PreStaging\Temp\ref__Except_<OS>_latestPRE.csv
	ab) Adjust 'Component names' etc. with 3rd parameter Except
	  						run ".\RflLists\monthly_new-RFLReference_Tech_OS.ps1 Except all EXCEPT"
	  The output files are: \RflLists\PreStaging\Temp\ref__Except_<OS>_latestPRE.csv ?

	b) generate new Binary Exception csv files based on LAST month's list, with $HfSgoOnline=1:
	  if either an initial binaries file (see aa) is already built or when using the one from last month, use param3 to build from raw ref__Master_<OS>_latestPRE.csv:
							run ".\RflLists\monthly_new-RFLReference_Tech_OS.ps1 Except all BUILD -verbose"
	 ## The output files are: \RflLists\PreStaging\ref__Except_<OS>_latest.csv
	  The output files are: \RflLists\PreStaging\ref__Except_<OS>_latestPRE.csv ?
	  The output files are copied (for next month reference - do not edit) into:
				 \RflLists\PreStaging\ + $Ref20YYMM + "\ref__Except_"+ $OSshort +"_"+ $Ref20YYMM +".csv" - might be outdated after step c below

	c) Check if any binary changed from last month (i.e. a new Hotfix exists now for a binary which was on the exception list last month):
	  if there were changes necessary, correct the =>> RflLists\PreStaging\ref__Except_<OS>_latestPRE.csv for each OS
	  						run ".\RflLists\monthly_correct-RollupInfo_Tech_OS.ps1 Except all -verbose"
	  Output files are:  \RflLists\PreStaging\Temp\ref__Except_<OS>_latestPOST.csv
	  			\RflLists\PreStaging\ref__Except_<OS>_latest.csv <- this may be needed to be copeid to \RflLists\PreStaging\ + $Ref20YYMM +

	c) compare "\RflLists\PreStaging\$Ref20YYMM\" with "\RflLists\PreStaging\$RefYYlastMM\", if Bin-Ver is same, prod except from last month is still valid; if they have diff versions, decide if this month bin KB article is valid.
	  MANUALly check the new Except files in folder
	  \RflLists\PreStaging\$Ref20YYMM\ref__Except_<OS>_$Ref20YYMM.csv
	  then edit file in folder
	  \RflLists\PreStaging\ref__Except_<OS>_latest.csv

	d) Check against KBs Online:
	  						run ".\RflLists\monthly_check-KBs_Tech_OS.ps1 Except all"
	  Output check file is: \Check\PreStaging\!_Check_KB-Issues_RFL_Except_all_<YY-MM>.txt
	  Note: the counter in line 'Difference to last month: n' shows differences from last online checked KBs

	e?) check with "Windiff \RflLists\PreStaging\ref__Except_<OS>_latestPRE.csv \RflLists\ref__Except_<OS>_latest_<YY-MM>.csv"
 #see https://technet.microsoft.com/en-us/library/ee156812.aspx
 #Compare-Object


PHASE II (MasterFile + Techs)
3. Merge/Replace the binary exceptions derived from PHASE #1, and Correct the RollupInfo, run the script:
	a) 						run ".\RflLists\monthly_correct-RollupInfo_Tech_OS.ps1 Master all -verbose"
	  Output files are: \RflLists\PreStaging\Temp\ref__Master_<OS>_latestPOST.csv
	  		   \RflLists\PreStaging\ref__Master_<OS>_latest.csv
	Note: if you see PS error below, you have duplicte entries in Except file!
	..The property 'Comment' cannot be found on this object. Verify that the property exists and can be set.
	At P:\_New_RFL\RflLists\monthly_correct-RollupInfo_Tech_OS.ps1:176 char:5
       $ReplaceLine.Comment = "rEX"  # "rEX" = derived from r ...

4. OPTIONAL - if you work with already verified MANUAL Exceptions (see monthly_check-KBs_Tech_OS.ps1)
4. Run the script to check for expected binary versions in public KB articles:
	a) 						run ".\RflLists\monthly_check-KBs_Tech_OS.ps1 Master all"
	  watch progress in PS cmd for (red) errors - re-run command for affected OS in case of error
	  Output file is: \Check\PreStaging\!_Check_KB-Issues_RFL_Master_2008-2008R2-2012-2012R2_<date>.txt

5. Create all platform tech RFL lists, run this script:
  For testing/verifying first: $MoveProdFiles=0, $MovePuasFiles=0
  For production:		$MoveProdFiles=1, $MovePuasFiles=1
	a) 						run ".\RflLists\monthly_new-RFLReference_Tech_OS.ps1 all all BUILD"
	  Output files are: 	\RflLists\PreStaging\ref__<tech>_<OS>_latest.csv
  	  if $MoveProdFiles=1	\RflLists\ref__<tech>_<OS>_latest.csv

PHASE III (Production)
7. double-check, if Engineer RFL scripts produces expected outcome
	a) 						run ".\_New_RFL\check-rfl-csv_Tech_Path.ps1 [tech] [path to SDP folder]"


B) For Non-Platform RFL lists (Non-OS RFL lists, like Exchange, SQL, CM2007)
-----------------------------
Unless RFL champs update the .csv files directly (not recommended by now), you can convert the traditional V1 input *.txt files KB_info_<non-OS-tech>.txt into V2 format:
Example:  .\RflLists\make_NonOS_V2_from_V1_KB_info.ps1 CM2012RTM KB_info_CM2012RTM.txt -verbose
	  .\RflLists\make_NonOS_V2_from_V1_KB_info.ps1 all -verbose
	 Output files are: \RflLists\PreStaging\ref__<tech>_latest.csv / \RflLists\ref__<tech>_latest.csv

_____________________________
Changes necessary for new Window 10 version, in 11 Files: 4x monthly_*.ps1, check-RegistryKeyNames.ps1, check-rfl-*.ps1, get-events.ps1, get-latest-binary-version.ps1, get-pma.ps1, get-PStatSum.ps1
	Search and Replace:
	2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004
	2016,2016RS1,2016RS2,2016RS3,2016RS4,2016RS5,201619H1,201619H2,20162004
	"2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","201619H2","20162004"

Build version: 	RS2 10.0.15063
		RS3 10.0.16299
		RS4 10.0.17134
		RS5 10.0.17763
		19H1 10.0.18362
		19H2 10.0.18363
		2004 10.0.19041 // toDo
#>

<#
VERSION and AUTHOR:
    Ver 0.98; 21 July 2014;
    Ioan Corcodel 	- script logic 					- ioanc@microsoft.com
		Walter Eder 	- Net list + script improvement		- waltere@microsoft.com
		Josef Holzer	- Cluster + Core list			- josefh@microsoft.com
		Roland Wacker	- Dom list				- rolandw@microsoft.com
		http://hotfixsearch

HISTORY
	display path where the reference list will be saved
	add prio to each binary
	add component to each binary
	add "comment" column
	corrected GPP and ProfProc lines
	build logic to get if last version is LDR only or dual
	change branch to "LDR" or "LDRGDR"
	add columns - LDROnlyKB, LDROnlyTitle, LDROnlyLink
	2014-07-16 add $HypVNet to NET
	2014-07-18 add Core list, add HyperV list, progress-bar
	2014-07-20 consolidating 2008,2008R2,2012,2012R2 into one monthly_new-RFLReference_Tech_OS.ps1
		  add RDS list
	2014-07-22 add KB only entries in the reference list
		  added important KBs/rollup KBs, enabled $DbgOut i.e for get-kbonly
		  most recent rollup KBs are not found on http://hotfixsearch -> lists are incomplete -> done using KBOnlyRollup2012*.csv
	2014-07-23 add Print list, ** Note: informational KBs are not found, only Hotfix KBs
	2014-07-26 Build **unique* KB list from list of all KBs for binaries ->for customer emails
	2014-07-27 Avoid searching HotfixSearch for Rollup Kb for each tech build (use one common List to include) - NEEDS manual update monthly once.
	 	 -> for 2012*: Script picks up KBOnlyRollup2012*.csv and appends it to ref__RFL output file
		  Script picks up corrective KBOnly_<Tech>_<OS>.csv (if exists) and appends it to ref__RFL output file
	2014-08-13 get-help addition
		  Note: verify that the new Hotfix articles are public already (this could take a few days after patch Tuesday)
	2014-10-24 added funtionality for "Client"- RFL
	2014-11-04 added Client $KBOnlyClient2008R2
	2014-11-18 changed $CORE to include $VSS
	2014-11-29 Parameter input for Techs and OSs: Choose one or more (separated by comma), or 'all' (build_monthly_new-RFLReference_Techs.ps1 no more needed)
	2014-12-11 work with "Pre-Staging" Folder and .. move manually ref_*latest.csv later into production folder AFTER validation check.
	2015-01-21- after building *2012R2_latest.csv do a global replace:
		 --> ACTION: globally replace kb/2990852"," ","No Rollup" with kb/2990852"," ","14-11Rollup" for these binary lines in ref__*_2012R2_latest.csv
		 --> ACTION: globally replace kb/3000850"," ","No Rollup" with kb/3000850"," ","14-11Rollup" for these binary lines in ref__*_2012R2_latest.csv
		 --> also append correct "14-**Rollup" for all fixes with ($Title -match 'update rollup'), extract the $KB and Rollup info from table in KBOnlyRollup_2012R2.csv
		 => done, see new script monthly_correct-RollupInfo_Tech_OS.ps1
	2015-01-21 - backup *_latest.csv files at each run -> see \Prestaging\Temp\ folder (ref__<tech>_<OS>_YY-mm-dd_mm-ss.csv)
		 remove duplicate, added thru exception list:
		 for all exceptions manifested in KBOnly_Net_<OS>.csv, which are appended to _latest.csv remove duplicate binaries, keep the one on the bottom (before 2012* rollup fixes)
		 => almost done, changed build process, have only ONE file KBOnly_<OS>.csv per OS, grep binary and replace information,
		 see new script \Prestaging\monthly-replace-csv-lines.ps1, to be included in monthly_correct-RollupInfo_Tech_OS.ps1
		 - Instead of using KBOnly*.csv for each tech, built one excetion KB list per OS: KBOnly_Binaries_<OS>.csv, read in this list, if current binary is included in list, use this line
		 - Put some comment in "Comment" field, if RollupInfo YY-MMRollup has been found via http//bugcheck lookup ("rBC"= bugcheck, "rKB" = online KB, "rEX" = from Except file)

	2015-01-02 NET: added "Tdx.sys" to $NetProtocol
	2015-01-21 NET: added "Rastls.dll" to $IEEE802x
	2015-02-17 CORE: added "dedup.sys" to $CoreFS
		  --> need to update ref__net* , ref__client* on OS 2012* after successfull build of ref__master*
	2015-03-10 ran script with $MovePuasFiles=1 and $MoveProdFiles=1, the set back values to =0
		  - introduce new function to avoid duplicate searches on http://hotfixsearch, which compiles Client,HyCoClNe *_latest.csv from results of existing Techs
		  => done, we can now just search all binaries combined in Master DB
	2015-05-06 added $CoreDisk (Storport) to $Cluster
	2015-06-11 added $HNV = "HNV_Net","1","Rasapi32.dll","Mprapi.dll" -- for 2008R2 and 2012R2 $net, $HyCoClNe and $HyperV
			 $NetCfg = "Net_Config","1","Netcfgx.dll" -- for All_OS, NET and Client
			 --> need to update ref__net* , ref__HyperV* and ref__HyCoClNe* and ref__Client* after successfull build of ref__master*
		  Workaround for wrong title in HFS output: "__ HFS_bad_title_CTYPE and __ HFS_bad_LDRonly_title_CTYPE"
	2015-06-21 v1.11 - check / improve all 2012R2 results for "14-04Rollup" -> replace with "No Rollup" where apropriate; most likely: script to check online needs improvement for single fixes created in 2015+; perhaps check for release date of fix creation >2015?
		  => done in script monthly_correct-RollupInfo
		  FIX  - correct wrong LDRonly information = Rollup fixes in OS 2012 ( RegEx in Master.csv: "LDR".*Windows 8 and Windows Server 2012)
		  => setting "No LDR Only available" information if Rollup fix apeared in LDRonly
		  - do cosmetic changes: replace "&quot;" with a single " in the title of a KB article
		  - copy Master.csv to production folder (with name "All_OS.csv" according to Shell extension) - see script monthly_Correct-RollupInfo.ps1
	2015-09-09 v1.14 - added $NetWorkFolder "Net_WorkFolders" for NET
	2015-09-11 v1.15 - adding support for Windows10
	2015-09-14 v1.16 - adding support to build Tech template (Binaries, Component, Prio, important_KBs) from settings in this script without using HFSearch ($HfSgoOnline=0) - run ".\RflLists\monthly_new-RFLReference_Tech_OS.ps1 <Tech> <OS> -verbose" - Outfile is by now in \Prestaging ! => move to \RflLists (or perhaps temp folder)
	2015-09-15 v1.17 - changed order of "$_.binary -match $Tech_binary" in Function: build-new-RFL-lists-from-MasterCsv
			 - added template building for Techs (with accurate binaries + KBarticle), stored in PHASE 0 1.b) \RflLists\PreStaging\Template\ref__<Tech>_<OS>_template.csv
	2015-09-20 - for Win2012R2: if cumulative updates April+Nov are installed, omit May-Oct_2014 updates
	2015-09-25 - added binary Svhdxflt.sys in $ClusCSV2, qmgr.dll in $NetBITS, webio.dll BranchCache binaries in $BranchCache
	2015-10-04 done interim solution in check-rfl-csv_Tech_Path.ps1 v1.10 / check-rfl-csv_MultiTech_Path.ps1 v1.18
		  obsolete: - Get also GDR version from HFS, so that we can compare later, if Hotfix with GDR version is already installed (T-SYS issue)
		   -or- as an interim solution, check in script check-rfl-csv_Tech_Path.ps1 if GDR fix KB is installed, using SDP hotfix.txt ?
		   -or- mark in Branch column LDR or GDR, instead of Yes/No
		  - consider RFL list for OS Win2003 -> out of scope
	2015-10-14 - added binary Netbt.sys for 2012*
	2015-11-05 v1.20 - changed for OS 2012*,2016: '$query = "pub:FALSE|os:$HotfixSearchOS|bin:$bin"'
		  - RFL 2008R2 need update, see results of newer CX versions in Z:\115073012993309_Borodi\2015-09-29\Repro_29Sep_2015_DaimlerClient\SDP\Results_CLBEVMSO116_2015-09-29_17.09.19
		 done in script check-rfl-csv_Tech_Path with Telemetry feedback
	2015-11-09 added 2975061 in $KBOnlyCore2012R2, 2015-12-11 now superseeded by 3021910
	2015-11-10 - changed for all OS: '$query = "pub:FALSE|os:$HotfixSearchOS|bin:$bin"'
	2015-11-12 ** added $NetQoS "Pacer.sys", + HyperV Vmwp.exe
	2015-11-19 adding support for Win10/2016TH2
	2015-11-27 verify that production Master.csv is copied back correct (seems to fail if Master_PRE in \temp already exists --> delete Prestaging\temp\*.csv
	2015-12-08 build Except from Master
		- **2016-01-13 KBonly 3021910 for Win2012R2 has missing title on HFS! -> therefor missing in Template file (added manually for Core Clus HyperV* All_OS-2012R2)
		for Win7:
		3020369	April 2015 servicing stack update for Windows 7 and Windows Server 2008 R2
	2016-01-29 add $KBOnlyHyperV* - 3063283 Update to improve the backup of Hyper-V Integrated components in Hyper-V Server 2012 R2
	2016-02-01 **added $NetQoS "Pacer.sys", + Hyper-V_app Vmwp.exe
	2016-02-10 add $KBOnlyHyperV* - outdated 3063283 (Hyper-V Integration components) replaced with 3063109 'Virtual machine crashes ..'
	2016-02-14 v1.23 - Note: 2016TH2 needs to be built manually, as there are no binaries available on HFS
		  -> created script "monthly_new-Master-or-Except-FromCsv_OS.ps1 [2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|all]" to derive latest 2016* binaries for Master file from downloaded CSV
	2016-02-25 including for 2012: 3003729 April 2015 servicing stack update for Windows 8 and Windows Server 2012
			+ 3020369	April 2015 servicing stack update for Windows 7 and Windows Server 2008 R2
	2016-02-25 v1.24 Search important KBs in VKB instead of HotfixSearch (using new Function get-kbonly-fromVKB)
	2016-03-03 	adding $Win32kernel = ..,"win32k.sys"
	2016-03-07 	adding $IE_Cli = "IE_Client","0","MSHTML.DLL"
	2016-03-10	marking for add of KB3147099 for RDS2012R2 (and the binaries listed in 3147099, by David Rankin: $RDSgateway $RDSlicense $RDShost)
			  put in reminder to generate PUAS files at least every 3 month (Mar,Jun,Sep,Dec)
	2016-03-20	adding $HypVNet	= ..,"pvhdparser.sys"
	2016-04-08	adding Ntdsutil.exe
	2016-04-21	adding "Iphlpapi.dll"
	2016-05-18	substituting ent.rollup 2775511 with conv.pack 2775511,3125574,3156417
	2015-11-25 - get-local-RFL.ps1 - using get-hotfix etc. to check local system against RFL - in progress with get-MiniSDP.ps1
	2016-06-22 v1.25 reverting change above, added 2008R2 for appending Rollup info ( because of new Rollup packages for Win7 as of 2016 May)
	2016-07-11 	removed KB 2992611 from all 2008-R2, deleting references to 2614066,2555428, 2750841 and 2775511 as it is included in conv.pack 3125574, 2760730 moved to _history.txt
			added 3020369 (Servicing Stack because of pre-req for Conv-Pack 3125574) to KBOnlyRollup_2008R2.csv
	2016-07-13	adding kb 3004383 as PreRequ for Convenience Pack, 2775511 in KBOnlyRollup_2008R2.csv
	2016-08-03 	adding 2016RS1,
				substituting 3003729 with 3173426 Servicing Stack update for 2012, substituting 3021910 with 3173424 Servicing Stack update for 2012-R2
	2016-09-23 'write script get-latest-binary-version.ps1 to output latest version for all OS by binary input (or partly input)'
	2016-May Note: monthly Rollup csv files for 2012 and 2012R2 have two Space delimiter, need to globally replace ' ' with ' ' in Text-Editor first for correct operation of get-latest-binary-version.ps1 Rollup
	2017-01-22 Win10 RTM: March 26 is marked as the end date for support of the original Windows 10 edition
	2017-01-31 added "dpapisvr.dll"
	2017-03-15 #_#workaround_2017-03-15: adding "All_OS_<OS>_important_KB" to 'KBOnlyRollup_'+ $OSshort +'.csv', as workaround because get-kbonly-fromVKB doesn't work after Portico update
	2017-03-01 support for 2008CP = Convenience pack
	2017-04-01 adding 2016RS2
	2017-10-06 v1.26 adding 2016RS3
	2018-04-05 v1.27 adding 2016RS4

	ToDo: (in Prio order)
	2016-10-13 consider different lists for architecture x64/x86 as version numbers can differ for same binary
	2016-09-13 for Win2016* - check why * lserver.dll and some other files non-unique file-names don't show up with correct version --> System.Object
	2016-08-17 for Win7 after 16-09C: consider 3177467 Packages won't be re-evaluated after switch to single-branch servicing in Windows 7 SP1 and Windows Server 2008 R2 SP1
	2016-06-22	- consider to include Windows6.x-hypervintegrationservices-x64.cab in RFL
		- Except files are missing for running script 'monthly_new-RFLReference_Tech_OS.ps1' if building new master from HFS -- expected?
		- avoid 5xdouble-quote """"" in Masterfile (as a result of double substitute of entries in ref__Except_* file ?)
		- check if destination SDP folder is writable, else use temp path
		- combine Steps in "Order of Build Process" with less # of scripts?
		- block multiple simultanous script runs (from diff persons) by a Mutex ( if Block_file exists -> don't run at same time.., like done ins SDP report gathering)
		- $MovePuasFiles=1 only at one run per month (move the _latest file built a few weeks ago?)
		- perhaps Check if fixes are available on MS Catalog http://catalog.update.microsoft.com/
		- counter for "rBC" = found via http//bugcheck lookup
		- double-check the differences in master files of previous month compared to current month (using PS Compare-Object #see https://technet.microsoft.com/en-us/library/ee156812.aspx )
		- consider a stripped offline version for outsourcers
	2015-10-30 - need to evaluate the necessity of individual DB *.csv files, -> why not adjusting script check-rfl-csv_Tech_Path.ps1 to take only binaries of interest (Tech) from master DB?
	2018-03-14 	adding $HypVNet	= ..,"Wmisvc.dll"
	2018-04-05 adding 2016RS4
	2018-04-05	adding Net DirectAccess: Damgmt.dll

WSD Release Calendar:
https://insights/Report?id=01a0847e-efc1-4071-a0dc-f94a0440c1a8&isPublished=true#=undefined&inputReleaseDate=2020-07-21&_tab=0&Security=undefined&NonSecurity=undefined&Hotfix=undefined

#>

<#
.SYNOPSIS
The script generates RFL refence lists for [Net|Dom|Cluster|Core|VSS|HyperV|RDS|Print|Custom|HyCoClNe|SCVMM|SCVMM2012R2|Client|Exchange|Except|Master|CM2007|CM2012RTM|CM2012SP1|CM2012R2] - OS: Windows [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004]

SYNTAX: .\monthly_new-RFLReference_Tech_OS.ps1 [Net|Dom|Cluster|Core|VSS|HyperV|RDS|Print|Custom|HyCoClNe|SCVMM|SCVMM2012R2|Client|Exchange|Except|Master|CM2007|CM2012RTM|CM2012SP1|CM2012R2] [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004]

Remember for MANUAL BUILD:
  PHASE  0: adjust .\RflLists\KBOnlyRollup_20*.csv; + download *.csv file in monthly rollup KBs
  PHASE  I: .\RflLists\monthly_new-RFLReference_Tech_OS.ps1 Master all -verbose 	#(for master file, HfSgoOnline=1)
  +for 2016: .\RflLists\monthly_new-Master-or-Except-FromCsv_OS.ps1 [2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|all]
  	   .\RflLists\monthly_new-RFLReference_Tech_OS.ps1 all 2016,2016RS1,2016RS2,2016RS3,2016RS4,2016RS5,201619H1,201619H2,20162004 -verbose #(for building templates, HfSgoOnline=0)
  PHASE II: .\RflLists\monthly_correct-RollupInfo_Tech_OS.ps1 Master all -verbose 	#(for reading except files + correct-RollupInfo)
  PHASE IIa: .\RflLists\monthly_check-KBs_Tech_OS.ps1 Master all -verbose 		#(check if binary is listed in public KB)
       .\RflLists\monthly_new-RFLReference_Tech_OS.ps1 all all BUILD -verbose	#(for building all tech databases)
  PHASE III: test the new database files
  Remember to build Non-OS files once per quarter 03/06/09/12

.DESCRIPTION
This script can generate latest RFL refence lists (Net|Dom|Cluster|Core|VSS|HyperV|RDS|Print|Custom|HyCoClNe|SCVMM|SCVMM2012R2|Client|Exchange|Except|Master|CM2007|CM2012RTM|CM2012SP1|CM2012R2) for Windows 2008,2008R2,2012,2012R2,2016,2016RS1,2016RS2,2016RS3,2016RS4,2016RS5,201619H1,201619H2,20162004
using the Web-service http://hotfixsearch (or http://aka.ms/trackitbinarysearch) for latest binaries available in public Hotfixes.
The corresponding script check-rfl-csv_Tech_Path.ps1 will check the various RFL binaries for NET, DOM etc. against customer SDP report.

This script will generate a .csv file for NET, DOM etc. containing the latest version of the list of specific binaries.
The header of the CSV output file is:
|Binary|Component|Version|Prio|Published|Branch|Article|Title|Link|LDROnlyKB|LDROnlyTitle|LDROnlyLink|Comment|RollupInfo|

.EXAMPLE
.\monthly_new-RFLReference_Tech_OS.ps1 Custom 2012 [\\muc-vfs-01a\rfl\_New_RFL]

Script version v0.97
Generate RFL for: custom, OS Shortname: 2012 Longname: Windows 8/Windows Server 2012
Save file to -> \\emeacssdfs\netpodW$\rfl\ref__custom_2012_11-Jul-2014_23-38.csv
....DONE !

.LINK
email: ioanc@microsoft.com

#>

Param(
	[ValidateSet("net","dom","cluster","core","vss","HyperV","RDS","Print","SCVMM2012R2","HyCoClNe","Exchange","Client","Except","Master","All_OS","CM2007","CM2012RTM","CM2012SP1","CM2012SP2","CM2012R2","custom","all")]
	[Parameter(Mandatory=$False,Position=0,HelpMessage='Choose one or more technology separated by comma: [Net|Dom|Cluster|Core|VSS|HyperV|RDS|Print|Custom|HyCoClNe|SCVMM|SCVMM2012R2|Client|Exchange|Except|Master|All_OS|CM2007|CM2012RTM|CM2012SP1|CM2012R2|all]')]
	[string[]]$RFLTechs
,
	[ValidateSet("2008","2008CP","2008R2","2012","2012R2","2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","201619H2","20162004","all")]
	[Parameter(Mandatory=$False,Position=1,HelpMessage='Choose one or more OS separated by comma: [2008|2008R2|2012|2012R2|2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|all]')]
	[string[]]$OSshortList
,
	[ValidateSet("Except","Build","default")]
	[Parameter(Position=2,HelpMessage='What actions for RFL csv files? Choose one [Except|Build]')]
	[string]$RFLaction = "default"
,
	[ValidateScript({Test-Path $_ -PathType 'Container'})]
	[Parameter(Position=3,HelpMessage='Where do you want to save the Reference RFL file?')]
	[string]$RFLPath = "."
	)

Process
{

############################################################
## customization section of script
$LateChange=0 # set to 1, if you manually need to run the script for the last month
$RFLpath= 	"\\emeacssdfs.europe.corp.microsoft.com\netpodW$\rfl\RflLists\"	#default path is '.' unless user provided other path
$Puaspath= 	"\\emeacssdfs.europe.corp.microsoft.com\netpodW$\rfl\Puas\"
$MovePuasFiles=0 # CAUTION! move _latest.csv to _Puas_min_1.csv, move _Puas_min_1.csv to _Puas_min_2.csv
$MoveProdFiles=1 # CAUTION! set to "1" only if you wish to move new *.csv date to production immediatelly, "0" when you want to double check first and move manually
$HfSgoOnline=0	 # 1 = fetch info from http://HotfixSearch for Tech build
$RFLPrestagingPath		= $RFLpath + "PreStaging\"
$RFLPrestagingTempPath		= $RFLpath + "PreStaging\Temp\"
$RFLPrestagingTemplatePath	= $RFLpath + "PreStaging\Template\"
$DbgOut=0
$PickKBonly=0			# 1 = append KBonly*.csv, 0 = don't append -- this was used for exceptions per Tech, should be no more necessary now
$onScreen=0			# display table of previous and new Build csv files
############################################################
$Stats=1
$VerMa="1"
$VerMi="27"
$start = Get-Date
$CheckDate = (Get-Date -UFormat "%Y-%m-%d_%R").Replace(":","-")
$CountInvFil = "\\waltere-VDI\netpod\tools\RFL\count_mnRFL.dat"
# \\waltere-VDI\netpod\tools\RFL\ToDo_RFLupdates.csv ; file get info during rfl check , when binary in sdp is highr that in the rfl
$CountInvFil2 = $CountInvFil +'.us'
$Year		= (Get-Date -UFormat "%y").Replace(":","-")
$Month 		= (Get-Date -UFormat "-%m").Replace(":","-")
$LastMonth 	= Get-Date (Get-Date).AddMonths(-1) -f MM
$Ref20YYMM 	= (Get-Date -UFormat "%Y-%m").Replace(":","-")
$RefYYlastMM 		= ((Get-Date).AddMonths(-1)).ToString("yyyy-MM")
if ($LateChange) {$Year		= "20"
				$Month		= "-" + $LastMonth
				$Ref20YYMM	= "20" + $Year + $Month
				$YYMM		= $Year + $Month
				Write-host "LateChange: Ref20YYMM: $Ref20YYMM - YYMM: $YYMM "}

$Ref20YYMMpath = $RFLpath + $Ref20YYMM
 If((Test-Path $Ref20YYMMpath) -ne $true){ New-Item -Path $Ref20YYMMpath -ItemType directory }
$RefPreYYMMpath = $RFLPrestagingPath + $Ref20YYMM
#_# If((Test-Path $RefPreYYMMpath) -ne $true){ New-Item -Path $RefPreYYMMpath -ItemType directory }
#$RefPuasYYMMpath = $Puaspath + $RefYYlastMM
# If((Test-Path $RefPuasYYMMpath) -ne $true){ New-Item -Path $RefPuasYYMMpath -ItemType directory }

Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "Note: RefYYlastMM last month: '$RefYYlastMM'"
If ($PSBoundParameters[�Debug�]) { $DebugPreference='Continue'}


### Enable parameter 'all' for user input (Tech and OS)
if ($RFLTechs -ieq 'all'){
	[string[]]$RFLTechs = "Net","Dom","Cluster","Core","HyperV","RDS","VSS","Print","HyCoClNe","Client","All_OS"
	}
if ($OSshortList -ieq 'all'){
	[string[]]$OSshortList = "2008","2008R2","2012","2012R2","2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","201619H2","20162004"
	}

"`n_RFLTechs/OS: '$RFLTechs / $OSshortList / $RFLaction'"
### walk through each Tech in inputlist (like Core,Dom,Net)
foreach ($RFLTech in $RFLTechs){
	$startRFLTech = Get-Date
	foreach ($OSshort in $OSshortList){
		$startRFLTechOS = Get-Date

############################################################
# Function will fetch the latest RollupInfo of the binary based on bug id, from bugcheck; WindowsSE only database
$rollup="No Rollup"	##??
function Check-BugKBRollupInfo ($bug)
    {
    Write-Debug "Enter [Check-BugKBRollupInfo] WinSE $bug"
    $wc = New-Object System.Net.WebClient
		$wc.UseDefaultCredentials = $true
		$url = "http://bugcheck/bug/BugContent?bugid=$bug&dbName=WindowsSE"
    $page = $wc.DownloadString($url)
		$project = ($page -split '<Group Name="Project">')[1]
		$project = ($project -split '</Group><Group Name="Project2">')[0]
		$Key_Words = ($project -split '<Key_Words_>')[1]
		$Key_Words = ($Key_Words -split '</Key_Words_><Beta_ID_MSRC_ID>')[0]
		#$project
		if($Key_Words -notmatch 'Rollup=')
			{"No Rollup"}
		else{
			$rollup = ($Key_Words -split 'Rollup="')[1]
			$rollup = ($rollup -split '";')[0]
			$rollup
			}
	}

############################################################
# Function will lookup the latest binary version from HfS http://hotfixSearch (the WinSE hosted db that contains build data).
# Return binary version nr. ?
Function get-HfSversion ($bin,$prio,$component,$OSshort)
	{
	#!#!# "[get-HfSversion]..contacting Webservice http://HotfixSearch Query: pub:TRUE|os:$HotfixSearchOS|bin:$RFLTech"
	#!#!# Write-Debug "[get_HfSversion]...HfS Lookup: $bin $prio component $($OSshort)"
	Write-Debug "...[get-HfSversion] HfS Lookup: $bin $prio"
	# switch to user provided OS for use on http://HotfixSearch
	switch($OSshort)
		{
		"2008"		{$HotfixSearchOS="Windows Server 2008|SP:SP2"}
		"2008R2"	{$HotfixSearchOS="Windows 7/Windows Server 2008 R2|SP:SP1"}
		"2008CP"	{$HotfixSearchOS="Windows 7/Windows Server 2008 R2|SP:SP1"}
		"2012"		{$HotfixSearchOS="Windows 8/Windows Server 2012|SP:RTM"}
		"2012R2"	{$HotfixSearchOS="Windows 8.1/Windows Server 2012 R2|SP:RTM"}
		"2016"		{$HotfixSearchOS="Windows 10|SP:RTM"}
		"2016RS1"	{$HotfixSearchOS="Windows 10|SP:RTM"}	### toDo
		"2016RS2"	{$HotfixSearchOS="Windows 10|SP:RTM"}	### toDo
		"2016RS3"	{$HotfixSearchOS="Windows 10|SP:RTM"}	### toDo
		"2016RS4"	{$HotfixSearchOS="Windows 10|SP:RTM"}	### toDo
		"2016RS5"	{$HotfixSearchOS="Windows 10|SP:RTM"}	### toDo
		"201619H1"	{$HotfixSearchOS="Windows 10|SP:RTM"}	### toDo
		"201619H2"	{$HotfixSearchOS="Windows 10|SP:RTM"}	### toDo
		"20162004"	{$HotfixSearchOS="Windows 10|SP:RTM"}	### toDo
		}
		#Write-Verbose "...HotfixSearchOS: $HotfixSearchOS"
	# get our HotfixSearch service reference and call it
	$ws = New-WebServiceProxy -uri http://hotfixsearch:90/hotfixservice.asmx -UseDefaultCredential
	# query for published KBs or all (published and non-published)
	if($OSshort -match '2008__R2') {$query = "pub:TRUE|os:$HotfixSearchOS|bin:$bin"}	#2015-11-05 as long as convenience rollup is not ready for win7
	else {$query = "pub:FALSE|os:$HotfixSearchOS|bin:$bin"}					#2015-11-05 get latest updates, KB-title may not be avail on HFS
	Write-Debug "...[get-HfSversion] query = $query"
	$results = $ws.webSearchv2($query)

	$kbs = $results.Tables[0] | Sort-Object binaryversion -Descending| Select-Object kb,kbmajor,kbminor,branch,binaryname,binaryversion,kbtitle,date,bug

	if(($OSshort -eq '2012R2') -or ($OSshort -match '2016'))
		{ # change logic, because Win2012R2 contains only GDR hotfixes
		$lastKbLDR = $kbs|?{$_.branch -eq "GDR"}| Select-Object -First 1
		$lastKbGDR = $kbs|?{$_.branch -eq "LDR"}| Select-Object -First 1
		}
	else
		{
		$lastKbLDR = $kbs|?{$_.branch -eq "LDR"}| Select-Object -First 1
		$lastKbGDR = $kbs|?{$_.branch -eq "GDR"}| Select-Object -First 1
		}

	if($lastKbLDR.kb -ne $lastKbGDR.kb)
		{ # already found LDR only
		$lastKbLDRonly=$lastKbLDR
		}
	else
		{
		$kbLDR = $kbs|?{$_.branch -eq "LDR"}| Sort-Object -Descending kb
		$kbGDR = $kbs|?{$_.branch -eq "GDR"}| Sort-Object -Descending kb
		foreach ($ldr in $kbLDR)
			{
			if(($kbGDR| ForEach-Object{$_.kb}) -notcontains $ldr.kb)
				{$lastKbLDRonly=$ldr;break}	## WalterE: needs clarification, re. 2012 Rollup packages, which have both LDR and GDR?
			}
		}

	if(($OSshort -eq '2012R2') -or ($OSshort -match '2016'))
		{ # change logic, because Win2012R2 contains only GDR hotfixes
		if ($lastKbLDR -eq $lastKbLDRonly) {$branch="GDR"} else {$branch="LDRGDR"};
		}
	else	# for OS is 2008*,2012
		{
		if($lastKbLDR -eq $lastKbLDRonly){$branch="LDR"} else{$branch="LDRGDR"};
		}

	if($lastKbLDRonly)
		{
		$lastKbLDRonlyArticle= $lastKbLDRonly.kb.ToString() + " (v" + $lastKbLDRonly.kbmajor.ToString() + "." + $lastKbLDRonly.kbminor.ToString() + ")"
		$lastKbLDRonlyTitle = $lastKbLDRonly.kbtitle
		$lasktkbLDRonlyLink = 'http://support.microsoft.com/kb/' + ($lastKbLDRonly.kb.ToString())
		IF (($OSshort -NotMatch '2008') -and (($lastKbLDRonlyTitle -match "update rollup") -or ($lastKbLDRonlyTitle -match "cumulative update"))) {
			$lastKbLDRonlyArticle="No LDR Only available"
			$lastKbLDRonlyTitle="No LDR Only available"
			$lasktkbLDRonlyLink="No LDR Only available"
			}
		}
	else
		{
		$lastKbLDRonlyArticle="No LDR Only available"
		$lastKbLDRonlyTitle="No LDR Only available"
		$lasktkbLDRonlyLink="No LDR Only available"
		}
	if (($OSshort -eq '2012R2') -or ($OSshort -match '2016')) { # there are no LDRonly fixes for 2012R2
		$lastKbLDRonlyArticle="No LDR Only available"
		$lastKbLDRonlyTitle="No LDR Only available"
		$lasktkbLDRonlyLink="No LDR Only available"
		}

	### fetch RollupInfo from Bugcheck for OS 2012/2012R2
	if ($OSshort -match '2012')
		{
		[int]$bugID = $lastKbLDR.bug
		$rollup = Check-BugKBRollupInfo ($bugID)	# call function
		$lastKbLDRonlyComment = " "
		if ($rollup -NotMatch "No Rollup") {
				Write-Debug "...RollupInfo found by BugCheck: WinSE-$($bugID) - Rollup: $rollup"
				$lastKbLDRonlyComment = 'rBC'}	# "rBC" : RollupInfo found by BugCheck
		}
	else	{$lastKbLDRonlyComment = " "} #fill comment for 2008*

	### Workaround for wrong title in HFS output -- search for correct title will be done in script monthly_check-KBs_Tech_OS.ps1
	if (($lastKbLDR.kbtitle -match "CTYPE") -or ($lastKbLDR.kbtitle -eq "")) {
			Write-verbose "$bin -- __ HFS_bad_title_CTYPE __"
			$lastKbLDR.kbtitle = "HFS_bad_title_CTYPE"}
	if (($lastKbLDRonlyTitle -match "CTYPE") -or ($lastKbLDRonlyTitle -eq "")) {
			Write-verbose "$bin -- __ HFS_bad_LDRonly_title_CTYPE __"
			$lastKbLDRonlyTitle ="HFS_bad_LDRonly_title_CTYPE"}
	### finally...
	$lastKbLDR|
		select 	@{Label="Binary";Expression={$_.binaryname}},
		@{Label="Component";Expression={$component}},
		@{Label="Version";Expression={$_.binaryversion}},
		@{Label="Prio";Expression={$prio}},
		@{Label="Published";Expression={$date = Get-Date($_.date) -format d;$date}},
		@{Label="Branch";Expression={$branch}},
		@{Label="Article";Expression={$_.kb.ToString() + " (v" + $_.kbmajor.ToString() + "." + $_.kbminor.ToString() + ")"}},
		@{Label="Title";Expression={$_.kbtitle}},
		@{Label="Link";Expression={'http://support.microsoft.com/kb/' + ($_.kb.ToString())}},
		@{Label="LDROnlyKB";Expression={$lastKbLDRonlyArticle}},
		@{Label="LDROnlyTitle";Expression={$lastKbLDRonlyTitle}},
		@{Label="LDROnlyLink";Expression={$lasktkbLDRonlyLink}},
		@{Label="Comment";Expression={$lastKbLDRonlyComment}},
		@{Label="RollupInfo";Expression={$rollup}}

} # end function get-HfSversion

############################################################
# Function will fetch KB information from http://hotfixsearch
Function get-kbonly ($kb,$prio,$component)
{
$ws = New-WebServiceProxy -uri http://hotfixsearch:90/hotfixservice.asmx -UseDefaultCredential
$query = "pub:TRUE|os:$HotfixSearchOS|kba:$kb"
$results = $ws.webSearchv2($query)
$kbs = $results.Tables[0] | Sort-Object date -Descending| Select-Object kb,kbmajor,kbminor,branch,kbtitle,date| Select-Object -First 1

$kbs | Select-Object @{Label="Binary";Expression={$_.kb}},
	@{Label="Component";Expression={$component}},
	@{Label="Version";Expression={"KBOnlyVersion"}},
	@{Label="Prio";Expression={$prio}},
	@{Label="Published";Expression={$date = Get-Date($_.date) -format d;$date}},
	@{Label="Branch";Expression={$_.branch}},
	@{Label="Article";Expression={$_.kb.ToString() + " (v" + $_.kbmajor.ToString() + "." + $_.kbminor.ToString() + ")"}},
	@{Label="Title";Expression={$_.kbtitle}},
	@{Label="Link";Expression={'http://support.microsoft.com/kb/' + ($_.kb.ToString())}},
	@{Label="LDROnlyKB";Expression={"KB only"}},
	@{Label="LDROnlyTitle";Expression={"KB only"}},
	@{Label="LDROnlyLink";Expression={"KB Only"}},
	@{Label="Comment";Expression={" "}},
	@{Label="RollupInfo";Expression={$rollup}}
if (-not $kbs) {Write-Host -BackgroundColor Yellow -ForegroundColor Black -NoNewline -Object ".$kb" -Separator .}
}
############################################################
# Function will fetch KB information from VKB
Function get-kbonly-fromVKB ($PublicKB,$prio,$component)
{
  	try
  	{
  	$ws = $null
	$ws = Invoke-WebRequest "https://vkbexternal.partners.extranet.microsoft.com/VKBWebService/ViewContent.aspx?scid=KB;EN-US;$PublicKB" -UseDefaultCredentials
	## internal.support.services.microsoft.com
	$PublicKB_title = $ws.ParsedHtml.title
	$PublicKB_title = [regex]::Split($PublicKB_title,"- ")[1]	# when using vkbexternal
	Write-Verbose "__Title: $PublicKB $PublicKB_title"
	$outerText 	= $ws.ParsedHtml.body.outerText
  	#$firstPublished = ($outerText|findstr /C:"First Published").Split(":")[2]
  	$revision 	= ($outerText | Select-String "Revision.*" | ForEach-Object { $_.Matches } | ForEach-Object { $_.Value } ).split(":")[1]
  	$revision 	= $revision.replace("`n","").replace("`r","")
  	$lastRevised 	= ($outerText | Select-String "Last Revised.*" | ForEach-Object { $_.Matches } | ForEach-Object { $_.Value } ).Split(":")[2]
  	$lastRevised 	= $lastRevised.replace("`n","").replace("`r","")
  	$Article 	= $PublicKB.ToString()+ ' (v' +$revision.ToString()+ ')'
  	#$Article	= $Article.replace("`n","").replace("`r","")
  	$Link 		= 'http://support.microsoft.com/kb/' + ($PublicKB.ToString())
	$kbs 		= "$PublicKB,$component,,$prio,$lastRevised,,$revision,$PublicKB_title"
	Write-verbose "_kb: $PublicKB _Rev: $revision _Date: $lastRevised "
	$kbs | Select-Object @{Label="Binary";Expression={$PublicKB}},
		@{Label="Component";Expression={$component}},
		@{Label="Version";Expression={"KBOnlyVersion"}},
		@{Label="Prio";Expression={$prio}},
		@{Label="Published";Expression={$lastRevised.ToString()}},
		@{Label="Branch";Expression={"GDR"}},
		@{Label="Article";Expression={$Article}},
		@{Label="Title";Expression={$PublicKB_title}},
		@{Label="Link";Expression={$Link}},
		@{Label="LDROnlyKB";Expression={"KB only"}},
		@{Label="LDROnlyTitle";Expression={"KB only"}},
		@{Label="LDROnlyLink";Expression={"KB only"}},
		@{Label="Comment";Expression={" "}},
		@{Label="RollupInfo";Expression={"No Rollup"}}
	if (-not $kbs) {Write-Host -BackgroundColor Yellow -ForegroundColor Black -NoNewline -Object ".$PublicKB" -Separator .}
	Write-Debug "KBs $kbs"
    }
    catch
    {
      # retry above?
      Write-Error "Could not read KB$PublicKB . The error was '$($_.Exception.Message)'"
      ### Write Error to log
    }
    finally
    {
      #Write-Debug"Error retrieving KB$PublicKB"
  	}
}

############################################################
# Function: compare-binary-with-exception
# -> compare two csv files by binary name
# Output: diff binaries
function compare-binary-with-exception ($csv_file,$Except_file,$item)
{
  switch($item)
	{
	"Binary"	{$csv_file.binary | Select-Object -uniq | ? { $Except_file.binary -contains $_ } }
	"Article"	{$csv_file.article | Select-Object -uniq | ? { $Except_file.article -contains $_ } }
	}
	#$csv_file.binary | Select-Object -uniq | ? { $Except_file.binary -contains $_ }
	#$csv_file.binary | Select-Object -uniq | ? { $Except_file.binary -match $_ }
}

############################################################
# Function: replace-binary-with-exception
# Result: replace the line containing the binary.name
function replace-binary-with-exception ($csv_file,$Master_file)
{
 foreach ($line in $csv_file)
	{
	Write-debug "`n...processing KB: $($line.Article) Binary: $($line.Binary)"
	[string]$common_binaries = compare-binary-with-exception $csv_file $Master_file "Binary"
	Write-debug "`ncommon_binaries: $common_binaries `n"
	if ($line.Binary -notmatch "[1-9][0-9][0-9][0-9][0-9]")
	 { # processing binaries, no KB#'s
		if ( "$($common_binaries)" -match "$($line.binary)" )
			{
			#Write-debug "*** Exception-Record: '$($common_binaries)' for Binary: $($line.binary)"
			Write-debug " OriginalLine: $line"
			 $ReplaceLine = $Master_file | Where-Object { $line.binary -match $_.binary }
			 #$ReplaceLine.Comment ="rKB"	# "rKB" = verified by public KB info
			 #$ReplaceLine.Component = $line.Component
			Write-debug " -> ReplaceLine: $ReplaceLine"
			$line = $ReplaceLine
			#$line
	 		}
		#else { Write-debug " keep orig binary csv line"
		#	$line = $ReplaceLine
		#	#$line
		#	}
	 }
	else # ($line.Binary -match "[1-9][0-9][0-9][0-9][0-9]")
		{ # processing KB#'s, no binaries
		#Write-debug "keep orig KB / $OSshortList Rollup csv line"
		$line
		}
	} # end foreach
} #end function

############################################################
# Function will fetch last version for binaries per Tech component, or create template with all binaries needed for <tech>
# -> this func invokes func get-HfSversion
# Output: writes binary line into $csvTempPath
# Example: $TechGroup = $Custom = $Custom1,$Custom2,$Custom3
Function get-last-version-for-TechGroup ($TechGroup,$HfSgoOnline)
	{
	write-debug "Enter [get-last-version-for-TechGroup HfSgoOnline: $HfSgoOnline]"
	foreach($comp in $TechGroup)			#Example: $TechGroup = $ProfProc_Cli = "Dom_ProfProc","0","Profprov.dll","Profsvc.dll"
		{
		Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "." -Separator .
		$Bin_Component = $comp[0]		# Binary
		$prio = $comp[1]			# Prio
		$count = $comp.Count			# count of list
		$binary_names = $comp[2..$count]	# list of binary-names
		Write-Debug "[get-last-version-for-TechGroup] Mod: $($comp[0]) Prio: $($comp[1]) Bins: $($comp[2..$count]) " #!#!# - $TechGroup"

		foreach ($i in $binary_names)
			{
			if($i -isnot [int32]) {# working on 'binary'
				if (($HfSgoOnline) -or ($RFLTechs -match "Master")) { # ignore $HfSgoOnline for building Master list
					get-HfSversion $i $prio $Bin_Component $OSshort |Export-Csv -Append -Path $csvTempPath -NoTypeInformation # call func get-HfSversion
				}
				else { # if $HfSgoOnline=0 do not go online for binaries
					# create template with all binaries needed for <tech>
					Write-Verbose " $i ___HfSgoOnline 1=Yes: $HfSgoOnline"
					$obj1 = new-object PSObject -Property @{Binary=$i;Component=$Bin_Component;Version="";Prio=$Prio;Published="";Branch="";Article="";Title="";Link="";LDROnlyKB="";LDROnlyTitle="";LDROnlyLink="";Comment="";RollupInfo=""}
				  	$obj1 | Select-Object Binary,Component,Version,Prio,Published,Branch,Article,Title,Link,LDROnlyKB,LDROnlyTitle,LDROnlyLink,Comment,RollupInfo |Export-Csv -Append -Path $csvTempPath -NoTypeInformation} # template only
			}
			else	{ # working on KB article
				if($DbgOut) {get-kbonly-fromVKB $i $prio $Bin_Component }
			#_#workaround_2017-03-15	else	  {get-kbonly-fromVKB $i $prio $Bin_Component |Export-Csv -Append -Path $csvTempPath -NoTypeInformation}
				}
			if($DbgOut) {Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "$i !" -Separator "!"}
			}
		}
} #end function get-last-version-for-TechGroup

###################################################################################################################################################
# Function: execute-monthly-new-RFL
function execute-monthly-new-RFL ($RFLTechs,$OSshortList)
{
 Write-Output "__Building RFL list for $RFLTech $OSshort"
  Write-Output "_2_Building RFL list for $RFLTech $OSshortList - GoOnline: $HfSgoOnline"
 if ($HfSgoOnline) {"..contacting Webservice http://HotfixSearch Query: pub:TRUE|os:$OSshort|bin:$RFLTech"}
 $startexeRFL = Get-Date

##_______________________________________________________________________________________________________________________________

## Definitions of RFL Binaries for Techs ##
############################################################
## NET - NETWORKING - List of RFL binaries
## maintained by: waltere - last-revised: 2015-09-10
##### $KBOnlyNet*OS can have only comma separated list of Hotfix KB#s, which are found in VKB (previously on HotfixSearch)

#$Kernel see Core	= "Net_Kernel","0","Ntoskrnl.exe","Ntkrnlpa.exe","Crashdmp.sys"
#$NetFileSystem # see $CoreFS 	= "Net_FileSystem","0","Ntfs.sys"
$SMBServer 		= "Net_SMB_Server","0","srv.sys","srv2.sys","srvnet.sys","Srvsvc.dll"
$SMBClient 		= "Net_SMB_Client","0","Mrxsmb.sys","Mrxsmb10.sys","Mrxsmb20.sys","Rdbss.sys","Netbt.sys","Mup.sys","wkssvc.dll"
$NetProtocol		= "Net_Protocol","0","Tcpip.sys","Afd.sys","Netio.sys","Ndis.sys","Netiohlp.dll","Tdx.sys","Iphlpapi.dll" #,"Fwpkclnt.sys"
$IPv6			= "Net_IPv6","1","Tunnel.sys","Dhcpcore6.dll","Dhcpcsvc6.dll"
$NLA			= "Net_NLA","0","Nlasvc.dll","Ncsi.dll","Nlaapi.dll"
#$NTLM #see Dom		= "Net_NTLM","1","Msv1_0.dll"
$DNSSrv 		= "Net_DNS_Srv","0","Dns.exe"
$DHCPSrv 		= "Net_DHCP_Srv","0","Dhcpssvc.dll"
$DFSNSrv		= "Net_DFS-N_Srv","0","Dfssvc.exe"
$NFSSrv 		= "Net_NFS_Srv","0","Nfssvc.exe","Nfssvr.sys","Msnfsflt.sys","portmap.sys","rpcxdr.sys"
$NLBSrv 		= "Net_NLB_Srv","0","Nlb.sys"
$CSC 			= "Net_CSC_Offline","1","Csc.sys","Cscapi.dll","Cscdll.dll","Cscsvc.dll","Cscmig.dll","Cscui.dll"
$WebDAV			= "Net_WebDAV","1","Mrxdav.sys","Webclnt.dll","Davclnt.dll","Shell32.dll","Winhttp.dll"
$DFSNCli		= "Net_DFS-N_Client","0","Dfsc.sys"
$DHCPCli 		= "Net_DHCP_Client","1","Dhcpcore.dll","Dhcpcsvc.dll"
#$GPP	#see Dom	= "Net_GPP","1","Gpprefcl.dll","Gpme.dll","Gppref.dll","Gpprefbr.dll","Gpprefcn.dll","Gpregistrybrowser.dll","Propshts.dll" #see DOM
#$ProfProc		= "Net_ProfProc","1","Profprov.dll","Profsvc.dll" 	#see DOM
#$KERBEROS		= "Net_Kerberos_Client","0","Kerberos.dll"		#see DOM
$NFSCli 		= "Net_NFS_Client","1","Nfsclnt.exe","Nfsnp.dll","Nfsrdr.sys"
$Posix			= "Net_Posix","1","Psxdll.dll","Psxdllsvr.dll","Psxss.exe","Posix.exe"
$DNSCli 		= "Net_DNS_Client","1","dnsapi.dll","dnsrslvr.dll","Dnscacheugc.exe"
$Rpc 			= "Net_RPC","1","Rpcss.dll","Rpchttp.dll","Rpcrt4.dll"
$IpsecBFE 		= "Net_Ipsec_BFE","1","Bfe.dll","Ikeext.dll","Fwpuclnt.dll"
$DACli 			= "Net_DirectAccess_Client","1","Iphlpsvc.dll","Iphlpsvcmigplugin.dll","Netcorehc.dll","Daotpcredentialprovider.dll","Rdpcore.dll"
$DASrv 			= "Net_DirectAccess_Srv","1","Damgmt.dll","Ramgmtui.exe","Ramgmtsvc.dll","Rasclusterres.dll","Raserverpsprovider.dll"
$IEEE802x		= "Net_IEEE802.1x","1","dot3svc.dll","Rastls.dll"
# $HypVNet #see HyperV	= "Net_Hyper-V_Net","1","Vmswitch.sys","Mslbfoprovider.sys","Wnv.sys","Vmsntfy.dll","Ndisimplatform.sys","Vmms.exe","Winnat.sys"	#see HyperV
$NetAppl 		= "Net_Applications","1","Robocopy.exe"
$NetCfg 		= "Net_Config","1","Netcfgx.dll"
$WLAN 			= "Net_WLAN_Client","1","wlansvc.dll","wlanmsm.dll","wlanapi.dll","wlansec.dll","wlansvcpal.dll","wlanhlp.dll"
$NetWorkFolder 		= "Net_WorkFolders","1","WorkFolders.exe","WorkFoldersshell.dll","WorkFolderssvc.dll","WorkFolderscontrol.dll","WorkFoldersGPExt.dll","Syncsharesvc.dll","Syncsharesrv.dll","Syncsharettlib.dll","Syncsharettsvc.exe"
$BranchCache		= "Net_BranchCache","1","WebIo.dll","Smbhash.exe"
$NetQoS			= "Net_QoS","1","Pacer.sys"
$Firewall		= "Net_Firewall","1","Mpsdrv.sys","MpsSvc.dll"
$NetBITS 		= "Net_BiTS","1","qmgr.dll"

### KBOnly component format:
# $KBOnly = "KBOnly description","<prio>",<list of KB number without quotation marks, comma separated>
# e.g. $KBOnlyNet2008R2	= "KBOnlyNet2008R","0",2775511,2639043
# NOTE: only Hotfix KBs are found and added, no informational KBs !

$KBOnlyNet2008		= "Net_2008_important_KB","0",2760730,2862566,2780879
$KBOnlyNet2008R2	= "Net_2008R2_important_KB","0" #,3004383 #,2780879 #,2965917 //3004383	High CPU usage by an application that depends on a Microsoft LDAP client in Windows Server 2008 R2 SP1
#$KBOnlyNet2012		= "Net_2012_important_KB","0",2842111 #,2957623 # because of wrong V4 fix "2878635 (v4.0)"
$KBOnlyNet2012R2	= "Net_2012R2_important_KB","0",3123245,3149157

############################################################
## CLUSTER - List of RFL binaries
## maintained by: josefh;virgivi - last-revised: 2014-07-25
##### $KBOnlyCluster*OS can have only comma separated list of Hotfix KB#s, which are found in VKB (previously on HotfixSearch)

$ClusterCore		= "Cluster_Core","0","Clussvc.exe","ClusWMI.dll","Rhs.exe","Clusres.dll","Clusres2.dll","Netft.sys","Clusauthmgr.dll","Witness.dll"
$ClusCSV1		= "Cluster_CSV","0","Csvflt.sys","Csvfs.sys"
$ClusCSV2		= "Cluster_CSV","0","Csvfilter.sys","Vhdmp.sys","Svhdxflt.sys"
#$ClusDisk		= "Cluster_Disk","0","Clusdisk.sys","Volsnap.sys"
$ClusDisk1		= "Cluster_Disk","0","Clusdisk.sys"
$ClusVolsnap		= "Cluster_Volsnap","0","Volsnap.sys"
$ClusterValidation	= "Cluster_Validation","1","Cprepsrv.exe","Failoverclusters.agent.interop.dll","Microsoft.failoverclusters.framework.dll"
#$KBOnlyCluster2008	= "Cluster_2008_important_KB","0" #,2447854
$KBOnlyCluster2008R2	= "Cluster_2008R2_important_KB","0" #,3004383
$KBOnlyCluster2012	= "Cluster_2012_important_KB","0",3173426 #3003729 #,2929078,2935616,2901896,2920193 # because of wrong V4 fix "2878635 (v4.0)"
$KBOnlyCluster2012R2	= "Cluster_2012R2_important_KB","0",3173424

############################################################
## HYPERV - List of RFL binaries
## maintained by: robertvi;adelinao - last-revised: 2014-07-25
##### $KBOnlyHyperV*OS can have only comma separated list of Hotfix KB#s, which are found in VKB (previously on HotfixSearch)

#$HypVdisk # see Cluster = "Hyper-V_Disk","0","Volsnap.sys"
#$HypVCSV # see Core	= "Hyper-V_CSV","0","Csvflt.sys","Csvfs.sys"
$HypVNet		= "Hyper-V_Net","1","Vmswitch.sys","Mslbfoprovider.sys","Wnv.sys","Vmsntfy.dll","Ndisimplatform.sys","Vmms.exe","Winnat.sys","pvhdparser.sys","Wmisvc.dll","Vmbus.sys"
$HNV			= "HNV_Net","1","Rasapi32.dll","Mprapi.dll"
$HypVapp		= "Hyper-V_app","1","Vmwp.exe"
$HyperV2008		= "Hyper-V_2008","0","Hvax64.exe","Hvboot.sys","Hvix64.exe","Vid.dll","Vmbuspipe.dll","Vmbusvdev.dll","Vmwpctrl.dll"
$KBOnlyHyperV2008	= "Hyper-V_2008_important_KB","0"
$KBOnlyHyperV2008R2	= "Hyper-V_2008R2_important_KB","0" #,3004383
$KBOnlyHyperV2012R2	= "Hyper-V_2012R2_important_KB","0",3173424,3063109
$KBOnlyHyperV2016	= "Hyper-V_2016_important_KB","0"

$KBOnlyHyCoClNe2008R2 	= "HyCoClNe_2008R2_important_KB","0" #,3004383
$KBOnlyHyCoClNe2012 	= "HyCoClNe_2012_important_KB","0",3173426
$KBOnlyHyCoClNe2012R2 	= "HyCoClNe_2012R2_important_KB","0",3173424,3063109

############################################################
## CORE - List of RFL binaries
## maintained by: josefh;khirschb; holgerh (VSS) - last-revised: 2014-08-07
##### $KBOnlyCore*OS can have only comma separated list of Hotfix KB#s, which are found in VKB (previously on HotfixSearch)

$Kernel 		= "Core_Kernel","0","Ntoskrnl.exe","Ntkrnlpa.exe","Crashdmp.sys"
$KernelFiles 		= "Core_Kernel","0","Ntdll.dll","Hal.dll","Fltmgr.sys"
$Win32kernel 		= "Core_Kernel","0","win32k.sys"
$CoreFS 		= "Core_FileSystem","0","Ntfs.sys","dedup.sys"
$DiskSystem 		= "Core_DiskSystem","0","Msiscsi.sys","Iscsitgt.dll"
$CoreDisk 		= "Core_DiskSystem","0","Storport.sys"
$WMI			= "Core_WMI","0","Repdrvfs.dll"
$MPIO 			= "Core_MPIO","0","Mpio.sys","Msdsm.sys"
$CoreVSS		= "Core_VSS","1","Vssapi.dll","Vsstrace.dll","vsssvc.exe","Swprv.dll","spp.dll","wbengine.exe","blbsrv.dll"
$CoreSys		= "Core_Sys","1","pci.sys","Termdd.sys","Volmgr.sys"
$CoreApps 		= "Core_Apps","0","Advapi32.dll"
$TimeZone 		= "Core_TimeZone","1","Tzres.dll"
#$CRYPTO # see Domain	= "Dom_CRYPTO","1","Crypt32.dll","Cryptsvc.dll","Cryptnet.dll","Wintrust.dll","Cryptdll.dll","Cryptcatsvc.dll"

$KBOnlyCore2008		= "Core_2008_important_KB","0"
$KBOnlyCore2008R2	= "Core_2008R2_important_KB","0" #,3004383 #,2965917
$KBOnlyCore2012		= "Core_2012_important_KB","0",3173426
$KBOnlyCore2012R2	= "Core_2012R2_important_KB","0",3173424

############################################################
## DOM - DOMAINS - List of RFL binaries
## maintained by: rolandw - last-revised: 2014-09-30
##### $KBOnlyDom*OS can have only comma separated list of Hotfix KB#s, which are found in VKB (previously on HotfixSearch)

$NETLOGON 		= "Dom_NETLOGON","0","Netlogon.dll","LogonCli.dll"
$WINLOGON		= "Dom_WINLOGON","0","Winlogon.exe"
$KERBEROS		= "Dom_KERBEROS","0","Kerberos.dll"
$NTLM 			= "Dom_NTLM","1","Msv1_0.dll"
$LDAPClient		= "Dom_LDAPClient","0","Wldap32.dll"
$LSA			= "Dom_LSA","0","Lsass.exe","Lsasrv.dll","Ksecdd.sys","Ksecpkg.sys","Secur32.dll","Sspicli.dll","Sspisrv.dll","Schannel.dll","dpapisvr.dll"
$SecAuditAndConfig	= "Dom_SecAuditAndConfig","1","Scesrv.dll","AclUI.dll"
$SCProvider		= "Dom_SC_Provider","1","Winscard.dll","Basecsp.dll","Scksp.dll"
$SCSrv			= "Dom_SC_Srv","1","ScardSvr.dll","Scfilter.sys","Certprop.dll"
$CRYPTO			= "Dom_CRYPTO","1","Crypt32.dll","Cryptsvc.dll","Cryptnet.dll","Wintrust.dll","Cryptdll.dll","Cryptcatsvc.dll"
$DIMS			= "Dom_DIMS","1","Dimsroam.dll","Dimsjob.dll","Adprovider.dll","Capiprovider.dll","Cngprovider.dll","Dpapiprovider.dll","Wincredprovider.dll"
$GPSVC			= "Dom_GPSVC","1","Gpapi.dll","Gpsvc.dll","Gpmgmt.dll","Gprsop.dll","Userenv.dll"
$GPExt			= "Dom_GPExt","1","Gpprnext.dll","Appmgmts.dll"
$GPP			= "Dom_GPP","1","Gpprefcl.dll","Gpme.dll","Gppref.dll","Gpprefbr.dll","Gpprefcn.dll","Gpregistrybrowser.dll","Propshts.dll"
#$WMIDom see Core    	= "Dom_WMI",1,"Repdrvfs.dll"
$ProfProc		= "Dom_ProfProc","1","Profprov.dll","Profsvc.dll"
$FolderRedirDom		= "Dom_FolderRedir","1","Fdeploy.dll"
#$CSCDom  #see NET	= "Dom_CSC","1","Csc.sys","Cscapi.dll","Cscdll.dll","Cscsvc.dll","Cscmig.dll","Cscui.dll"
$ESENT			= "Dom_ESENT","0","Esent.dll"
$NTDSAI			= "Dom_NTDSAI","0","Ntdsai.dll","Ntdsutil.exe"	#2016-04-08
#$Dom_Tools		= "Dom_Tools","1","Ntdsutil.exe"	#2016-04-08
$SAMSRV			= "Dom_SAMSRV","0","Samsrv.dll","Samlib.dll"
$KDCSVC			= "Dom_KDCSVC","0","Kdcsvc.dll"
$DFSR			= "Dom_DFS-R","0","Dfsrs.exe","Dfsrress.dll","Dfsrro.sys"
$ADFS			= "Dom_ADFS","0","Microsoft.identityserver.service.dll","Microsoft.identityserver.webhost.dll","Microsoft.identityserver.web.dll","Microsoft.identityserver.dll","Microsoft.identityserver.proxyservice.exe"

$KBOnlyDom2008		= "Dom_2008_important_KB","0",2992611	#2992611=MS14-066, 3018238= followup fix, but included in 2992611
$KBOnlyDom2008R2	= "Dom_2008R2_important_KB","0" #,3004383
$KBOnlyDom2012		= "Dom_2012_important_KB","0",2992611
$KBOnlyDom2012R2	= "Dom_2012R2_important_KB","0",2992611

############################################################
## RDS - Remote Desktop Services - List of RFL binaries
## maintained by: robertvi - last-revised: 2014-07-25
##### $KBOnlyRDS*OS can have only comma separated list of Hotfix KB#s, which are found in VKB (previously on HotfixSearch)

$RDSremApp		= "RDS_remote_App","0","Rdpshell.exe","Rdsdwmdr.dll","Tscfgwmi.dll"
$RDSdevRdr		= "RDS_devRdr","1","Audioeng.dll","Audiokse.dll","Audioses.dll","Audiosrv.dll" #,"Rdpvideominiport.sys"
$RDSmsTsc		= "RDS_msTsc","1","Wsepno.dll","Xpsgdiconverter.dll"
$RDSvHost		= "RDS_vHost","0","Vmrdvcore.dll","Tsvmhasvc.dll","Tssdis.exe"
$RDSgateway		= "RDS_gateway","1","aaedge.dll"
$RDSlicense		= "RDS_license","1","lserver.dll","licmgr.exe"
$RDShost		= "RDS_host","1","dxgkrnl.sys","sessenv.dll"
$RDS2008		= "RDS_2008","0","termsrv.dll","Sdclient.dll","Tssdjet.dll","Tsconfig.dll"
$RDS2008R2		= "RDS_2008R2","0","termsrv.dll","RDPWD.SYS","Winsta.dll","rdpcorekmts.dll","rdpdr.sys","termdd.sys","Userenv.dll","ntkrnlmp.exe"
$KBOnlyRDS2008		= "RDS_2008_important_KB","0"
$KBOnlyRDS2008R2	= "RDS_2008R2_important_KB","0",2601888 #,3004383	# fixed 2016-03-08 - note! 2601888 does not exist on HFS, so this will not work, -> put in KB_info_RDS_2008R2.txt
$KBOnlyRDS2012R2	= "RDS_2012R2_important_KB","0",2933664 #,3147099

############################################################
## PRINT - Printing - List of RFL binaries
## maintained by: bhogen - last-revised: 2014-07-25
##### $KBOnlyPrint*OS can have only comma separated list of Hotfix KB#s, which are found in VKB (previously on HotfixSearch)

$PrintSpool		= "Print_Spool","0","Localspl.dll","Win32spl.dll","Spoolss.dll","Spoolsv.exe","Winspool.drv"
$PrintApp		= "Print_App","0","Ntprint.exe","Printui.dll","Printcom.dll","Printfilterpipelineprxy.dll","Printfilterpipelinesvc.exe","Printbrm.exe","splwow64.exe"
$PrintDrv		= "Print_Driver","1","Mxdwdrv.dll","Pcl4res.dll","Pscript5.dll","Unidrv.dll","Unires.dll","Xpssvcs.dll"
#$PrintShrd		= "Print_Shared","1","Cryptnet.dll","Cryptsvc.dll" #/removed 2014-12-11
$KBOnlyPrint2008	= "Print_2008_important_KB","0"
$KBOnlyPrint2008R2	= "Print_2008R2_important_KB","0" #,3004383

############################################################
## SCVMM - System Center 2012 - List of RFL binaries
## maintained by: walterWe - last-revised: 2014-04-01
##### $KBOnlySCVMM*OS can have only comma separated list of Hotfix KB#s, which are found in VKB (previously on HotfixSearch)

$SCVMM1			= "SCVMM_1","1","Vmms.exe","AdtAgent.exe"
$SCVMM2			= "SCVMM_2","1","ClientShared.dll"
$KBOnlySCVMM2012	= "SCVMM_2012R2_important_KB","0"
$KBOnlySCVMM2012R2	= "SCVMM_2012R2_important_KB","0",2802159

############################################################
## CM - Configuration Manager - List of RFL binaries: none, does not work with HotfixSearch
## maintained by: jensg - last-revised: 2014-05-12
# $CM2007 need to have minimum 2 components !!!
##### $KBOnlyCM2007 can have only comma separated list of Hotfix KB#s, which are found in VKB (previously on HotfixSearch)

$CM2007			= "CM_2007_SP2","0","Ntfs.sys"
$CM2012RTM		= "CM_2012_RTM","0","Ntfs.sys"
$CM2012SP1		= "CM_2012_SP1","0","Ntfs.sys"
$CM2012R2		= "CM_2012_R2","0","Ntfs.sys"
$KBOnlyCM2007		= "CM_2007_SP2_important_KB","0"
$KBOnlyCM2012RTM	= "CM_2012_RTM_important_KB","0"
$KBOnlyCM2012SP1	= "CM_2012_SP1_important_KB","0"
$KBOnlyCM2012R2		= "CM_2012_R2_important_KB","0"

############################################################
## EXCHANGE - Exchange Server - List of RFL binaries
## maintained by: NourdinB - last-revised: 2014-06-18
##### $KBOnlyExchange*OS can have only comma separated list of Hotfix KB#s, which are found in VKB (previously on HotfixSearch)

$Exch_OS1		= "Exchange_OS","1","system.dll"
$Exch_OS2		= "Exchange_OS","1","Cryptdll.dll","Cng.sys"
$KBOnlyExchange2008	= "Exch_2008_important_KB","0"
$KBOnlyExchange2008R2	= "Exch_2008R2_important_KB","0"
$KBOnlyExchange2012	= "Exch_2012_important_KB","0"
$KBOnlyExchange2012R2	= "Exch_2012R2_important_KB","0"

############################################################
## CUSTOM
# $custom need to have minimum 2 components !!!
#### $KBOnlyCustom*OS can have only comma separated list of Hotfix KB#s, which are found in VKB (previously on HotfixSearch)

$Custom1		= "RDS_license","0","lserver.dll","licmgr.exe"
$Custom2		= "RDS_host","1","win32k.sys","dxgkrnl.sys","sessenv.dll","profsvc.dll"
$Custom3		= "RDS_gateway","0","aaedge.dll"
$KBOnlyCustom2008	= "Custom_2008_important_KB","0",2862566
$KBOnlyCustom2008R2	= "Custom_2008R2_important_KB","0"
$KBOnlyCustom2012	= "Custom_2012_important_KB","0",2937350
$KBOnlyCustom2012R2	= "Custom_2012R2_important_KB","0",2919442
$KBOnlyCustom2016	= "Custom_2016_important_KB","0"

############################################################
## EXCEPT 	- Binaries per OS, which were incorrect last month on http://HotfixSearch
## maintained by: waltere - last-revised: 2015-03-09
$KBOnlyExcept1		= "KBonly_Except","0"
$KBOnlyExcept2		= "KBonly_Except","0"
$KBOnlyExcept2008	= "KBonly_Except_2008","0","srv.sys","crypt32.dll","cryptsvc.dll","cryptnet.dll","ntfs.sys","wbengine.exe"
$KBOnlyExcept2008R2	= "KBonly_Except_2008R2","0","repdrvfs.dll","advapi32.dll","ndis.sys","nlb.sys","rdpshell.exe","nlasvc.dll","ncsi.dll","nlaapi.dll","winlogon.exe","lsasrv.dll","ksecpkg.sys","secur32.dll","schannel.dll","crypt32.dll","cryptsvc.dll","cryptnet.dll","wintrust.dll","clussvc.exe","cluswmi.dll","audioeng.dll","audiokse.dll","audioses.dll","audiosrv.dll"
$KBOnlyExcept2008CP	= "KBonly_Except_2008CP","0"
$KBOnlyExcept2012	= "KBonly_Except_2012","0","cluswmi.dll","witness.dll","csvflt.sys","Csvvbus.sys","rdbss.sys","bfe.dll","ikeext.dll","msv1_0.dll","kerberos.dll","winlogon.exe","lsasrv.dll","audiokse.dll"
$KBOnlyExcept2012R2	= "KBonly_Except_2012R2","0","lsasrv.dll","ksecpkg.sys","kerberos.dll","srv2.sys","profsvc.dll","ntoskrnl.exe","ntdll.dll","nlaapi.dll"
$KBOnlyExcept2016	= "KBonly_Except_2016","0"
$KBOnlyExcept2016RS1	= "KBonly_Except_2016RS1","0"
$KBOnlyExcept2016RS2	= "KBonly_Except_2016RS2","0"
$KBOnlyExcept2016RS3	= "KBonly_Except_2016RS3","0"
$KBOnlyExcept2016RS4	= "KBonly_Except_2016RS4","0"
$KBOnlyExcept2016RS5	= "KBonly_Except_2016RS5","0"
$KBOnlyExcept201619H1	= "KBonly_Except_201619H1","0"
$KBOnlyExcept201619H2	= "KBonly_Except_201619H2","0"
$KBOnlyExcept20162004	= "KBonly_Except_20162004","0"

############################################################
## MASTER file 	- all Binaries of Platform / OS
## is being the basis to generate individual <Tech>_<OS>*latest.csv in offline mode
## maintained by: waltere - last-revised: 2015-01-21
######## = combination of
## MASTER NET - List of RFL binaries
## MASTER CLUSTER - List of RFL binaries
## MASTER HYPERV - List of RFL binaries
## MASTER CORE - List of RFL binaries
## MASTER DOM - DOMAINS - List of RFL binaries
## MASTER RDS - Remote Desktop Services - List of RFL binaries
## MASTER PRINT - Printing - List of RFL binaries
# end Master __________________

$KBOnlyAll_OS2008R2 	= "All_OS_2008R2_important_KB","0",2601888 #,3004383 // 2601888	Available Updates for Remote Desktop Services (Terminal Services) on Windows Server 2008 R2 SP1
$KBOnlyAll_OS2012 	= "All_OS_2012_important_KB","0",3173426
$KBOnlyAll_OS2012R2 	= "All_OS_2012R2_important_KB","0",3173424,3123245,3063109 #,2992611

############################################################
## Client - CLIENT OS - List of RFL binaries
## maintained by: MMark - last-revised: 2014-10-30
##### $KBOnlyNet*OS can have only comma separated list of Hotfix KB#s, which are found in VKB (previously on HotfixSearch)
# some modules may seem duplicate, but have different Prio

# Dom (different Prio)
$DIMS_Cli		= "Dom_DIMS","0","Dimsroam.dll","Dimsjob.dll","Adprovider.dll","Capiprovider.dll","Cngprovider.dll","Dpapiprovider.dll","Wincredprovider.dll"
$GPSVC_Cli		= "Dom_GPSVC","0","Gpapi.dll","Gpsvc.dll","Gpmgmt.dll","Gprsop.dll","Userenv.dll"
$GPExt_Cli		= "Dom_GPExt","0","Gpprnext.dll","Appmgmts.dll"
$GPP_Cli		= "Dom_GPP","0","Gpprefcl.dll","Gpme.dll","Gppref.dll","Gpprefbr.dll","Gpprefcn.dll","Gpregistrybrowser.dll","Propshts.dll"
$ProfProc_Cli		= "Dom_ProfProc","0","Profprov.dll","Profsvc.dll"
$FolderRedirDom_Cli	= "Dom_FolderRedir","0","Fdeploy.dll"
# Net (different Prio)
$CSC_Cli		= "Net_CSC Offline","0","Csc.sys","Cscapi.dll","Cscdll.dll","Cscsvc.dll","Cscmig.dll","Cscui.dll"
$WebDAV_Cli		= "Net_WebDAV","0","Mrxdav.sys","Webclnt.dll","Davclnt.dll","Shell32.dll","Winhttp.dll"
$DHCP_Cli 		= "Net_DHCP_Client","0","Dhcpcore.dll","Dhcpcsvc.dll"
$DNS_Cli 		= "Net_DNS_Client","0","dnsapi.dll","dnsrslvr.dll","Dnscacheugc.exe"
$IE_Cli 		= "IE_Client","0","Mshtml.dll"

$KBOnlyClient2008	= "Client_Vista_important_KB","0",2614066
$KBOnlyClient2008R2	= "Client_Win7_important_KB","0",2601888 #,3004383  #,2965917
$KBOnlyClient2012	= "Client_Win8_important_KB","0"	# out of support
$KBOnlyClient2012R2	= "Client_Win8.1_important_KB","0",3173424

############################################################
## defining RFL component list for: Net|Dom|Cluster|Core|VSS|HyperV|RDS|Print|Custom|HyCoClNe|SCVMM|SCVMM2012R2|Client|Exchange|Except|Master|CM2007|CM2012RTM|CM2012SP1|CM2012R2

$Master		= $NetAppl,$SMBServer,$SMBClient,$NetProtocol,$IPv6,$NLA,`
			$DNSSrv,$DHCPSrv,$DFSNSrv,$NFSSrv,$NLBSrv,$CSC,$WebDAV,`
			$DFSNCli,$DHCPCli,$NFSCli,$Posix,$DNSCli,$Rpc,$IpsecBFE,$DACli,$DASrv,$IEEE802x,$WLAN,$NetCfg,$NetWorkFolder,$BranchCache,$NetQoS,$Firewall,$NetBITS,`
		$NETLOGON,$WINLOGON,$KERBEROS,$NTLM,$LDAPClient,$LSA,$SecAuditAndConfig,$SCProvider,`
			$SCSrv,$CRYPTO,$DIMS,$GPSVC,$GPExt,$GPP,$ProfProc,$FolderRedirDom,`
			$ESENT,$NTDSAI,$SAMSRV,$KDCSVC,$DFSR,$ADFS,`
		$ClusterCore,$ClusCSV1,$ClusCSV2,$ClusDisk1,$ClusVolsnap,$ClusterValidation,`
		$Kernel,$KernelFiles,$Win32kernel,$CoreFS,$DiskSystem,$CoreDisk,$WMI,$MPIO,$CoreApps,$CoreVSS,$CoreSys,$TimeZone,`
		$HypVNet,$HNV,$HypVapp,`
		$RDSremApp,$RDSdevRdr,$RDSmsTsc,$RDSvHost,$RDSgateway,$RDSlicense,$RDShost,`
		$PrintSpool,$PrintApp,$PrintDrv,$IE_Cli
#$All_OS		= $Master
$Net 		= $Kernel,$CoreFS,$NetAppl,$SMBServer,$SMBClient,$NetProtocol,$IPv6,$NLA,$NTLM,`
			$DNSSrv,$DHCPSrv,$DFSNSrv,$NFSSrv,$NLBSrv,$CSC,$WebDAV,`
			$DFSNCli,$DHCPCli,$GPP,$ProfProc,$KERBEROS,$NFSCli,$Posix,$DNSCli,$Rpc,$IpsecBFE,$DACli,$DASrv,$IEEE802x,$WLAN,$NetCfg,$HNV,$BranchCache,$NetQoS,$Firewall,$NetBITS

$Dom		= $NETLOGON,$WINLOGON,$KERBEROS,$NTLM,$LDAPClient,$LSA,$SecAuditAndConfig,$SCProvider,`
			$SCSrv,$CRYPTO,$DIMS,$GPSVC,$GPExt,$GPP,$WMI,$ProfProc,$FolderRedirDom,$CSC,`
			$ESENT,$NTDSAI,$SAMSRV,$KDCSVC,$DFSR,$ADFS

$Cluster	= $ClusterCore,$ClusCSV1,$ClusCSV2,$ClusDisk1,$ClusVolsnap,$ClusterValidation,$MPIO,$CoreDisk

$Core		= $Kernel,$KernelFiles,$Win32kernel,$CoreFS,$DiskSystem,$CoreDisk,$WMI,$MPIO,$CoreApps,$CoreVSS,$ClusVolsnap,$CoreSys,$CRYPTO,$TimeZone
$VSS		= $Kernel,$CoreVSS,$ClusVolsnap,$CoreSys,$CRYPTO

$HyperV		= $ClusVolsnap,$ClusCSV1,$HypVNet,$HNV,$HypVapp

$RDS		= $Kernel,$Win32kernel,$RDSremApp,$RDSdevRdr,$RDSmsTsc,$RDSvHost,$RDSgateway,$RDSlicense,$RDShost,$ProfProc

$Print		= $PrintSpool,$PrintApp,$PrintDrv #,$PrintShrd /removed 2014-12-11

$SCVMM		= $SCVMM1,$SCVMM2

$CM2007		= $CM2007,$KBOnlyCM2007
$CM2012RTM	= $CM2012RTM,$KBOnlyCM2012RTM
$CM2012SP1	= $CM2012SP1,$KBOnlyCM2012SP1
$CM2012R2	= $CM2012R2,$KBOnlyCM2012R2

$Exchange	= $Exch_OS1,$Exch_OS2

## $Custom need to have minimum 2 components !!!
# >> use this short list for testing
$Custom 	= $Custom1,$Custom2,$Custom3

## $Except* need to have minimum 2 components !!!
# >> use this list for doublecheck whether there are updated binaries now available on http://HotfixSearch
$Except 	= $KBOnlyExcept1,$KBOnlyExcept2

# HyperV Cluster with Core and Net
$HyCoClNe 	= $Kernel,$KernelFiles,$Win32kernel,$CoreFS,$DiskSystem,$CoreDisk,$WMI,$MPIO,$CoreVSS,$CoreSys,$CoreApps,$TimeZone,`
		$ClusterCore,$ClusCSV1,$ClusCSV2,$ClusDisk1,$ClusVolsnap,$ClusterValidation,`
		$HypVNet,$HNV,$HypVapp,`
		$NetProtocol,$SMBServer,$SMBClient

# Definitions for Client report
$Client		= $NETLOGON,$WINLOGON,$KERBEROS,$NTLM,$LDAPClient,$LSA,$SecAuditAndConfig,$SCProvider,`
		$SCSrv,$CRYPTO,$DIMS_Cli,$GPSVC_Cli,$GPExt_Cli,$GPP_Cli,$ProfProc_Cli,$FolderRedirDom_Cli,`
		$ESENT,$NTDSAI,$SAMSRV,`
		$SMBClient,$NetProtocol,$DFSNCli,$CSC_Cli,$WebDAV_Cli,$DHCP_Cli,$DNS_Cli,$Rpc,$IpsecBFE,$DACli,$IEEE802x,$WLAN,$NetCfg,$HNV,$IPv6,$BranchCache,$NetQoS,$Firewall,`
		$Kernel,$KernelFiles,$Win32kernel,$CoreFS,$DiskSystem,$CoreDisk,$WMI,$CoreApps,$IE_Cli

############################################################
#Add important/rollup KB-only to each speciality, depending on OS version
switch($OSshort)
	{
	"2008"		{$Net	=$Net 		+ ,$KBOnlyNet2008
			 $Dom	=$Dom 		+ ,$KBOnlyDom2008
			 $Cluster=$Cluster 	#+ ,$KBOnlyCluster2008
			 $Core	=$Core 		+ ,$KBOnlyCore2008
			 $HyperV=$HyperV 	+ ,$HyperV2008 + ,$KBOnlyHyperV2008
			 $RDS	=$RDS 		+ ,$RDS2008 + ,$KBOnlyRDS2008
			 $Print	=$Print 	+ ,$KBOnlyPrint2008
			 $Custom=$Custom 	+ ,$KBOnlyCustom2008
			 $Exchange=$Exchange 	+ ,$KBOnlyExchange
 			 $Client=$Client 	+ ,$KBOnlyClient2008
 			 $Except=$Except 	+ ,$KBOnlyExcept2008
 			 $All_OS=$Master
			}
	"2008R2"	{$Net	=$Net 		+ ,$KBOnlyNet2008R2
			 $Dom	=$Dom 		+ ,$KBOnlyDom2008R2
			 $Cluster=$Cluster 	+ ,$KBOnlyCluster2008R2
			 $Core	=$Core 		+ ,$KBOnlyCore2008R2
			 $HyperV=$HyperV 	+ ,$HyperV2008 + ,$KBOnlyHyperV2008R2
			 $RDS	=$RDS 		+ ,$RDS2008R2 + ,$KBOnlyRDS2008R2
			 $Print	=$Print 	+ ,$KBOnlyPrint2008R2
			 $Custom=$Custom 	+ ,$KBOnlyCustom2008R2
			 $Exchange=$Exchange 	+ ,$KBOnlyExchange
 			 $Client=$Client 	+ ,$KBOnlyClient2008R2
 			 $Except=$Except 	+ ,$KBOnlyExcept2008R2
 			 $All_OS=$Master 	+ ,$KBOnlyAll_OS2008R2
 			 }
	"2008CP"	{$Net	=$Net 		+ ,$KBOnlyNet2008R2
			 $Dom	=$Dom 		+ ,$KBOnlyDom2008R2
			 $Cluster=$Cluster 	+ ,$KBOnlyCluster2008R2
			 $Core	=$Core 		+ ,$KBOnlyCore2008R2
			 $HyperV=$HyperV 	+ ,$HyperV2008 + ,$KBOnlyHyperV2008R2
			 $RDS	=$RDS 		+ ,$RDS2008R2 + ,$KBOnlyRDS2008R2
			 $Print	=$Print 	+ ,$KBOnlyPrint2008R2
			 $Custom=$Custom 	+ ,$KBOnlyCustom2008R2
			 $Exchange=$Exchange 	+ ,$KBOnlyExchange
 			 $Client=$Client 	+ ,$KBOnlyClient2008R2
 			 $Except=$Except 	+ ,$KBOnlyExcept2008R2
 			 $All_OS=$Master 	+ ,$KBOnlyAll_OS2008R2
 			 }
	"2012"		{$Net	=$Net 		+ ,$HypVNet # + ,$KBOnlyNet2012
			 $Dom	=$Dom		+ ,$KBOnlyDom2012
			 $Cluster=$Cluster 	+ ,$KBOnlyCluster2012
			 $Core	=$Core		+ ,$KBOnlyCore2012
			 $HyperV=$HyperV
			 $HyCoClNe=$HyCoClNe	+ ,$KBOnlyHyCoClNe2012
			 $RDS	=$RDS
			 $Print	=$Print
			 $SCVMM =$SCVMM 	+ ,$KBOnlySCVMM2012
			 $Custom=$Custom 	+ ,$KBOnlyCustom2012
			 $Exchange=$Exchange 	+ ,$KBOnlyExchange
 			 $Client=$Client 	+ ,$KBOnlyClient2012
 			 $Except=$Except 	+ ,$KBOnlyExcept2012
 			 $All_OS=$Master	+ ,$KBOnlyAll_OS2012
 			 }
	"2012R2"	{$Net	=$Net 		+ ,$HypVNet + ,$NetWorkFolder + ,$KBOnlyNet2012R2
			 $Dom	=$Dom		+ ,$KBOnlyDom2012R2
			 $Cluster=$Cluster	+ ,$KBOnlyCluster2012R2
			 $Core	=$Core 		+ ,$KBOnlyCore2012R2
			 $HyperV=$HyperV 	+ ,$KBOnlyHyperV2012R2
			 $HyCoClNe=$HyCoClNe 	+ ,$KBOnlyHyCoClNe2012R2
			 $RDS	=$RDS 		+ ,$KBOnlyRDS2012R2
			 $Print	=$Print
			 $SCVMM =$SCVMM 	+ ,$KBOnlySCVMM2012R2
			 $Custom=$Custom 	+ ,$KBOnlyCustom2012R2
			 $Exchange=$Exchange 	+ ,$KBOnlyExchange
 			 $Client=$Client 	+ ,$KBOnlyClient2012R2
 			 $Except=$Except	+ ,$KBOnlyExcept2012R2
 			 $All_OS=$Master	+ ,$KBOnlyAll_OS2012R2
 			 }
	"2016"		{$Net	=$Net 		+ ,$HypVNet + ,$NetWorkFolder
			 $Dom	=$Dom
			 $Cluster=$Cluster
			 $Core	=$Core
			 $HyperV=$HyperV
			 $RDS	=$RDS
			 $Print	=$Print
			 $SCVMM =$SCVMM
			 $Custom=$Custom 	+ ,$KBOnlyCustom2016
			 $Exchange=$Exchange
 			 $Client=$Client
 			 $Except=$Except	+ ,$KBOnlyExcept2016
 			 $All_OS=$Master
 			 }
	"2016RS1"	{$Net	=$Net 		+ ,$HypVNet + ,$NetWorkFolder
			 $Dom	=$Dom
			 $Cluster=$Cluster
			 $Core	=$Core
			 $HyperV=$HyperV
			 $RDS	=$RDS
			 $Print	=$Print
			 $SCVMM =$SCVMM
			 $Custom=$Custom
			 $Exchange=$Exchange
 			 $Client=$Client
 			 $Except=$Except	+ ,$KBOnlyExcept2016RS1
 			 $All_OS=$Master
 			 }
	"2016RS2"	{$Net	=$Net 		+ ,$HypVNet + ,$NetWorkFolder
			 $Dom	=$Dom
			 $Cluster=$Cluster
			 $Core	=$Core
			 $HyperV=$HyperV
			 $RDS	=$RDS
			 $Print	=$Print
			 $SCVMM =$SCVMM
			 $Custom=$Custom
			 $Exchange=$Exchange
 			 $Client=$Client
 			 $Except=$Except	+ ,$KBOnlyExcept2016RS2
 			 $All_OS=$Master
 			 }
	"2016RS3"	{$Net	=$Net 		+ ,$HypVNet + ,$NetWorkFolder
			 $Dom	=$Dom
			 $Cluster=$Cluster
			 $Core	=$Core
			 $HyperV=$HyperV
			 $RDS	=$RDS
			 $Print	=$Print
			 $SCVMM =$SCVMM
			 $Custom=$Custom
			 $Exchange=$Exchange
 			 $Client=$Client
 			 $Except=$Except	+ ,$KBOnlyExcept2016RS3
 			 $All_OS=$Master
 			 }
	"2016RS4"	{$Net	=$Net 		+ ,$HypVNet + ,$NetWorkFolder
			 $Dom	=$Dom
			 $Cluster=$Cluster
			 $Core	=$Core
			 $HyperV=$HyperV
			 $RDS	=$RDS
			 $Print	=$Print
			 $SCVMM =$SCVMM
			 $Custom=$Custom
			 $Exchange=$Exchange
 			 $Client=$Client
 			 $Except=$Except	+ ,$KBOnlyExcept2016RS4
 			 $All_OS=$Master
 			 }
 	"2016RS5"	{$Net	=$Net 		+ ,$HypVNet + ,$NetWorkFolder
 			 $Dom	=$Dom
 			 $Cluster=$Cluster
 			 $Core	=$Core
 			 $HyperV=$HyperV
 			 $RDS	=$RDS
 			 $Print	=$Print
 			 $SCVMM =$SCVMM
 			 $Custom=$Custom
 			 $Exchange=$Exchange
 			 $Client=$Client
 			 $Except=$Except	+ ,$KBOnlyExcept2016RS5
 			 $All_OS=$Master
 			 }
 	"201619H1"	{$Net	=$Net 		+ ,$HypVNet + ,$NetWorkFolder
 			 $Dom	=$Dom
 			 $Cluster=$Cluster
 			 $Core	=$Core
 			 $HyperV=$HyperV
 			 $RDS	=$RDS
 			 $Print	=$Print
 			 $SCVMM =$SCVMM
 			 $Custom=$Custom
 			 $Exchange=$Exchange
 			 $Client=$Client
 			 $Except=$Except	+ ,$KBOnlyExcept201619H1
 			 $All_OS=$Master
 			 }
 	"201619H2"	{$Net	=$Net 		+ ,$HypVNet + ,$NetWorkFolder
 			 $Dom	=$Dom
 			 $Cluster=$Cluster
 			 $Core	=$Core
 			 $HyperV=$HyperV
 			 $RDS	=$RDS
 			 $Print	=$Print
 			 $SCVMM =$SCVMM
 			 $Custom=$Custom
 			 $Exchange=$Exchange
 			 $Client=$Client
 			 $Except=$Except	+ ,$KBOnlyExcept201619H2
 			 $All_OS=$Master
 			 }
  	"20162004"	{$Net	=$Net 		+ ,$HypVNet + ,$NetWorkFolder
  			 $Dom	=$Dom
  			 $Cluster=$Cluster
  			 $Core	=$Core
  			 $HyperV=$HyperV
  			 $RDS	=$RDS
  			 $Print	=$Print
  			 $SCVMM =$SCVMM
  			 $Custom=$Custom
  			 $Exchange=$Exchange
  			 $Client=$Client
  			 $Except=$Except	+ ,$KBOnlyExcept20162004
  			 $All_OS=$Master
 			 }
 		}

############################################################
## switch to correct technology from user input
$TechGroup = $RFLTech
switch($TechGroup)
	{
	"net"		{$TechGroup = $Net}
	"dom"		{$TechGroup = $Dom}
	"cluster"	{$TechGroup = $Cluster}
	"core"		{$TechGroup = $Core}
	"vss"		{$TechGroup = $VSS}
	"hyperv"	{$TechGroup = $HyperV}
	"RDS"		{$TechGroup = $RDS}
	"Print"		{$TechGroup = $Print}
	"SCVMM"		{$TechGroup = $SCVMM}
	"SCVMM2012R2"	{$TechGroup = $SCVMM2012R2}
	"HyCoClNe"	{$TechGroup = $HyCoClNe}
	"Exchange"	{$TechGroup = $Exchange}
	"Client"	{$TechGroup = $Client}
	"CM2007"	{$TechGroup = $CM2007}
	"CM2012RTM"	{$TechGroup = $CM2012RTM}
	"CM2012SP1"	{$TechGroup = $CM2012SP1}
	"CM2012R2"	{$TechGroup = $CM2012R2}
	"custom"	{$TechGroup = $Custom}
	"Except"	{$TechGroup = $Except}
	"All_OS"	{$TechGroup = $All_OS}
	"Master"	{$TechGroup = $Master}
#	"help"	{"Choose technologie from : Net|Dom|Cluster|Core|VSS|HyperV|RDS|Print|Custom|HyCoClNe|SCVMM|Client|Exchange|Except|Master|CM2007|CM2012RTM|CM2012SP1|CM2012R2"}
	}
Write-Debug "OSshort: $OSshort : RflTech $RFLTech"

############################################################
## without user input, default Save path is current working dir "."
if($RFLPath.EndsWith("\")){$RFLPath=$RFLPath}
else{$RFLPath=$RFLPath +'\'}

$RefCsvDate 		= (Get-Date -UFormat "%Y-%m-%d_%R").Replace(":","-")
$csvTempPath 		= $RFLPrestagingTempPath+"ref__"+$RFLTech+"_"+$OSshort+"_"+$RefCsvDate+".csv"
$csvPathLatestPRE 	= $RFLPrestagingTempPath+"ref__"+$RFLTech+"_"+$OSshort+"_latestPRE.csv"
$csvTechTemplatePath 	= $RFLPrestagingTemplatePath + "ref__"+$RFLTech+"_"+$OSshort+"_template.csv"
$ProductionTechCsvPath 	= $RFLPath + "ref__"+$RFLTech+"_"+$OSshort+"_latest.csv"
$csvPuas_min_1_Path 	= $PuasPath + "ref__"+$RFLTech+"_"+$OSshort+"_Puas_min_1.csv"
$csvPuas_min_2_Path 	= $PuasPath + "ref__"+$RFLTech+"_"+$OSshort+"_Puas_min_2.csv"
$csvPuas_min_1_PreMMPath 	= $RefPuasYYMMpath + "\ref__"+$RFLTech+"_"+$OSshort+"_Puas_min_1.csv"
$csvPuas_min_2_PreMMPath 	= $RefPuasYYMMpath + "\ref__"+$RFLTech+"_"+$OSshort+"_Puas_min_2.csv"
 $ProductionExceptCsvPath 	= $RFLpath + 			 "ref__Except_"+$OSshort+"_latest.csv"
 $ThisMonthExceptCsvPathLatest	= $RFLPrestagingPath+ 		 "ref__Except_"+$OSshort+"_latest.csv"

#if ((-not $HfSgoOnline) -and ($RFLTechs -NotMatch "Master")) {$csvTempPath = $csvTechTemplatePath}

## Move PUAS reference files ## *ToDo: - $MovePuasFiles= only at one run per month (move the _latest file built a few weeks ago?) # 2015-02-02 do it after building Master, when building individual Tech csvs
## #NOTE: - ToDo: this will need to implement some sanity check like [if(Diff(_latest.csv _Puas_min_1.csv > 30 days)) Move-Item ..]
If ($MovePuasFiles -eq 1) {
 If (Test-Path $csvPuas_min_1_Path){
	Write-Verbose "Move '$csvPuas_min_2_Path' to $csvPuas_min_2_PreMMPath"
	Move-Item $csvPuas_min_2_Path $csvPuas_min_2_PreMMPath -Force
	Write-Verbose "Copy '$csvPuas_min_1_Path' to $csvPuas_min_2_Path"
	Copy-Item $csvPuas_min_1_Path $csvPuas_min_2_Path -Force }
 If (Test-Path $ProductionTechCsvPath){
	Write-Verbose "Move '$csvPuas_min_1_Path' to $csvPuas_min_1_PreMMPath"
	Move-Item $csvPuas_min_1_Path $csvPuas_min_1_PreMMPath -Force
	Write-Verbose "Move '$ProductionTechCsvPath' to $csvPuas_min_1_Path"
	Move-Item $ProductionTechCsvPath $csvPuas_min_1_Path -Force }
 }

#"Generate RFL for: $RFLTech, OS Shortname: '$OSshort', OS Longname: '$HotfixSearchOS' "
"Generate RFL for: $RFLTech, OS Shortname: "+$OSshort+", OS Longname: "+$HotfixSearchOS

if($RFLPath -eq '.\')
	{
	$savepath = ((Split-Path $script:MyInvocation.MyCommand.Path)+$csvTempPath)
	$index=$savepath.IndexOf(".")
	$savepath=$savepath.Remove($index,1)
	Write-Verbose "Save file to . -> $savepath"
	}
else
	{Write-Verbose "Interim Save file to -> $csvTempPath"}

## get latest binary versions from http://HotfixSearch - or create template for NON_Master techs
if ((-not $HfSgoOnline) -and ($RFLTechs -match "Master")) {#copy last month \RflLists\ref__Master_<OS>_latest.csv to \RflLists\PreStaging\Temp\ref__Master_<OS>_latestPRE.csv
	write-verbose "Offline Master: Skip 'get-last-version-for-TechGroup'"
}else{get-last-version-for-TechGroup $TechGroup $HfSgoOnline}	# call function
#get-last-version-for-TechGroup $TechGroup $HfSgoOnline	# call function
#write-verbose "___HfSgoOnline: $HfSgoOnline"

### pick up KBOnly_<Tech>_<OS>.csv (if exists) and append it to RFL output file - this was used for exceptions per Tech, should be no more necessary now
If ($PickKBonly) {
	$csvKBTechOSpath = $RFLpath +'KBOnly_'+ $RFLTech +'_'+ $OSshort +'.csv'
	If (Test-Path $csvKBTechOSpath){
		"`n...adding informational KBs: $csvKBTechOSpath"
		Write-Debug "`n** csvKBTechOSpath: '$csvKBTechOSpath'"
		Get-Content $csvKBTechOSpath -Encoding Ascii | Out-File $csvTempPath -Append -Encoding Ascii
		Write-Verbose "NOTE: ref__$($RFLTech)_$($OSshort)_latest.csv may need manual correction on duplicate binaries. "
		}
	}
### pick up KBOnlyRollup2012*/2016.csv and append it to RFL output file
if((("$OSshort" �match "2008CP") -or ("$OSshort" �match "2008") -or ("$OSshort" �match "2012") -or ("$OSshort" �match "2016")) -and ("$RFLTech" -NotMatch "Except") -and ("$RFLTech" -NotMatch "Master"))
	{
	$csvKBRollupPath = $RFLpath +'KBOnlyRollup_'+ $OSshort +'.csv'
	Write-Debug "`n** KBOnlyRollupPath: '$csvKBRollupPath'"
	Get-Content $csvKBRollupPath -Encoding Ascii | Out-File $csvTempPath -Append -Encoding Ascii
	"...adding list of $OSshort Rollup KBs"
	"`nNote: last Rollup KB in $csvKBRollupPath is:"
	Get-Content $csvKBRollupPath | Select-Object -last 1
	}

# if template
if ((-not $HfSgoOnline) -and ($RFLTechs -NotMatch "Master"))
	{#
	Write-verbose "Offline Template: Copy-Item $csvTempPath $csvTechTemplatePath"
	Copy-Item $csvTempPath $csvTechTemplatePath -Force
	"`nRFL PRE Out-file: $csvTechTemplatePath"}
elseif ((-not $HfSgoOnline) -and ($RFLTechs -match "Master")) {
	### Delete old *.csv in \temp folder
	$TempFiles = $RFLPrestagingTempPath + '*.csv'
	Write-Verbose "Remove-Item $TempFiles"
	Remove-Item $TempFiles
	#copy last month \RflLists\ref__Master_<OS>_latest.csv to \RflLists\PreStaging\Temp\ref__Master_<OS>_latestPRE.csv
	write-verbose "Offline Master: Copy last month production <Master> for further processing in $csvPathLatestPRE"
	copy-item $ProductionTechCsvPath $csvPathLatestPRE -Force
	write-verbose "Copy last month production <Except> for MANUAL editing: $ThisMonthExceptCsvPathLatest"
	copy-item $ProductionExceptCsvPath $ThisMonthExceptCsvPathLatest -Force
	}
else {
	Write-verbose ": Copy-Item $csvTempPath $csvPathLatestPRE"
	Copy-Item $csvTempPath $csvPathLatestPRE -Force
	"`nRFL PRE Out-file: $csvPathLatestPRE"
   }

#"$(Get-Date -UFormat "%R") DONE $RFLTech $OSshort!"
$endThis = Get-Date
 $DurationRFL = $endThis - $startexeRFL
 Write-Host -BackgroundColor Green -ForegroundColor Black "$(Get-Date -UFormat "%R") DONE $RFLTech $OSshort : Duration: $DurationRFL"

} #end execute-monthly-new-RFL ($RFLTechs,$OSshortList)
#_______________________


############################################################
# Function: build-new-exception-list
# to be called by: .\monthly_new-RFLReference_Tech_OS.ps1 Except <OS> EXCEPT
# for building an *intitial* binary exception list, you can define the bins per OS as usual: run ".\RflLists\monthly_new-RFLReference_Tech_OS.ps1 Except all"
# once the csv is built, we can build *future* csv by looking up the previuos month's list: run ".\RflLists\monthly_new-RFLReference_Tech_OS.ps1 Except all EXCEPT"
# Output File: "ref__Except_<OS>_YYMM.csv"
function build-new-exception-list ($RFLaction)
{
 if ($RFLaction -ieq 'EXCEPT') {
 	Write-Debug "Enter [build-new-exception-list]"
 	############################################################
 	#$BinToKeepFromLastMonth = "",""
 	$RefCsvDate 			= (Get-Date -UFormat "%Y-%m-%d_%R").Replace(":","-")
 	$ProductionExceptCsvPath 	= $RFLpath + 			 "ref__"+$RFLTech+"_"+$OSshort+"_latest.csv"
 	$LastMonthExceptCsvPath 	= $RFLPrestagingPath +$RefYYlastMM+ 	"\ref__"+$RFLTech+"_"+$OSshort+"_"+$RefYYlastMM+".csv"
# 	$csvExceptBckPath   		= $RFLPrestagingTempPath+	 "ref__"+$RFLTech+"_"+$OSshort+"_"+$RefCsvDate+".csv"
 	$ThisMonthExceptCsvPath 	= $RFLPath +$Ref20YYMM+ 		"\ref__"+$RFLTech+"_"+$OSshort+"_"+$Ref20YYMM+".csv"	# makes changes here
 	$ThisMonthExceptCsvPathLatest	= $RFLPrestagingPath+ 		 "ref__"+$RFLTech+"_"+$OSshort+"_latest.csv"
$Except_filePath = $RFLpath + $Ref20YYMM + "\ref__Except_"+ $OSshort +"_"+ $Ref20YYMM +".csv"
<#
 	### Read in previous Except latest.Csv File, in order to check if there are changes relevant
 	"_Fetch previous $RefYYlastMM Except list:`n '$LastMonthExceptCsvPath'"
 	$LastMonthExceptCsvFile = import-csv $LastMonthExceptCsvPath
 	$LastMonthExceptCsvFile | Select-Object Binary,Article,Component,Version,Published,Comment,Title | Sort-Object Binary,Component | Format-Table -auto

	###Build new Except list based on previous binaries for comparison
	# --> the can be done without going out to internet by looking up Master PRE csv : run ".\RflLists\monthly_new-RFLReference_Tech_OS.ps1 Except all BUILD"
	"_Build new Except list:`n '$ThisMonthExceptCsvPath'"
	foreach ($line in $LastMonthExceptCsvFile)
		{
		Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "." -Separator .
		$Except_binary 		= $line.Binary
		$Except_Prio 		= $line.Prio
		$Except_Component 	= $line.Component

			if($Except_binary -isnot [int32])
				{
					get-HfSversion $Except_binary $Except_Prio $Except_Component $OSshort |Export-Csv -Append -Path $csvExceptBckPath -NoTypeInformation
				}
			else	{
				if($DbgOut) {get-kbonly-fromVKB $Except_binary $Except_Prio $Except_Component }
				else	  {get-kbonly-fromVKB $Except_binary $Except_Prio $Except_Component | Export-Csv -Append -Path $csvExceptBckPath -NoTypeInformation}
				}
			if($DbgOut) {Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "$Except_binary !" -Separator "!"}

		}
	Copy-Item $csvExceptBckPath $ThisMonthExceptCsvPath -Force
	Copy-Item $ThisMonthExceptCsvPath $ThisMonthExceptCsvPathLatest -Force
	Write-Verbose "_Copied new latest Except list to:`n '$ThisMonthExceptCsvPathLatest'"
#>
	Copy-Item $ThisMonthExceptCsvPathLatest $ThisMonthExceptCsvPath -Force
	Write-Verbose "_Copied new latest Except list to:`n '$ThisMonthExceptCsvPath'"

	"_Here is this month's $Ref20YYMM generated Except list:`n '$ThisMonthExceptCsvPathLatest'"
	$ThisMonthExceptCsvFile = import-csv $ThisMonthExceptCsvPathLatest
	$ThisMonthExceptCsvFile | Select-Object Binary,Article,Component,Version,Published,Comment,Title | Sort-Object Component,Binary | Format-Table -auto

	#Compare with last month's Except list
	"_Compare Last month's $RefYYlastMM latest Except list with above list:`n '$LastMonthExceptCsvPath'"
	$LastMonthExceptCsvFile = import-csv $LastMonthExceptCsvPath
	$LastMonthExceptCsvFile | Select-Object Binary,Article,Component,Version,Published,Comment,Title | Sort-Object Component,Binary | Format-Table -auto

	"_Here is the current production Except list:`n '$ProductionExceptCsvPath'"
	$ProductionExceptCsvFile = import-csv $ProductionExceptCsvPath
	$ProductionExceptCsvFile | Select-Object Binary,Article,Component,Version,Published,Comment,Title | Sort-Object Component,Binary | Format-Table -auto


	Write-Verbose "`nToDo: compare this and last month's lists, return diffs"
	#to do: call function compare-binary-with-exception
	[string]$common_KBs = compare-binary-with-exception $ThisMonthExceptCsvPathLatest $LastMonthExceptCsvPath "Article"
	"KBnumbers: $common_KBs "
	" If last month's and current Exception files are identically, good to go because same exceptions are still valid, else make changes and copy new file into production folder '$ProductionExceptCsvPath' `n"
	write-verbose " Copy-Item $ThisMonthExceptCsvPath $ProductionExceptCsvPath -Force `n"
	#break
 } # end if ($RFLaction -ieq 'Except')
} # end function build-new-exception-list


############################################################
# Function: build-new-RFL-lists-from-MasterCsv
# -> build new RFL-list
# Output File: "ref__<Tech>_<OS>_latest.csv"
function build-new-RFL-lists-from-MasterCsv ($RFLaction)
{ Write-Debug "Enter Build Process"
 if ($RFLaction -ieq 'Build') {
 Write-Debug "Enter [build-new-RFL-lists-from-MasterCsv]"
 ############################################################
 Write-Host "BUILD Script for '$RFLTech $OSshort'"

 $RefCsvDate 			= (Get-Date -UFormat "%Y-%m-%d_%R").Replace(":","-")
 $MasterCsvPath		= $RFLPrestagingPath+	 "ref__Master_"   +$OSshort+"_latest.csv"
  if ($RFLTech -ieq "Except") {
	  $MasterCsvPath = $RFLPrestagingTempPath+"ref__Master_"+$OSshort+"_latestPRE.csv"
	  $ExceptCsvPath = $RFLPrestagingTempPath+"ref__Except_"+$OSshort+"_latestPRE.csv"}
 # $All_OSCsvPath		= $RFLpath+	 	 "ref__All_OS_"   +$OSshort+"_latest.csv"
 $ProductionTechCsvPath 	= $RFLpath+		 "ref__"+$RFLTech+"_"+$OSshort+"_latest.csv"
 $ProductionTechCsvPathBck	= $RFLpath+$RefYYlastMM+ "\ref__"+$RFLTech+"_"+$OSshort+"_"+$RefYYlastMM+".csv"
 $csvTechTemplatePath		= $RFLPrestagingTemplatePath+	 "ref__"+$RFLTech+"_"+$OSshort+"_template.csv"
 $csvTechBckPath   		= $RFLPrestagingTempPath+"ref__"+$RFLTech+"_"+$OSshort+"_"+$RefCsvDate+".csv"
 $NewTechCsvPath   		= $RFLPrestagingTempPath+"ref__"+$RFLTech+"_"+$OSshort+"_"+$Ref20YYMM+".csv"
 $NewTechCsvPathLatest		= $RFLPrestagingPath+	 "ref__"+$RFLTech+"_"+$OSshort+"_latest.csv"
 $Except_filePath 		= $RFLPrestagingPath+ $Ref20YYMM + "\ref__Except_"+ $OSshort +"_"+ $Ref20YYMM +".csv"
 $Except_filePrestagingPath 	= $RFLPrestagingPath+ "ref__Except_"+ $OSshort +"_latest.csv"
 #$LastMonthTechCsvPathLatest 	= $RFLPrestagingPath+	 "ref__"+$RFLTech+"_"+$OSshort+"_"+$RefYYlastMM+".csv"
 $csvPuas_min_1_Path 		= $PuasPath + 		 "ref__"+$RFLTech+"_"+$OSshort+"_Puas_min_1.csv"
 $csvPuas_min_2_Path 		= $PuasPath + 		 "ref__"+$RFLTech+"_"+$OSshort+"_Puas_min_2.csv"
 $csvPuas_min_1_PreMMPath 	= $RefPuasYYMMpath + "\ref__"+$RFLTech+"_"+$OSshort+"_Puas_min_1.csv"
 $csvPuas_min_2_PreMMPath 	= $RefPuasYYMMpath + "\ref__"+$RFLTech+"_"+$OSshort+"_Puas_min_2.csv"

  	### Read in current <Master> latest.Csv File
  	Write-Verbose "_Fetch current Master file:`n '$MasterCsvPath'"
 	$MasterCsvFile = import-csv $MasterCsvPath

 	### Read in previous <Tech> latest.Csv File
 	#Write-Verbose "_Fetch previous '$RFLTech' list:`n '$ProductionTechCsvPath'"
	#$PreviousTechCsvFile = import-csv $ProductionTechCsvPath

 	if ($RFLTech -ieq "Except") {	#2015-12-08
 		Write-Verbose "__Copying latest prod '$RFLTech' list to:`n '$csvTechTemplatePath'"
 		Copy-Item $ProductionTechCsvPath $csvTechTemplatePath -Force
	  }
 	Write-Verbose "_Fetch '$RFLTech' template:`n '$csvTechTemplatePath'"
	$PreviousTechCsvFile = import-csv $csvTechTemplatePath
	If ($onScreen) { $PreviousTechCsvFile | Select-Object Binary,Article,Component,Version,Published,Comment,Title | Sort-Object Component,Binary | Format-Table -auto }
	###
	Write-Host "_Build new '$RFLTech' list:`n '$NewTechCsvPath'"
#	replace-binary-with-exception $PreviousTechCsvFile $MasterCsvFile | Export-Csv -Append -Path $NewTechCsvPath -NoTypeInformation

	foreach ($line in $PreviousTechCsvFile)
		{
		Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "." -Separator .
		$Tech_binary 		= $line.Binary
		Write-debug "tech_B $Tech_binary"
		$Tech_Prio 		= $line.Prio
		#$Tech_Component 	= $line.Component

		if ($Tech_binary -notmatch "[1-9][0-9][0-9][0-9][0-9]")
			{ Write-debug " ***** working on binary line: $Tech_binary"
			 # Write-debug "`n$line"
			 if ($RFLTech -ieq "Client") {
			 Write-debug "Tech: $RFLTech - orig Prio: $Tech_Prio - Bin: $Tech_binary"
			 	$ReplaceLine = $MasterCsvFile | Where-Object { $_.binary -match $Tech_binary }
			 	if ($ReplaceLine) {$ReplaceLine.prio = $Tech_Prio
			 		Write-debug "Tech: $RFLTech - new Prio: $Tech_Prio ***"} #	# take client prio form last month client file
			 	}
			 else { # avoid finding srv.sys: -> change order: $_.binary -match $Tech_binary
			 	#$ReplaceLine = $MasterCsvFile | Where-Object { $Tech_binary -match $_.binary }
			 	$ReplaceLine = $MasterCsvFile | Where-Object { $_.binary -match $Tech_binary }
				}
			 $ReplaceLine | Export-Csv -Append -Path $csvTechBckPath -NoTypeInformation
			 Write-debug "** ReplaceLine: `n$ReplaceLine"
			 }
		else	{ Write-debug " ***** working on KB_important / rollup line: $Tech_binary"
			Write-debug " ...keep orig binary csv line"
			#$PreviousTechCsvFile | Where-Object { $Tech_binary -match $_.binary }
			$ReplaceLine = $line
			$line | Export-Csv -Append -Path $csvTechBckPath -NoTypeInformation
			}
		if($DbgOut) {Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "$Tech_binary !" -Separator "!"}
		}

	Write-Host "`n__Copying new latest '$RFLTech' list to:`n '$NewTechCsvPathLatest'"
	Copy-Item $csvTechBckPath $NewTechCsvPath -Force
 	#_#Write-Host "`nRFL Out-file: $NewTechCsvPathLatest"
 	Copy-Item $NewTechCsvPath $NewTechCsvPathLatest -Force
	$CurrentTechCsvFile = import-csv $NewTechCsvPathLatest
	If ($onScreen) { $CurrentTechCsvFile | Select-Object Binary,Article,Component,Version,Published,Comment,Title | Sort-Object Component,Binary | Format-Table -auto }


	if ($RFLTech -ieq "Except") {
 		Write-Host "__Copying this month latest '$RFLTech' list to:`n '$Except_filePath'"
 		Copy-Item $NewTechCsvPathLatest $Except_filePath -Force
 		Write-Host "__Copying this month latest '$RFLTech' list to:`n '$ExceptCsvPath'"		#2015-12-08
 		Copy-Item $NewTechCsvPathLatest $ExceptCsvPath -Force					#2015-12-08
 		}
	## Move PUAS reference files ## *ToDo: - $MovePuasFiles= only at one run per month (move the _latest file built a few weeks ago?) # 2015-02-02 do it after building Master, when building individual Tech csvs
	If ($MovePuasFiles -eq 1) {
	 	Write-Host "__Backup last month productive latest '$RFLTech' list to:`n '$ProductionTechCsvPathBck'"
	 	Copy-Item $ProductionTechCsvPath $ProductionTechCsvPathBck -Force
	  If (Test-Path $csvPuas_min_1_Path){
		 Write-Verbose "___Bck/Move '$csvPuas_min_2_Path' to $csvPuas_min_2_PreMMPath"
		 Move-Item $csvPuas_min_2_Path $csvPuas_min_2_PreMMPath -Force
		 Write-Verbose "___Bck/Copy '$csvPuas_min_1_Path' to $csvPuas_min_1_PreMMPath"
		 Copy-Item $csvPuas_min_1_Path $csvPuas_min_1_PreMMPath -Force
	 	Write-Host "___PUAS-Move '$csvPuas_min_1_Path' to $csvPuas_min_2_Path"
	 	Move-Item $csvPuas_min_1_Path $csvPuas_min_2_Path -Force }
	  If (Test-Path $ProductionTechCsvPath){
	 	Write-Host "___PUAS-Move '$ProductionTechCsvPath' to $csvPuas_min_1_Path"
	 	Move-Item $ProductionTechCsvPath $csvPuas_min_1_Path -Force }
	  } # end if MovePuasFiles

	## Copy Prestaging reference files to production folder
	If ($MoveProdFiles -eq 1) {
		Write-Host "__Moving new latest '$RFLTech' list to production folder:`n '$ProductionTechCsvPath'"
		Move-Item $NewTechCsvPath $ProductionTechCsvPath -Force
		If ($RFLTech -eq "All_OS") {
			If ($OSshort -NotMatch "2016") {
				# copy back PreStaging\ref__Master_<OS>_latest.csv, PreStaging\ref__Except_<OS>_latest.csv to production folder \RflLists\
				Write-Host "`n___Copying back '$MasterCsvPath' to production folder"
				Copy-Item $MasterCsvPath  "$($RFLpath+'ref__Master_'+$OSshort+'_latest.csv')" -Force
				Write-Host "___Copying back '$Except_filePrestagingPath' to production folder"
		 		Copy-Item $Except_filePrestagingPath "$($RFLpath+'ref__Except_'+$OSshort+'_latest.csv')" -Force
			}
			If (($OSshort -Match "2016RS5") -or ($OSshort -Match "201619H") -or ($OSshort -Match "20162004")) {
			 Write-Host "`n___RS5+ Copying back '$MasterCsvPath' and _Except_ to production folder"
				Copy-Item $MasterCsvPath  "$($RFLpath+'ref__Master_'+$OSshort+'_latest.csv')" -Force
				Copy-Item $MasterCsvPath  "$($RFLpath+'ref__Except_'+$OSshort+'_latest.csv')" -Force
			}
		 }
	  } # end if MoveProdFiles

 } # end if ($RFLaction -ieq 'Build')
} # end function build-new-RFL-lists-from-MasterCsv


### : main ###################################################
if ($RFLaction -ieq 'Except') { build-new-exception-list $RFLaction }
if ($RFLaction -ieq 'Build') { build-new-RFL-lists-from-MasterCsv $RFLaction }
if ($RFLaction -ieq 'default'){ execute-monthly-new-RFL $RFLTechs $OSshortList }

################
	 } #end of foreach ($OSshort in $OSshortList)
	 $endRFLTechOS = Get-Date
	 Write-Host -BackgroundColor Gray -ForegroundColor Black "___OS: Build-Script v$($VerMa).$($VerMi) $RFLTech - $OSshortList took: $($endRFLTechOS - $startRFLTechOS)"
	} #end of loop: # walk through each Tech in inputlist (like Core,Dom,Net)
	$endRFLTech = Get-Date
	Write-Host -BackgroundColor Green -ForegroundColor Black "_Tech: Build-Script v$($VerMa).$($VerMi) $RFLTech $OSshortList took: $($endRFLTech - $startRFLTech)"


### : END
 $end = Get-Date
 $Duration = $end - $start
 Write-Host -BackgroundColor Green -ForegroundColor Black "$(Get-Date -UFormat "%R") Overall: Duration of building '$RFLTechs - $OSshortList': $Duration"
 "Remember for MANUAL BUILD:
  PHASE  0: adjust .\RflLists\KBOnlyRollup_20*.csv; + download *.csv file in monthly rollup KBs, correct double-space in 2012*.csv
  PHASE  I: .\RflLists\monthly_new-RFLReference_Tech_OS.ps1 Master all -verbose 	#(for master file, HfSgoOnline=1)
  +for 2016: .\RflLists\monthly_new-Master-or-Except-FromCsv_OS.ps1 [2016|2016RS1|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|all]	#(for building 2016* master files)
  	   .\RflLists\monthly_new-RFLReference_Tech_OS.ps1 all 2008R2,2012,2012R2,2016,2016RS1,2016RS3,2016RS4,2016RS5,201619H1,201619H2,20162004 -verbose #(for building templates, HfSgoOnline=0)
  PHASE Ib: .\RflLists\monthly_new-Master-or-Except-FromCsv_OS.ps1 2008R2,2012,2012R2 #(for updating 2008R2,2012* except files)
  PHASE II: .\RflLists\monthly_correct-RollupInfo_Tech_OS.ps1 Master all -verbose 	#(for reading except files + correct-RollupInfo)
  PHASE IIa: .\RflLists\monthly_check-KBs_Tech_OS.ps1 Master all -verbose 		#(check if binary is listed in public KB)
  PHASE IIb: .\RflLists\monthly_new-RFLReference_Tech_OS.ps1 all all BUILD -verbose	#(for building all tech databases)
  PHASE III: test the new database files
  "

### Stats
If ($Stats) {
 ($j=[int32](Get-Content $CountInvFil)) |Out-Null
 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
 ([string]$j + " ;$CheckDate; $RFLTechs; $OSshortList ;" + [System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" | Out-File $CountInvFil2 -Append -Encoding UTF8
 }
} #end of process

####################################################################################################################################
