﻿#************************************************
# TS_GetEvents.ps1
# Version 2.3.5
# Date: 05-13-2013 - Last_Edit: 2018-06-16
# Author: Andre Teixeira - andret@microsoft.com
# Description: This script is used to export machine event logs in different formats, such as EVT(X), CSV and TXT
#************************************************

PARAM($EventLogNames="AllWMI", 
	  $OutputFormats="",
	  $ExclusionList="", 
	  $Days="", 
	  $EventLogAdvisorAlertXMLs ="",
	  $SectionDescription="Event Logs",
	  $Prefix=$null,
	  $Suffix=$null,
	  $Query=$Null,
	  $After,
	  $Before,
	  [switch] $DisableRootCauseDetection)

Import-LocalizedData -BindingVariable GetEventsStrings

Write-DiagProgress -Activity $GetEventsStrings.ID_EVENTLOG -Status $GetEventsStrings.ID_ExportingLogs

$DisplayToAdd = ''
if (-not (Test-Path($PWD.Path + "\EventLogs"))) {[void]( md ($PWD.Path + "\EventLogs")) }
$OutputPath = $PWD.Path + "\EventLogs"

if (($OSVersion.Major -lt 6) -and ($EventLogNames -eq "AllEvents")) #Pre-WinVista
{
	$EventLogNames = "AllWMI"
}

if ($Days -ne "")
{
	$Days = "/days:$Days"
	$DisplayToAdd = " ($Days days)"
	
	if ($Query -ne $null) {"WARNING: Query argument cannot be used in conjunction with -Days and will be ignored" | WriteTo-StdOut -IsError -ShortFormat -InvokeInfo $MyInvocation}
	if (($After -ne $null) -or ($Before -ne $null) ) {"WARNING: -After or -Before arguments cannot be used in conjunction with -Days and will be ignored" | WriteTo-StdOut -ShortFormat -InvokeInfo $MyInvocation}
}
elseif ($Query -ne $null)
{
	$Query = "`"/query:$Query`""
	if (($After -ne $null) -or ($Before -ne $null)) {"WARNING: -After or -Before arguments cannot be used in conjunction with -Query and will be ignored" | WriteTo-StdOut -ShortFormat -InvokeInfo $MyInvocation}
}
elseif (($After -ne $null) -and ($Before -ne $null) -and ($Before -le $After))
{
	"WARNING: -Before argument contains [$Before] and cannot be earlier than -After argument: [$After] and therefore it will ignored." | WriteTo-StdOut -ShortFormat -InvokeInfo $MyInvocation
	$After = $null
}

if ((($After -ne $null) -or ($Before -ne $null)) -and ($OSVersion.Major -ge 6))
{
	if (($After -ne $null) -and (($After -as [DateTime]) -eq $null))
	{
		"-After argument type is [" + $After.GetType() + "] and contains value [$After]. This value cannot be converted to [datetime] and will be ignored" | WriteTo-StdOut -IsError
		$After = $null
	}
	
	if (($Before -ne $null) -and (($Before -as [DateTime]) -eq $null))
	{
		"-Before argument type is [" + $Before.GetType() + "] and contains value [$Before]. This value cannot be converted to [datetime] and will be ignored" | WriteTo-StdOut -IsError
		$Before = $null
	}
	
	if (($After -ne $null) -or ($Before -ne $null))
	{
		$DisplayToAdd = " (Filtered)"
		$TimeRange = @()

		if ($Before -ne $null)
		{
			$BeforeLogString = "[Before: $Before $($Before.Kind.ToString())]"
			if ($Before.Kind -ne [System.DateTimeKind]::Utc)
			{
				$Before += [System.TimeZoneInfo]::ConvertTimeToUtc($Before)
			}
			$TimeRange += "@SystemTime <= '" + $Before.ToString("o") + "'"
		}
		
		if ($After -ne $null)
		{
			$AfterLogString = "[After: $After $($After.Kind.ToString())]"
			if ($After.Kind -ne [System.DateTimeKind]::Utc)
			{
				$After += [System.TimeZoneInfo]::ConvertTimeToUtc($After)
			}
			$TimeRange += "@SystemTime >= '" + $After.ToString("o") + "'"
		}

		"-Before and/ or -After arguments to TS_GetEvents were used: $BeforeLogString $AfterLogString" | WriteTo-StdOut

		$Query = "*[System[TimeCreated[" + [string]::Join(" and ", $TimeRange) + "]]]"
		$Query = "`"/query:$Query`""
	}
}
elseif ((($After -ne $null) -or ($Before -ne $null)) -and ($OSVersion.Major -lt 6))
{
	"WARNING: Arguments -After or -Before arguments are supported only on Windows Vista or newer Operating Systems and therefore it will ignored" | WriteTo-StdOut -ShortFormat -InvokeInfo $MyInvocation
	$After = $null
	$Before = $null
}

switch ($EventLogNames)	
{
	"AllEvents" 
	{
		#Commented line below since Get-WinEvent requires .NET Framework 3.5 - which is not always installed on server media
		#$EventLogNames = Get-WinEvent -ListLog * | Where-Object {$_.RecordCount -gt 0} | Select-Object LogName
		$EventLogNames = wevtutil.exe el
	}
	"AllWMI" 
	{
		$EventLogList = Get-EventLog -List | Where-Object {$_.Entries.Count -gt 0} | Select-Object @{Name="LogName"; Expression={$_.Log}}
		$EventLogNames = @()
		$EventLogList | ForEach-Object {$EventLogNames += $_.LogName}
	}
}

if ($OutputFormats -eq "") 
{
	$OutputFormatCMD = "/TXT /CSV /evtx /evt"
} 
else 
{
	ForEach ($OutputFormat in $OutputFormats) 
	{
		$OutputFormatCMD += "/" + $OutputFormat + " "
	}
}

$EventLogAdvisorXMLCMD = ""

if (($EventLogAdvisorAlertXMLs -ne "") -or ($Global:EventLogAdvisorAlertXML -ne $null))
{
	$EventLogAdvisorXMLFilename = Join-Path -Path $PWD.Path -ChildPath "EventLogAdvisorAlerts.XML"
	"<?xml version='1.0'?>" | Out-File $EventLogAdvisorXMLFilename
	
	if ($EventLogAdvisorAlertXMLs -ne "")
	{
		ForEach ($EventLogAdvisorXML in $EventLogAdvisorAlertXMLs) 
		{
			#Save Alerts to disk, then, use file as command line for GetEvents script
			$EventLogAdvisorXML | Out-File $EventLogAdvisorXMLFilename -append
		}
	}
	
	if ($Global:EventLogAdvisorAlertXML -ne $null)
	{
		if (Test-Path $EventLogAdvisorXMLFilename)
		{
			"[GenerateEventLogAdvisorXML] $EventLogAdvisorXMLFilename already exists. Merging content."
			[xml] $EventLogAdvisorXML = Get-Content $EventLogAdvisorXMLFilename
			
			ForEach ($GlobalSectionNode in $Global:EventLogAdvisorAlertXML.SelectNodes("/Alerts/Section"))
			{
			
				$SectionName = $GlobalSectionNode.SectionName
				$SectionElement = $EventLogAdvisorXML.SelectSingleNode("/Alerts/Section[SectionName = `'$SectionName`']")
				if ($SectionElement -eq $null)
				{
					$SectionElement = $EventLogAdvisorXML.CreateElement("Section")						
					$X = $EventLogAdvisorXML.SelectSingleNode('Alerts').AppendChild($SectionElement)
					
					$SectionNameElement = $EventLogAdvisorXML.CreateElement("SectionName")
					$X = $SectionNameElement.set_InnerText($SectionName)						
					$X = $SectionElement.AppendChild($SectionNameElement)
					
					$SectionPriorityElement = $EventLogAdvisorXML.CreateElement("SectionPriority")
					$X = $SectionPriorityElement.set_InnerText(30)
					$X = $SectionElement.AppendChild($SectionPriorityElement)
				}
				
				ForEach ($GlobalSectionAlertNode in $GlobalSectionNode.SelectNodes("Alert"))
				{
					$EventLogName = $GlobalSectionAlertNode.EventLog
					$EventLogSource = $GlobalSectionAlertNode.Source
					$EventLogId = $GlobalSectionAlertNode.ID
					
					$ExistingAlertElement = $EventLogAdvisorXML.SelectSingleNode("/Alerts/Section[Alert[(EventLog = `'$EventLogName`') and (Source = `'$EventLogSource`') and (ID = `'$EventLogId`')]]")

					if ($ExistingAlertElement -eq $null)
					{
						$AlertElement = $EventLogAdvisorXML.CreateElement("Alert")
						$X = $AlertElement.Set_InnerXML($GlobalSectionAlertNode.Get_InnerXML())
						$X = $SectionElement.AppendChild($AlertElement)
					}
					else
					{
						"WARNING: An alert for event log [$EventLogName], Event ID [$EventLogId], Source [$EventLogSource] was already been queued by another script." | WriteTo-StdOut -ShortFormat
					}
				}
			}
			
			$EventLogAdvisorXML.Save($EventLogAdvisorXMLFilename)
				
		}
		else
		{
			$Global:EventLogAdvisorAlertXML.Save($EventLogAdvisorXMLFilename)
		}
	}
	
	$EventLogAdvisorXMLCMD = "/AlertXML:$EventLogAdvisorXMLFilename /GenerateScriptedDiagXMLAlerts "
}
	
if ($SectionDescription -eq "") 
{
	$SectionDescription = $GetEventsStrings.ID_EventLogFiles
}

if ($Prefix -ne $null)
{
	$Prefix = "/prefix:`"" + $ComputerName + "_evt_" + $Prefix + "`""
}

if ($Suffix -ne $null)
{
	$Suffix = "/suffix:`"" + $Suffix + "`""
}

ForEach ($EventLogName in $EventLogNames) 
{
    if ($ExclusionList -notcontains $EventLogName) 
	{
		$ExportingString = $GetEventsStrings.ID_ExportingLogs
    	Write-DiagProgress -Activity $GetEventsStrings.ID_EVENTLOG -Status ($ExportingString + ": " + $EventLogName)
    	$CommandToExecute = "cscript.exe //E:vbscript GetEvents.VBS `"$EventLogName`" /channel $Days $OutputFormatCMD $EventLogAdvisorXMLCMD `"$OutputPath`" /noextended $Query $Prefix $Suffix"
		$OutputFiles = $OutputPath + "\" + $Computername + "_evt_*.*"
		$FileDescription = $EventLogName.ToString() + $DisplayToAdd

		RunCmD -commandToRun $CommandToExecute -sectionDescription $SectionDescription -filesToCollect $OutputFiles -fileDescription $FileDescription

		$EventLogFiles = Get-ChildItem $OutputFiles
		if ($EventLogFiles -ne $null) 
		{
    		$EventLogFiles | Remove-Item
    	}
    }
}

$EventLogAlertXMLFileName = $Computername + "_EventLogAlerts.XML"

if (($DisableRootCauseDetection.IsPresent -ne $true) -and (test-path $EventLogAlertXMLFileName)) 
{	
	[xml] $XMLDoc = Get-Content -Path $EventLogAlertXMLFileName
	if($XMLDoc -ne $null)
	{
		$Processed = $XMLDoc.SelectSingleNode("//Processed").InnerXML
	}
	
	if($Processed -eq $null)
	{
		#Check if there is any node that does not contain SkipRootCauseDetection. In this case, set root cause detected to 'true'
		if ($XMLDoc.SelectSingleNode("//Object[not(Property[@Name=`"SkipRootCauseDetection`"])]") -eq $null)
		{
			Update-DiagRootCause -id RC_GetEvents -Detected $true
			
			if($XMLDoc -ne $null)
			{
				[System.Xml.XmlElement] $rootElement=$XMLDoc.SelectSingleNode("//Root")
				[System.Xml.XmlElement] $element = $XMLDoc.CreateElement("Processed")
				$element.innerXML = "True"
				$rootElement.AppendChild($element)
				$XMLDoc.Save($EventLogAlertXMLFileName)	
			}
		}
	}
}
