﻿<# Script name: tss_DAclient-collector.ps1
Purpose: - a script you can use to generate the same information that the DCA generates for DirectAccess
 see also DARA: DirectAccess troubleshooting guide https://internal.support.services.microsoft.com/en-US/help/2921221
#>

param(
	[Parameter(Mandatory=$False,Position=0,HelpMessage='Choose a writable output folder location, i.e. C:\Temp\ ')]
	[string]$DataPath = (Split-Path $MyInvocation.MyCommand.Path -Parent)
)

$ScriptVer="1.01"	#Date: 2018-12-19
$logfile = $DataPath+"\_DirectAccessCli_"+$env:COMPUTERNAME+"_"+(Get-Date -Format yyddMMhhmm)+".txt"

Write-Host "v$ScriptVer Starting collection of debug information for DirectAccess Client on this machine ..." -ForegroundColor White -BackgroundColor DarkGreen
Write-Host "... resulting Logfile: $logfile"
$user = whoami
write-output "v$ScriptVer - Direct Access connectivity status for user: $user is" | out-file -Encoding ascii $logfile
$date = date
Write-output "DATE: $date" | Out-File -Encoding ascii -Append $logfile


# Get a List of all available DTEs
$RegDTEs = get-item hklm:\SOFTWARE\Policies\Microsoft\Windows\NetworkConnectivityAssistant\DTEs -EA SilentlyContinue
$DTEs=($RegDTEs).property -split ("PING:")
$DTEs= $DTEs | ?{$_}
# $DTEs

# Get a List of all available Probes
# Separate them into icmp and http probes
$RegProbes = get-item "HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetworkConnectivityAssistant\Probes" -EA SilentlyContinue
$probelist = ($RegProbes).property
$httpprobe = New-Object System.Collections.ArrayList
$ICMPProbe = New-Object System.Collections.ArrayList
foreach($probe in $probelist)
	{
		if($probe -match "http") {	$httpprobe = $httpprobe + $probe}
		else					 {	$ICMPProbe = $ICMPProbe + $probe}
	}
$httpprobe = $httpprobe -csplit "HTTP:"
$httpprobe = $httpprobe | ?{$_}
$icmpprobe = $icmpprobe -csplit "PING:"
$icmpprobe = $icmpprobe | ?{$_}

# $httpprobe
# $icmpprobe

# check if each of the probe URLs are accessible
if($httpprobe -gt 0)
{
Write-output "`n =============HTTP PROBES=============" | Out-File -Encoding ascii -Append $logfile
foreach ($URL in $httpprobe)
	{
		$result = (Invoke-WebRequest -Uri $URL).statusdescription
		Invoke-WebRequest -Uri $url -ErrorAction SilentlyContinue -ErrorVariable test
		if($result = 'OK' -and !$test)
			{    write-output "$url Pass" | Out-File -Encoding ascii -Append $logfile}
		elseif ($test -match "Unable to connect to the remote server" )
			{	write-output "$url (NAME Resolved)" | Out-File -Encoding ascii -Append $logfile}
		else 
			{	write-output "$url Failed" | Out-File -Encoding ascii -Append $logfile}
	}
}
else
{
Write-output "There are no HTTP probes configured" | Out-File -Encoding ascii -Append $logfile
}	

# check if each ICMP probe is accessible
if($icmpprobe -gt 0)
{
Write-output "`n =============ICMP PROBES=============" | Out-File -Encoding ascii -Append $logfile
foreach($ip in $icmpprobe)
	{
		$result = ping $ip -n 1
		if($result -match "Packets: Sent = 1, Received = 1, Lost = 0")
			{	write-output "$ip PASS" | Out-File -Encoding ascii -Append $logfile}
		elseif($result -match "Pinging")
			{	write-output "$ip Name resolved But ping failed" | Out-File -Encoding ascii -Append $logfile}
		else
			{	write-output "$ip Failed to resolve name" | Out-File -Encoding ascii -Append $logfile}
	}
}
else 
{
Write-output "There are no ICMP probes configured" | Out-File -Encoding ascii -Append $logfile
}

# check if DTEs are pingable
Write-output "`n =============DTEs=============" | Out-File -Encoding ascii -Append $logfile
if ($DTEs) {
  foreach($ip in $DTEs)
	{
		$result = ping $ip -n 1
		if($result -match "Packets: Sent = 1, Received = 1, Lost = 0")
			{	write-output "DTE: $ip PASS" | Out-File -Encoding ascii -Append $logfile}
		else
			{	write-output "DTE: $ip Fail" | Out-File -Encoding ascii -Append $logfile}
	}		
  }
  else
			{	write-output "There are no DTE's to test configured in `n HKLM\SOFTWARE\Policies\Microsoft\Windows\NetworkConnectivityAssistant\DTEs " | Out-File -Encoding ascii -Append $logfile}

Write-output "`n _____ IP Configuration (Get-NetIPConfiguration -All -Detailed)" | Out-File -Encoding ascii -Append $logfile
Get-NetIPConfiguration -All -Detailed | Out-File -Encoding ascii -Append $logfile

Write-output "`n _____ System Info (systeminfo)" | Out-File -Encoding ascii -Append $logfile
systeminfo | Out-File -Encoding ascii -Append $logfile

Write-output "`n _____ 6to4 State (Netsh int 6to4 show state)" | Out-File -Encoding ascii -Append $logfile
Netsh int 6to4 show state | Out-File -Encoding ascii -Append $logfile
Write-output "`n _____ teredo State (Netsh int teredo show state)" | Out-File -Encoding ascii -Append $logfile
Netsh int teredo show state | Out-File -Encoding ascii -Append $logfile
Write-output "`n _____ httpstunnel Int (Netsh int httpstunnel show int)" | Out-File -Encoding ascii -Append $logfile
Netsh int httpstunnel show int | Out-File -Encoding ascii -Append $logfile
Write-output "`n _____ dnsclient State (Netsh dnsclient show state)" | Out-File -Encoding ascii -Append $logfile
Netsh dnsclient show state | Out-File -Encoding ascii -Append $logfile

Write-output "`n _____ 6to4 Configuration (Get-Net6to4Configuration)" | Out-File -Encoding ascii -Append $logfile
Get-Net6to4Configuration | Out-File -Encoding ascii -Append $logfile

Write-output "`n _____ Proxy Configuration (netsh winhttp show proxy)" | Out-File -Encoding ascii -Append $logfile
netsh winhttp show proxy | Out-File -Encoding ascii -Append $logfile

Write-output "`n _____ Teredo Configuration (Get-NetTeredoConfiguration)" | Out-File -Encoding ascii -Append $logfile
Get-NetTeredoConfiguration | Out-File -Encoding ascii -Append $logfile

Write-output "`n _____ Teredo State (Get-NetTeredoState)" | Out-File -Encoding ascii -Append $logfile
Get-NetTeredoState | Out-File -Encoding ascii -Append $logfile

Write-output "`n _____ HTTPs Configuration (Get-NetIPHttpsConfiguration)" | Out-File -Encoding ascii -Append $logfile
Get-NetIPHttpsConfiguration | Out-File -Encoding ascii -Append $logfile

Write-output "`n _____ IP-HTTPs State (Get-NetIPHttpsState)" | Out-File -Encoding ascii -Append $logfile
Get-NetIPHttpsState | Out-File -Encoding ascii -Append $logfile

Write-output "`n _____ Certificate Store (root) (certutil -store root)" | Out-File -Encoding ascii -Append $logfile
certutil -store root | Out-File -Encoding ascii -Append $logfile

Write-output "`n _____ NRPT Policy (Get-DnsClientNrptPolicy)" | Out-File -Encoding ascii -Append $logfile
Get-DnsClientNrptPolicy | Out-File -Encoding ascii -Append $logfile
Write-output "`n _____ NCSI Policy (Get-NCSIPolicyConfiguration)" | Out-File -Encoding ascii -Append $logfile
Get-NCSIPolicyConfiguration | Out-File -Encoding ascii -Append $logfile

Write-output "`n _____ Winsock Catalog (netsh winsock show catalog)" | Out-File -Encoding ascii -Append $logfile
netsh winsock show catalog | Out-File -Encoding ascii -Append $logfile

Write-output "`n _____ WFP Netevents (netsh wfp show netevents file=-)" | Out-File -Encoding ascii -Append $logfile
netsh wfp show netevents file=- | Out-File -Encoding ascii -Append $logfile

Write-output "`n _____ IPsec Rules (Show-NetIPsecRule -PolicyStore ActiveStore)" | Out-File -Encoding ascii -Append $logfile
Show-NetIPsecRule -PolicyStore ActiveStore | Out-File -Encoding ascii -Append $logfile

Write-output "`n _____ IPsec Main Mode SA's (Get-NetIPsecMainModeSA)" | Out-File -Encoding ascii -Append $logfile
Get-NetIPsecMainModeSA | Out-File -Encoding ascii -Append $logfile

Write-output "`n _____ IPsec Quick Mode SA's (Get-NetIPsecQuickModeSA)" | Out-File -Encoding ascii -Append $logfile
Get-NetIPsecQuickModeSA | Out-File -Encoding ascii -Append $logfile

Write-output "`n _____ IP Address (Get-NetIPAddress)" | Out-File -Encoding ascii -Append $logfile
Get-NetIPAddress | Out-File -Encoding ascii -Append $logfile

Write-output "`n _____ Route (Get-NetRoute)" | Out-File -Encoding ascii -Append $logfile
Get-NetRoute | Out-File -Encoding ascii -Append $logfile

Write-output "`n _____ DA Multisite (Get-DAEntryPointTableItem)" | Out-File -Encoding ascii -Append $logfile
Get-DAEntryPointTableItem | Out-File -Encoding ascii -Append $logfile

Write-output "`n _____ DA ConnectionStatus (Get-DAConnectionStatus)" | Out-File -Encoding ascii -Append $logfile
$DaStat_Temp = Get-DAConnectionStatus -EA SilentlyContinue
if ($DaStat_Temp) {
		Get-DAConnectionStatus | Out-File -Encoding ascii -Append $logfile}
Write-output "`n _____ DA Settings (Get-DAClientExperienceConfiguration)" | Out-File -Encoding ascii -Append $logfile
Get-DAClientExperienceConfiguration | Out-File -Encoding ascii -Append $logfile

Write-output "`n _____ Prefix Policy Table (Get-NetPrefixPolicy)" | Out-File -Encoding ascii -Append $logfile
Get-NetPrefixPolicy | Out-File -Encoding ascii -Append $logfile

Write-output "`n _____ Certificate Store (my) (certutil -silent -store -user my)" | Out-File -Encoding ascii -Append $logfile
certutil -silent -store -user my | Out-File -Encoding ascii -Append $logfile

Write-output "`n _____ Groups (whoami /all)" | Out-File -Encoding ascii -Append $logfile
whoami /all | Out-File -Encoding ascii -Append $logfile

Write-output "`n _____ === END of DAclient collector ===" | Out-File -Encoding ascii -Append $logfile	

Write-Host "$(Get-Date -Format 'HH:mm:ss') Done - tss_DAclient-collector`n" -ForegroundColor White -BackgroundColor DarkGreen