<# last edit by: waltere 2020-08-11
 File Name:  monthly_updateRFL_OS_Type.ps1

 MANUALLY
 1- Change: $UpdType="B"
 2- Update $NewPublishedDate
 3- Update $NewKBTitle in section 'switch($OSshort)' - and download KB's *.csv files, 
 4-    + substitute in KB titles "—" with "-"
 5- - delete the two lines reg. previous monthly KB in KBonlyRollup_<os>.csv
 #>

Param(
	[ValidateSet("2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","201619H2","20162004","all","2008","2008R2","2012","2012R2","help")]
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Choose one OS from list: [2016|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5|201619H1|201619H2|20162004|2008|2008R2|2012|2012R2]')]
	[string]$OSshortList
	,
	[ValidateSet("A","B","C","D","E")]
	[Parameter(Mandatory=$False,Position=1,HelpMessage='optional: Choose from list: [A|B|C|D|E]')]
	[string]$UpdType="B"
	,
	[Parameter(Mandatory=$False,Position=2,HelpMessage='optional: Choose from list: [latest cumulative kb]')]
	[string]$CumKB
	)

############################################################
## customization section of script
$NewPublishedDate="11-Aug-2020"
$LateChange=0 # set to 1, if you manually need to run the script for the last month  #_# ToDo lateChange for D
$RFLpath 			= "\\emeacssdfs.europe.corp.microsoft.com\netpodW$\rfl\RflLists\"
$RFLPrestagingPath		= $RFLpath + "PreStaging\"
$RFLPrestagingTempPath		= $RFLpath + "PreStaging\Temp\"
$RFLPrestagingTemplatePath	= $RFLpath + "PreStaging\Template\"
$csvDelimiter=","
############################################################
$Debug_out=0
$CsvHeader = "Binary","Version","size","Published","Time","Platform","SP_requirement","Service","branch"
# 2017-03-16 Wrong csv format for 2012R2 March 2017 2012R2-03B_4012216.csv has additional column ,Hashes,
#$CsvHeader = "Binary","Version","size","Published","Time","Hashes","Platform","SP_requirement","Service","branch"

$OpenSummary=1
$Super_verbose=0
$Stats=1
$VerMa="1"
$VerMi="01"
$start = Get-Date
$CheckDate = (Get-Date -UFormat "%Y-%m-%d_%R").Replace(":","-")
$CountInvFil = "\\waltere-VDI\netpod\tools\RFL\count_mnXls-update.dat"
$CountInvFil2 = $CountInvFil +'.us'
$RefCsvDate = (Get-Date -UFormat "%Y-%m-%d_%R").Replace(":","-")
$Year		= (Get-Date -UFormat "%y").Replace(":","-")
$Month 		= (Get-Date -UFormat "-%m").Replace(":","-")
$ThisMonth 	= $Month
$LastMonth 	= Get-Date (Get-Date).AddMonths(-1) -f MM
$Ref20YYMM 	= (Get-Date -UFormat "%Y-%m").Replace(":","-")
$YYMM 		= (Get-Date -UFormat "%y-%m").Replace(":","-")
$lastYYMM 	= Get-Date (Get-Date).AddMonths(-1) -f yy-MM
#if ("$UpdType" -match "B|A") {$Month = $LastMonth} #; $YYMM = Get-Date (Get-Date).AddMonths(-1) -f yy-MM}
if ($LateChange) {$Year		= "20"
				$Month		= $LastMonth
				$Ref20YYMM	= "20" + $Year + $Month
				$YYMM		= $Year + "-" + $Month
				Write-host "LateChange: Ref20YYMM: $Ref20YYMM - YYMM: $YYMM "}
Set-Variable -Name ErrorMsg -value "" -Scope Script #$ErrorMsg = ""

If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}
If ($Stats) {
 ($j=[int32](Get-Content $CountInvFil -ErrorAction SilentlyContinue)) |Out-Null
 (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
 }

function downloadCsvFile ($CsvLink)
{
	Write-host "Downloading the latest *.csv referenced in KB article: $CsvLink"
	# https://keithga.wordpress.com/2017/05/21/new-tool-get-the-latest-windows-10-cumulative-updates/
	Start-BitsTransfer $CsvLink -Destination $RFLpath
	}
function updateHistoryFiles ($csv_file)
{
	# Read last line of KBOnlyRollup_OS.csv
	KBOnlyRollup_
	# Append last line of KBOnlyRollup_OS.csv to KBOnlyRollup_OS_History.txt
	Get-Content -Path $RFLpath\$KBOnlyRollup_$OS`.csv| Out-File $RFLpath\$KBOnlyRollup_$OS`.txt -Append -Encoding ASCII
}

### MAIN __________________ Enable parameter 'all' for user input (Tech and OS, parameter #1 and #2) of this script
if ($OSshortList -eq 'all'){
	[string[]]$OSshortList = "2016","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","201619H1","201619H2","20162004"
	}


### walk through each OSshort
foreach ($OSshort in $OSshortList)
	{
		### Extracting KB and Title from current KBOnlyRollup_<$OSshort>.csv
		$KBOnlyRollupFileName	= $RFLpath + 'KBOnlyRollup_' +$OSshort+ '.csv'
		#$KBOnlyRollupFileName2	= $RFLpath + 'KBOnlyRollup_' +$OSshort+ '_2.csv'
		Write-Host "$(Get-Date -UFormat "%R:%S") ___Step#1: looking up cumulative KB-nr and Title in last line of file $KBOnlyRollupFileName "
		$KBOnlyRollupFileLastLine = Import-Csv -Path $KBOnlyRollupFileName -Header Binary,Component,Version,Prio,Published,Branch,Article,Title,Link,LDROnlyKB,LDROnlyTitle,LDROnlyLink,Comment,RollupInfo | Select-Object -last 1

	if ("$UpdType" -match "B|A") {$Month = $LastMonth; $LastYYMM = Get-Date (Get-Date).AddMonths(-1) -f yy-MM}
	if ("$UpdType" -match "C|D|E") {$Month = $Month; $LastYYMM = $YYMM}

		if ($KBOnlyRollupFileLastLine -match $LastYYMM) {
			$CumKB 	= $($KBOnlyRollupFileLastLine.Binary)
			$CumKBTitle = $($KBOnlyRollupFileLastLine.Title)
			Write-Host ".... Copying $LastYYMM KB to History: $CumKB Title: $CumKBTitle"
			# Append last line of KBOnlyRollup_OS.csv to KBOnlyRollup_OS_History.txt
			$KBOnlyRollupHistoryFileName	= $RFLpath + 'KBOnlyRollup_' +$OSshort+ '_History.txt'
			$KBOnlyRollupFileLastLineA = Get-Content -Path $KBOnlyRollupFileName | Select-Object -last 1
			$KBOnlyRollupHistoryFileLastLine = Get-Content -Path $KBOnlyRollupHistoryFileName | Select-Object -last 1
			if ($KBOnlyRollupHistoryFileLastLine -notMatch $KBOnlyRollupFileLastLineA) { $KBOnlyRollupFileLastLineA | Out-File $KBOnlyRollupHistoryFileName -Append -Encoding ASCII }

			}
		else {	Write-Host -BackgroundColor Black -ForegroundColor Red -Object "$($OSshort): No latest $($YYMM) rollup info in current $KBOnlyRollupFileName
		 Make sure you have updated $KBOnlyRollupFileName with latest monthly update KB"
			break}

	switch($OSshort)
			{
			"2008"		{$NewKBTitle="August 11, 2020-KB4571730 (Monthly Rollup)"
							$CsvLink="https://download.microsoft.com/download/3/9/f/39f2b02e-f6f1-42e5-bacd-0b118fe4ba84/4571730.csv"}
			"2008R2"	{$NewKBTitle="August 11, 2020-KB4571729 (Monthly Rollup)"
							$CsvLink="https://download.microsoft.com/download/b/b/f/bbf6b802-dbd9-473d-a471-1f0167bdb8c5/4571729.csv"}
			"2012"		{$NewKBTitle="August 11, 2020-KB4571736 (Monthly Rollup)"
							$CsvLink="https://download.microsoft.com/download/f/2/6/f26cf98e-6381-4cf7-b399-273a6a857f95/4571736.csv"}
			"2012R2"	{$NewKBTitle="August 11, 2020-KB4571703 (Monthly Rollup)"
							$CsvLink="https://download.microsoft.com/download/b/f/b/bfbab488-6b5b-413c-9c9a-216acd7eae1d/4571703.csv"}
			"2016"		{$NewKBTitle="August 11, 2020-KB4571692 (OS Build 10240.18666)"
							$CsvLink="https://download.microsoft.com/download/3/d/8/3d89dd6f-9ea4-4cd3-a88e-1a1dfa19f1bc/4571692.csv"}
			"2016RS1"	{$NewKBTitle="August 11, 2020-KB4571694 (OS Build 14393.3866)"
							$CsvLink="https://download.microsoft.com/download/b/3/d/b3d9f092-7e70-48dc-95fb-89738ced31a3/4565513.csv"}
			"2016RS2"	{$NewKBTitle="August 11, 2020-KB4571689 (OS Build 15063.2467)"
							$CsvLink="https://download.microsoft.com/download/1/a/2/1a2c0938-7fee-425f-9fc9-55b87d1cf2c6/4571689.csv"}
			"2016RS3"	{$NewKBTitle="August 11, 2020-KB4571741 (OS Build 16299.2045)"
							$CsvLink="https://download.microsoft.com/download/3/9/5/39533ff3-1aaa-4ae2-8073-46ae8639a93d/4571741.csv"}
			"2016RS4"	{$NewKBTitle="August 11, 2020-KB4571709 (OS Build 17134.1667)"
							$CsvLink="https://download.microsoft.com/download/f/1/e/f1e623ec-2a10-4d81-bc69-be9708968929/4571709.csv"}
			"2016RS5"	{$NewKBTitle="August 11, 2020-KB4565349 (OS Build 17763.1397)"
							$CsvLink="https://download.microsoft.com/download/2/d/9/2d96e68f-824a-47b7-9f6f-8a01d8ba471d/4565349.csv"}
			"201619H1"	{$NewKBTitle="August 11, 2020-KB4565351 (OS Builds 18362.1016 and 18363.1016)"
							$CsvLink="https://download.microsoft.com/download/8/6/6/86675c3e-a5c4-43c9-9afd-ef8159a41f48/4565351.csv"}
			"201619H2"	{$NewKBTitle="August 11, 2020-KB4565351 (OS Builds 18362.1016 and 18363.1016)"
							$CsvLink="https://download.microsoft.com/download/8/6/6/86675c3e-a5c4-43c9-9afd-ef8159a41f48/4565351.csv"}
			"20162004"	{$NewKBTitle="August 11, 2020-KB4566782 (OS Build 19041.450)"
							$CsvLink="https://download.microsoft.com/download/5/c/b/5cb90c87-f1dd-4274-9ed4-5ee09827a75c/4566782.csv"}
			}
	[string]$NewKBTitle="$(($NewKBTitle).Replace("�","-"))"
	$NewBinary=($NewKBTitle -split '-KB')[1]
	$NewBinary=($NewBinary -split ' ')[0]
	$NewComponent="Win" + $OSshort + "_" + $YYMM + "_" + $UpdType + "_rollup_KB"
	$NewPublished=$NewPublishedDate
	$NewArticle="$NewBinary (v1.0)"
	$NewLink="http://support.microsoft.com/kb/$NewBinary"
	$NewRollupInfo="$YYMM`Rollup"
	$NewKBOnlyRollupFileLastLine = new-object PSObject -Property @{Binary=$NewBinary;Component=$NewComponent;Version=" ";Prio="0";Published=$NewPublished;Branch="GDR";Article=$NewArticle;Title=$NewKBTitle;Link=$NewLink;LDROnlyKB="KB only";LDROnlyTitle="KB only";LDROnlyLink="KB only";Comment=" ";RollupInfo=$NewRollupInfo}
	#$NewKBOnlyRollupFileLastLine = new-object PSObject -Property @{Binary=$Binary;Component=$Component;Version=$Version;Prio=$Prio;Published=$Published;Branch=$Branch;Article=$Article;Title=$Title;Link=$Link;LDROnlyKB=$LDROnlyKB;LDROnlyTitle=$LDROnlyTitle;LDROnlyLink=$LDROnlyLink;Comment=$Comment;RollupInfo=$RollupInfo}
	#$NewKBOnlyRollupFileLastLine=$NewBinary,$NewComponent," ","0",$NewPublished,"GDR",$NewArticle,$NewKBTitle,$NewLink,"KB only","KB only","KB Only"," ",$NewRollupInfo
	Write-Host ".... Append/Export to $KBOnlyRollupFileName "
			#$NewKBOnlyRollupFileLastLine | Select-Object Binary,Component,Version,Prio,Published,Branch,Article,Title,Link,LDROnlyKB,LDROnlyTitle,LDROnlyLink,Comment,RollupInfo `
			# | Export-Csv -Path $KBOnlyRollupFileName2 -NoTypeInformation -Append -Force
			$NewKBOnlyRollupFileLastLine | Select-Object Binary,Component,Version,Prio,Published,Branch,Article,Title,Link,LDROnlyKB,LDROnlyTitle,LDROnlyLink,Comment,RollupInfo `
			 | ConvertTo-Csv  -NoTypeInformation | Out-File $KBOnlyRollupFileName -Append -Force -Encoding Ascii
			#$NewKBOnlyRollupFileLastLine | Export-Csv -Path $KBOnlyRollupFileName2 -NoTypeInformation -Append -Force
			##$App = $NewKBOnlyRollupFileLastLine | Select-Object Binary,Component,Version,Prio,Published,Branch,Article,Title,Link,LDROnlyKB,LDROnlyTitle,LDROnlyLink,Comment,RollupInfo | ConvertTo-Csv  -NoTypeInformation | Out-File $KBOnlyRollupFileName2 -Append -Force -Encoding Ascii
			#$App | Out-File $KBOnlyRollupFileName2 -Append -Force -Encoding Ascii
			$App
			#$NewKBOnlyRollupFileLastLine | Export-Csv -Path $KBOnlyRollupFileName2 -NoTypeInformation -Append -Delimiter "$csvDelimiter"
	downloadCsvFile $CsvLink
	$NewCsvName = $OSshort + $ThisMonth + $UpdType + "_" + $NewBinary +".csv"
	Rename-Item -Path "$RFLpath$NewBinary.csv" -NewName $NewCsvName 
	} #end of foreach ($OSshort in $OSshortList)
	$end = Get-Date
$Duration = $end - $start
Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R") $($NodeName) Done $($OSshortList) monthly_updateRFL_OS_Type.ps1 Script version v$VerMa.$VerMi took $Duration"

Write-output "`n"
If ($Stats) {
 ([string]$j + " ;$CheckDate; $OSshortList ;" + [System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; Err: $($ErrorMsg)" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
 }