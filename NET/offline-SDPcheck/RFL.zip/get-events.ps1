<# last edit by: waltere 2018-04-05
   File Name: get-events.ps1 - Extract last events from *.evtx Eventlogs
   Objective: This script is intended to provide a quick summary of Events from all providers (data in Eventlog folder)
   Show all last events for all providers for last 6 hours ( or maybe in a specific time-range).

 call script with -Verbose or -Debug for add. console output
 Help: get-help \\emeacssdfs\netpod\rfl\get-events.ps1 -detailed

VERSION and AUTHORs:
        Ver 1.00 - 07.08.2016
	Walter Eder	- waltere@microsoft.com (

### show Events from all providers (data in Eventlog folder) in a specifix time-range

HISTORY
	2016-08-07  v1.00 checking last 200 events
	2016-08-14  v1.01 Perf-improvement: - changed to use -FilterXPath; now checking last 12hours since *_System.evtx had been created
	2016-08-18	reducing $NrOfHours from 12 to 8h back
	2016-08-21	reducing $NrOfHours from 8 to 6h back
	2016-09-13	changed may line length per item from  #4096 to 1024
	2017-01-05	changed may line length per item from  #1024 to 600 = $OutFileChars
	2017-10-06  v1.03 adding 2016RS3
	2018-04-05  adding 2016RS4
	
#>

<#
.SYNOPSIS
The script reads SDP report folder and displays a quick summary of Events from all providers (data in Eventlog folder)
Show last events for all providers - or in a specifix time-range, default of NrOfHours=6.

SYNTAX: .\get-events.ps1 [full-path-to-expanded-SDP-report] [number of hours back]

.DESCRIPTION
The script reads in the *evtx file(s) from the SDP report and displays a quick summary of Events from all providers.
Note: Expand the SDP report cab file into folder before running this script.


If you experience PS error '...is not digitally signed.' run the command:
 Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

.EXAMPLE
Example 1, Get only all events for last 6 hours
\\localhost\ToolsShare\rfl\get-events.ps1 \\ioanc00\temp\New_RFL\SDPs\FileServer

.EXAMPLE
Example 2, Get only all events for last 3 hours
\\localhost\ToolsShare\rfl\get-events.ps1 \\ioanc00\temp\New_RFL\SDPs\FileServer 3

.LINK
waltere@microsoft.com

#>

Param(
	[ValidateScript({Test-Path $_ -PathType 'Container'})]
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Choose a writable SDP folder location, i.e. C:\SR\SDP-report\ ')]
	[string]$SDPPath
,
	[ValidateSet("1","2","3","4","5","6","7","8","9","10","11","12","24")]
	[Parameter(Mandatory=$False,Position=1,HelpMessage='optional: Choose 1,2,3,4,5,6,7,8,9,10,11,12,24 hours')]
	[string]$NrOfHours = "6"
,
	[ValidateSet("2008","2008R2","2012","2012R2","2016","2016TH2","2016RS1","2016RS2","2016RS3","2016RS4","2016RS5","help","")]
	[Parameter(Mandatory=$False,Position=2,HelpMessage='optional: Choose one OS from list: [2008|2008R2|2012|2012R2|2016|2016TH2|2016RS1|2016RS2|2016RS3|2016RS4|2016RS5]')]
	[string]$OSversion
	)

Process
{
############################################################
## customization section of script
$RFLpath = "\\localhost\ToolsShare\rfl\"
$NrOfHours = "6"
############################################################
$pmaScript = $RFLpath + "pma.vbs"
$Stats=0
#$StatsServerPath="\\netpod.europe.corp.microsoft.com\upload\RFL\"
$StatsServerPath="\\waltere-vdi.europe.corp.microsoft.com\netpod\tools\RFL\"
$VerMa="1"
$VerMi="03"
$OutFileChars=600
$start = Get-Date
$CheckDate = (Get-Date -UFormat "%Y-%m-%d_%R-%S").Replace(":","-")
$CountInvFil = $StatsServerPath +'countEvt.dat'
$CountInvFil2 = $CountInvFil +'.us'
Set-Variable -Name ErrorMsgEvt -Scope Script -Force
#Set-Variable -Name OSVersion -value "" -Scope Script
If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}

### Trail SDPPath with \ and allow path with space character
if ($SDPPath.EndsWith("\")){$SDPPath="$SDPPath"}
else {$SDPPath="$SDPPath" +"\"}
If (-NOT (Test-Path $SDPPath -PathType 'Container')){Throw "$($SDPPath) is not a valid folder"}

###########################################################
### function Get-OS-from-MSinfo32* files
# Return: $OSVersion
function Get-OS-from-MSinfo32 ($SDPPath,$NodeName)
{
	write-debug "__enter Get-OS-from-MSinfo32($SDPPath,$NodeName)"
	### Validate user input of expanded SDP report and identify the number of msinfo32.txt files and the names of the computers $NodeNames (in Cluster Report)
	$msinfo32 = $SDPPath + $NodeName + '*msinfo*.txt' # Try .txt
	If (-NOT (Test-Path $msinfo32)) {
	 Write-Verbose "** $SDPPath without *msinfo32.txt"
	 $msinfo32 = $SDPPath + $NodeName + '*msinfo*.nfo' # Try .nfo
	 }
	  ### Get OS version from SDP report from msinfo.txt
	  If ("$msinfo32" -match ".txt"){
	    Write-Debug "...$NodeName Using msinfo32.txt = $msinfo32 "
	    #Read-in content from Msinfo file
	    if ($msinfo32file = get-childitem $msinfo32) {
	         Write-Debug "msinfo32file: $msinfo32file "
		 $SDPdate = $msinfo32file.LastWriteTime
		 Write-Verbose "`n$NodeName : SDP Date: $SDPdate"
		 $msinfo32 = Get-Content $msinfo32 -TotalCount 7
		 If ($msinfo32) {$OSbuild = $msinfo32[-1]
		 		$OSName = $msinfo32[-2];$OSName=$OSName.Split(" ",3)[2]
		 		$ComputerName = $msinfo32[1].Split("")[-1] }
      		 Else {$ErrorMsgRG += "No-Valid-MsI32txt "}
		 }
	  }
	  Else { # Get OS version from SDP report from msinfo.nfo  / seems not to work for some localized OS
	    Write-Debug "...$NodeName Using msinfo32.nfo = $msinfo32 "
	    if ($msinfo32file = get-childitem $msinfo32) {
		$SDPdate = $msinfo32file.LastWriteTime
		Write-Verbose "`n$NodeName : SDP Date: $SDPdate"
		[xml]$nfo = Get-Content $msinfo32file
		$summary = $nfo.MSInfo.Category.Data.value
		If ($summary.'#cdata-section') {$OSbuild = $summary.'#cdata-section'[1]
		      				$OSName = $summary.'#cdata-section'[0]
		      				$computername = $summary.'#cdata-section'[4] }
      		Else {$ErrorMsgRG += "No-Valid-MsI32nfo "}
		}
	  } #end Else
	### match Build number in SDP report with OS short name
	if("$OSbuild" -match "2600"){$OSVersion_old="old-XP"}   # or Windows XP
	if("$OSbuild" -match "3790"){$OSVersion_old="old-2003"}   # or Windows 2003
	if("$OSbuild" -match "6001"){$OSVersion_old="old-2008-SP1"}   # or Windows Vista SP1
	if("$OSbuild" -match "6002"){$OSVersion="2008"}   # or Windows Vista SP2
	if("$OSbuild" -match "7600"){$OSVersion_old="old-2008R2-RTM"} # or Windows 7 RTM
	if("$OSbuild" -match "7601"){$OSVersion="2008R2"} # or Windows 7
	if("$OSbuild" -match "9200"){$OSVersion="2012"}   # or Windows 8
	if("$OSbuild" -match "9600"){$OSVersion="2012R2"} # or Windows 8.1
	if("$OSbuild" -match "10.0.10240"){$OSVersion="2016"} 		# or Windows 10
	if("$OSbuild" -match "10.0.10586"){$OSVersion="2016TH2"} 	# or Windows 10 TH2
	if("$OSbuild" -match "10.0.14393"){$OSVersion="2016RS1"} 	# or Windows 10 RS1
	if("$OSbuild" -match "10.0.15063"){$OSVersion="2016RS2"} 	# or Windows 10 RS2
	if("$OSbuild" -match "10.0.16299"){$OSVersion="2016RS3"} 	# or Windows 10 RS3
	if("$OSbuild" -match "10.0.17134"){$OSVersion="2016RS4"} 	# or Windows 10 RS4
	if("$OSbuild" -match "10.0.17763"){$OSVersion="2016RS5"} 	# or Windows 10 RS5
	
	Write-Verbose " SDP Date: $($SDPdate) / OS-Version: $($OSVersion) $($OSVersion_old)"
	Write-Verbose " SDP computer name: $ComputerName $OSbuild $OSName"
	$OSVersion
} # end function Get-OS-from-MSinfo32

### === main
"`n$(Get-Date -UFormat "%R:%S") ==Events check==... runnning 'Event Log check' back $NrOfHours h based on data collected at time of the SDP report was created."
## change directory to $SDPPath as required by pma.vbs script
#Push-Location
#Set-Location $SDPPath


$EventLogFiles = Get-Item -path ($SDPPath + "*.evtx") # all *.evtx files in given folder
if (!$EventLogFiles) {  Write-Host -BackgroundColor Black -ForegroundColor Red -Object  "There is no *.evtx file in $SDPPath - Double-check SDP path again!"
			$ErrorMsgEvt += "No-Valid-Evt " }

$NodeNames = foreach ($EventLogFile in $EventLogFiles){($EventLogFile.name).split('_')[0]}
$NodeNames = $NodeNames | Sort-Object | Get-Unique
Write-Host "$(Get-Date -UFormat "%R:%S") ...NodeName(s): $NodeNames"
Write-Host "$(Get-Date -UFormat "%R:%S") ....working on Evt logs ... please stay tuned a couple of min's..." #could take 20min or more..
## foreach loop: processing per NodeName in Cluster report
$NodeCnt=0
foreach ($NodeName in $NodeNames) {
 $NodeCnt++
 $EvtCheckFile = $SDPPath + '!'+$NodeName+'_Evt-Check.txt' #_'+$OSVersion+'.txt'
# "$NodeName - Latest $NrOfEntries events from all recorded Eventlog providers in SDP" > $EvtCheckFile # initialize, write new file
 "$NodeName - Events from all recorded Eventlog providers in SDP report back $NrOfHours hours" > $EvtCheckFile # initialize, write new file
 $EventLogFiles = Get-Item -path ($SDPPath + $NodeName +"_*.evtx")

     ## get only events records x ($NrOfHours) hours back to collecting SDP report
     if ($EventLogSysFile = get-childitem ($SDPPath + $NodeName +"_*System.evtx")) {
      	$EvtSysDate = $EventLogSysFile.LastWriteTime
      	Write-host "  Date of SystemEvt:  $EvtSysDate"
      	## check only Events for 12-hours back -- #-hour $NrOfHours
      	$EvtStartDate = Get-Date ($EvtSysDate - (New-TimeSpan -hour $NrOfHours)) -Format o
      	"  check only Events for $NrOfHours hours back - based on SDP System Eventlog time: $EvtSysDate " >> $EvtCheckFile
      	Write-host "  SystemEvtDate - $NrOfHours h: $EvtStartDate"

		Write-Host -BackgroundColor Blue -ForegroundColor Cyan -NoNewline -Object "$($NodeCnt) " -Separator .
		$NodeName = ($EventLogFile.name).split('_')[0]
		Write-Verbose "OSVersion in script param1: $($OSVersion) "
		if (!$OSversion) {$OSVersion = Get-OS-from-MSinfo32 $SDPPath $NodeName}			# Call function
		Write-Verbose "OSVersion in SDP report: $($OSVersion) - ComputerName: $($NodeName)"
		if ($($NodeCnt) -lt 32) {
			if ($NodeNames.count -gt 1) {Write-Host "Node $NodeName $NodeCnt of $($NodeNames.count)"}
			#& wscript.exe $pmaScript $EventLogFile $quiet
			### show $NrOfEntries last events for all providers:
#			Get-WinEvent -Path $EventLogFiles -Oldest | Sort-Object -Property TimeCreated -Descending | Select-Object -First $NrOfEntries | Out-file $EvtCheckFile -Append -Width 4096
			Get-WinEvent -Path $EventLogFiles -FilterXPath "*[System[TimeCreated[@SystemTime&gt;='$($EvtStartDate)']]]" | Out-file $EvtCheckFile -Append -Width $OutFileChars -ErrorAction SilentlyContinue #1024 #4096
			##-FilterXPath "*[System[TimeCreated[@SystemTime&gt;='2016-08-03T13:06:10.000Z' and @SystemTime&lt;='2016-08-03T13:07:20.999Z']]]"
			"$NodeName => Output file will be saved to: $EvtCheckFile "
			Invoke-Item $EvtCheckFile
		}
		else {Write-Host "$(Get-Date -UFormat "%R:%S") ...checked only first 32 nodes" }
		}
	 else {Write-host "  System Eventlog $NodeName .evtx is missing." -ForegroundColor Cyan} 	
}

"`nUsing favorite editor to open $NodeNames EventLog Report(s) - this could take a few seconds until your Text Editor opens with results ..."

$end = Get-Date
Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R:%S") Done Get-Events script version v$VerMa.$VerMi took $($end - $start) `n"

#Pop-Location

### Stats
$Duration = $end - $start
If ($Stats) {
  ($j=[int32](Get-Content $CountInvFil -ErrorAction SilentlyContinue)) |out-null
  (++$j) | Set-Content $CountInvFil -ErrorAction SilentlyContinue
  "$j" + " ;$CheckDate" + "; $OSVersion; " + ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) + "; $($Duration)" + "; $NodeCnt" + "; $SDPPath" + "; $ErrorMsgEvt" + "; v$VerMa.$VerMi" | Out-File $CountInvFil2 -Append -Encoding UTF8 -ErrorAction SilentlyContinue
  }
}

