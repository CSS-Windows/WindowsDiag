#************************************************
# DC_Setup_Addons.ps1
# Version 1.0
# Date: 2009-2019
# Author: Walter Eder (waltere@microsoft.com)
# Description: Collects additional Setup information.
# Called from: TS_AutoAddCommands_Setup.ps1
#*******************************************************

Param($MachineName = $Computername, $Path = "")

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Write-verbose "$(Get-Date -UFormat "%R:%S") : Start of script DC_Setup_Addons.ps1"

Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status $ScriptVariable.ID_CTSAddonsDescription


# detect OS version
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber

function isOSVersionAffected
{
	if ([int]$bn -gt [int](9600))
	{
		return $true
	}
	else
	{
		return $false
	}
}

function RunNet ([string]$NetCommandToExecute="")
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSSMBClient -Status "net $NetCommandToExecute"
	
	$NetCommandToExecuteLength = $NetCommandToExecute.Length + 6
	"`n`n`n" + "=" * ($NetCommandToExecuteLength) + "`r`n" + "net $NetCommandToExecute" + "`r`n" + "=" * ($NetCommandToExecuteLength) | Out-File -FilePath $OutputFile -append

	$CommandToExecute = "cmd.exe /c net.exe " + $NetCommandToExecute + " >> $OutputFile "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	"`n`n`n" | Out-File -FilePath $OutputFile -append
}


function RunPS ([string]$RunPScmd="", [switch]$ft)
{
	$RunPScmdLength = $RunPScmd.Length
	"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
	"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
	"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
	if ($ft)
	{
		# This format-table expression is useful to make sure that wide ft output works correctly
		Invoke-Expression $RunPScmd	|format-table -autosize -outvariable $FormatTableTempVar | Out-File -FilePath $outputFile -Width 500 -append
	}
	else
	{
		Invoke-Expression $RunPScmd	| Out-File -FilePath $OutputFile -append
	}
	"`n`n`n" | Out-File -FilePath $OutputFile -append
}

#--- Section CBS & PNP info, components hive, SideBySide hive, Iemain.log
$sectionDescription = "Windows logs folders"

if(test-path (join-path $Env:windir "Logs"))
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Compress \Logs"
	$DestinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
	Copy-Item "$env:WinDir\Logs" -Destination $DestinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
	CompressCollectFiles -filesToCollect $DestinationTempFolder -DestinationFileName ($ComputerName + "_Windows-Logs.zip") -fileDescription "Windows Log Folder" -sectionDescription $sectionDescription -Recursive
	Remove-Item $DestinationTempFolder -Force -Recurse
}
if(test-path (join-path $Env:windir "System32\LogFiles"))
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Compress \System32\LogFiles"
	$DestinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
	Copy-Item "$env:WinDir\System32\LogFiles" -Destination $DestinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
	CompressCollectFiles -filesToCollect $DestinationTempFolder -DestinationFileName ($ComputerName + "_Windows-System32-Logs.zip") -fileDescription "System32 LogFiles Folders" -sectionDescription $sectionDescription -Recursive
	Remove-Item $DestinationTempFolder -Force -Recurse
}

Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status (join-path $Env:windir "Servicing\Sessions")
$arrWindirLogsFiles = get-childitem -force -path (join-path $Env:windir "Servicing\Sessions") -recurse -exclude *.temp,*.tmp | Where {$_.psIsContainer -eq $false} | foreach {$_.fullname}
CompressCollectFiles -filesToCollect $arrWindirLogsFiles -fileDescription "Windows\Servicing\Sessions folder" -sectionDescription "Servicing\Sessions Folder" -DestinationFileName ($MachineName + "Windows-Servicing-Sessions.zip") -RenameOutput $true -recursive 

Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status (join-path $Env:windir "inf")
$arrWindirLogsFiles = get-childitem -force -path (join-path $Env:windir "inf\*") -include *.log | Where {$_.psIsContainer -eq $false} | foreach {$_.fullname}
CompressCollectFiles -filesToCollect $arrWindirLogsFiles -fileDescription "Windows\inf\*.log" -sectionDescription "inf\*.log" -DestinationFileName ($MachineName + "Windows-Inf-logs.zip") -RenameOutput $true -recursive 

	$filesToCollect = "$env:WinDir\servicing\sessions\sessions.xml"
	$filesDescription = "servicing\sessions\sessions.xml"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -RenameOutput $true -MachineNamePrefix $ComputerName
	}

	$filesToCollect = "$env:WinDir\Logs\MoSetup\UpdateAgent.log"
	$filesDescription = "MoSetup\UpdateAgent.log"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -RenameOutput $true -MachineNamePrefix $ComputerName
	}

	$filesToCollect = "$env:WinDir\iemain.log"
	$filesDescription = "iemain.log"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -RenameOutput $true -MachineNamePrefix $ComputerName
	}

#----------Registry
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Collect Registry files"

	$OutputFile= $MachineName + "_reg_Component_Based_Servicing.HIV"
	RegSave -RegistryKey "HKLM\Software\Microsoft\Windows\CurrentVersion\Component Based Servicing" -OutputFile $OutputFile -fileDescription "Components CBS Hive"

	$OutputFile= $MachineName + "_reg_SideBySide.HIV"
	RegSave -RegistryKey "HKLM\Software\Microsoft\Windows\CurrentVersion\SideBySide" -OutputFile $OutputFile -fileDescription "SideBySide Hive"

	$OutputFile= $MachineName + "_reg_SideBySide.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\SideBySide" -OutputFile $OutputFile -fileDescription "SideBySide Reg key" -Recursive $true
		
#----------Registry Section Misc Registry Info
	$OutputFile= $MachineName + "_reg_Langpack.txt"
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\MUI\UILanguages" -OutputFile $OutputFile -fileDescription "Langpack Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_services.txt"
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Services" -OutputFile $OutputFile -fileDescription "services Reg key" -Recursive $true
	$OutputFile= $MachineName + "_reg_services.HIV"
	RegSave -RegistryKey "HKLM\System\CurrentControlSet\Services" -OutputFile $OutputFile -fileDescription "services Reg Hive" -Recursive $true
			
	$OutputFile= $MachineName + "_reg_CurrentVersion.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion" -OutputFile $OutputFile -fileDescription "Windows NT\CurrentVersion Reg key" -Recursive $true
	$OutputFile= $MachineName + "_reg_CurrentVersion.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion" -OutputFile $OutputFile -fileDescription "Windows\CurrentVersion Reg key" -Recursive $true
	
	$OutputFile= $MachineName + "_reg_BuildInfo.txt"
	$RegKeysValues = "BuildLab", 
					"BuildLabEx", 
					"UBR", 
					"ProductName"
	RegQueryValue -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion" -RegistryValues $RegKeysValues -OutputFile $OutputFile -fileDescription "BuildInfo" -CollectResultingFile $true
	
	$OutputFile= $MachineName + "_reg_AppModelVersion.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\AppModel" -OutputFile $OutputFile -fileDescription "AppModel Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_FirmwareResources.txt"
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\FirmwareResources" -OutputFile $OutputFile -fileDescription "FirmwareResources Reg key" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\AppModel" -OutputFile $OutputFile -fileDescription "AppModel Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_Appx.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\Appx" -OutputFile $OutputFile -fileDescription "Appx Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_Superfetch.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion\Superfetch" -OutputFile $OutputFile -fileDescription "Superfetch Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_Uninstall.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\Uninstall" -OutputFile $OutputFile -fileDescription "Uninstall Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall" -OutputFile $OutputFile -fileDescription "Uninstall Reg keys" -Recursive $true

	$OutputFile= $MachineName + "_reg_Recovery.txt"
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\CrashControl" -OutputFile $OutputFile -fileDescription "Recovery Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\Session Manager" -OutputFile $OutputFile -fileDescription "Recovery Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\Session Manager\Memory Management" -OutputFile $OutputFile -fileDescription "Recovery Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion\AeDebug" -OutputFile $OutputFile -fileDescription "Recovery Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion\Image File Execution Options" -OutputFile $OutputFile -fileDescription "Recovery Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\Windows Error Reporting" -OutputFile $OutputFile -fileDescription "Recovery Reg keys" -Recursive $true

	$OutputFile= $MachineName + "_reg_Startup.txt"
	RegQuery -RegistryKeys "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" -OutputFile $OutputFile -fileDescription "Startup Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\Runonce" -OutputFile $OutputFile -fileDescription "Startup Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\ShellServiceObjectDelayLoad" -OutputFile $OutputFile -fileDescription "Startup Reg keys" -Recursive $true

	$OutputFile= $MachineName + "_reg_TimeZone.txt"
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\TimeZoneInformation" -OutputFile $OutputFile -fileDescription "TimeZone Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion\Time Zones" -OutputFile $OutputFile -fileDescription "TimeZone Reg keys" -Recursive $true

	$OutputFile= $MachineName + "_reg_TermServices.txt"
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\Terminal Server" -OutputFile $OutputFile -fileDescription "TermServices Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_SVCHost.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion\SvcHost" -OutputFile $OutputFile -fileDescription "SVCHost Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_ProfileList.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion\ProfileList" -OutputFile $OutputFile -fileDescription "ProfileList Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_DriverDatabase.HIV"
	RegSave -RegistryKey "HKLM\System\DriverDatabase" -OutputFile $OutputFile -fileDescription "DriverDatabase Hive"
	$OutputFile= $MachineName + "_reg_DriverDatabase.txt"
	RegQuery -RegistryKeys "HKLM\System\DriverDatabase" -OutputFile $OutputFile -fileDescription "DriverDatabase Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_.NET-Framework-Setup.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\NET Framework Setup\NDP" -OutputFile $OutputFile -fileDescription ".NET-Framework-Setup Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_Winevt.HIV"
	RegSave -RegistryKey "HKLM\Software\Microsoft\Windows\currentversion\winevt" -OutputFile $OutputFile -fileDescription "Winevt Hive"
	$OutputFile= $MachineName + "_reg_Winevt.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\currentversion\winevt" -OutputFile $OutputFile -fileDescription "Winevt Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_Setup.txt"
	RegQuery -RegistryKeys "HKLM\System\Setup" -OutputFile $OutputFile -fileDescription "Setup Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\Setup\OOBE" -OutputFile $OutputFile -fileDescription "Setup Reg keys"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\Setup\State" -OutputFile $OutputFile -fileDescription "Setup Reg keys"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\Setup\Sysprep" -OutputFile $OutputFile -fileDescription "Setup Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\Setup\SysPrepExternal" -OutputFile $OutputFile -fileDescription "Setup Reg keys" -Recursive $true

	$OutputFile= $MachineName + "_reg_WMI.txt"
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\WMI" -OutputFile $OutputFile -fileDescription "WMI Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_Drivers.HIV"
	RegSave -RegistryKey "HKLM\DRIVERS" -OutputFile $OutputFile -fileDescription "Drivers Hive"

#----------Directory listing 
	$sectionDescription = "Dir $env:WinDir\Winsxs\temp"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_dir_winsxsTEMP.txt")
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	$CommandToExecute = 'dir /a /s "$env:WinDir\Winsxs\temp" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription $fileDescription -sectionDescription $sectionDescription

	$sectionDescription = "Dir $env:WinDir\Winsxs"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_dir_winsxs.txt")
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	$CommandToExecute = 'dir /a /s "$env:WinDir\Winsxs" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription $fileDescription -sectionDescription $sectionDescription
	
	$sectionDescription = "Dir $env:WinDir\servicing\packages"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_dir_servicing-packages.txt")
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	$CommandToExecute = 'dir /a /s "$env:WinDir\servicing\packages" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription $fileDescription -sectionDescription $sectionDescription

#----------Directory listing: Get registry size info including Config and profile info
	$sectionDescription = "Dir $env:WinDir\system32\config"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_dir_registry_list.txt")
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	$CommandToExecute = 'dir /a /s "$env:WinDir\system32\config" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	$CommandToExecute = 'dir /a /s "c:\users\ntuser.dat" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription $fileDescription -sectionDescription $sectionDescription


#---------- Section Windows Store info
	$sectionDescription = "Copying Windows Store logs"
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status $sectionDescription

	$filesToCollect = "$Env:Temp\winstore.log"
	$filesDescription = "$Env:Temp\winstore.log"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
	}

	$filesToCollect = "$Env:Temp\winstore.log"
	$filesDescription = "$Env:Temp\winstore.log"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
	}
	
if (test-path "$env:localappdata\Packages\WinStore_cw5n1h2txyewy\AC\Temp\Winstore.log")
{
	CollectFiles -filesToCollect "$env:localappdata\Packages\WinStore_cw5n1h2txyewy\AC\Temp\Winstore.log" -fileDescription "Winstore log" -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
}
if (test-path "$env:localappdata\Temp\WinStore.log")
{
	CollectFiles -filesToCollect "$env:localappdata\Temp\WinStore.log" -fileDescription "Broker log" -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
}
	
#---------- MUSE logs for Win10+
if (get-service usosvc -EA SilentlyContinue)
 {
	$sectionDescription = "Copying MUSE logs for Win10"
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status $sectionDescription

		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Copy UsoPrivate\UpdateStore"
		$DestinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
		Copy-Item "$env:programdata\UsoPrivate\UpdateStore" -Destination $DestinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
		CompressCollectFiles -filesToCollect $DestinationTempFolder -DestinationFileName ($ComputerName + "_UsoPrivate-UpdateStore.zip") -fileDescription "UsoPrivate-UpdateStore Folder" -sectionDescription $sectionDescription -Recursive
		Remove-Item $DestinationTempFolder -Force -Recurse
		
		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Copy UsoShared\Logs"
		$DestinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
		Copy-Item "$env:programdata\USOShared\Logs" -Destination $DestinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
		CompressCollectFiles -filesToCollect $DestinationTempFolder -DestinationFileName ($ComputerName + "_USOShared-Logs.zip") -fileDescription "USOShared-Logs Folder" -sectionDescription $sectionDescription -Recursive
		Remove-Item $DestinationTempFolder -Force -Recurse
		
	  # robocopy %_OLDPROGRAMDATA%\USOPrivate\UpdateStore %_TEMPDIR%\Windows.old\MUSE %_ROBOCOPY_PARAMS% /S > nul
	  # robocopy %_OLDPROGRAMDATA%\USOShared\Logs %_TEMPDIR%\Windows.old\MUSE %_ROBOCOPY_PARAMS% /S > nul

	$sectionDescription = "SCHTASKS /query /v /TN \Microsoft\Windows\UpdateOrchestrator\"
		$OutputFile = Join-Path $pwd.path ($ComputerName + "_MUSE_ScheduledTasks.txt")
		Write-DiagProgress -activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status "MUSE ScheduledTasks"
		$CommandToExecute = 'SCHTASKS /query /v /TN \Microsoft\Windows\UpdateOrchestrator\ '
		RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
		collectfiles -filesToCollect $OutputFile -fileDescription "MUSE: ScheduledTasks" -sectionDescription $sectionDescription
}
#---------- Section Delivery Optimizaton logs and powershell for Win10+
if (get-service dosvc -EA SilentlyContinue) {
	$sectionDescription = "Copying DeliveryOptimization logs"
	if (test-path "$Env:windir\ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Logs" )
	{
		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Copy DeliveryOptimization\Logs"
		$arrDOlogsFiles = get-childitem -force -path (join-path $Env:windir "ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Logs") -recurse -include *.log,*.etl | Where {$_.psIsContainer -eq $false} | foreach {$_.fullname}
		CompressCollectFiles -filesToCollect $arrDOlogsFiles -fileDescription "DeliveryOptimization\Logs folder" -sectionDescription "DeliveryOptimization\Logs Folder" -DestinationFileName ($MachineName + "DeliveryOptimization-logs.zip") -RenameOutput $true -recursive 
	}
	if (test-path "$Env:windir\SoftwareDistribution\DeliveryOptimization\SavedLogs" )
	{
		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Copy DeliveryOptimization\SavedLogs"
		$arrDOsavedLogsFiles = get-childitem -force -path (join-path $Env:windir "SoftwareDistribution\DeliveryOptimization\SavedLogs") -recurse -include *.log,*.etl | Where {$_.psIsContainer -eq $false} | foreach {$_.fullname}
		CompressCollectFiles -filesToCollect $arrDOsavedLogsFiles -fileDescription "DeliveryOptimization\SavedLogs folder" -sectionDescription "DeliveryOptimization\SavedLogs Folder" -DestinationFileName ($MachineName + "DeliveryOptimization-SavedLogslogs.zip") -RenameOutput $true -recursive 
	}
}
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Get DeliveryOptimization Registry"
	$OutputFile= $ComputerName + "_reg_DeliveryOptimization.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\DeliveryOptimization" -OutputFile $OutputFile -fileDescription "DeliveryOptimization Reg key" -Recursive $true
	
	$OutputFile = $ComputerName + "_DeliveryOptimization_info.txt"
	Get-DeliveryOptimizationPerfSnap -Debug -Verbose | Out-File -FilePath $OutputFile -append 
	Get-DeliveryOptimizationStatus -Debug -Verbose | Out-File -FilePath $OutputFile -append 
 
#---------- Windows Upgrade logs, see *.ps1


#W8/WS2012 and later
if ($bn -gt 9000)
{
	#----------Event Logs - Windows Setup 
	$sectionDescription = "Event Logs - Windows Store Apps"
	$EventLogNames = "Setup", "Microsoft-Windows-WMI-Activity/Operational", "Microsoft-Windows-Setup/Analytic", "General Logging", "HardwareEvents", "Microsoft-Windows-Crashdump/Operational", "Microsoft-Windows-Dism-Api/Analytic", "Microsoft-Windows-EventLog-WMIProvider/Debug", "Microsoft-Windows-EventLog/Analytic", "Microsoft-Windows-EventLog/Debug", "Microsoft-Windows-Kernel-Boot/Operational" 
	$Prefix = "_evt_"
	$Suffix = ""
	.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix
}
 
#----------  Disk Info
$OutputFile = Join-Path $pwd.path ($Env:ComputerName + "_Storage_Info.txt")
Get-PhysicalDisk  | Out-File -FilePath $OutputFile -append
$Pdisk= Get-PhysicalDisk 
ForEach ( $LDisk in $PDisk )
                {
                $LDisk.FriendlyName | Out-File -FilePath $OutputFile -append
                $LDisk.HealthStatus | Out-File -FilePath $OutputFile -append
                $LDisk | Get-StorageReliabilityCounter | Select-Object * | FL | Out-File -FilePath $OutputFile -append
                "==================" | Out-File -FilePath $OutputFile -append 
                } 

#---------- Running process info
Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Getting Process info"

	$sectionDescription = "Process_and_Service_Tasklist"
		$OutputFile = Join-Path $pwd.path ($ComputerName + "_Process_and_Service_info.txt")
		Write-DiagProgress -activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status "Process_and_Service_Tasklist"
		$CommandToExecute = 'tasklist /svc /fo list'
		RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
		collectfiles -filesToCollect $OutputFile -fileDescription "Process_and_Service_Tasklist" -sectionDescription $sectionDescription

	$sectionDescription = "Process_and_Service_info"
		$OutputFile = Join-Path $pwd.path ($ComputerName + "_Process_and_Service_info.txt")
		Write-DiagProgress -activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status "Process_and_Service_info"
		$CommandToExecute = 'wmic process get * /format:texttable'
		RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
		collectfiles -filesToCollect $OutputFile -fileDescription "Process_and_Service_info" -sectionDescription $sectionDescription


Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Getting app list"
if ($bn -gt 9000) {
	$OutputFile = Join-Path $pwd.path ($Env:ComputerName + "_GetAppxPackage.txt")
	import-module appx;get-appxpackage -allusers | Out-File -FilePath $OutputFile -append
}
if ($bn -gt 9600) {
	$OutputFile = Join-Path $pwd.path ($Env:ComputerName + "_GetAppxPackageBundle.txt")
	get-appxpackage -packagetype bundle | Out-File -FilePath $OutputFile -append
	
	$sectionDescription = "Dism /Get-ProvisionedAppxPackages"
		$OutputFile = Join-Path $pwd.path ($ComputerName + "_GetAppxProvisioned.txt")
		Write-DiagProgress -activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status $sectionDescription
		$CommandToExecute = 'dism /online /Get-ProvisionedAppxPackages'
		RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
		collectfiles -filesToCollect $OutputFile -fileDescription "$CommandToExecute" -sectionDescription $sectionDescription
}


 

Write-verbose "$(Get-Date -UFormat "%R:%S") :   end of script DC_Setup_Addons.ps1"