# 2019-03-20 WalterE added Trap #_#

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Write-Host -BackgroundColor Gray -ForegroundColor Black -Object " --- $(Get-Date -Format 'HH:mm:ss') $Global:SDPtech - Collect Phase module: Common ---"
	# version of the psSDP Diagnostic
	Run-DiagExpression .\DC_NetworkingDiagnostic.ps1

	# Basic System Information
	Run-DiagExpression .\DC_BasicSystemInformation.ps1

	# Collects System and Application Event Logs 
	Run-DiagExpression .\DC_SystemAppEventLogs.ps1
	
	# MSInfo
	Run-DiagExpression .\DC_MSInfo.ps1
	
	# Obtain pstat output
	Run-DiagExpression .\DC_PStat.ps1
	
	# ChkSym
	Run-DiagExpression .\DC_ChkSym.ps1
	# Looking to gain efficiencies wherever we can so eliminating SPOOL which we were previously including by allowing collection to default to ALL
	#_# $range = "Drivers", "Process", "RunningDrivers"
	#_# Run-DiagExpression .\DC_ChkSym.ps1 -range $range

	# AutoRuns Information
	Run-DiagExpression .\DC_Autoruns.ps1

	# Collects Windows Server 2008/R2 Server Manager Information
	Run-DiagExpression .\DC_ServerManagerInfo.ps1
	
	# User Rights (privileges) via the userrights.exe tool
	Run-DiagExpression .\DC_UserRights.ps1

	# GetEnvironmentVariables
	Run-DiagExpression .\DC_EnvVars.ps1 -XmlOutput

	# PoolMon
	Run-DiagExpression .\DC_PoolMon.ps1
	
	# Collect summary report 
	Run-DiagExpression .\DC_SummaryReliability.ps1
	
Write-Host -BackgroundColor Gray -ForegroundColor Black -Object " --- $(Get-Date -Format 'HH:mm:ss') $Global:SDPtech - Collect Phase module: Net ---"
	# Collects Basic Networking Information (TCP/IP - SMB)
	Run-DiagExpression .\DC_NetBasicInfo.ps1

	# DC_GetNetworkAdaptersInfo
	Run-DiagExpression .\DC_NetworkAdapters-Component.ps1

	# DNS Client Component
	Run-DiagExpression .\DC_DNSClient-Component.ps1

	# Firewall
	Run-DiagExpression .\DC_Firewall-Component.ps1

	# Windows_TcpIp_Registry
	Run-DiagExpression .\DC_TCPIP-Component.ps1
	
Write-Host -BackgroundColor Gray -ForegroundColor Black -Object " --- $(Get-Date -Format 'HH:mm:ss') $Global:SDPtech - Collect Phase module: DOM ---"
	# Collects functional level and local group membership information (DSMisc)
	Run-DiagExpression .\DC_DSMisc.ps1

	# Kerberos Component
	Run-DiagExpression .\DC_Kerberos-Component.ps1
	
Write-Host -BackgroundColor Gray -ForegroundColor Black -Object " --- $(Get-Date -Format 'HH:mm:ss') $Global:SDPtech - Collect Phase module: Setup ---"
	# Enumerate minifilter drivers via Fltmc.exe command
	Run-DiagExpression .\DC_Fltmc.ps1	

	# Obtain information about Upper and lower filters Information fltrfind.exe utility
	Run-DiagExpression .\DC_Fltrfind.ps1

Write-Host -BackgroundColor Gray -ForegroundColor Black -Object " --- $(Get-Date -Format 'HH:mm:ss') $Global:SDPtech - Collect Phase module: SQL ---"
	# Get_System_Info
	Run-DiagExpression .\SQL_Get_SystemInfo.ps1
	
	# DC_SQLInstances_Network_Configurations
	#_# Run-DiagExpression .\DC_SQLInstances_Network_Configurations.ps1

	# SQL Server Log Collector
	Run-DiagExpression .\DC_CollectSqlLogs.ps1 -Instances $null -CollectSqlErrorlogs -CollectSqlAgentLogs

	# SQL Server XE System Health Collector
	Run-DiagExpression .\DC_GetSqlXeLogs.ps1 -Instances $null -CollectSqlDefaultDiagnosticXeLogs -CollectFailoverClusterDiagnosticXeLogs -CollectAlwaysOnDiagnosticXeLogs

	# SQL Server minidump files Collector
	Run-DiagExpression .\DC_CollectSqlMinidumps.ps1 -Instances $null

	# SQL Server Log Collector
	Run-DiagExpression .\DC_RunSqlDiagScripts.ps1 -Instances $null -CollectSqlDiag -CollectAlwaysOnInfo

	# Misc_SQL_Keys
	Run-DiagExpression .\DC_SQL_Registries.ps1

	# DC_SvcAccts_SPNs_And_ADProperties
	Run-DiagExpression .\DC_SvcAccts_SPNs_And_ADProperties.ps1

	# DC_SQLInstances_Spn_Summary
	Run-DiagExpression .\DC_SQLInstances_Spn_Summary.ps1

Write-Host -BackgroundColor Gray -ForegroundColor Black -Object " --- $(Get-Date -Format 'HH:mm:ss') $Global:SDPtech - Diag Phase module: TS_HyperV ---"
	# Detect Virtualization
	Run-DiagExpression .\TS_Virtualization.ps1
	
	
	# DC_GetAllServicesEx
	#_#Run-DiagExpression .\DC_GetAllServicesEx.ps1

	# DC_Auth_Registry
	#_#Run-DiagExpression .\DC_Auth_Registry.ps1

Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "*** $(Get-Date -UFormat "%R:%S") DONE TS_AutoAddCommands_SQLconn.ps1 SkipTS: $Global:skipTS - SkipBPA: $Global:skipBPA"