﻿#************************************************
# DC_HotfixRollups.ps1
# Version 1.0.04.02.14: Created script to easily view what rollups are installed for W7/WS2008R2, W8/WS2012, and W8.1/WS2012R2
# Version 1.1.05.16.14: Added W8.1 Update1 (April2014 rollup);  Added OS Version below each heading.
# Version 1.2.05.19.14: Added May2014 updates for W8/W8.1
# Version 1.3.07.23.14: Added June and July, 2014
# Version 1.4.08.13.14: Added Aug2014 updates for W8/W8.1
# Version 1.5.09.17.14: Added Sep2014 updates for W8/W8.1
# Version 1.6.10.16.14: Added Oct2014 updates for W8/W8.1
# Date: 2019
# Author: Boyd Benson (bbenson@microsoft.com) +WalterE
# Description: Creates output to easily identify what rollups are installed on W7/WS2008R2 and later.
# Called from: Networking Diagnostics
# ToDo: needs re-check fo Win10 rollup detection!
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Import-LocalizedData -BindingVariable ScriptVariable

$OutputFile = $ComputerName + "_HotfixRollups.TXT"
$sectionDescription = "Hotfix Rollups"


function CheckForHotfix ($hotfixID, $title, $Warn="")
{
	$hotfixesWMIQuery = "SELECT * FROM Win32_QuickFixEngineering WHERE HotFixID='KB$hotfixID'"
	$hotfixesWMI = get-wmiobject -query $hotfixesWMIQuery											# or PS > Get-HotFix
	$link = "http://support.microsoft.com/kb/" + $hotfixID
	if ($hotfixesWMI -eq $null)
	{
		"No          $hotfixID - $title   ($link)" | Out-File -FilePath $OutputFile -append
		If (($bn -lt 10240) -and ($Warn -match "Yes")) {Write-Host -ForegroundColor Red "*** WARNING latest OS cumulative KB $hotfixID is missing"}
	}
	else
	{
		"Yes         $hotfixID - $title   ($link)" | Out-File -FilePath $OutputFile -append
	}
}

#----------detect OS version and SKU
	$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
	[int]$bn = [int]$wmiOSVersion.BuildNumber
	$sku = $((gwmi win32_operatingsystem).OperatingSystemSKU)

if ($bn -eq 18362)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 19H1 v1903 and Windows Server 2019 19H1 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4507453 -title "August 13, 2019-KB4512508 (OS Build 18362.295)" -Warn "Yes"
	CheckForHotfix -hotfixID 4507453 -title "July 9, 2019-KB4507453 (OS Build 18362.239)"
	CheckForHotfix -hotfixID 4503293 -title "June 11, 2019-KB4503293 (OS Build 18362.175)"
	CheckForHotfix -hotfixID 4505057 -title "2019-KB4505057 Update for Windows 10, version 1903: May 19, 2019"
	CheckForHotfix -hotfixID 4508433 -title "Servicing stack update for Windows 10, Version 1903: July 26, 2019"
}
elseif ($bn -eq 17763)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 RS5 v1809 and Windows Server 2019 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4507469 -title "August 13, 2019-KB4511553 (OS Build 17763.678)" -Warn "Yes"
	CheckForHotfix -hotfixID 4507469 -title "July 9, 2019-KB4507469 (OS Build 17763.615)"
	CheckForHotfix -hotfixID 4503327 -title "June 11, 2019-KB4503327 (OS Build 17763.557)"
	CheckForHotfix -hotfixID 4505056 -title "May 19, 2019-KB4505056 (OS Build 17763.504)"
	CheckForHotfix -hotfixID 4493509 -title "April 9, 2019-KB4493509 (OS Build 17763.437)"
	CheckForHotfix -hotfixID 4489899 -title "March 12, 2019-KB4489899 (OS Build 17763.379)"
	CheckForHotfix -hotfixID 4487044 -title "February 12, 2019-KB4487044 (OS Build 17763.316)"
	CheckForHotfix -hotfixID 4480116 -title "January 8, 2019-KB4480116 (OS Build 17763.253)"
	CheckForHotfix -hotfixID 4471332 -title "December 11, 2018-KB4471332 (OS Build 17763.194)"
	CheckForHotfix -hotfixID 4512937 -title "Servicing stack update for Windows 10, Version 1809: July 22, 2019"
}
elseif ($bn -eq 17134)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 RS4 v1803 and Windows Server 2016 RS4 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4507435 -title "August 13, 2019-KB4512501 (OS Build 17134.950)" -Warn "Yes"
	CheckForHotfix -hotfixID 4507435 -title "July 9, 2019-KB4507435 (OS Build 17134.885)"
	CheckForHotfix -hotfixID 4503286 -title "June 11, 2019-KB4503286 (OS Build 17134.829)"
	CheckForHotfix -hotfixID 4505064 -title "May 19, 2019-KB4505064 (OS Build 17134.766)"
	CheckForHotfix -hotfixID 4493464 -title "April 9, 2019-KB4493464 (OS Build 17134.706) "
	CheckForHotfix -hotfixID 4489868 -title "March 12, 2019-KB4489868 (OS Build 17134.648) "
	CheckForHotfix -hotfixID 4487017 -title "February 12, 2019-KB4487017 (OS Build 17134.590)"
	CheckForHotfix -hotfixID 4480966 -title "January 8, 2019-KB4480966 (OS Build 17134.523)"
	CheckForHotfix -hotfixID 4471324 -title "December 11, 2018-KB4471324 (OS Build 17134.471)"
	CheckForHotfix -hotfixID 4509094 -title "Servicing stack update for Windows 10, Version 1803: July 9, 2019"
}
elseif ($bn -eq 16299)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 RS3 v1709 and Windows Server 2016 RS3 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4507455 -title "August 13, 2019-KB4512516 (OS Build 16299.1331)" -Warn "Yes"
	CheckForHotfix -hotfixID 4507455 -title "July 9, 2019-KB4507455 (OS Build 16299.1268)"
	CheckForHotfix -hotfixID 4503284 -title "June 11, 2019-KB4503284 (OS Build 16299.1217)"
	CheckForHotfix -hotfixID 4499179 -title "May 14, 2019-KB4499179 (OS Build 16299.1146)"
	CheckForHotfix -hotfixID 4493441 -title "April 9, 2019-KB4493441 (OS Build 16299.1087)"
	CheckForHotfix -hotfixID 4489886 -title "March 12, 2019-KB4489886 (OS Build 16299.1029)"
	CheckForHotfix -hotfixID 4486996 -title "February 12, 2019-KB4486996 (OS Build 16299.967)"
	CheckForHotfix -hotfixID 4480978 -title "January 8, 2019-KB4480978 (OS Build 16299.904)"
	CheckForHotfix -hotfixID 4471329 -title "December 11, 2018-KB4471329 (OS Build 16299.846)"
	CheckForHotfix -hotfixID 4509093 -title "Servicing stack update for Windows 10, Version 1709: July 9, 2019"
}
elseif ($bn -eq 15063)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 RS2 v1703 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4507450 -title "August 13, 2019-KB4512507 (OS Build 15063.1988)" -Warn "Yes"
	CheckForHotfix -hotfixID 4507450 -title "July 9, 2019-KB4507450 (OS Build 15063.1928)"
	CheckForHotfix -hotfixID 4503279 -title "June 11, 2019-KB4503279 (OS Build 15063.1868)"
	CheckForHotfix -hotfixID 4499181 -title "May 14, 2019-KB4499181 (OS Build 15063.1805)"
	CheckForHotfix -hotfixID 4493474 -title "April 9, 2019-KB4493474 (OS Build 15063.1746)"
	CheckForHotfix -hotfixID 4489871 -title "March 12, 2019-KB4489871 (OS Build 15063.1689)"
	CheckForHotfix -hotfixID 4487020 -title "February 12, 2019-KB4487020 (OS Build 15063.1631)"
	CheckForHotfix -hotfixID 4480973 -title "January 8, 2019-KB4480973 (OS Build 15063.1563)"
	CheckForHotfix -hotfixID 4471327 -title "December 11, 2018-KB4471327 (OS Build 15063.1506)"
	CheckForHotfix -hotfixID 4509092 -title "Servicing stack update for Windows 10, Version 1703: July 9, 2019"
}
elseif ($bn -eq 14393)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 RS1 v1607 and Windows Server 2016 RS1 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4507460 -title "August 13, 2019-KB4512517 (OS Build 14393.3144)" -Warn "Yes"
	CheckForHotfix -hotfixID 4507460 -title "July 9, 2019-KB4507460 (OS Build 14393.3085)"
	CheckForHotfix -hotfixID 4503267 -title "June 11, 2019-KB4503267 (OS Build 14393.3025)"
	CheckForHotfix -hotfixID 4494440 -title "May 14, 2019-KB4494440 (OS Build 14393.2969)"
	CheckForHotfix -hotfixID 4493470 -title "April 9, 2019-KB4493470 (OS Build 14393.2906)"
	CheckForHotfix -hotfixID 4489882 -title "March 12, 2019-KB4489882 (OS Build 14393.2848)"
	CheckForHotfix -hotfixID 4487026 -title "February 12, 2019-KB4487026 (OS Build 14393.2791)"
	CheckForHotfix -hotfixID 4480961 -title "January 8, 2019-KB4480961 (OS Build 14393.2724)"
	CheckForHotfix -hotfixID 4471321 -title "December 11, 2018-KB4471321 (OS Build 14393.2665)"
	CheckForHotfix -hotfixID 4509091 -title "Servicing stack update for Windows 10, Version 1607: July 9, 2019"
}	
elseif ($bn -eq 10240)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 and Windows Server 2016 RTM Rollups"	 | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4507458 -title "August 13, 2019-KB4512497 (OS Build 10240.18305)" -Warn "Yes"
	CheckForHotfix -hotfixID 4507458 -title "July 9, 2019-KB4507458 (OS Build 10240.18275)"
	CheckForHotfix -hotfixID 4503291 -title "June 11, 2019-KB4503291 (OS Build 10240.18244)"
	CheckForHotfix -hotfixID 4499154 -title "May 14, 2019-KB4499154 (OS Build 10240.18215)"
	CheckForHotfix -hotfixID 4493475 -title "April 9, 2019-KB4493475 (OS Build 10240.18186)"
	CheckForHotfix -hotfixID 4489872 -title "March 12, 2019-KB4489872 (OS Build 10240.18158)"
	CheckForHotfix -hotfixID 4487018 -title "February 12, 2019-KB4487018 (OS Build 10240.18132)"
	CheckForHotfix -hotfixID 4480962 -title "January 8, 2019-KB4480962 (OS Build 10240.18094)"
	CheckForHotfix -hotfixID 4471323 -title "December 11, 2018-KB4471323 (OS Build 10240.18063)"
	CheckForHotfix -hotfixID 4509090 -title "Servicing stack update for Windows 10, Version 1507: July 9, 2019"
}
elseif ($bn -eq 9600)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 8.1 and Windows Server 2012 R2 Rollups"	 | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4512488 -title "August 13, 2019-KB4512488 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 4507448 -title "July 9, 2019-KB4507448 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4503276 -title "June 11, 2019-KB4503276 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4499151 -title "May 14, 2019-KB4499151 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4493446 -title "April 9, 2019-KB4493446 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4489881 -title "March 12, 2019-KB4489881 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4487000 -title "February 12, 2019-KB4487000 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4480963 -title "January 8, 2019-KB4480963 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4471320 -title "December 11, 2018-KB4471320 (Monthly Rollup)"
	CheckForHotfix -hotfixID 3123245 -title "Update improves port exhaustion identification in Windows Server 2012 R2"
	CheckForHotfix -hotfixID 4504418 -title "Servicing stack update for Windows Server 2012, Windows 8.1 and Windows Server 2012 R2: July 9, 2019"
	CheckForHotfix -hotfixID 3179574 -title "August 2016 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3172614 -title "July 2016 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3013769 -title "December 2014 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3000850 -title "November 2014 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 2919355 -title "[Windows 8.1 Update 1] Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2 Update: April 2014"
	CheckForHotfix -hotfixID 2883200 -title "Windows 8.1 and Windows Server 2012 R2 General Availability Update Rollup"
}
elseif ($bn -eq 9200)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows Server 2012 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------"  | Out-File -FilePath $OutputFile -append
	
	CheckForHotfix -hotfixID 4512518 -title "August 13, 2019-KB4512518 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 4507462 -title "July 9, 2019-KB4507462 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4503285 -title "June 11, 2019-KB4503285 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4499171 -title "May 14, 2019-KB4499171 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4493451 -title "April 9, 2019-KB4493451 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4489891 -title "March 12, 2019-KB4489891 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4487025 -title "February 12, 2019-KB4487025 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4480975 -title "January 8, 2019-KB4480975 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4471330 -title "December 11, 2018-KB4471330 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4504418 -title "Servicing stack update for Windows Server 2012, Windows 8.1 and Windows Server 2012 R2: July 9, 2019"
	CheckForHotfix -hotfixID 3179575 -title "August 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3172615 -title "July 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3161609 -title "June 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3156416 -title "May 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3013767 -title "December 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 3000853 -title "November 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 2995388 -title "October 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012 "
	CheckForHotfix -hotfixID 2984005 -title "September 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 2975331 -title "August 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 2967916 -title "July 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012" 
	CheckForHotfix -hotfixID 2962407 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: June 2014" 
	CheckForHotfix -hotfixID 2955163 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: May 2014"
	CheckForHotfix -hotfixID 2934016 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: April 2014" 	
	CheckForHotfix -hotfixID 2928678 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: March 2014" 	
	CheckForHotfix -hotfixID 2919393 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: February 2014"
	CheckForHotfix -hotfixID 2911101 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: January 2014"
	CheckForHotfix -hotfixID 2903938 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: December 2013"
	CheckForHotfix -hotfixID 2889784 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: November 2013"
	CheckForHotfix -hotfixID 2883201 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: October 2013"
	CheckForHotfix -hotfixID 2876415 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: September 2013"
	CheckForHotfix -hotfixID 2862768 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: August 2013"	
	CheckForHotfix -hotfixID 2855336 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: July 2013"	
	CheckForHotfix -hotfixID 2845533 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: June 2013"	
	CheckForHotfix -hotfixID 2836988 -title "Windows 8 and Windows Server 2012 Update Rollup: May 2013" 				
	CheckForHotfix -hotfixID 2822241 -title "Windows 8 and Windows Server 2012 Update Rollup: April 2013"				
	CheckForHotfix -hotfixID 2811660 -title "Windows 8 and Windows Server 2012 Update Rollup: March 2013"				
	CheckForHotfix -hotfixID 2795944 -title "Windows 8 and Windows Server 2012 Update Rollup: February 2013"			
	CheckForHotfix -hotfixID 2785094 -title "Windows 8 and Windows Server 2012 Update Rollup: January 2013"				
	CheckForHotfix -hotfixID 2779768 -title "Windows 8 and Windows Server 2012 Update Rollup: December 2012"			
	CheckForHotfix -hotfixID 2770917 -title "Windows 8 and Windows Server 2012 Update Rollup: November 2012"			
	CheckForHotfix -hotfixID 2756872 -title "Windows 8 Client and Windows Server 2012 General Availability Update Rollup"
}
elseif ($bn -eq 7601)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 7 and Windows Server 2008 R2 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn + "   (RTM=7600, SP1=7601)" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------"  | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4512506 -title "August 13, 2019-KB4512506 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 4507449 -title "July 9, 2019-KB4507449 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4503292 -title "June 11, 2019-KB4503292 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4499164 -title "May 14, 2019-KB4499164 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4493472 -title "April 9, 2019-KB4493472 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4489878 -title "March 12, 2019-KB4489878 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4486563 -title "February 12, 2019-KB4486563 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4480970 -title "January 8, 2019-KB4480970 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4471318 -title "December 11, 2018-KB4471318 (Monthly Rollup)"
	CheckForHotfix -hotfixID 3125574 -title "Convenience roll-up update for Windows 7 SP1 and Windows Server 2008 R2 SP1"
	CheckForHotfix -hotfixID 4490628 -title "Servicing stack update for Windows 7 SP1 and Windows Server 2008 R2 SP1: March 12, 2019"
	CheckForHotfix -hotfixID 2775511 -title "An enterprise hotfix rollup is available for Windows 7 SP1 and Windows Server 2008 R2 SP1"

	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Followup Fixes Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   -----------------------------"  | Out-File -FilePath $OutputFile -append
	CheckForHotfix -hotfixID 2732673 -title "`"Delayed write failed`" error message when .pst files are stored on a network file server that is running Windows Server 2008 R2"
	CheckForHotfix -hotfixID 2728738 -title "You experience a long logon time when you try to log on to a Windows 7-based or a Windows Server 2008 R2-based client computer that uses roaming profiles"
	CheckForHotfix -hotfixID 2878378 -title "OpsMgr 2012 or OpsMgr 2007 R2 generates a Heartbeat Failure message and then goes into a greyed out state in Windows Server 2008 R2 SP1"
}
elseif ($bn -eq 6002)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows Vista and Windows Server 2008 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn + "   (RTM=6000, SP2=6002)" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------"  | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 4512476 -title "August 13, 2019-KB4512476 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 4507452 -title "July 9, 2019-KB4507452 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4503273 -title "June 11, 2019-KB4503273 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4499149 -title "May 14, 2019-KB4499149 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4493471 -title "April 9, 2019-KB4493471 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4489880 -title "March 12, 2019-KB4489880 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4487023 -title "February 12, 2019-KB4487023 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4480968 -title "January 8, 2019-KB4480968 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4471325 -title "December 11, 2018-KB4471325 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4493730 -title "Servicing stack update for Windows Server 2008 SP2: April 9, 2019"
}

	CollectFiles -filesToCollect $OutputFile -fileDescription "Hotfix Rollups" -SectionDescription $sectionDescription

