# KB4528577 Registry Files
In order to enable faster and error free implementation of the registry based solution, as described in  https://internal.support.services.microsoft.com/en-us/help/4528577, Winodws CSS team provided the relevant zip files.

## WARNING: serious problems might occur if you modify the registry incorrectly by using Registry Editor or by using another method. These problems might require you to reinstall the operating system. Microsoft cannot guarantee that these problems can be resolved. Modify the registry at your own risk. 