﻿
# Load Common Library
#_#$debug = $false

. ./utils_cts.ps1
#_#. ./TS_RemoteSetup.ps1 #_#

$FirstTimeExecution = FirstTimeExecution
if ($FirstTimeExecution) 
{
	#Event Logs - System & Application logs
	$sectionDescription = "Event Logs (System and Application)"
	$EventLogNames = "System", "Application"
	#_#
	Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription

	if ($Global:skipBPA -ne $true) {
		#Windows Server 2008+
		if ($OSVersion.Build -gt 6000)
		{
			#BPA section
			if ((Get-WmiObject -Class Win32_ComputerSystem).DomainRole -gt 1)
			{
				#DHCP Role
				$SvcKey = "HKLM:\SYSTEM\CurrentControlSet\services\DHCPServer"
				if (Test-Path $SvcKey) 
				{
				Run-DiagExpression .\TS_BPAInfo.ps1 -BPAModelID "Microsoft/Windows/DHCPServer" -OutputFileName ($Computername + "_DhcpServer_BPAInfo.HTM") -ReportTitle "DHCP Best Practices Analyzer" 
				}

				#DNSServer Role
				$SvcKey = "HKLM:\SYSTEM\CurrentControlSet\services\DNS"
				if (Test-Path $SvcKey) 
				{
				Run-DiagExpression .\TS_BPAInfo.ps1 -BPAModelID "Microsoft/Windows/DNSServer" -OutputFileName ($Computername + "_DnsServer_BPAInfo.HTM") -ReportTitle "DNS Server Best Practices Analyzer" 
				}

				#NPAS Role
				If ((Get-WmiObject Win32_ServerFeature -Filter "ID=14") -ne $null)
				{
					$RunNPASCollector = $true
					if($OSVersion.Build -eq 9200) #Windows Server 2012
					{
						#System locale is ja-JP and Hotfix KB2787651 is not installed
						if(($PSCulture -eq "ja-JP") -and ((Get-HotFix -Id "KB2787651") -eq $null))
						{
							$RunNPASCollector = $false
							"[Warning] KB2787651 is not installed on a Japanese System. This is required to be installed on Windows Server 2012. NPAS BPA will not be collected." | WriteTo-StdOut -ShortFormat
						}
					}
					if($RunNPASCollector)
					{
						Run-DiagExpression .\TS_BPAInfo.ps1 -BPAModelID "Microsoft/Windows/NPAS" -OutputFileName ($Computername + "_NPAS_BPAInfo.HTM") -ReportTitle "NPAS Best Practices Analyzer" 
					}
				}		

				#File Services Role
				If ((Get-WmiObject Win32_ServerFeature -Filter "ID=6") -ne $null)
				{
				Run-DiagExpression .\TS_BPAInfo.ps1 -BPAModelID "Microsoft/Windows/FileServices" -OutputFileName ($Computername + "_SMBServer_BPAInfo.HTM") -ReportTitle "FileServices Best Practices Analyzer" 
				}
			}
		}
	}
	
	#_#Run-DiagExpression .\TS_QueueEventLogRules.ps1
	Run-DiagExpression .\TS_DumpCollector.ps1 -CopyWERMinidumps -CopyMachineMiniDumps -MaxFileSize 300 -CopyUserDumps -CopyWERFulldumps

	# Auto Added Commands [AutoAdded]
	.\TS_AutoAddCommands_NET.ps1

	EndDataCollection
	#_#EndDataCollection_rem

} 
else
{
	#2nd execution. Delete the temporary flag file then exit
	EndDataCollection -DeleteFlagFile $True
}

Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}


