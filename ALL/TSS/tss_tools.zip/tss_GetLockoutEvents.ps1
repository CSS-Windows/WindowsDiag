# Name tss_GetLockoutEvents.ps1

<# 
.SYNOPSIS
 Script to find Account Lockout: PowerShell script collects Security events from all DCs related with Bad Password attempts

.DESCRIPTION
 PowerShell script sample to assist in troubleshooting account lockout issues. It can be used to collect Security Events from all DCs in a given forest or domain.
 It collects events like 4625, 4771, 4776 with error codes 0x18 and c000006a respectively.
 You do not have to run the script elevated. However you have to run it with *domain admin* privileges.
 It can be run against any domain in the forest you logon to run the script. Running against a different domain may need you to run the script with other domain admin privileges or Enterprise Admin.
 Script can also detect trusted domains and collect events from remote DCs. Make sure that the domain admin running the script has the permission to collect events remotely from trusted domains.

.PARAMETER UserName
 Please enter the UserName (sAMAccountName)
 
.PARAMETER DomainName
 Please enter the NetBIOS or FQDN of any domain in the forest
 
.PARAMETER DataPath
 This switch determines the path for output files
 
.EXAMPLE
 .\tss_GetLockoutEvents.ps1 -UserName "User1" -DomainName "Contoso" -DataPath "C:\MS_DATA" 
 Example 1:  for User1 in domain Contoso
 
.LINK
 https://internal.support.services.microsoft.com/en-us/help/4498703
 https://microsoft.sharepoint.com/teams/HybridIdentityPOD/_layouts/15/Doc.aspx?sourcedoc={5bec59af-bf31-4073-9111-a63486fcdf0c}&action=view&wd=target%28Account%20Lockouts.one%7C9a46c4f5-38af-4648-93f2-8a976a91c463%2FWorkflow%20Account%20Lockout%20Data%20Collection%20-%20Reactive%7Cdc03d719-fff5-4bdf-b46e-15456c2521f1%2F%29
 
 Author: Ahmed Fouad (v-ahfoua@microsoft.com)
#>


# Version 1.4 - 2020.03.25 WalterE

[CmdletBinding()]
PARAM (
    [Parameter(Mandatory=$True,Position=0,HelpMessage='Enter user sAMAccountName')]
	[string]$UserName
	,
	[Parameter(Mandatory=$True,Position=1,HelpMessage='Enter DomainName')]
	[string]$DomainName
	,
	[string]$DataPath = (Split-Path $MyInvocation.MyCommand.Path -Parent)
)

#region helper functions
function CheckDomain
{	# Check domain and user variables
	try 
	{
	  Write-Host "..Checking whether domain $DomainName exists" 
	  if (Get-ADDomain $DomainName) 
	   {
		Write-Host "Domain '$DomainName' exists" -fore Green
	   }

	}
	catch 
	{
		 Write-Host $_.Exception.Message -fore Red
		 break 
	}
}

function CheckUser
{	# Check whether the user exist or not
	try
	{
	   Write-Host "..Checking whether AD user $UserName exists" 
	   if (Get-ADUser -Identity $UserName -Server $DomainName) 
		{
		 Write-Host "AD user '$UserName' exists in '$DomainName' domain" -fore Green
		}
	}
	catch 
	{
		Write-Host  $_.Exception.Message -fore Red
		break 
	}
}

function CheckDomainAdmin
{
	Write-Host "..Checking whether the current user $env:Username has domain admin privilege" 

	if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole("$DomainName\Domain Admins") -and  (-not  ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole("Enterprise Admins") ) ) 
	  {
		Write-Host "Sorry you '$env:Username' don't have domain admin privilege to run this script" -fore Red
		Break
	  }
	Else 
	  {
		Write-Host "User '$UserName' is member of '$DomainName\Domain Admins'" -fore Green 
	  }
}
#endregion helper functions


#region variables

[xml]$xmlfilter = "<QueryList> 
           <Query Id='0'> 
              <Select Path='Security'> 
                 *[EventData[Data[@Name='TargetUserName'] and (Data='$username')]] 
                  and 
                 *[EventData[Data[@Name='status'] and (Data='0x18')]] 
                 and
                 *[System[(EventID='4771' or EventID='4768' or EventID='4769' )]]
              </Select> 
           </Query> 
<Query Id='1'> 
              <Select Path='Security'> 
               *[EventData[Data[@Name='TargetUserName'] and (Data='$username')]] 
               and  
               *[EventData[Data[@Name='substatus'] and (Data='0xc000006a')]] 
                  and
               *[System[(EventID='4625' )]] 
               </Select> 
           </Query> 
<Query Id='2'> 
              <Select Path='Security'> 
               *[EventData[Data[@Name='TargetUserName'] and (Data='$username')]] 
                  and
               *[System[(EventID='4740' or EventID='4767' )]] 
               </Select> 
           </Query> 
<Query Id='3'> 
              <Select Path='Security'> 
               *[EventData[Data[@Name='TargetUserName'] and (Data='$username')]] 
               and  
               *[EventData[Data[@Name='Status'] and (Data='0xc000006a')]] 
                  and
               *[System[(EventID='4776' )]] 
               </Select> 
           </Query> 

</QueryList>"

#_# $DataPath = read-host "Please enter the path of the report (leave it blank to use the default path)"

if ($DataPath)
    {
      $fullpath = $DataPath
      New-Item -ItemType Directory -Path $fullpath\LockoutLogs -ErrorAction SilentlyContinue -InformationAction SilentlyContinue | Out-Null
    }
Else 
    {
     $fullpath = (get-location).path
     New-Item -ItemType Directory -Path $fullpath\LockoutLogs -ErrorAction SilentlyContinue -InformationAction SilentlyContinue | Out-Null
    
    }

$CSVPath = $fullpath + "\LockoutLogs\Report.csv" 


$AllEvents = @()
$SourceMachines = @()
$ExchangeServersIPv4 = @()

foreach ($ExchangeServer in $ExchangeServers ) 
{
   $ExchangeServersIPv4 += (Resolve-DnsName $ExchangeServer.name).IPAddress

}

#endregion variables

function GetEventsFromAllDCs
{
	$Dcs = Get-ADDomainController -Filter * -Server $DomainName
	#get events from all domain controllers
	foreach ($dc in $Dcs)
	{
	$serverName = $dc.HostName
	Write-Host "Checking connectivity to DC:" $serverName 
	$PingStatus = gwmi win32_pingStatus -Filter "Address = '$serverName'"

	if ($PingStatus.StatusCode -eq 0)
		{  
		  Write-Host $serverName  " is Online" -fore Green
		  Write-Host "Collecting logs from:" $serverName
		  $Events = get-winevent -FilterXml $xmlfilter -ComputerName $serverName -ErrorAction SilentlyContinue  
		  foreach ($event in $events)
		  {
		   $eventxml = [xml]$event.ToXml()

		   if ($event.Id -eq "4771")
			 {
			  $ipv4 = ($eventxml.Event.EventData.Data[6].'#text').Split(":")
			  $myObject = New-Object System.Object
			  $myObject | Add-Member -type NoteProperty -name "Source Machine" -Value $ipv4[($ipv4.length -1 )]
			  $myObject | Add-Member -type NoteProperty -name "Event ID" -Value "4771"
			  $SourceMachines += $myObject
			 } 
		   if ($event.Id -eq "4776")
			 {
			  $ipv4 = Resolve-DnsName ($eventxml.Event.EventData.Data[2].'#text')
			  $myObject = New-Object System.Object
			  $myObject | Add-Member -type NoteProperty -name "Source Machine" -Value $ipv4.IPAddress
			  $myObject | Add-Member -type NoteProperty -name "Event ID" -Value "4776"
			  $SourceMachines += $myObject
			   
			 }
		   if ($event.Id -eq "4625")
			 {
			  $ipv4 = Resolve-DnsName ($eventxml.Event.EventData.Data[2].'#text')
			  $myObject = New-Object System.Object
			  $myObject | Add-Member -type NoteProperty -name "Source Machine" -Value $ipv4.IPAddress
			  $myObject | Add-Member -type NoteProperty -name "Event ID" -Value "4625"
			  $SourceMachines += $myObject
			 }
		  }
		  if ($($Events.count) -eq 0) {
			Write-Host "[Info] Found $($Events.count) Events on $serverName for $UserName" -ForegroundColor Cyan
		  } else { Write-Host "[Warning] Found $($Events.count) Events on $serverName for $UserName" -BackgroundColor Red}
 		  
		  $AllEvents += $Events
		}
	Else 
	   {
		 Write-Host "$serverName is offline" -fore Red
	   }
	}

	# save the report 
	if ($AllEvents -ne 0)
	   { 
		 $AllEvents | select MachineName,TimeCreated,ProviderName,Id,@{n='Message';e={$_.Message -replace '\s+', " "}} | Export-Csv -Path  $CSVPath -NoTypeInformation
	   }
	if ($($AllEvents.count) -eq 0) {
		Write-Host "[Info] $($AllEvents.count) events found on all domain controllers `n" -ForegroundColor green
	} else { Write-Host "[Warning] $($AllEvents.count) events found on all domain controllers `n" -BackgroundColor Red}
	Write-Verbose "$AllEvents"

	if ($SourceMachines.Count -gt 0 )
	  {
		Write-Host "Summary of source machines for the bad password `n" -BackgroundColor Green -ForegroundColor Red
		$SourceMachines | Group-Object "Source Machine","Event ID"  -NoElement   | Sort-Object -Property Count -Descending
		$ExchangeServersIncluded = Compare-Object -ReferenceObject $SourceMachines."Source Machine"  -DifferenceObject $ExchangeServersIPv4  -IncludeEqual -ExcludeDifferent
		if ($ExchangeServersIncluded.InputObject.Length -gt 0 ) 
		   { 
			 Write-Host "`n Below Exchange Servers included in bad password source machines list `n" -BackgroundColor Green -ForegroundColor Red
			 $ExchangeServersIncluded.InputObject

			 $ExportExchangeLogs = read-host "`nDo you want to export IIS logs from mentioned Exchange servers (Yes/No)" 
			 if ($ExportExchangeLogs = "yes ")
				{
				  foreach ($ip in $ExchangeServersIncluded.InputObject)
					{
					  New-Item -ItemType Directory -Path "$fullpath\Exchange_$ip" -InformationAction SilentlyContinue -ErrorAction SilentlyContinue | Out-Null
					  Copy-Item -Path \\$ip\c$\inetpub\logs\LogFiles -Destination "$fullpath\LockoutLogs\Exchange_$ip" -Recurse -Force
					}
				}
		   }
	  }
} # end GetEventsFromAllDCs

# MAIN 
CheckDomainAdmin
CheckDomain
CheckUser
GetEventsFromAllDCs
