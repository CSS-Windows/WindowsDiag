# NOREPAD

##Purpose 
Reader application for huge text files. 

##Details
This can be big ETL files or AD �dumpdatabase� dumps.
Normal �editor� type applications give up in the xxGB range, Norepad opens them without delay.

NOREPAD does become slower searching the files as they become bigger, but there is no upper size limit on files it can open. You can open one file per instance, but have multiple search windows per file.

The behavior selecting text is strange, it really only works with the mouse. Select bigger areas using the Shift key and clicking on the target end of selection location with the mouse. For example, se that to copy interesting sections into text buffers of regular editors.

## Important "General Data Protection Regulation and Legal" Notes:
NOREPAD is used for reading text files and it is not intended for data collection.
NOREPAD is provided as it is and neither Microsoft nor the author have any legal responsibility over it.