﻿# xray_sha.ps1
# Created by tdimli
# March 2020
#
# Support for known issues in SHA area
# contributors: 
# developers: 

# version
$SHA_version = "1.0.200421.0"

# Area and Area/Component arrays
# Example: $AREA = @("Component1", "Component2")
$SHA = @()

#Component/Diagnostic (Check) Function arrays
# Example: $Component1 = @("Diag_Func1", "Diag_Func1")

# For more details, please review developer.md file for guidance for diagnostic function developers

# begin: diagnostic functions
#    <your diagnostic functions here>
# end: diagnostic functions