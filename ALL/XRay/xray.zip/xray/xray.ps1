﻿# xray.ps1
# by tdimli
# March 2020
# Checks for known issues

# parameters
# Specify either one or more area(s) or component(s), not both
Param(
    [Parameter(Mandatory=$true,
    ParameterSetName="Areas")]
    [String[]]
    $Area,

    [Parameter(Mandatory=$true,
    ParameterSetName="Components")]
    [String[]]
    $Component,

    [Parameter(Mandatory=$false,
    ParameterSetName="Areas")]
    [Parameter(Mandatory=$false,
    ParameterSetName="Components")]
    [String[]]
    $DataPath,

    [Parameter(Mandatory=$false,
    ParameterSetName="Areas")]
    [Parameter(Mandatory=$false,
    ParameterSetName="Components")]
    [switch]
    $Offline,

    [Parameter(Mandatory=$false)]
    [switch]
    $WaitBeforeClose,

    [Parameter(Position=0, Mandatory=$false,
    ParameterSetName="Help")]
    [AllowEmptyString()]
    [AllowNull()]
    [String]
    $Help
)

# tech-area specific diagnostic files
. ".\xray_ads.ps1"
. ".\xray_dnd.ps1"
. ".\xray_net.ps1"
. ".\xray_prf.ps1"
. ".\xray_sha.ps1"
. ".\xray_uex.ps1"

#region globals
# version
$version = "1.0.200404.0"

# Area and Area/Component arrays
$TechAreas = @("ADS", "DND", "NET", "PRF", "SHA", "UEX")

# constant return codes
Set-Variable -Name "ReturnCode_Success" -Option Constant -Value [Int]0 #-Visibility Public
Set-Variable -Name "ReturnCode_Skipped" -Option Constant -Value [Int]1 #-Visibility Public
Set-Variable -Name "ReturnCode_Failed" -Option Constant -Value [Int]2 #-Visibility Public

# counters
[int]$Global:DiagnosticsRun = 0
[int]$Global:DiagnosticsSuccess = 0
[int]$Global:DiagnosticsSkipped = 0
[int]$Global:DiagnosticsFailed = 0
[int]$Global:IssuesFound = 0
#endregion variables

#region diaghelpers
# For use by diagnostic functions

# To report an issue if one was identified by a diagnostic function
# Diagnostic functions use this function to report the issue they have identified 
function ReportIssue
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [String]
        $issueMsg,

        [Parameter(Mandatory=$true,
        Position=1)]
        [String]
        $issueDocName
    )

    $Global:IssuesFound = $IssuesFound + 1

    # retrieve online doc and add to message
    $uri = "https://raw.githubusercontent.com/CSS-Windows/WindowsDiag/master/ALL/XRay/$issueDocName"
    $issueMsg += "`n"
    $issueMsg += GetIssueDetails $uri

    # get caller/diagnostic details
    $callStack = Get-PSCallStack
    if ($callStack.Count -gt 1) {
        $caller = $callStack[1].FunctionName + " " + (Split-Path -Path $callStack[1].ScriptName -Leaf).ToString() + ":" +  $callStack[1].ScriptLineNumber
    }

    LogToFile "Issue reported by diagnostic [$caller]($Global:IssuesFound): $issueDocName"
    if(1 -eq $Global:IssuesFound) {
        "xray $version`n">$reportfile
    }
    "Issue $Global:IssuesFound - Found a potential issue ($issueDocName):">>$reportfile
    "`tReported by diagnostic [$caller]`n">>$reportfile
    $issueMsg>>$reportfile
    
    # show message on screen
    Write-Host "`nIssue $Global:IssuesFound - Found a potential issue ($issueDocName):" -ForegroundColor red
    IndentMsg $issueMsg
}

# Wraps a filename with "xray_" prefix and timestamp & computername suffix "" for consistency
# Ensures all files created have the same name format and same run of xray script use the same timestamp-suffix
function MakeFileName 
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [String]
        $name,

        [Parameter(Mandatory=$true,
        Position=1)]
        [String]
        $extension
    )   
    $computer = hostname
    $newname = "xray_" + "_" + $name + "_" + $timestampSuffix + $computer + "." + $extension
    if ($DataPath -and (Test-Path -Path $DataPath)) {
        $newname = Join-Path -Path $DataPath -ChildPath $newname
    }
    return $newname
}

# Logs to activity log with timestamp
function LogToFile
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [String]
        $logentry
    )

    $callStack = Get-PSCallStack
    if ($callStack.Count -gt 1) {
        $caller = $callStack[1].FunctionName + " " + (Split-Path -Path $callStack[1].ScriptName -Leaf).ToString() + ":" +  $callStack[1].ScriptLineNumber
    }
    $timestamp = (Get-Date -Format "yyyy/MM/dd HH:mm:ss.fffffff").ToString()
    "$timestamp [$caller] $logentry" >> $logfile
}
#endregion diaghelpers

#region helpers
# For use by main script functions
# Not for use by diagnostic functions

# Processes provided area(s) with all its components & checks
function RunAreaChecks($areas)
{
    $areas = $areas.Split(",", [System.StringSplitOptions]::RemoveEmptyEntries)
    foreach ($area in $areas) {
        LogToFile "Processing area:$area"
        $ErrorActionPreference = "Stop"
        try {
            $components = (Get-Variable -Name $area).Value
        }
        catch {
            LogToFile $Error[0].Exception
            continue
        }
        finally {
            $ErrorActionPreference = "Continue"
        }
        RunComponentChecks $components
    }
}

# Processes provided components and runs corresponding checks
function RunComponentChecks($components)
{
    $components = $components.Split(",", [System.StringSplitOptions]::RemoveEmptyEntries)
    foreach ($component in $components) {
        LogToFile "Processing component: $component"
        $ErrorActionPreference = "Stop"
        try {
            $checks = (Get-Variable -Name $component).Value
        }
        catch {
            LogToFile $Error[0].Exception
            continue
        }
        finally {
            $ErrorActionPreference = "Continue"
        }

        # to prevent failure messages from diag functions
        $ErrorActionPreference = "Stop"

        foreach ($check in $checks) {
            LogToFile "Running check: $check"
            Write-Host "." -NoNewline
            try {
                $Global:DiagnosticsRun = $DiagnosticsRun + 1
                $result = & $check $Offline
            }
            catch {
                $Global:DiagnosticsFailed = $DiagnosticsFailed + 1
                LogToFile $Error[0].Exception
                continue
            }

            if($result -eq $ReturnCode_Success){
                $Global:DiagnosticsSuccess = $DiagnosticsSuccess + 1
            }
            elseif($result -eq $ReturnCode_Skipped){
                $Global:DiagnosticsSkipped = $DiagnosticsSkipped + 1
            }
            else {
                $Global:DiagnosticsFailed = $DiagnosticsFailed + 1
            }
        }

        # this was to prevent failure messages from diag functions, now revert to normal error handling 
        $ErrorActionPreference = "Continue"
    }
}

# Shows message on screen indented for readability
function IndentMsg($msg)
{
    $newMsg = $msg -split "`n"
    foreach ($line in $newMsg) {
        Write-Host "   $line"
    }
}

function GetIssueDetails
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [String]
        $uri
    )

    try
    {
        $Response = Invoke-WebRequest -URI $uri -ErrorAction Stop
        # This will only execute if the Invoke-WebRequest is successful.
        if($Response.StatusCode -eq 200) {
            $issueDetails = $Response.Content
        }
        else {
            LogToFile "Error whilst retrieving issue details [$uri]: $Response.StatusCode"
        }
    }
    catch
    {
        LogToFile "Exception whilst retrieving issue details [$uri]: $_.Exception.Response.StatusCode.value__"
    }

    if($issueDetails) {
        return $issueDetails
    }
    else {
        return "For more information on this issue please visit $uri" 
    }
}

# Displays help/usage info
function ShowHelp
{
    "xray by tdimli, v$version"
    ""
    "Checks for known Windows issues"
    ""
    "Usage:"
    "xray.ps1 -Area <string[]> [-DataPath <string[]>] [-Offline] [-WaitBeforeClose] [<CommonParameters>]"
    "xray.ps1 -Component <string[]> [-DataPath <string[]>] [-Offline] [-WaitBeforeClose] [<CommonParameters>]"
    "xray.ps1 [-Help]"
    "`tParameters:"
    "`tSpecify either Area or Component to check for (they are mutually exclusive), multiple items can be specified (comma-separated)."
    "`t`tWhen area(s) specified, all components within the specified area(s) are checked"
    "`t`tArea:all or Area:* checks all areas"
    "`t-DataPath: Path for input/output files"
    "`t-Offline: Not running on the actual machine being examined (some -not all- diagnostics can use data files to search for issues)"
    "`t-WaitBeforeClose: Pauses the script just before window closes, use when script is run in a new window to read output before it closes"
    ""
    "`tExample: .\xray.ps1 -Component dhcpsrv,dnssrv -DataPath c:\xray"
    ""
    "List of available diagnostic areas/components to scan for issues:"
    "Area (version):  `tComponents:"
    "=================`t==========="
    foreach ($techarea in $TechAreas) {
        $version_name = $techarea + "_version"
        $techarea_version = (Get-Variable -Name $version_name).Value
        $components = (Get-Variable -Name $techarea).Value
        "$techarea ($techarea_version)`t$components"
    }
    ""
}
#endregion helpers

#region main
# main script

if($Help -ne $null) {
    $Help
}

if (($Area -eq $null) -and ($Component -eq $null)) {
    # show help if no area or component specified
    ShowHelp
}
else {
    # create activity log
    $timestampSuffix = Get-Date -Format "yyyyMMddHHmmss"
    $logfile = MakeFileName "log" "txt"
    $reportfile = MakeFileName "REPORT" "txt"
    LogToFile "xray $version"
    Write-Host "xray $version"
    foreach ($techarea in $TechAreas) {
        $version_name = $techarea + "_version"
        $techarea_version = (Get-Variable -Name $version_name).Value
        LogToFile " $techarea $techarea_version"
    }
    # log parameters
    LogToFile "Parameters:"
    LogToFile " Area(s): $Area"
    LogToFile " Component(s): $Component"
    LogToFile " Datapath: $DataPath"
    LogToFile " Offline: $Offline"
    LogToFile " WaitBeforeClose: $WaitBeforeClose"

    LogToFile "Log file: $logfile"
    LogToFile "Starting diagnostic checks..."
    Write-Host "Starting diagnostic checks..."

    if ($Area) {
        # do we need to run checks for all areas?
        if (($Area -eq  "all") -or ($Area -eq  "*")) {
            # run checks for all areas
            RunAreaChecks $TechAreas
        } else {
            # run checks for the area(s) specified
            RunAreaChecks $Area
        }
    } elseif ($Component) {
        # run checks for the component(s) specified
        RunComponentChecks $Component
    }

    LogToFile "$DiagnosticsRun diagnostic(s) run (Success: $DiagnosticsSuccess | Failure: $DiagnosticsFailed | Skipped: $DiagnosticsSkipped)"
    LogToFile "$IssuesFound issue(s) found"
    LogToFile "Finished"
}

if($IssuesFound -eq 0) {
    # show summary
    Write-Host "`n$DiagnosticsRun diagnostic(s) run (Success: $DiagnosticsSuccess | Failure: $DiagnosticsFailed | Skipped: $DiagnosticsSkipped)"
    Write-Host "$IssuesFound issue(s) found"
    Write-Host "Diagnostics completed`n"
}
elseif($WaitBeforeClose) {
    # wait to ensure issue details are seen
    pause
}
#endregion main
