﻿# xray_net.ps1
# Created by tdimli
# March 2020
#
# Support for known issues in NET area
# contributors: tdimli
# developers: tdimli

# version
$NET_version = "1.0.200423.0"

# Area and Area/Component arrays
$NET = @("DhcpSrv", "802Dot1x") #, "WLAN", "Auth", "BITS", "BranchCache", "Container", "CSC", "DAcli", "DAsrv", "DFScli", "DFSsrv", "DHCPcli", "DNScli", "DNSsrv", "Firewall", "General", "HypHost", "HypVM", "IIS", "IPAM", "MsCluster", "MBAM", "MBN", "Miracast", "NCSI", "NetIO", "NFScli", "NFSsrv", "NLB", "NPS", "Proxy", "RAS", "RDMA", "RDScli", "RDSsrv" "SDN" "SdnNC" "SQLtrace" "SBSL" "UNChard" "VPN" "WFP" "Winsock" "WIP" "WNV" "Workfolders")

#Component/Diagnostic (Check) Function arrays
$DhcpSrv = @("net_dhcpsrv_KB4503857")
$802Dot1x = @("net_802Dot1x_KB4556307")
$WLAN = @()

# begin: diagnostic functions

#region net_dhcpsrv_KB4503857
<#
Checks for:
The issue where a DHCP Server has Option 66 (Boot Server Host Name) defined
but the name(s) cannot be resolved to IP addresses.
This causes DHCP Server repeatedly spending time to resolve these names and
prevents it from serving clients. This can cause DHCP outages.
#>
function net_dhcpsrv_KB4503857
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [Boolean]
        $offline
    )

    $issueMsg = "
Following Option 66 (Boot Server Host Name) values are configured on this DHCP 
Server but cannot be resolved to IP address. This can cause DHCP outages!

<xray!diag>

Resolution:
Check Option 66 entries listed above and ensure that all configured names can 
be resolved and resolved in a timely manner by the DHCP Server.
To test, you can use ping command or Resolve-DnsName Powershell cmdlet.
Remove any Option 66 entry that contains a name which cannot be resolved.
"

    if($offline) { 
        LogToFile "Cannot run offline, skipping"
        return $ReturnCode_Skipped
    }

    $services = Get-Service -Name "DHCPServer" -ErrorAction SilentlyContinue
    if(($services.Count -ne 1) -or ($services.Status -ne "Running")) {
        # No DHCP Server, nothing to check
        LogToFile "No running DHCP Server, nothing to check, skipping"
        return $ReturnCode_Skipped
    }

    $outfile = MakeFileName "dhcpexport" "xml"

    try{
        Export-DhcpServer -File $outfile -Force -ErrorVariable DhcpError
    }
    catch {
        # export failed, not running on DHCP server?
        LogToFile "Error: Export failed - exiting! (Error: $_)"
        return $ReturnCode_Failed
    }

    [xml]$Dhcp = Get-Content $outfile

    $FailedNames = ""

    # Check Server Options for unresolvable Option 66 Boot Server Host Name
    $Dhcp.DHCPServer.IPv4.OptionValues.OptionValue | ForEach-Object -Process {
        if ($_.OptionId -eq 66) {
            $Option66 = $_.Value
            if (!(ResolveDnsName $Option66)) {
                # failed, add error to return msg
                $FailedNames += "$Option66 (IPv4->Server Options)`n"
            }
        }
    }

    # Check Server-level Policy Options for unresolvable Option 66 Boot Server Host Name
    $Dhcp.DHCPServer.IPv4.Policies.Policy | ForEach-Object -Process {
        $PolicyName = $_.Name
        $_.OptionValues.OptionValue | ForEach-Object -Process {
            if ($_.OptionId -eq 66) {
                $Option66 = $_.Value
                if (!(ResolveDnsName $Option66)) {
                    # failed, add error to return msg
                    $FailedNames += "$Option66 (IPv4->Policies->$PolicyName)`n"
                }
            }
        }
    }

    # Check Scopes for unresolvable Option 66 Boot Server Host Name
    $Dhcp.DHCPServer.IPv4.Scopes.Scope | ForEach-Object -Process {
        $ScopeId = $_.ScopeId

        # Scope options
        $_.OptionValues.OptionValue | ForEach-Object -Process {
            if ($_.OptionId -eq 66) {
                $Option66 = $_.Value
                if (!(ResolveDnsName $Option66)) {
                    # failed, add error to return msg
                    $FailedNames += "$Option66 (IPv4->Scope[$ScopeId])`n"
                }
            }
        }

        # Scope Policy Options
        $_.Policies.Policy | ForEach-Object -Process {
            $PolicyName = $_.Name
            $_.OptionValues.OptionValue | ForEach-Object -Process {
                if ($_.OptionId -eq 66) {
                    $Option66 = $_.Value
                    if (!(ResolveDnsName $Option66)) {
                        # failed, add error to return msg
                        $FailedNames += "$Option66 (IPv4->Scope[$ScopeId]->Policies->$PolicyName)`n"
                    }
                }
            }
        }
    }

    if ($FailedNames){
        $FailedNames += "A DHCP Server export is saved as $outfile"
        ReportIssue $issueMsg $FailedNames $IssueType_Error
    }
    else {
        # no issue found, no reason to keep DHCP Server export
        Remove-Item $outfile -ErrorAction SilentlyContinue
    }

    return $ReturnCode_Success
}

# Returns $false if name cannot be resolved
function ResolveDnsName
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [String]
        $DnsName
    )

    $result = Resolve-DnsName -Name $DnsName -Type A -ErrorVariable DnsError -ErrorAction SilentlyContinue

    if($DnsError -or ($result.Count -eq 0)){
        return $false
    }
    foreach($rec in $result) {
        if ($rec.IP4Address) {
            return $true
        }
    }
    return $false
}
#endregion net_dhcpsrv_KB4503857

#region net_802Dot1x_KB4556307
<# 
Component: 802Dot1x
 
 Checks for:
 A post-release issue starting with Feb 2020 updates
 Resolved in 2020.4B and later
 Network indication is skipped when a 802.1x re-auth occurs.
 If account-based VLANs are used, then this will cause connectivity issue
#>
function net_802Dot1x_KB4556307
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [Boolean]
        $offline
    )

    $affectedUpdates = @("KB4535996","KB4540673","KB4551762","KB4541335","KB4554364","KB4537572")

    $issueMsg = "
Following 802.1x network adapter (wired or wireless) is in connected state
but has no connectivity:

<xray!diag>

You might be hitting an issue affecting wired 802.1x adapters when user logon
triggers a change of VLAN.

Resolution:
Please install below Windows Update (or a later one) to resolve this issue:
""April 14, 2020—KB4549951 (OS Builds 18362.778 and 18363.778)""
""https://support.microsoft.com/help/4549951/windows-10-update-kb4549951""

- Addresses an issue that prevents a wired network interface from obtaining a
new Dynamic Host Configuration Protocol (DHCP) IP address on new subnets and 
virtual LANs (VLAN) after wired 802.1x re-authentication. The issue occurs if
you use VLANs that are based on accounts and a VLAN change occurs after a user
signs in.
"

    if($offline) {
        LogToFile "Cannot run offline, skipping"
        return $ReturnCode_Skipped
    }

    # Look for the issue
    $services = Get-Service -Name "dot3svc" -ErrorAction SilentlyContinue
    if(($services.Count -ne 1) -or ($services.Status -ne "Running")) {
        # dot3svc (Wired AutoConfig) not running, nothing to check
        LogToFile "dot3svc (Wired AutoConfig) service is not running, issue cannot be present"
    }
    else {
        # dot3svc (Wired AutoConfig) is running
        try {
            $hotfixes = (Get-HotFix | Sort-Object -Property InstalledOn -Descending)
            foreach($hotfix in $hotfixes) {
                # look if any of the affected updates are installed
                if($hotfix.HotFixID -in $affectedUpdates) {
                    $logMsg = "An affected update (" + $hotfix.HotFixID + ") is installed!"
                    LogToFile $logMsg 
                    # affected update(s) installed, check for issue
                    $netadapters = Get-NetAdapter
                    foreach($netadapter in $netadapters) {
                        $adapter = "NetAdapter " + $netadapter.Name + " [" + $netadapter.MediaType + "," + $netadapter.MediaConnectState + "]"
                        if(($netadapter.MediaConnectState -eq 1) -and ($netadapter.MediaType -eq "Native 802.11")) { 
                            # 802.1x adapter in connected state, test connectivity
                            $logMsg = "Testing adapter [" + $netadapter.Name + "] for issue..."
                            LogToFile $logMsg
                            $netipconfig = Get-NetIPConfiguration -InterfaceIndex $netadapter.ifIndex
                            # has IP address?
                            if($netipconfig.IPv4Address.count -gt 0) {
                                $logMsg = "Pinging default gateway..."
                                LogToFile $logMsg
                                $result = Test-Connection -ComputerName $netipconfig.IPv4DefaultGateway.NextHop -Count 4 -Quiet 
                                LogToFile "Test-Connection returned: $result"
                                if($result -eq $false) {
                                    # Issue present
                                    $diagInfo += "`tName: " + $netadapter.Name + ", IP Address: " + $netipconfig.IPv4Address
                                    ReportIssue $issueMsg $diagInfo $IssueType_Error
                                }
                            }
                        }
                    }
                    # run the test once
                    break
                }
            }
        }
        catch {
            LogToFile $Error[0].Exception
            return $ReturnCode_Failed
        }
    }
    return $ReturnCode_Success
}
#endregion net_802Dot1x_KB4556307

# end: diagnostic functions