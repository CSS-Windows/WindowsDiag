﻿# xray_dnd.ps1
# Created by tdimli
# March 2020
#
# Support for known issues in DND area
# contributors: 
# developers: 

# version
$DND_version = "1.0.200401.0"

# Area and Area/Component arrays
# Example: $AREA = @("Component1", "Component2")
$DND = @()

#Component/Diagnostic (Check) Function arrays
# Example: $Component1 = @("Diag_Func1", "Diag_Func1")

# For more details, please review readme file for guidance for diagnostic function developers

# begin: diagnostic functions
#    <your diagnostic functions here>
# end: check functions