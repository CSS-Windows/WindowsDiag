﻿#************************************************
# CollectDPMLogs.ps1
# Version 2.0.0
# Date: 09-27-2011
# Author: Patrick Lewis   - patlewis@microsoft.com
# Co-author: Wilson Souza - wsouza@microsoft.com
# Description: This script collects the .errlog and .Crash logs from the DPM\Temp directory
#************************************************
Import-LocalizedData -BindingVariable LocalsCollectDPMLogs -FileName DC_CollectDPMLogs -UICulture en-us

#Main

$DPMFolder= GetDPMInstallFolder # GetDPMInstallFolder is a function from Functions.ps1
If ($DPMFolder -ne $null)
{
	$DPMRAVersion = DPMRAVersion ($DPMFolder)
}
else 
{
	$LocalsCollectDPMLogs.ID_DPM_NotInstalled | WriteTo-StdOut -ShortFormat
}

if($DPMRAVersion -ne $null)
{
	Write-DiagProgress -Activity $LocalsCollectDPMLogs.ID_DPM_COLLECT_LOGS 
	if ($DPMRAVersion -ne 2)
	{
		$DPMFolderTemp = Join-Path $DPMFolder "temp\"
	}
	else
	{
		$DPMFolderTemp = $DPMFolder
	}
	$OutputBase= "$ComputerName$Prefix" + "_DPM_Error_Logs" + ".zip"	
	CompressCollectFilesForTimePeriod -filesToCollect ($DPMFolderTemp + "*.errlog") -DestinationFileName ($OutputBase) -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION -fileDescription $LocalsCollectDPMLogs.ID_DPM_ErrorLogs_Files -Recursive -NumberOfDays 7
	
	$DPMFolderConfig = Join-Path $DPMFolder "config\"
	$OutputBase = "$ComputerName$Prefix" + "_DPM_config_xml"
	CompressCollectFilesForTimePeriod -filesToCollect ($DPMFolderConfig + "*.*") -DestinationFileName ($OutputBase) -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION -fileDescription $LocalsCollectDPMLogs.ID_DPM_CONFIG_FILES -Recursive -NumberOfDays 3650

	# Collecting DPMLogs folder (this folder contains DPM Setup log, rollup update logs)
	$OutputBase = "$ComputerName$Prefix" + "_DPM_Install_Logs" 
	$DPMInstallLogs = "empty"
	if ($DPMRAVersion -eq 4)
	{
		$DPMInstallLogs = ($DPMFolder | split-path -parent) + "\DPMLogs"
	}

	if ($DPMRAVersion -eq 2 -or $DPMRAVersion -eq 3)
	{
			$DPMInstallLogs = $env:SystemDrive + "\DPMLogs"
			if (!(test-path $DPMInstallLogs))
			{
				$DPMInstallLogs = $env:ALLUSERSPROFILE + "\DPMLogs"
			}
			
	}
	if (test-path $DPMInstallLogs)
	{
		CompressCollectFilesForTimePeriod -filesToCollect ($DPMInstallLogs + "\*.*") -DestinationFileName ($OutputBase) -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION -fileDescription $LocalsCollectDPMLogs.ID_DPM_ErrorLogs_Files -Recursive -NumberOfDays 3650	
	}
	else
	{
		$OutputBase += ".txt"
		"DPMLogs folder wasn't found on this system" | out-file $OutputBase
	}

	# Collecting DPM Agent installation files
	$OutputBase = "$ComputerName$Prefix" + "_DPM_Agent_Install_Logs" 
	$temp = $env:windir + "\Temp"
	if (test-path ($temp + '\MSDPM*'))
	{
		CompressCollectFilesForTimePeriod -filesToCollect ($Temp + "\MSDPM*.*") -DestinationFileName ($OutputBase) -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION -fileDescription $LocalsCollectDPMLogs.ID_DPM_ErrorLogs_Files -Recursive -NumberOfDays 3650	
	}
	else
	{
		$OutputBase += ".txt"
		"DPM Agent installation Logs weren't found on this system" | out-file $OutputBase
	}

	# Collect DPMUI logs from DPM 2010/2012 which resides on the user profile
	$MSDPMVersion = [System.Diagnostics.FileVersionInfo]::GetVersionInfo(($DPMFolder + 'bin\msdpm.exe')).filemajorpart.ToString() + "." + [System.Diagnostics.FileVersionInfo]::GetVersionInfo(($DPMFolder + 'bin\msdpm.exe')).FileMinorPart.ToString()
	switch ($MSDPMVersion)
	{

		'3.0'  {
					$ProfileRelativePath = '\AppData\Roaming\Microsoft\Microsoft System Center Data Protection Manager 2010'
		       }

		'4.0'  {
					$ProfileRelativePath = '\AppData\Roaming\Microsoft\Microsoft System Center 2012 Data Protection Manager' 
		       }

		'4.1'  {
				    $ProfileRelativePath = '\AppData\Roaming\Microsoft\Microsoft System Center 2012 Service Pack 1 Data Protection Manager'
			   }

		'4.2'  {
					$ProfileRelativePath = '\AppData\Roaming\Microsoft\Microsoft System Center 2012 R2 Data Protection Manager'
		 	   }

		'5.0'  {
					$ProfileRelativePath = '\AppData\Roaming\Microsoft\Microsoft System Center 2016 Technical Preview 4 Data Protection Manager'
		 	   }

		'11.0' {
					$ProfileRelativePath = '\AppData\Roaming\Microsoft\Microsoft Azure Backup'
			   }
	}

	$ProfileFolders = @(dir ((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList").ProfilesDirectory) | ? { $_.Attributes -match 'Directory' -and ($_.pschildname -notmatch 'Public' -or $_.pschildname -notmatch 'Default')})

	foreach ($Profile in $Profilefolders)
	{
		$ProfileFullPath = $Profile.FullName + $ProfileRelativePath
		If ($ProfileFullPath)
		{
			$OutputBase = $ComputerName + "_DPM_UI_CLI_Settings_" + $Profile.basename + ".Logs" 
			CompressCollectFilesForTimePeriod -filesToCollect ($ProfileFullPath + "\*.errlog") -DestinationFileName ($OutputBase) -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION -fileDescription $LocalsCollectDPMLogs.ID_DPM_ErrorLogs_Files -Recursive -NumberOfDays 3650	
		}
	}


	# Collect DPM Active Owner
	if ($DPMRAVersion -eq 3 -or $DPMRAVersion -eq 4)
	{
		$DPMActiveOwner = Join-Path $DPMFolder "ActiveOwner\"
		$OutputBase = $ComputerName + "_ActiveOwner" 
		CompressCollectFilesForTimePeriod -filesToCollect ($DPMActiveOwner + "\*.*") -DestinationFileName ($OutputBase) -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION -fileDescription $LocalsCollectDPMLogs.ID_DPM_ErrorLogs_Files -Recursive -NumberOfDays 3650	
	}
	
	# Collect Last queries executed against DPMDB
	if ((Test-Path "HKLM:SOFTWARE\Microsoft\Microsoft Data Protection Manager\DB") -eq $true)
	{		
		add-pssnapin sqlservercmdletsnapin100 -ErrorAction SilentlyContinue
		Push-Location; Import-Module SQLPS; Pop-Location
		$OutputBase = $ComputerName + "_Last_Updated_Tables" 
		$SQLServer   = (get-itemproperty HKLM:\SOFTWARE\Microsoft\"Microsoft Data Protection Manager"\DB).SqlServer
		$SQLInstance = (get-itemproperty HKLM:\SOFTWARE\Microsoft\"Microsoft Data Protection Manager"\DB).InstanceName
		$SQLDPMDB    = (get-itemproperty HKLM:\SOFTWARE\Microsoft\"Microsoft Data Protection Manager"\DB).DatabaseName
		$Query = "SELECT OBJECT_NAME(OBJECT_ID) AS DatabaseName, last_user_update
				  FROM sys.dm_db_index_usage_stats
		          WHERE database_id = DB_ID( '" + $SQLDPMDB + "')
		          ORDER BY last_user_update desc"
		invoke-sqlcmd -serverinstance ($SQLServer + "\"+ $SQLInstance) -query $Query -database $SQLDPMDB ! out-file $OutputBase 
		CompressCollectFilesForTimePeriod -filesToCollect $OutputBase -DestinationFileName ($OutputBase) -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION -fileDescription $LocalsCollectDPMLogs.ID_DPM_ErrorLogs_Files -Recursive -NumberOfDays 3650			
	}
}
		
	




# SIG # Begin signature block
# MIIa7QYJKoZIhvcNAQcCoIIa3jCCGtoCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU2/wvIqwDRcWTTdOji+Zx1mGt
# 4SegghWDMIIEwzCCA6ugAwIBAgITMwAAAKxjFufjRlWzHAAAAAAArDANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwNTAzMTcxMzIz
# WhcNMTcwODAzMTcxMzIzWjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkMwRjQtMzA4Ni1ERUY4MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnyHdhNxySctX
# +G+LSGICEA1/VhPVm19x14FGBQCUqQ1ATOa8zP1ZGmU6JOUj8QLHm4SAwlKvosGL
# 8o03VcpCNsN+015jMXbhhP7wMTZpADTl5Ew876dSqgKRxEtuaHj4sJu3W1fhJ9Yq
# mwep+Vz5+jcUQV2IZLBw41mmWMaGLahpaLbul+XOZ7wi2+qfTrPVYpB3vhVMwapL
# EkM32hsOUfl+oZvuAfRwPBFxY/Gm0nZcTbB12jSr8QrBF7yf1e/3KSiqleci3GbS
# ZT896LOcr7bfm5nNX8fEWow6WZWBrI6LKPx9t3cey4tz0pAddX2N6LASt3Q0Hg7N
# /zsgOYvrlwIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFCFXLAHtg1Boad3BTWmrjatP
# lDdiMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAEY2iloCmeBNdm4IPV1pQi7f4EsNmotUMen5D8Dg4rOLE9Jk
# d0lNOL5chmWK+d9BLG5SqsP0R/gqph4hHFZM4LVHUrSxQcQLWBEifrM2BeN0G6Yp
# RiGB7nnQqq86+NwX91pLhJ5LBzJo+EucWFKFmEBXLMBL85fyCusCk0RowdHpqh5s
# 3zhkMgjFX+cXWzJXULfGfEPvCXDKIgxsc5kUalYie/mkCKbpWXEW6gN+FNPKTbvj
# HcCxtcf9mVeqlA5joTFe+JbMygtOTeX0Mlf4rTvCrf3kA0zsRJL/y5JdihdxSP8n
# KX5H0Q2CWmDDY+xvbx9tLeqs/bETpaMz7K//Af4wggTtMIID1aADAgECAhMzAAAB
# QJap7nBW/swHAAEAAAFAMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTE2MDgxODIwMTcxN1oXDTE3MTEwMjIwMTcxN1owgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBANtLi+kDal/IG10KBTnk1Q6S0MThi+ikDQUZWMA81ynd
# ibdobkuffryavVSGOanxODUW5h2s+65r3Akw77ge32z4SppVl0jII4mzWSc0vZUx
# R5wPzkA1Mjf+6fNPpBqks3m8gJs/JJjE0W/Vf+dDjeTc8tLmrmbtBDohlKZX3APb
# LMYb/ys5qF2/Vf7dSd9UBZSrM9+kfTGmTb1WzxYxaD+Eaxxt8+7VMIruZRuetwgc
# KX6TvfJ9QnY4ItR7fPS4uXGew5T0goY1gqZ0vQIz+lSGhaMlvqqJXuI5XyZBmBre
# ueZGhXi7UTICR+zk+R+9BFF15hKbduuFlxQiCqET92ECAwEAAaOCAWEwggFdMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBSc5ehtgleuNyTe6l6pxF+QHc7Z
# ezBSBgNVHREESzBJpEcwRTENMAsGA1UECxMETU9QUjE0MDIGA1UEBRMrMjI5ODAz
# K2Y3ODViMWMwLTVkOWYtNDMxNi04ZDZhLTc0YWU2NDJkZGUxYzAfBgNVHSMEGDAW
# gBTLEejK0rQWWAHJNy4zFha5TJoKHzBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNDb2RTaWdQQ0Ff
# MDgtMzEtMjAxMC5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY0NvZFNpZ1BDQV8wOC0z
# MS0yMDEwLmNydDANBgkqhkiG9w0BAQUFAAOCAQEAa+RW49cTHSBA+W3p3k7bXR7G
# bCaj9+UJgAz/V+G01Nn5XEjhBn/CpFS4lnr1jcmDEwxxv/j8uy7MFXPzAGtOJar0
# xApylFKfd00pkygIMRbZ3250q8ToThWxmQVEThpJSSysee6/hU+EbkfvvtjSi0lp
# DimD9aW9oxshraKlPpAgnPWfEj16WXVk79qjhYQyEgICamR3AaY5mLPuoihJbKwk
# Mig+qItmLPsC2IMvI5KR91dl/6TV6VEIlPbW/cDVwCBF/UNJT3nuZBl/YE7ixMpT
# Th/7WpENW80kg3xz6MlCdxJfMSbJsM5TimFU98KNcpnxxbYdfqqQhAQ6l3mtYDCC
# BbwwggOkoAMCAQICCmEzJhoAAAAAADEwDQYJKoZIhvcNAQEFBQAwXzETMBEGCgmS
# JomT8ixkARkWA2NvbTEZMBcGCgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UE
# AxMkTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5MB4XDTEwMDgz
# MTIyMTkzMloXDTIwMDgzMTIyMjkzMloweTELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEjMCEGA1UEAxMaTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQ
# Q0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCycllcGTBkvx2aYCAg
# Qpl2U2w+G9ZvzMvx6mv+lxYQ4N86dIMaty+gMuz/3sJCTiPVcgDbNVcKicquIEn0
# 8GisTUuNpb15S3GbRwfa/SXfnXWIz6pzRH/XgdvzvfI2pMlcRdyvrT3gKGiXGqel
# cnNW8ReU5P01lHKg1nZfHndFg4U4FtBzWwW6Z1KNpbJpL9oZC/6SdCnidi9U3RQw
# WfjSjWL9y8lfRjFQuScT5EAwz3IpECgixzdOPaAyPZDNoTgGhVxOVoIoKgUyt0vX
# T2Pn0i1i8UU956wIAPZGoZ7RW4wmU+h6qkryRs83PDietHdcpReejcsRj1Y8wawJ
# XwPTAgMBAAGjggFeMIIBWjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTLEejK
# 0rQWWAHJNy4zFha5TJoKHzALBgNVHQ8EBAMCAYYwEgYJKwYBBAGCNxUBBAUCAwEA
# ATAjBgkrBgEEAYI3FQIEFgQU/dExTtMmipXhmGA7qDFvpjy82C0wGQYJKwYBBAGC
# NxQCBAweCgBTAHUAYgBDAEEwHwYDVR0jBBgwFoAUDqyCYEBWJ5flJRP8KuEKU5VZ
# 5KQwUAYDVR0fBEkwRzBFoEOgQYY/aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQGCCsGAQUFBwEB
# BEgwRjBEBggrBgEFBQcwAoY4aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNyb3NvZnRSb290Q2VydC5jcnQwDQYJKoZIhvcNAQEFBQADggIBAFk5
# Pn8mRq/rb0CxMrVq6w4vbqhJ9+tfde1MOy3XQ60L/svpLTGjI8x8UJiAIV2sPS9M
# uqKoVpzjcLu4tPh5tUly9z7qQX/K4QwXaculnCAt+gtQxFbNLeNK0rxw56gNogOl
# VuC4iktX8pVCnPHz7+7jhh80PLhWmvBTI4UqpIIck+KUBx3y4k74jKHK6BOlkU7I
# G9KPcpUqcW2bGvgc8FPWZ8wi/1wdzaKMvSeyeWNWRKJRzfnpo1hW3ZsCRUQvX/Ta
# rtSCMm78pJUT5Otp56miLL7IKxAOZY6Z2/Wi+hImCWU4lPF6H0q70eFW6NB4lhhc
# yTUWX92THUmOLb6tNEQc7hAVGgBd3TVbIc6YxwnuhQ6MT20OE049fClInHLR82zK
# wexwo1eSV32UjaAbSANa98+jZwp0pTbtLS8XyOZyNxL0b7E8Z4L5UrKNMxZlHg6K
# 3RDeZPRvzkbU0xfpecQEtNP7LN8fip6sCvsTJ0Ct5PnhqX9GuwdgR2VgQE6wQuxO
# 7bN2edgKNAltHIAxH+IOVN3lofvlRxCtZJj/UBYufL8FIXrilUEnacOTj5XJjdib
# Ia4NXJzwoq6GaIMMai27dmsAHZat8hZ79haDJLmIz2qoRzEvmtzjcT3XAH5iR9HO
# iMm4GPoOco3Boz2vAkBq/2mbluIQqBC0N1AI1sM9MIIGBzCCA++gAwIBAgIKYRZo
# NAAAAAAAHDANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZImiZPyLGQBGRYDY29tMRkw
# FwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9v
# dCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMDcwNDAzMTI1MzA5WhcNMjEwNDAz
# MTMwMzA5WjB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCfoWyx39tIkip8ay4Z4b3i48WZUSNQrc7dGE4kD+7R
# p9FMrXQwIBHrB9VUlRVJlBtCkq6YXDAm2gBr6Hu97IkHD/cOBJjwicwfyzMkh53y
# 9GccLPx754gd6udOo6HBI1PKjfpFzwnQXq/QsEIEovmmbJNn1yjcRlOwhtDlKEYu
# J6yGT1VSDOQDLPtqkJAwbofzWTCd+n7Wl7PoIZd++NIT8wi3U21StEWQn0gASkdm
# EScpZqiX5NMGgUqi+YSnEUcUCYKfhO1VeP4Bmh1QCIUAEDBG7bfeI0a7xC1Un68e
# eEExd8yb3zuDk6FhArUdDbH895uyAc4iS1T/+QXDwiALAgMBAAGjggGrMIIBpzAP
# BgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBQjNPjZUkZwCu1A+3b7syuwwzWzDzAL
# BgNVHQ8EBAMCAYYwEAYJKwYBBAGCNxUBBAMCAQAwgZgGA1UdIwSBkDCBjYAUDqyC
# YEBWJ5flJRP8KuEKU5VZ5KShY6RhMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eYIQea0WoUqgpa1Mc1j0BxMuZTBQBgNVHR8E
# STBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEESDBGMEQGCCsG
# AQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFJvb3RDZXJ0LmNydDATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0B
# AQUFAAOCAgEAEJeKw1wDRDbd6bStd9vOeVFNAbEudHFbbQwTq86+e4+4LtQSooxt
# YrhXAstOIBNQmd16QOJXu69YmhzhHQGGrLt48ovQ7DsB7uK+jwoFyI1I4vBTFd1P
# q5Lk541q1YDB5pTyBi+FA+mRKiQicPv2/OR4mS4N9wficLwYTp2OawpylbihOZxn
# LcVRDupiXD8WmIsgP+IHGjL5zDFKdjE9K3ILyOpwPf+FChPfwgphjvDXuBfrTot/
# xTUrXqO/67x9C0J71FNyIe4wyrt4ZVxbARcKFA7S2hSY9Ty5ZlizLS/n+YWGzFFW
# 6J1wlGysOUzU9nm/qhh6YinvopspNAZ3GmLJPR5tH4LwC8csu89Ds+X57H2146So
# dDW4TsVxIxImdgs8UoxxWkZDFLyzs7BNZ8ifQv+AeSGAnhUwZuhCEl4ayJ4iIdBD
# 6Svpu/RIzCzU2DKATCYqSCRfWupW76bemZ3KOm+9gSd0BhHudiG/m4LBJ1S2sWo9
# iaF2YbRuoROmv6pH8BJv/YoybLL+31HIjCPJZr2dHYcSZAI9La9Zj7jkIeW1sMpj
# tHhUBdRBLlCslLCleKuzoJZ1GtmShxN1Ii8yqAhuoFuMJb+g74TKIdbrHk/Jmu5J
# 4PcBZW+JC33Iacjmbuqnl84xKf8OxVtc2E0bodj6L54/LlUWa8kTo/0xggTUMIIE
# 0AIBATCBkDB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMw
# IQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQQITMwAAAUCWqe5wVv7M
# BwABAAABQDAJBgUrDgMCGgUAoIHtMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEE
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBSf
# Bsn12k2YqwZ8gTRAuI7YmBRXfTCBjAYKKwYBBAGCNwIBDDF+MHygYoBgAFMAeQBz
# AHQAZQBtAEMAZQBuAHQAZQByAEQAUABNAF8ATQBBAEIAXwBnAGwAbwBiAGEAbABf
# AEQAQwBfAEMAbwBsAGwAZQBjAHQARABQAE0ATABvAGcAcwAuAHAAcwAxoRaAFGh0
# dHA6Ly9taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBACw7g9UsoSE9lDLM
# DB+Pbb4vJKIy4Br6RD/paVwwaYIJl7NzLcVMtIPJEjYpe6IqAJnWmjVfDnIRl8aB
# v/ee5lNzjq0+XK/pLDXm6yujBBUlm0e26XAFdxsM0YehGdDZ5vZ/AAJ8t6Im/RsT
# GA/a+7jjxOdpj1pFYREL3ZeAv0ZF3Ofd9Vkf4hVxef7JkZ/0W/5lCdtjovZij5RI
# BPaOVEFgClvQrS5PVrki8VBabJ+M5a38SM8v1mPI4HQ9Zq2VXET8By8equT7hhfj
# DK/6OVQurDnhe3aiUl9T4Uzn6WoeuN+E6DlvPOoL4bnkBsB43oK/8SPe9mfZ7dao
# uDnlfj+hggIoMIICJAYJKoZIhvcNAQkGMYICFTCCAhECAQEwgY4wdzELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEhMB8GA1UEAxMYTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBAhMzAAAArGMW5+NGVbMcAAAAAACsMAkGBSsOAwIaBQCg
# XTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0xNjA4
# MzAyMTMxNTBaMCMGCSqGSIb3DQEJBDEWBBRing/kKYTkaUcaWOnRx69zd7Pw4TAN
# BgkqhkiG9w0BAQUFAASCAQAe/8KPJ7XIZiW+bkBgCuO2kLWXIxQ5DpCd2mboKsQT
# WgFt3NgllkOVKvxtsNTJxF3XO4F2XoI1BgCR7LXKDBLNO/EhP73TjxYC6GivujS0
# hrPVv0UNuJBp8c7S830SKiBfkdzwEU0mw019dEW+3tRDSrKeVHkw2zpVwPEDtwSe
# ZBzKbSYjYQ+93qu2tVhQ68bKARRbQPyrqZ6yq3RMGBe0epT+J5G0LQ6e3pqvIwBJ
# qsQwWJExe1IAE2EUMHPTmjAZglz0/Q/Ghw/ga5rnbKyog926KLSY2ymn4xyHd4GA
# BkBUsPt0RbfUygiMR3zYN+f00U+I75/mumjaAP/0uQ11
# SIG # End signature block
