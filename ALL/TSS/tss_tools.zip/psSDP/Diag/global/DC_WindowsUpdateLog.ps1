﻿# File: DC_WindowsUpdateLog.ps1
# Date: 2009-2019
# Author: + Walter Eder (waltere@microsoft.com)
# Description: Collects additional WindowsUpdate information.
#*******************************************************

PARAM([string]$MachineName = $ComputerName,[string]$Path= $null)

Function CopyWindowsupdateLog($sourceFileName, $destinationFileName, $fileDescription) 
{

	$sectionDescription = "Windows Update"
	
	if (test-path $sourceFileName) {
		$sourceFile = Get-Item $sourceFileName
		#copy the file only if it is not a 0KB file.
		if ($sourceFile.Length -gt 0) 
		{
			$CommandLineToExecute = "cmd.exe /c copy `"$sourceFileName`" `"$destinationFileName`""
			RunCmD -commandToRun $CommandLineToExecute -sectionDescription $sectionDescription -filesToCollect $destinationFileName -fileDescription $fileDescription
		}
	}
}

function RunPS ([string]$RunPScmd="", [switch]$ft)
{
	$RunPScmdLength = $RunPScmd.Length
	"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
	"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
	"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
	
	if ($ft)
	{
		# This format-table expression is useful to make sure that wide ft output works correctly
		Invoke-Expression $RunPScmd	|format-table -autosize -outvariable $FormatTableTempVar | Out-File -FilePath $outputFile -Width 500 -append
	}
	else
	{
		Invoke-Expression $RunPScmd	| Out-File -FilePath $OutputFile -append
	}
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
}

$FileToCollect = $null
if([string]::IsNullOrEmpty($Path))
{
	$FileToCollect = Join-Path $Env:windir "windowsupdate.log"
}
else
{
	$FileToCollect = Join-Path $Path "windowsupdate.log"

}


Import-LocalizedData -BindingVariable ScriptStrings

# detect OS version
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber

Write-DiagProgress -activity $ScriptStrings.ID_WindowsUpdateLogCollect -status $ScriptStrings.ID_WindowsUpdateLogCollectDesc
$FileDescription = "Windows update log"
$destinationFileName = $MachineName + "_windowsupdate.log"
CopyWindowsupdateLog -sourceFileName $FileToCollect -destinationFileName $destinationFileName -fileDescription $FileDescription
#CollectFiles -filesToCollect $FileToCollect -fileDescription $FileDescription -sectionDescription $SectionDescription -renameOutput $true

# --------------------------------------------------------------- added 2019-07-15 #_#
# SECTION - Windows Update
Write-DiagProgress -activity $ScriptStrings.ID_WindowsUpdateLogCollect -status "Get \SoftwareDistribution\ReportingEvents.log"
$FileDescription = "Windows update SoftwareDistribution\ReportingEvents.log"
$FileToCollect = Join-Path $Env:windir "SoftwareDistribution\ReportingEvents.log"
$destinationFileName = $MachineName + "_WindowsUpdate_ReportingEvents.log"
CopyWindowsupdateLog -sourceFileName $FileToCollect -destinationFileName $destinationFileName -fileDescription $FileDescription

if (test-path $env:localappdata\microsoft\windows\windowsupdate.log)
	{
	$FileDescription = "Windows update SoftwareDistribution\ReportingEvents.log"
	$FileToCollect = Join-Path $Env:localappdata "microsoft\windows\windowsupdate.log"
	$destinationFileName = $MachineName + "_WindowsUpdatePerUser.log"
	CopyWindowsupdateLog -sourceFileName $FileToCollect -destinationFileName $destinationFileName -fileDescription $FileDescription
	}

if (test-path "$env:windir\microsoft\windows\windowsupdate (1).log")
	{
	$FileDescription = "Windows update WindowsUpdate.Old.log"
	$FileToCollect = Join-Path $Env:windir "windowsupdate (1).log"
	$destinationFileName = $MachineName + "_WindowsUpdate.Old.log"
	CopyWindowsupdateLog -sourceFileName $FileToCollect -destinationFileName $destinationFileName -fileDescription $FileDescription
	}

if (test-path "$env:systemdrive\Windows.old\Windows\SoftwareDistribution\ReportingEvents.log")
	{
	$FileDescription = "Windows update WindowsUpdate.Old.log"
	$FileToCollect = Join-Path $Env:systemdrive "Windows.old\Windows\SoftwareDistribution\ReportingEvents.log"
	$destinationFileName = $MachineName + "_Old.ReportingEvents.log"
	CopyWindowsupdateLog -sourceFileName $FileToCollect -destinationFileName $destinationFileName -fileDescription $FileDescription
	}
if (test-path "$env:windir\SoftwareDistribution\Plugins\7D5F3CBA-03DB-4BE5-B4B36DBED19A6833\TokenRetrieval.log")
	{
	$FileDescription = "Windows update WindowsUpdate.Old.log"
	$FileToCollect = Join-Path $Env:windir "SoftwareDistribution\Plugins\7D5F3CBA-03DB-4BE5-B4B36DBED19A6833\TokenRetrieval.log"
	$destinationFileName = $MachineName + "_WindowsUpdate_TokenRetrieval.log"
	CopyWindowsupdateLog -sourceFileName $FileToCollect -destinationFileName $destinationFileName -fileDescription $FileDescription
	}

#---------- Win10 Get-WindowsUpdateLog ETL
if ([int]$bn -gt [int](9600))
	{
	$sectionDescription = "Windows Update ETW W10"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_WindowsUpdate.txt")
	$OutputFileW10 = Join-Path $pwd.path ($ComputerName + "_WindowsUpdate.ETW_Converted.txt")
	Write-DiagProgress -Activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status "Windows Update ETW log"
	RunPS "Get-WindowsUpdateLog -LogPath $OutputFileW10"
	collectfiles -filesToCollect $OutputFile -fileDescription "Windows Update ETW log" -sectionDescription $sectionDescription
	
	if (test-path "$env:windir.old\Windows\Logs\WindowsUpdate")
	{
		$sectionDescription = "Old Windows ETL Update"		
		Write-DiagProgress -Activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status "Get Old Windows Update ETL logs"
		compresscollectfiles -filesToCollect (join-path $env:systemdrive "Windows.old\Windows\Logs\WindowsUpdate\*.ETL") -Recursive -fileDescription "Old Windows Update ETW Files" -sectionDescription $sectiondescription -DestinationFileName "Windows.old_WU-ETW.zip" -RenameOutput $true
		}
	}

 
#----------UUP logs and action list xmls
#----------Registry
	#	Command: Registry dump HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\WindowsUpdate reg key
	$sectiondescription = "WindowsUpdate_reg_wu TXT file"
	$OutputFile = Join-Path $pwd.path ($ComputerName +  "_WindowsUpdate_reg_wu.txt")
	$fileDescription = "HKLM\Software\Microsoft\Windows\CurrentVersion\WindowsUpdate - registry key export"
	$CommandToExecute = 'cmd.exe /c REG EXPORT "HKLM\Software\Microsoft\Windows\CurrentVersion\WindowsUpdate" ' + $OutputFile
	Write-DiagProgress -activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status "Get $sectiondescription"
	RunCmD -commandToRun $CommandToExecute 
	collectfiles -filestocollect $OutputFile -filedescription $fileDescription -sectiondescription $sectionDescription -noFileExtensionsOnDescription -RenameOutput $true

	$sectiondescription = "WindowsUpdate_reg_wupolicy TXT file"
	$OutputFile = Join-Path $pwd.path ($ComputerName +  "_WindowsUpdate_reg_wupolicy.txt")
	$fileDescription = "HKLM\Software\Policies\Microsoft\Windows\WindowsUpdate - registry key export"
	$CommandToExecute = 'cmd.exe /c REG EXPORT "HKLM\Software\Policies\Microsoft\Windows\WindowsUpdate" ' + $OutputFile
	Write-DiagProgress -activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status "Get $sectiondescription"
	RunCmD -commandToRun $CommandToExecute 
	collectfiles -filestocollect $OutputFile -filedescription $fileDescription -sectiondescription $sectionDescription -noFileExtensionsOnDescription -RenameOutput $true

	$sectiondescription = "WindowsUpdate_reg_wuhandlers TXT file"
	$OutputFile = Join-Path $pwd.path ($ComputerName +  "_WindowsUpdate_reg_wuhandlers.txt")
	$fileDescription = "HKLM\Software\Microsoft\WindowsUpdate - registry key export"
	$CommandToExecute = 'cmd.exe /c REG EXPORT "HKLM\Software\Microsoft\WindowsUpdate" ' + $OutputFile
	Write-DiagProgress -activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status "Get $sectiondescription"
	RunCmD -commandToRun $CommandToExecute 
	collectfiles -filestocollect $OutputFile -filedescription $fileDescription -sectiondescription $sectionDescription -noFileExtensionsOnDescription -RenameOutput $true

	$sectiondescription = "WindowsUpdate_reg_SIH TXT file"
	$OutputFile = Join-Path $pwd.path ($ComputerName +  "_WindowsUpdate_reg_SIH.txt")
	$fileDescription = "HKLM\Software\Microsoft\sih - registry key export"
	$CommandToExecute = 'cmd.exe /c REG EXPORT "HKLM\Software\Microsoft\sih" ' + $OutputFile
	Write-DiagProgress -activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status "Get $sectiondescription"
	RunCmD -commandToRun $CommandToExecute 
	collectfiles -filestocollect $OutputFile -filedescription $fileDescription -sectiondescription $sectionDescription -noFileExtensionsOnDescription -RenameOutput $true

	$sectiondescription = "WindowsUpdate_reg_SIH Hive file"
	$OutputFile = Join-Path $pwd.path ($ComputerName +  "_WindowsUpdate_reg_SIH.hiv")
	$fileDescription = "HKLM\Software\Microsoft\sih - registry Hive export"
	$CommandToExecute = 'cmd.exe /c REG SAVE "HKLM\Software\Microsoft\sih" ' + $OutputFile
	Write-DiagProgress -activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status "Get $sectiondescription"
	RunCmD -commandToRun $CommandToExecute 
	collectfiles -filestocollect $OutputFile -filedescription $fileDescription -sectiondescription $sectionDescription -noFileExtensionsOnDescription -RenameOutput $true

#----------Service status, BitsAdmin, SchTasks
	#$OutputFile1 = join-path $pwd.path ($ComputerName + "_WindowsUpdate_wuauserv-state.txt")
	#$command1 = $Env:windir + "\system32\cmd.exe /d /c sc query wuauserv > `"$OutputFile1`""

	$sectionDescription = "sc query wuauserv"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_WindowsUpdate_wuauserv-state.txt")
	Write-DiagProgress -activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status "WUauserv Service Status"
	$CommandToExecute = 'sc query wuauserv '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription "WinUpdate: WUauserv Service Status" -sectionDescription $sectionDescription

	$sectionDescription = "BitsAdmin /list /allusers /verbose"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_bitsadmin.txt")
	Write-DiagProgress -activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status "BitsAdmin Status"
	$CommandToExecute = 'bitsadmin /list /allusers /verbose '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription "WinUpdate: BitsAdmin Status" -sectionDescription $sectionDescription

	$sectionDescription = "SCHTASKS /query /v /TN \Microsoft\Windows\WindowsUpdate\"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_WindowsUpdate_ScheduledTasks.txt")
	Write-DiagProgress -activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status "ScheduledTasks"
	$CommandToExecute = 'SCHTASKS /query /v /TN \Microsoft\Windows\WindowsUpdate\ '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription "WinUpdate: ScheduledTasks" -sectionDescription $sectionDescription
	
#----------Dir Outputs
	$sectionDescription = "Dir %windir%\SoftwareDistribution"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_WindowsUpdate_dir_SoftwareDistribution.txt")
	Write-DiagProgress -Activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status "Get $sectiondescription"
	$CommandToExecute = 'dir /a /s "$Env:windir\SoftwareDistribution" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription "WinUpdate: $sectionDescription output" -sectionDescription $sectionDescription
	
#----------Windows Update file versions
	$sectionDescription = "Windows Update file versions"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_WindowsUpdate_FileVersions.txt")
	Write-DiagProgress -Activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status "Get $sectiondescription"
	"===================================================="			| Out-File -FilePath $OutputFile -append
	"Windows Update file versions in $env:windir\system32\"			| Out-File -FilePath $OutputFile -append
	"===================================================="			| Out-File -FilePath $OutputFile -append
	$binaries = @("wuaext.dll", "wuapi.dll", "wuaueng.dll", "wucltux.dll", "wudriver.dll", "wups.dll", "wups2.dll", "wusettingsprovider.dll", "wushareduxresources.dll", "wuwebv.dll", "wuapp.exe", "wuauclt.exe", "storewuauth.dll", "wuuhext.dll", "wuuhmobile.dll", "wuau.dll", "wuautoappupdate.dll")
	foreach($file in $binaries)
	{
		if(test-path "$env:windir\system32\$file") 
		{ 
		   $version = (Get-Command "$env:windir\system32\$file").FileVersionInfo
		   "$file : $($version.FileMajorPart).$($version.FileMinorPart).$($version.FileBuildPart).$($version.FilePrivatePart)" | Out-File -FilePath $OutputFile -append
		} 
	}
	"`n `n"	| Out-File -FilePath $OutputFile -append
	"===================================================="			| Out-File -FilePath $OutputFile -append
	"Windows Update file versions in $env:windir\system32\en-US\"	| Out-File -FilePath $OutputFile -append
	"===================================================="			| Out-File -FilePath $OutputFile -append
	$muis = @("wuapi.dll.mui", "wuaueng.dll.mui", "wucltux.dll.mui", "wusettingsprovider.dll.mui", "wushareduxresources.dll.mui")
	foreach($file in $muis)
	{
		if(test-path "$env:windir\system32\en-US\$file") 
		{ 
		   $version = (Get-Command "$env:windir\system32\en-US\$file").FileVersionInfo
		   "$file : $($version.FileMajorPart).$($version.FileMinorPart).$($version.FileBuildPart).$($version.FilePrivatePart)" | Out-File -FilePath $OutputFile -append
		} 
	}
