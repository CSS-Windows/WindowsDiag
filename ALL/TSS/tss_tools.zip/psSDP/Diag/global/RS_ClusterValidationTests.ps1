﻿PARAM($XMLFilename)

. ./utils_cts.ps1
SkipSecondExecution

[xml] $ValidationXMLDoc = Get-Content -Path $XMLFilename

$MHTFileName = $Computername + "_ValidationReport.mht.htm"
$MoreInfoMsg = "Please open the file <a href= `"`#" + $MHTFileName + "`">" + $MHTFileName + "</a> for the complete validation report."


if ($ValidationXMLDoc -ne $null) {

	$WarningErrNodes = $ValidationXMLDoc.SelectNodes("//Channel[Message[(@Level=`'Warn`') or (@Level=`'Fail`')]]")
	$ID = 0
	Foreach ($WarningErrNode in $WarningErrNodes) {
		$ValidationMsg_Summary = new-object PSObject
		$ReportXMLMsg = "<table class=`"info`" shade=`"true`">"	
	
		ForEach ($ChildNode in $WarningErrNode.ChildNodes) {
			if ($ChildNode.LocalName -eq "Message") {
				if (($ChildNode.Attributes.GetNamedItem("Level").Value -eq "Warn") -or ($ChildNode.Attributes.GetNamedItem("Level").Value -eq "Fail")) {
					$ReportXMLMsg += "<tr><td>" + $ChildNode.InnerText + "</td></tr>"
					switch ($ChildNode.GetAttribute("Level")) {
						"Warn" {$verbosity = "Warning"} 
						default {$verbosity = "Error" }
					}
				}
			}
			
			if ($ChildNode.LocalName -eq "Table") {
				$TableXML = "<tr><td><table>"
				$TableNode = $ChildNode.NextSibling
				
				$TableXML += "<tr>"
				ForEach ($ColumnHeader in $TableNode.SelectNodes("Column")) {
					$TableXML += "<th><b>" + $ColumnHeader.InnerText + "</b></th>"
				}
				$TableXML += "</tr>"
				
				ForEach ($RowNode in $TableNode.SelectNodes("Row")) {
					$TableXML += "<tr>"
					ForEach ($Value in $RowNode.SelectNodes("Value")) {
						$TableXML += "<td>" + $Value.InnerText + "</td>"
					}
					$TableXML += "</tr>"
				}
				$TableXML += "</table></td></tr>"
				$ReportXMLMsg += $TableXML
			}						
		} 
		$ReportXMLMsg += "</table>"
		$NameMember = $verbosity			
		add-member -inputobject $ValidationMsg_Summary -membertype noteproperty -name $NameMember -value $ReportXMLMsg
		$ID += 1
		$IDStr = $ID.ToString() + "_Validation"
		$SectionName = $WarningErrNode.SelectNodes("Title/Value").Item(0).InnerText
		$ValidationMsg_Summary | ConvertTo-Xml2 | update-diagreport -ID $IDStr -name $SectionName -verbosity $verbosity
	}
	$MoreInfo_Summary = new-object PSObject
	$ReportXMLMsg = $MoreInfoMsg
	add-member -inputobject $MoreInfo_Summary -membertype noteproperty -name "Message" -value $ReportXMLMsg
	$MoreInfo_Summary | ConvertTo-Xml2 | update-diagreport -ID "99_Validation" -name "More Information" -verbosity "Informational"
}
