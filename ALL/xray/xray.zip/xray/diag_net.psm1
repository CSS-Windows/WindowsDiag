﻿# diag_net.ps1
# Created by tdimli
# March 2020
#
# Diagnostic functions for NET area
# contributors: tdimli
# developers: tdimli, dosorr

Import-Module -Name .\diag_api.psm1 -Force

# version
$NET_version = "1.0.200724.0"

# Area and Area/Component arrays
$NET = @("802Dot1x", "DAsrv", "DhcpSrv", "DNScli", "Firewall", "HypHost", "NetIO", "Proxy", "srv", "VPN", "WFP", "WLAN") #"Auth", "BITS", "BranchCache", "Container", "CSC", "DAcli", "DFScli", "DFSsrv", "DHCPcli", "DNSsrv", "General", "HypVM", "IIS", "IPAM", "MsCluster", "MBAM", "MBN", "Miracast", "NCSI", "NFScli", "NFSsrv", "NLB", "NPS", "RAS", "RDMA", "RDScli", "RDSsrv" "SDN" "SdnNC" "SQLtrace" "SBSL" "UNChard" "Winsock" "WIP" "WNV" "Workfolders"

#Component/Diagnostic Function arrays
$802dot1x = @("net_802dot1x_KB4556307")
$dasrv = @("net_dasrv_KB4504598")
$dhcpsrv = @("net_dhcpsrv_KB4503857")
$dnscli = @("net_dnscli_KB4562541")
$firewall = @("net_firewall_KB4561854")
$hyphost = @("net_hyphost_KB4562593")
$netio = @("net_netio_KB4563820")
$proxy = @("net_proxy_KB4569506")
$srv = @("net_srv_KB4562940")
$wfp = @("net_netio_KB4563820")
$vpn = @("net_vpn_KB4553295", "net_vpn_KB4550202", "net_proxy_KB4569506")
$wlan = @("net_wlan_KB4557342")

# begin: diagnostic functions

#region 802dot1x
#region net_802dot1x_KB4556307
<# 
Component: 802dot1x
Checks for:
 A post-release issue starting with Feb 2020 updates
 Resolved in 2020.4B and later
 Network indication is skipped when a 802.1x re-auth occurs.
 If account-based VLANs are used, then this may cause connectivity issues
Created by: tdimli
#>
function net_802dot1x_KB4556307
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [Boolean]
        $offline
    )

    $issueMsg = "
Following 802.1x network adapter (wired or wireless) is in connected state
but has no connectivity:

{0}

You might be hitting an issue affecting wired 802.1x adapters when user logon
triggers a change of VLAN.

Resolution:
Please install following Windows Update (or a later one) to resolve 
this issue:

April 14, 2020—KB4549951 (OS Builds 18362.778 and 18363.778)
https://support.microsoft.com/help/4549951/windows-10-update-kb4549951

 - Addresses an issue that prevents a wired network interface from obtaining a
 new Dynamic Host Configuration Protocol (DHCP) IP address on new subnets and 
 virtual LANs (VLAN) after wired 802.1x re-authentication. The issue occurs if
 you use VLANs that are based on accounts and a VLAN change occurs after a user
 signs in.
"
    # updates (oldest update first), which when installed, may lead to this issue
    $effectingUpdates = @("KB4535996","KB4540673","KB4551762","KB4541335","KB4554364")
    # updates (oldest update first), which when installed, resolve this issue
    $resolvingUpdates = @("KB4549951","KB4550945", "KB4556799")

    if($offline) {
        LogWrite "Cannot run offline, skipping"
        return $RETURNCODE_SKIPPED
    }

    # issue only affects Win10 1903 or later, skip if earlier OS
    $curBuild = ($wmi_Win32_OperatingSystem.Version.Split('.'))[2]/1
    $reqVer = "10.0.18362"
    $reqBuild = ($reqVer.Split('.'))[2]/1
    if ($curBuild -lt $reqBuild ) {
        LogWrite "OS version $($wmi_Win32_OperatingSystem.Version) not affected, only $reqVer or later, skipping"
        return $RETURNCODE_SKIPPED
    }

    # Look for the issue
    $services = Get-Service -Name "dot3svc" -ErrorAction SilentlyContinue

    # issue only occurs with Wired Autoconfig, skip if it's not running
    if(($services.Count -eq 0) -or ($services.Status -ne "Running")) {
        # dot3svc (Wired AutoConfig) not running, nothing to check
        LogWrite "Wired AutoConfig (dot3svc) service is not running, nothing to check, skipping"
        return $RETURNCODE_SKIPPED
    }

    # dot3svc (Wired AutoConfig) is running
    try {
        $hotfixes = (Get-HotFix | Sort-Object -Property InstalledOn -Descending)
        foreach($hotfix in $hotfixes) {
            # look if any of the resolving updates that resolve this issue are installed
            if($resolvingUpdates.Contains($hotfix.HotFixID)) {
                LogWrite ("A resolving update ({0}) is installed!" -f $hotfix.HotFixID)
                break
            }
            # look if any of the effecting updates are installed
            if($effectingUpdates.Contains($hotfix.HotFixID)) {
                LogWrite ("An affected update ({0}) is installed!" -f $hotfix.HotFixID)
                # effecting update(s) installed, check for issue
                $netadapters = Get-NetAdapter
                foreach($netadapter in $netadapters) {
                    if(($netadapter.MediaConnectState -eq 1) -and ($netadapter.MediaType -eq "802.3")) { 
                        # adapter in connected state, test connectivity
                        LogWrite ("Testing adapter [{0}] for issue..." -f $netadapter.Name)
                        $netipconfig = Get-NetIPConfiguration -InterfaceIndex $netadapter.ifIndex
                        # has IP address?
                        if($netipconfig.IPv4Address.Count -gt 0) {
                            LogWrite "Pinging default gateway..."
                            $result = Test-Connection -ComputerName $netipconfig.IPv4DefaultGateway.NextHop -Count 1 -Quiet 
                            LogWrite ("Test-Connection returned: {0}" -f $result)
                            if($result -eq $false) {
                                # try again with ping count=4 to avoid false positives
                                $result = Test-Connection -ComputerName $netipconfig.IPv4DefaultGateway.NextHop -Count 4 -Quiet 
                                LogWrite ("Test-Connection (second try) returned: {0}" -f $result)
                                if($result -eq $false) {
                                    # Issue present
                                    $adapterInfo = "`tName: " + $netadapter.Name + ", IP Address: " + $netipconfig.IPv4Address
                                    $issueMsg = [string]::Format($issueMsg, $adapterInfo)
                                    ReportIssue $issueMsg $ISSUETYPE_ERROR $effectingUpdates $resolvingUpdates
                                    # reporting one instance of the issue is sufficient
                                    break
                                }
                            }
                        }
                    }
                }
                # run the test once
                break
            }
        }
    }
    catch {
        LogWrite "Failed - exiting! (Error: $_)"
        return $RETURNCODE_FAILED
    }

    return $RETURNCODE_SUCCESS
}
#endregion net_802Dot1x_KB4556307
#endregion 802dot1x

#region dasrv
#region net_dasrv_KB4504598
<# 
Component: dasrv
Checks for:
 DA non-paged pool memory leak, tag NDnd
Created by: tdimli
#>
function net_dasrv_KB4504598
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [Boolean]
        $offline
    )

    $issueMsg = "
Considerable amount of non-paged pool memory is allocated with pool tag NDnd:

Tag  Bytes
NDnd {0}

On Direct Access Servers this may be caused by a known memory leak which 
can cause performance degradation due to reduced amount of memory left 
available. If the leak grows too large, it can also deplete the non-paged 
pool memory and may cause the server to crash.

Resolution
This issue is fixed for WS2016 with January 23, 2020 update KB4534307 :
  - Addresses an issue that might cause Direct Access servers to use a large 
  amount of non-paged pool memory ( pooltag: NDnd ). 

Issue is not present in WS2019 and later versions of Windows Servers.

For 2012R2, the solution is to upgrade to a later version where this issue does 
not occur.

Following workarounds can be used for 2012R2 until upgrade can be performed:
  1. Monitor the leak amount and restart servers regularly to avoid the leak 
  growing too large and to prevent NPP memory from being depleted.
  2. MTU size can be reduced down to 1232 bytes to try and avoid packet 
  fragmentation and the resulting leak. This did not work for most customers.
"

    $infoMsg = "
Considerable amount of non-paged pool memory is allocated with pool tag NDnd:

Tag  Bytes
NDnd {0}

Note: This might not be directly related to the issue you are troubleshooting.

This type of memory is used by NDIS to store network packet information.
This corresponds to more than 15K full-size Ethernet packets which is unusual 
and will benefit from further investigation.
Consider collecting an xperf trace, ensuring multiple allocs/leaks (at least 
1 MB) are captured in the trace. Poolmon can be used to monitor that:
  poolmon -iNDnd -p

Following command can be used to capture such a trace:
  1. xperf -on Base+CSwitch+POOL -stackwalk PoolAlloc+PoolFree+PoolAllocSession+PoolFreeSession -PoolTag NDnd -BufferSize 1024 -MaxBuffers 1024 -MaxFile 2048 -FileMode Circular 
  2. Wait for 5-10 minutes or until sufficient allocs/leaks are captured
  3. xperf -d c:\NDnd.etl 

Following command will capture a trace of size specified by MaxSize parameter 
and stop automatically (can also be stopped -if needed- by: xperf -stop):
  xperf -on Base+CSwitch+POOL -stackwalk PoolAlloc+PoolFree+PoolAllocSession+PoolFreeSession -PoolTag NDnd -BufferSize 1024 -MaxBuffers 1024 -MaxFile 1024 -f c:\NDnd.etl

Poolmon: https://docs.microsoft.com/en-us/windows-hardware/drivers/devtest/poolmon
xperf: https://docs.microsoft.com/en-us/windows-hardware/test/wpt/
"

    if($offline) {
        LogWrite "Running offline"
    }
    else {
        LogWrite "Running online"
    }

    # Look for the issue
	try	{
        $puSets = GetPoolUsageByTag "NDnd" "Nonp"
        if (($puSets -ne $null) -and ($puSets.Count -gt 0)) {

            $threshold = 30 * 1024 * 1024 # 30 MB / > 30K allocs
            $bytesInUse = 0
            foreach ($puSet in $puSets) {
                # find the highest bytes value
                if ($puSet[3] -gt $bytesInUse) {
                    $bytesInUse = $puSet[3]
                }
            }

            if ($bytesInUse -gt $threshold) {
                # we have high usage of NDnd which likely points to an issue
                # is this the DA issue which affects WS2012 (9200), WS2012R2, WS2016 but not WS2019 (17763)
                $iType = $ISSUETYPE_INFO
                $iMsg = $infoMsg
                $curBuild = [Convert]::ToUInt32($wmi_Win32_OperatingSystem.BuildNumber)
                $minBuild = 9200
                $maxBuild = 17763
                if (($curBuild -ge $minBuild) -and ($curBuild -lt $maxBuild)) {
                    # is DA running?
                    $services = Get-Service -Name "RaMgmtSvc" -ErrorAction SilentlyContinue
                    if (($services.Count -eq 1) -and ($services.Status -eq "Running")) {
                        $iType = $ISSUETYPE_ERROR
                        $iMsg = $issueMsg
                    }
                    else {
                        LogWrite "Not a DA Server"
                    }
                }
                else {
                    LogWrite "OS not affected by DA issue"
                }
		        $iMsg = [string]::Format($iMsg, $bytesInUse)
		        ReportIssue $iMsg $iType $null $null
            }
        }
	}
	catch {
		LogWrite "Failed - exiting! (Error: $_)"
        return $RETURNCODE_FAILED
    }

    return $RETURNCODE_SUCCESS
}
#endregion net_dasrv_KB4504598
#endregion dasrv

#region dhcpsrv
#region net_dhcpsrv_KB4503857
<#
Component: dhcpsrv
Checks for:
 The issue where a DHCP Server has Option 66 (Boot Server Host Name) defined
 but the name(s) cannot be resolved to IP addresses.
 This causes DHCP Server repeatedly spending time to resolve these names and
 prevents it from serving clients. This can cause DHCP outages.
Created by: tdimli
#>
function net_dhcpsrv_KB4503857
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [Boolean]
        $offline
    )

    $issueMsg = "
Following Option 66 (Boot Server Host Name) values are configured on this DHCP 
Server but cannot be resolved to IP address(es). This can cause a DHCP outage 
where DHCP clients will not be able to receive IP addresses!

Server name(s) that cannot be resolved:
=======================================
{0}
Option 66 config location(s):
=============================
{1}
Resolution:
===========
Check Option 66 entries listed above and ensure that all values are valid and 
any configured names can be resolved and resolved in a timely manner by the 
DHCP Server.

Option 66 entries can only contain a single hostname or IP address, multiple 
values within the same option are not supported. If there are any entries with 
multiple values, please correct them.

Please remove any Option 66 entries that
1. point to decommissioned servers or servers that do not exist anymore
2. are not being used anymore

For servers in the list that are still active and being used as boot servers:
1. Ensure DNS records are created for them so that the names can be resolved

To test if a name can be resolved: 
Command prompt: ping -4 <server-name>
Powershell: Resolve-DnsName -Name <server-name> -Type A
"

    if($offline) { 
        LogWrite "Cannot run offline, skipping"
        return $RETURNCODE_SKIPPED
    }

    # Resolve-DnsName requires WS2012 or later, skip if earlier OS
    $curBuild = ($wmi_Win32_OperatingSystem.Version.Split('.'))[2]/1
    $reqVer = "6.2.9200"
    $reqBuild = ($reqVer.Split('.'))[2]/1
    if ($curBuild -lt $reqBuild ) {
        LogWrite "Cannot run on OS version $($wmi_Win32_OperatingSystem.Version), $reqVer or later required, skipping"
        return $RETURNCODE_SKIPPED
    }

    $services = Get-Service -Name "DHCPServer" -ErrorAction SilentlyContinue
    if(($services.Count -ne 1) -or ($services.Status -ne "Running")) {
        # No DHCP Server, nothing to check
        LogWrite "DHCPServer service is not running, nothing to check, skipping"
        return $RETURNCODE_SKIPPED
    }

    $dhcpexport = MakeFilename "dhcpexport" "xml"

    LogWrite "Exporting Dhcp Server data..."
    try{
        Export-DhcpServer -File $dhcpexport -Force 
    }
    catch {
        # export failed
        LogWrite "Failed - exiting! (Error: $_)"
        return $RETURNCODE_FAILED
    }

    LogWrite "Inspecting Dhcp Server data..."
    [xml]$Dhcp = Get-Content $dhcpexport

    $badOptions = ""
    [System.Collections.Generic.List[String]] $failedNames = New-Object "System.Collections.Generic.List[string]"

    # Check Server Options
    foreach ($option in $Dhcp.DHCPServer.IPv4.OptionValues.OptionValue) {
        if ($option.OptionId -eq 66) {
            if ($failedNames.Contains($option.Value) -or !(ResolveDnsName $option.Value)) {
                # failed, add error to return msg
                $badOptions += $option.Value + " (IPv4->Server Options)`r`n"
                if (!$failedNames.Contains($option.Value)) {
                    $failedNames.Add($option.Value)
                }
            }
        }
    }

    # Check IPv4 Policies
    foreach ($policy in $Dhcp.DHCPServer.IPv4.Policies.Policy) {
        foreach ($option in $policy.OptionValues.OptionValue) {
            if ($option.OptionId -eq 66) {
                if ($failedNames.Contains($option.Value) -or !(ResolveDnsName $option.Value)) {
                    # failed, add error to return msg
                    $badOptions += $option.Value + " (IPv4->Policies->" + $policy.Name + ")`r`n"
                    if (!$failedNames.Contains($option.Value)) {
                        $failedNames.Add($option.Value)
                    }
                }
            }
        }
    }

    # Check Scopes
    foreach ($scope in $Dhcp.DHCPServer.IPv4.Scopes.Scope) {

        # Scope Pptions
        foreach($option in $scope.OptionValues.OptionValue) {
            if ($option.OptionId -eq 66) {
                if ($failedNames.Contains($option.Value) -or !(ResolveDnsName $option.Value)) {
                    # failed, add error to return msg
                    $badOptions += $option.Value + " (IPv4->Scope[" + $scope.ScopeId + "])`r`n"
                    if (!$failedNames.Contains($option.Value)) {
                        $failedNames.Add($option.Value)
                    }
                }
            }
        }

        # Scope Policies
        foreach ($policy in $scope.Policies.Policy) {
            foreach ($option in $policy.OptionValues.OptionValue) {
                if ($option.OptionId -eq 66) {
                    if ($failedNames.Contains($option.Value) -or !(ResolveDnsName $option.Value)) {
                        # failed, add error to return msg
                        $badOptions += $option.Value + " (IPv4->Scope[" + $scope.ScopeId + "]->Policies->" + $policy.Name + ")`r`n"
                        if (!$failedNames.Contains($option.Value)) {
                            $failedNames.Add($option.Value)
                        }
                    }
                }
            }
        }
    }

    if ($failedNames.Count -gt 0){
        $failedNames.Sort()
        $tempInfo = ""
        foreach ($failedName in $failedNames) {
            $tempInfo += "$failedName`r`n"
        }
        $issueMsg = [string]::Format($issueMsg, $tempInfo, $badOptions)
        ReportIssue $issueMsg $ISSUETYPE_ERROR $null $null
    }
    else {
        # no issue found, no reason to keep DHCP Server export
        Remove-Item $dhcpexport -ErrorAction SilentlyContinue
    }

    return $RETURNCODE_SUCCESS
}

# Returns $false if name cannot be resolved
function ResolveDnsName
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [String]
        $DnsName
    )

    # no need to check if IP address
    try {return ($DnsName -match [IPAddress]$DnsName)} catch {}

    $result = Resolve-DnsName -Name $DnsName -Type A -ErrorVariable DnsError -ErrorAction SilentlyContinue

    if($DnsError -or ($result.Count -eq 0)){
        return $false
    }
    foreach($rec in $result) {
        if ($rec.IP4Address) {
            return $true
        }
    }
    return $false
}
#endregion net_dhcpsrv_KB4503857
#endregion dhcpsrv

#region dnscli
#region net_dnscli_KB4562541
<# 
Component: dnscli, vpn, da, ras
Checks for:
 The issue where multiple NRPT policies are configured and are in conflict.
 This will result in none of configured NRPT policies being applied.
Created by: tdimli 
#>
function net_dnscli_KB4562541
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [Boolean]
        $offline
    )

    $issueMsg = "
This computer has local NRPT rules configured when there are also domain 
group policy NRPT rules present. This can cause unexpected name resolution 
behaviour. 
When domain group policy NRPT rules are configured, local NRPT rules are 
ignored and not applied:
`tIf any NRPT settings are configured in domain Group Policy, 
`tthen all local Group Policy NRPT settings are ignored.

More Information:
https://docs.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2012-R2-and-2012/dn593632(v=ws.11)

Resolution:
Inspect configured NRPT rules and decide which ones to keep, local or domain 
Group Policy NRPT rules. 

Registry key where local group policy NRPT rules are stored:
  {0}

Registry key where domain group policy NRPT rules are stored:
  {1}

Note: Even if domain group policy registry key is empty, local group policy 
NRPT rules will still be ignored. Please delete the domain group policy 
registry key if it is not being used.
If it is being re-created, identify the policy re-creating it and remove the 
corresponding policy configuration.
"

    if($offline) {
        LogWrite "Cannot run offline, skipping"
        return $RETURNCODE_SKIPPED
    }

    # Look for the issue
    $localNRPTpath = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters"
    $domainNRPTpath = "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\DnsClient"
    $DnsPolicyConfig = "DnsPolicyConfig"

    try
    {
        # are there any local NRPTs configured which risk being ignored?
        if ((Get-ChildItem -Path "Registry::$localNRPTpath\$DnsPolicyConfig" -ErrorAction SilentlyContinue).Count -gt 0) {
            # does domain policy NRPT key exist (empty or not)?
            $domainNRPT = (Get-ChildItem -Path "Registry::$domainNRPTpath" -ErrorAction SilentlyContinue)
            if ($domainNRPT -ne $null) {
                if ($domainNRPT.Name.Contains("$domainNRPTpath\$DnsPolicyConfig")) {
                    # issue present: domain Group Policy NRPT key present, local Group Policy NRPT settings are ignored
                    $issueMsg = [string]::Format($issueMsg, "$localNRPTpath\$DnsPolicyConfig", "$domainNRPTpath\$DnsPolicyConfig")
                    ReportIssue $issueMsg $ISSUETYPE_ERROR $null $null
                }
            }
        }
    }
	catch {
		LogWrite "Failed - exiting! (Error: $_)"
        return $RETURNCODE_FAILED
    }

    return $RETURNCODE_SUCCESS
}
#endregion net_dnscli_KB4562541
#endregion dnscli

#region firewall
#region net_Firewall_KB4561854
<# 
Component: Firewall
Checks for:
 The issue where the Svchost process hosting BFE and Windows Defender Firewall
 takes up an unusual amount of CPU and RAM resources.
 This causes a performance degradation.
Created by: dosorr
#>
function net_firewall_KB4561854
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [Boolean]
        $offline
    )

    $issueMsg = "
Several duplicates of same firewall rules are present on this device. 
This will lead to unnecessary and additional CPU and memory load on the host 
and can cause a performance degradation. This additional load will appear as 
high CPU and memory consumption by the Svchost process hosting BFE service and 
Windows Defender Firewall.

Duplicate firewall rules:

`t{0} instances of {1}
`t{2} instances of {3}

Note: The higher the number, the more CPU cycles and memory are consumed!

Resolution:
You can delete these duplicate rules using following commands:
  netsh advfirewall firewall delete rule name=`"Core Networking - Teredo (ICMPv6-In)`"
  netsh advfirewall firewall delete rule name=`"Core Networking - Teredo (ICMPv6-Out)`"

You might also want to disable ""Teredo interface"" to prevent this from 
happening again. You can use following GPO setting to disable it:
  Computer Configuration\AdministrativeTeamplates\Network\TCPIPSettings\IPv6TransitionTechnologies
  Set Teredo State: Disabled
"

    if($offline) {
        LogWrite "Cannot run offline, skipping"
        return $RETURNCODE_SKIPPED
    }

    # Look for the issue
	try	{
        # halve the run-time checking number of duplicate rules for both -in and -out in one call
        $TeredoRuleName = "Core Networking - Teredo (ICMPv6-*)"
		$TeredoRuleCount = (Get-NetFirewallRule -DisplayName $TeredoRuleName -ErrorAction SilentlyContinue).Count

		# Issue present if any of the rule is present at least 10 times
		if($TeredoRuleCount -ge 20) {
            # do the full work only if needed
            $TeredoOutRuleName = "Core Networking - Teredo (ICMPv6-Out)"
		    $TeredoInRuleName = "Core Networking - Teredo (ICMPv6-In)"
            $TeredoOutRuleCount = (Get-NetFirewallRule -DisplayName $TeredoOutRuleName -ErrorAction SilentlyContinue).Count
		    $TeredoInRuleCount = (Get-NetFirewallRule -DisplayName $TeredoInRuleName -ErrorAction SilentlyContinue).Count
			# Issue detected
			$issueMsg = [string]::Format($issueMsg, $TeredoOutRuleCount, $TeredoOutRuleName, $TeredoInRuleCount, $TeredoInRuleName)
			ReportIssue $issueMsg $ISSUETYPE_ERROR $null $null
		}
	}
	catch {
		LogWrite "Failed - exiting! (Error: $_)"
        return $RETURNCODE_FAILED
    }

    return $RETURNCODE_SUCCESS
}
#endregion net_Firewall_KB4561854
#endregion firewall

#region hyphost
#region net_hyphost_KB4562593
<# 
Component: vmswitch
Checks for:
 NET: Hyper-V: Multicast, broadcast or unknown unicast 
 packet storm exhausts non-paged pool memory or causes 3B/9E bugchecks on Hyper-V hosts
Created by: vidou 
#>
function net_hyphost_KB4562593
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [Boolean]
        $offline
    )

    $issueMsg = "
This server had to allocate high amount of memory for packets in a vRss queue 
due to low resource on the physical NIC. 
This will cause packets to be dropped until the queue size falls below 512 MB.

Note: This might not be directly related to the issue you are troubleshooting.
 If you are troubleshooting an issue related to network connectivity/packet 
 drops, or server performance or crashes, then this is likely to be related.

The maximum memory that had to be allocated reached {0} MB within the last {1} 
days checked.
The higher this figure, the more the packet drops and the longer it lasts.

You can obtain more details by reviewing following events in System Event log:
ProviderName: {2}
Event Ids   : {3}

If you are a Microsoft Support Professional, please review KB4562593 for 
further assistance.
"

    if($offline) {
        LogWrite "Cannot run offline, skipping"
        return $RETURNCODE_SKIPPED
    }

    $minBuild = 14393 
    $curBuild = [Convert]::ToUInt32($wmi_Win32_OperatingSystem.BuildNumber)
    $productType = [Convert]::ToUInt32($wmi_Win32_OperatingSystem.ProductType)
    
    # issue may only affect Win10 Server above RS1
    if (($curBuild -lt $minBuild) -or ($productType -eq 1)) {
        LogWrite "OS build ($curBuild) not affected or client SKU ($productType), skipping"
        return $RETURNCODE_SKIPPED
    }

    try {
        #Checking that Hypv and at least one VMSwith is present
        $res = Get-WindowsFeature Hyper-V -ErrorAction SilentlyContinue
        if ( $res.InstallState -ne "Installed")
        {
            LogWrite "Hyper-V not installed, skipping"
            return $RETURNCODE_SKIPPED
        }

        #$IssueFound = $false
        #$VmSwitchCount = 0
        $VmSwitchCount = (Get-VMSwitch -ErrorAction SilentlyContinue).Count
        
        # if there is no vSwitch then exit
        if ( $VmSwitchCount -lt 1)
        {
            LogWrite "No vmswitch, skipping"
            return $RETURNCODE_SKIPPED
        }

        # examine System event log
        $providerName="Microsoft-Windows-Hyper-V-VmSwitch"
        $eventId = "252"
        $queueThreshold = 512
        $maxQueueSize = 0
        $days = 14
        $startTime = (Get-Date) - (New-TimeSpan -Day 14)
        $Log = Get-WinEvent -FilterHashtable @{ LogName="System"; Id=$eventId; ProviderName=$providerName; StartTime=$startTime } -ErrorAction SilentlyContinue
        
        if ( $Log -ne $null)
        {
            $IssueFound = $Log.Message.Split(" ") | ForEach-Object{ 
                if( $_ -match "MB")
                { 
                    $CurrentQueueSize=$_ -replace '(\d+).*','$1'
                    if ( [int]$CurrentQueueSize -gt $queueThreshold)
                    {
                        if ($CurrentQueueSize -gt $maxQueueSize) {
                            $maxQueueSize = $CurrentQueueSize
                        }
                        return $true
                    }
                }
            }

            if ( $IssueFound)
            {
                $issueMsg = [string]::Format($issueMsg, $maxQueueSize, $days, $providerName, $eventId)
    		    ReportIssue $issueMsg $ISSUETYPE_ERROR $null $null
            }
        }
    }
    catch {
        LogWrite "Failed - exiting! (Error: $_)"
        return $RETURNCODE_FAILED
    }

    return $RETURNCODE_SUCCESS
}
#endregion net_hyphost_KB4562593
#endregion hyphost

#region netio
#region net_netio_KB4563820
<# 
Component: dasrv
Checks for:
 NETIO/WFP non-paged pool memory leak, tag Afqc
Created by: tdimli
#>
function net_netio_KB4563820
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [Boolean]
        $offline
    )

    $issueMsg = "
Considerable amount of {1} pool memory is allocated with pool tag {0}:

Tag  Bytes
{0} {2}

Windows 10 clients (RS5 or later) may leak {1} pool memory (tag {0}) 
when RDP client is used over a VPN connection and AppLocker Security policies 
are in place.

This memory leak can cause performance degradation due to reduced amount of 
memory left available. If the leak grows too large, it can deplete the {1}  
pool memory and cause the computer to crash.

Resolution
We are currently working on a long-term resolution to address this issue.
Following workarounds can be used until a resolution becomes available:
  1. Monitor the leak amount and restart affected computers regularly to avoid 
  the leak growing too large and to prevent {1} pool memory from being depleted.
  2. If possible, disable AppLocker Security Policies in use temporarily
  3. If possible, reduce amount of activity over RDP and disconnect RDP 
  connections when not being used (an idle RDP connection may still leak memory)
"

    $infoMsg = "
Considerable amount of {1} pool memory is allocated with pool tag {0}:

Tag: {0}
Pool: {1}
Allocs in use: {3}
Bytes in use: {4}

Note: This might not be directly related to the issue you are troubleshooting.

This tag is used by {2}

{3} allocations being in use for this tag is unusual and may benefit from 
further investigation.
Consider collecting an xperf trace, ensuring multiple allocs/leaks (at least 
1 MB) are captured in the trace. Poolmon can be used to monitor that:
  poolmon -i{0}

Following command can be used to capture such a trace:
  1. xperf -on Base+CSwitch+POOL -stackwalk PoolAlloc+PoolFree+PoolAllocSession+PoolFreeSession -PoolTag {0} -BufferSize 1024 -MaxBuffers 1024 -MaxFile 2048 -FileMode Circular 
  2. Wait for 5-10 minutes or until sufficient allocs/leaks are captured
  3. xperf -d c:\{0}.etl 

Following command will capture a trace of size specified by MaxSize parameter 
and stop automatically (can also be stopped -if needed- by: xperf -stop):
  xperf -on Base+CSwitch+POOL -stackwalk PoolAlloc+PoolFree+PoolAllocSession+PoolFreeSession -PoolTag {0} -BufferSize 1024 -MaxBuffers 1024 -MaxFile 1024 -f c:\{0}.etl

Poolmon: https://docs.microsoft.com/en-us/windows-hardware/drivers/devtest/poolmon
xperf: https://docs.microsoft.com/en-us/windows-hardware/test/wpt/
"

    if($offline) {
        LogWrite "Running offline"
    }
    else {
        LogWrite "Running online"
    }

    # Look for the issue
    $tag = "Afqc"
    $pooltype = "Nonp"
    $comp = "TCPIP/WFP" # who uses this tag
    $threshold = 10 * 1024 # if over 10K allocs are leaked

	try	{
        $puSets = GetPoolUsageByTag $tag $pooltype
        if (($puSets -ne $null) -and ($puSets.Count -gt 0)) {
            
            $bytesInUse = 0
            $allocsInUse = 0
            $doubleAllocs = $false
            foreach ($puSet in $puSets) {
                # find the highest diff between allocs and frees
                if ($puSet[2] -gt $allocsInUse) {
                    $allocsInUse = $puSet[2]
                    $bytesInUse = $puSet[3]
                    if ($puSet[0] -ge (2 * $puSet[1])) { # alloc twice, free once issue
                        $doubleAllocs = $true
                    }
                }
            }

            $prodType = [Convert]::ToUInt32($wmi_Win32_OperatingSystem.ProductType)
            $curBuild = [Convert]::ToUInt32($wmi_Win32_OperatingSystem.BuildNumber)
            $minBuild = 17763

            if ($prodType -eq 1) {
                # only checking client SKUs, not servers
                if ($allocsInUse -gt $threshold) {
                    # is this the Afqc/AppLocker issue which affects Win10 RS5 and later?
                    $curBuild = [Convert]::ToUInt32($wmi_Win32_OperatingSystem.BuildNumber)
                    $minBuild = 17763
                    if ($curBuild -lt $minBuild) {
                        # not KB4563820 but we do have high usage of Afqc which still points to an issue
                        LogWrite "OS (Build:$curBuild) not affected by KB4563820 issue, this seems to be a new $tag mem leak"
                        $issueMsg = [string]::Format($infoMsg, $tag, $pooltype, $comp, $allocsInUse, $bytesInUse)
                        $issueType = $ISSUETYPE_INFO
                    }
                    elseif ($doubleAllocs) { 
                        # confirmed double alloc issue as per KB4563820
                        LogWrite "There are twice as many allocs as frees, definitely KB4563820"
		                $issueMsg = [string]::Format($issueMsg, $tag, $pooltype, $bytesInUse)
                        $issueType = $ISSUETYPE_ERROR
                    }
                    else { 
                        # not sure, might be KB4563820 or not, log as info for review
                        LogWrite "There is a leak but not sure if same issue as KB4563820, needs confirmation"
                        $issueMsg = [string]::Format($issueMsg, $tag, $pooltype, $bytesInUse)
                        $issueType = $ISSUETYPE_INFO
                    }
		            ReportIssue $issueMsg $issueType $null $null
                }
            }
            else {
                # server SKU
                LogWrite "ProductType ($prodType) is not client, skipping"
                return $Global:RETURNCODE_SKIPPED
            }
        }
        else {
            # no poolmon data
            LogWrite "No poolmon data, cannot run, skipping"
            return $Global:RETURNCODE_SKIPPED
        }
	}
	catch {
		LogWrite "Failed - exiting! (Error: $_)"
        return $RETURNCODE_FAILED
    }

    return $RETURNCODE_SUCCESS
}
#endregion net_netio_KB4563820
#endregion netio

#region proxy
#region net_proxy_KB4569506
<# 
Component: vpn
Checks for:
 An issue where modern apps like Edge might stop working or NLA might display 
 "No Internet" after some 3rd party VPNs connect
Created by: tdimli
#>
function net_proxy_KB4569506
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [Boolean]
        $offline
    )

    $issueMsg = @"
This computer has received an invalid option from DHCP Server:
Option 252, Proxy autodiscovery

Network interface over which the invalid option was received:
{0}

This may cause NCSI to fail to detect network connectivity and 
show "No Internet" 

Note: This might not be directly related to the issue you are troubleshooting.
 If you are troubleshooting an issue related to proxy and/or NCSI connectivity
 detection, then this is probably related.

Resolution
Either remove this invalid option from DHCP server or configure it with a 
valid URL.
"@

    if($offline) {
        LogWrite "Cannot run offline, skipping"
        return $RETURNCODE_SKIPPED
    }

    # Look for the issue
	try	{
        $curBuild = 17363 #[Convert]::ToUInt32($wmi_Win32_OperatingSystem.BuildNumber)
        $minBuild = 10000 
        if ($curBuild -gt $minBuild) {
            # Windows 10
            $error = $false
            $ifs = $null
            $connections = (Get-NetAdapter -ErrorAction SilentlyContinue)
            foreach ($netAdapter in $connections) {
                if ($netAdapter.MediaConnectionState -eq "Connected") {
                    $DhcpInterfaceOptions = (Get-ItemProperty -Path ("HKLM:\SYSTEM\CurrentControlSet\services\Tcpip\Parameters\Interfaces\{0}" -f $netAdapter.InterfaceGuid) -Name DhcpInterfaceOptions).DhcpInterfaceOptions
	                $pointer = 0
	                while ($pointer -lt $DhcpInterfaceOptions.length) 
	                {
		                $code = $DhcpInterfaceOptions[$pointer]
		                $pointer += 4
                        $cLength = $DhcpInterfaceOptions[$pointer]
		                $pointer += 4
		                $length = $DhcpInterfaceOptions[$pointer]
		                $pointer += 3 * 4 + $cLength + $length
                        $align = 4 - ($pointer % 4)
                        if ($align -lt 4) {
                            $pointer += $align
                        }
		
		                if ($code -eq 252)
		                {
                            if ($length -lt 8) {
                                if ($error) {
                                    $ifs += ", "
                                }
                                else {
                                    $error = $true
                                }
                                $ifs += $netAdapter.Name
                                break
                            }
		                }
	                }
                }
            }
            if ($error) {
                $issueMsg = [string]::Format($issueMsg, $ifs)
		        ReportIssue $issueMsg $ISSUETYPE_ERROR $null $null
            }
        }
        else {
            LogWrite "Not an impacted OS, skipping"
            return $RETURNCODE_SKIPPED
        }
	}
	catch {
		LogWrite "Failed - exiting! (Error: $_)"
        return $RETURNCODE_FAILED
    }

    return $RETURNCODE_SUCCESS
}
#endregion net_proxy_KB4569506
#endregion proxy

#region srv
#region net_srv_KB4562940
<# 
Component: srv
Checks for:
 The presence of SMBServer 1020/1031/1032 Events
 indicating a stalled I/O of more than 15 Seconds or Live Dump generation.
 Likely Cause: Broken Filterdrivers or extremly poor Storage Performance.
Created by: huberts
#>
function net_srv_KB4562940
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [Boolean]
        $offline
    )

    $issueMsg = "
This SMB Server has encountered file system operation(s) that has taken longer 
than expected.
The underlying file system has taken too long to respond to an operation. 
This typically indicates a problem with the storage and not SMB.

Note: This might not be directly related to the issue you are troubleshooting.
 If you are troubleshooting an issue related to server performance or hung SMB 
 server, then this is probably related.

An event is logged when file system operation takes longer than the default 
threshold of 15 seconds (120 seconds for asynchronous operations):
Microsoft-Windows-SMBServer/Operational Eventlog, EventID 1020

The latest occurrence  was at:
{0}

There have been a total of {1} occurrences in the last {2} days (period that 
was checked).
{3} 
"

    $NumberOfEventsToCheck = 500

    $issueMsg1 = "
Additionally the SMB Server tried to generate a live kernel dump because it 
encountered a problem. The reason for this dump is likely the same long-running 
filesystem operation.
Please check the Microsoft-Windows-SMBServer/Operational event log, look for 
event IDs 1031 & 1032 for further details, including the dump reason.
If a live dump was successfully created it can be found under:
%SystemRoot%\LiveKernelReports 
Such a dump is immensely useful for further troubleshooting.
"

    $AdditionalMsgText= "
There seems to be no live kernel dump(s) generated.
"

	# we can run offline, but need a seperate logic to retrieve information from exported .evtx files
    if($offline) {
        LogWrite "Cannot run offline, skipping"
        return $RETURNCODE_SKIPPED
    }
    
    # Look for the issue
    try {
	    # Get a list of shares to see if we are actually on a fileserver
        # Ignore Default Shares such as Temp$, IPC$, etc.
        $SMBshares = Get-SmbShare -ErrorAction SilentlyContinue | Where-Object {$_.Path -notlike "$Env:WinDir*" -and $_.Name -notlike "IPC$" -and $_.Name -notmatch "^[A-Z]{1}\$" }
        if ($SMBshares.Count -eq 0) {
            # no shares found -> nothing to check
            LogWrite "No Fileserver Shares found. Nothing to check. Skipping"
            return $RETURNCODE_SKIPPED
        }

        # check the eventlogs
        # get a maximum of $NumberOfEventsToCheck Events from the Eventlog (in order to limit runtime)
        $EventLog = Get-WinEvent -LogName 'Microsoft-Windows-SMBServer/Operational' -MaxEvents $NumberOfEventsToCheck | Sort-Object -Property TimeCreated -Descending

        if ($EventLog.Count -eq 0) {
            # no Eventlogs found -> nothing to check
            LogWrite "No Events in Microsoft-Windows-SMBServer/Operational found. Nothing to check. Skipping"
            return $RETURNCODE_SKIPPED
        }
        $Event1020 = $EventLog | Where-Object {$_.ID -eq 1020}

        if ($Event1020.Count -ne 0) {
            # OK! We found a 1020 Event!
            #Check the latest occurrence
            $1020_NewestOccurence = $Event1020 | Select-Object -First 1

            # Calculate the timeframe we covered with the $NumberOfEventsToCheck
            $NewestEvent = $EventLog | Select-Object -First 1 
            $OldestEvent = $EventLog | Select-Object -Last 1
            $TimeFrameChecked = [math]::Round(($NewestEvent.TimeCreated - $OldestEvent.TimeCreated).TotalDays)

            # Now lets check if we also have Messages stating that the Server tried to generate a Live Dump and if so provide further input.
            $DumpEvent = $EventLog | Where-Object {$_.ID -eq 1031 -or $_.ID -eq 1032}
            if ($DumpEvent.Count -ne 0) {
                $AdditionalMsgText = $issueMsg1
            }

            $issueMsg = [string]::Format($issueMsg, $1020_NewestOccurence.TimeCreated , $Event1020.Count , $TimeFrameChecked, $AdditionalMsgText)
            ReportIssue $issueMsg $ISSUETYPE_ERROR $null $null
        }
    }
	catch {
		LogWrite "Failed - exiting! (Error: $_)"
        return $RETURNCODE_FAILED
    }

    return $RETURNCODE_SUCCESS
}
#endregion net_srv_KB4562940
#endregion srv

#region vpn
#region net_vpn_KB4553295
<# 
Component: aovpn
Checks for:
 An issue where AoVPN might not detect that it's inside
Created by: tdimli
#>
function net_vpn_KB4553295
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [Boolean]
        $offline
    )

    $issueMsg = @"
There is a domain authenticated connection which is not in the trusted network 
list configured for Always on VPN (AoVPN) connection:
{0}

This might lead to unnecessary AoVPN connections being triggered.

Note: This might not be directly related to the issue you are troubleshooting.
 If you are troubleshooting an issue related to AoVPN trusted network detection 
 and/or AoVPN client initiating a connection when already have connectivity to 
 a DomainAuthenticated network, then this is likely to be related.

Resolution
To avoid a AoVPN connection being established when already connected to a domain 
network via "{0}", add its network name "{1}" to AoVPN 
configuration as a trusted network, e.g.:
<TrustedNetworkDetection>{2}{1}</TrustedNetworkDetection>
"@

    if($offline) {
        LogWrite "Cannot run offline, skipping"
        return $RETURNCODE_SKIPPED
    }

    # Look for the issue
	try	{
        $curBuild = [Convert]::ToUInt32($wmi_Win32_OperatingSystem.BuildNumber)
        $minBuild = 10000 
        if ($curBuild -gt $minBuild) {
            # Windows 10
            $vpnConn = (Get-VpnConnection -ErrorAction SilentlyContinue)
            if ($vpnConn) {
                $trustedNetworks = (Get-VpnConnectionTrigger -ConnectionName $vpnConn.Name -ErrorAction SilentlyContinue).TrustedNetwork
                if ($trustedNetworks) {
                    $connections = (Get-NetConnectionProfile -NetworkCategory DomainAuthenticated -ErrorAction SilentlyContinue)
                    foreach ($conn in $connections) {
                        if ($vpnConn.Name -ne $conn.InterfaceAlias) {
                            if (!$trustedNetworks.Contains($conn.Name)) {
                                $iType = $ISSUETYPE_ERROR
                                $badconn = $conn
                            }
                        }
                    }
                    if ($iType -eq $ISSUETYPE_ERROR) {
                        foreach ($net in $trustedNetworks) {
                            $trustedNetworkList += $net + ","
                        }
		                $issueMsg = [string]::Format($issueMsg, $badconn.InterfaceAlias, $badconn.Name, $trustedNetworkList)
		                ReportIssue $issueMsg $iType $null $null
                    }
                }
                else {
                    return $RETURNCODE_SKIPPED
                }
            }
            else {
                return $RETURNCODE_SKIPPED
            }
        }
	}
	catch {
		LogWrite "Failed - exiting! (Error: $_)"
        return $RETURNCODE_FAILED
    }

    return $RETURNCODE_SUCCESS
}
#endregion net_vpn_KB4553295

#region net_vpn_KB4550202
<# 
Component: vpn
Checks for:
 An issue where modern apps like Edge might stop working or NLA might display 
 "No Internet" after some 3rd party VPNs connect
Created by: tdimli
#>
function net_vpn_KB4550202
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [Boolean]
        $offline
    )

    $issueMsg = @"
There is a 3rd party VPN connection which is connected but hidden:
Name: {0}
Guid: {1}

Being hidden when connected might prevent NLA from detecting connectivity 
over this VPN connection and can lead to connectivity issues.

Note: This might not be directly related to the issue you are troubleshooting.
 If you are troubleshooting an issue related to VPN connectivity, such as 
 modern apps like Edge etc. stop working or NLA displaying "No Internet" after 
 a 3rd party VPN is connected.

Resolution
Ensure the VPN adapter is visible when connected. Contact VPN vendor for 
further assistance.
"@

    if($offline) {
        LogWrite "Cannot run offline, skipping"
        return $RETURNCODE_SKIPPED
    }

    # Look for the issue
	try	{
        $curBuild = [Convert]::ToUInt32($wmi_Win32_OperatingSystem.BuildNumber)
        $minBuild = 10000 
        if ($curBuild -gt $minBuild) {
            # Windows 10
            $vpnConn = (Get-VpnConnection -ErrorAction SilentlyContinue)
            if ($vpnConn) {
                if ($vpnConn.ConnectionStatus -eq "Connected") {
                    $connections = (Get-NetConnectionProfile -ErrorAction SilentlyContinue)
                    $vpnHidden = $true
                    foreach ($conn in $connections) {
                        if ($vpnConn.Name -eq $conn.InterfaceAlias) {
                            $vpnHidden = $false
                            LogWrite "VPN not hidden"
                        }
                    }
                    if ($vpnHidden) {
                        foreach ($net in $trustedNetworks) {
                            $trustedNetworkList += $net + ","
                        }
		                $issueMsg = [string]::Format($issueMsg, $vpnConn.Name, $vpnConn.Guid)
		                ReportIssue $issueMsg $ISSUETYPE_ERROR $null $null
                    }
                }
                else {
                    LogWrite "VPN not connected, skipping"
                    return $RETURNCODE_SKIPPED
                }
            }
            else {
                LogWrite "No VPN connection, skipping"
                return $RETURNCODE_SKIPPED
            }
        }
	}
	catch {
		LogWrite "Failed - exiting! (Error: $_)"
        return $RETURNCODE_FAILED
    }

    return $RETURNCODE_SUCCESS
}
#endregion net_vpn_KB4550202
#endregion vpn

#region wlan
#region net_wlan_KB4557342
<# 
Component: wlan
Checks for:
 The issue where WLAN profiles cannot be deleted, their password changed or
 network forgotten. 
Created by: dosorr 
#>
function net_wlan_KB4557342
{
    param(
        [Parameter(Mandatory=$true,
        Position=0)]
        [Boolean]
        $offline
    )

    $issueMsg = "
WLAN Profile Hash Table Lookup is disabled on this device. 
This can cause issues when deleting a WiFi profile, forgetting a WiFi network 
or changing its password. For instance, deleting a WLAN profile with 
""netsh wlan delete profile ProfileName"" can fail with ""Element not found.""

Resolution:
To enable WLAN Profile Hash Table Lookup and resolve this issue, please delete 
following registry entry or change its value to 1: 

`t{0}
`tName : {1}
`tType : REG_DWORD
`tValue: 1

This change will require a restart of the ""WLAN AutoConfig"" service to take 
effect.
"

    if($offline) {
        LogWrite "Cannot run offline, skipping"
        return $RETURNCODE_SKIPPED
    }

    # Look for the issue
    try
    {
        $regKeyPath = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\WlanSvc" 
        $regKeySetting = "EnableProfileHashTableLookup"
        $rItemProperty = Get-ItemProperty -Path "Registry::$regKeyPath" -Name $regKeySetting -ErrorAction SilentlyContinue

        # Issue if EnableProfileHashTableLookup is set to 0
        if(($rItemProperty) -and ($($rItemProperty.$regKeySetting) -eq 0))
        {
            # Issue detected
            $issueMsg = [string]::Format($issueMsg, $regKeyPath, $regKeySetting)
            ReportIssue $issueMsg $ISSUETYPE_ERROR $null $null
        }
    }
	catch {
		LogWrite "Failed - exiting! (Error: $_)"
        return $RETURNCODE_FAILED
    }

    return $RETURNCODE_SUCCESS
}
#endregion net_wlan_KB4557342
#endregion wlan

# end: diagnostic functions

Export-ModuleMember -Function * -Variable *